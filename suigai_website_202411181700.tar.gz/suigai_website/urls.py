from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    ### Common Applications
    path('', include('P0100Login.urls')),
    path('P0100Login/', include('P0100Login.urls')),

    ### File Applications
    path('P0110City/', include('P0110City.urls')),
    path('P0120Ken/', include('P0120Ken.urls')),
    path('P0130Manage/', include('P0130Manage.urls')),
    path('P0140Weather/', include('P0140Weather.urls')),
    path('P0150Truncate/', include('P0150Truncate.urls')),

    ### Excel Applications
    path('P0200Download/', include('P0200Download.urls')),

    ### Online Applications
    path('P0400Online/', include('P0400Online.urls')),

    ### Suigai Map Applications
    path('P0500GUI/', include('P0500GUI.urls')),           ### Kimura added this line on 2024/01/23, to include a new webpage.

    ### EStat Applications
    path('P0700EStat/', include('P0700EStat.urls')),       ### This URL is not planned to be released in the 2024 release.
    
    ###########################################################################
    ### The following web application is not in use and is planned to be removed.
    ### Approval Applications
    ### Reverse Applications
    ###########################################################################
    ### path('P0600Approval/', include('P0600Approval.urls')), ### This URL is not in use, so this line is planned to be removed eventually.
    ### path('P0800Reverse/', include('P0800Reverse.urls')),   ### This URL is not in use, so this line is planned to be removed eventually.
    
    ###########################################################################
    ### The following web application is probably not in use and is planned to be removed after confirmation.
    ### Action Applications
    ###########################################################################
    ### path('P0900Action/', include('P0900Action.urls')),     ### This URL is not in use, so this line is planned to be removed eventually.
    
    ###########################################################################
    ### SECURITY WARNING: Comment out this line in the production environment due to security concerns.
    ###########################################################################
    path('admin/', admin.site.urls),
]
