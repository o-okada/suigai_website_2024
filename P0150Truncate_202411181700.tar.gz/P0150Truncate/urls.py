from django.urls import path
from . import views

app_name = 'P0150Truncate'
urlpatterns = [
    path('', views.index_view, name='index_view'),

    path('truncate/ippan/', views.truncate_ippan_view, name='truncate_ippan_view'),
    path('truncate/chitan/', views.truncate_chitan_view, name='truncate_chitan_view'),
    path('truncate/hojo/', views.truncate_hojo_view, name='truncate_hojo_view'),
    path('truncate/koeki/', views.truncate_koeki_view, name='truncate_koeki_view'),
    path('truncate/weather/', views.truncate_weather_view, name='truncate_weather_view'),
]
