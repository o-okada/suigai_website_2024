from django.apps import AppConfig

class P0150TruncateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'P0150Truncate'
