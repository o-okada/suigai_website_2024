###############################################################################
### ファイル名：P0150Truncate/views.py
### データ消去
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### def custom_decorator(arg1)
### ビュー関数：ブラウザから呼ばれる関数
### def index_view(request)
### 更新履歴：
### 2024/10/13 画面制御用コード（暫定値、確報値）に対応した。
### 2024/11/06 水害区域図DB化をDB化対象外とするように修正した。
###############################################################################

import json
import os
import sys

from datetime import date, datetime
from datetime import timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound
from django.http.response import JsonResponse
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView
from django.views.decorators.csrf import csrf_exempt

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ
from P0000Common.models import PROVISIONED_CONFIRMED   ### 0000: 画面制御用コード（暫定値、確報値）

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

### from P0000Common.models import AREA                ### 7000: アップロードデータ_水害区域 ### 2024/11/06 comment out
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import IPPAN_HISTORY           ### 11000: ヒストリーデータ_一般資産調査票_調査員用
from P0000Common.models import CHITAN_HISTORY          ### 11010: ヒストリーデータ_公共土木施設調査票_地方単独事業
from P0000Common.models import HOJO_HISTORY            ### 11020: ヒストリーデータ_公共土木施設調査票_補助事業
from P0000Common.models import KOEKI_HISTORY           ### 11030: ヒストリーデータ_公益事業等調査票
from P0000Common.models import KUIKI_HISTORY           ### 11040: ヒストリーデータ_水害区域図

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def custom_decorator(arg1):

    def outer_wrapper(view_func):
        
        def inner_wrapper(request, *args, **kwargs):
            try:
                reset_log()
                print_log('[DEBUG] P0150Truncate.custom_decorator()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
                print_log('[DEBUG] P0150Truncate.custom_decorator()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
                print_log('[DEBUG] P0150Truncate.custom_decorator()関数 arg1={}'.format(arg1), 'DEBUG')
                PARAMS_SELECT_USER_PROXY = dict({
                    'USERNAME': str(request.user), 
                    'ROLE_CODE': _ROLE_MANAGE
                })
                SQL_SELECT_USER_PROXY = """
                    SELECT 
                        P1.ID, 
                        A1.USERNAME, 
                        P1.ROLE_CODE, 
                        P1.KEN_CODE, 
                        P1.CITY_CODE 
                    FROM USER_PROXY P1 
                    LEFT JOIN (
                        SELECT 
                            * 
                        FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                    WHERE 
                        A1.USERNAME=%(USERNAME)s AND 
                        P1.ROLE_CODE=%(ROLE_CODE)s"""
                SQL_SELECT_PROVISIONED_CONFIRMED = """
                    SELECT 
                        *
                    FROM PROVISIONED_CONFIRMED"""
                ### decoratorでビュー関数に変数を返す方法が不明のため、グローバル変数を使用した。
                global user_proxy_list
                global provisioned_confirmed_list
                user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
                provisioned_confirmed_list = PROVISIONED_CONFIRMED.objects.raw(SQL_SELECT_PROVISIONED_CONFIRMED)
        
                print_log('[DEBUG] P0150Truncate.custom_decorator()関数 user_proxy_list={}'.format(user_proxy_list), 'DEBUG')
                print_log('[DEBUG] P0150Truncate.custom_decorator()関数 len(user_proxy_list)={}'.format(len(user_proxy_list)), 'DEBUG')
                print_log('[DEBUG] P0150Truncate.custom_decorator()関数 provisioned_confirmed_list={}'.format(provisioned_confirmed_list), 'DEBUG')
                print_log('[DEBUG] P0150Truncate.custom_decorator()関数 len(provisioned_confirmed_list)={}'.format(len(provisioned_confirmed_list)), 'DEBUG')
                    
                ### デコレータの処理で警告が発生したら（user_proxy_listが正常に取得できなかったら）、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                if (user_proxy_list == False):
                    print_log('[WARN] P0150Truncate.custom_decorator()関数が警告終了しました。', 'WARN')
                    if (arg1 == 'index_view') or (
                        arg1 == 'truncate_ippan_view') or (
                        arg1 == 'truncate_chitan_view') or (
                        arg1 == 'truncate_hojo_view') or (
                        arg1 == 'truncate_koeki_view') or (
                        arg1 == 'truncate_weather_view'):
                        template = loader.get_template('P0150Truncate/index.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    else:
                        pass
                
                ### ここまで正常に処理できたら、ビュー関数を戻して、ビュー関数の処理に移行する。
                return view_func(request, *args, **kwargs)
            
            except:
                ### デコレータの処理で異常が発生したら、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                print_log('[WARN] P0150Truncate.custom_decorator()関数が異常終了しました。', 'WARN')
                if (arg1 == 'index_view') or (
                    arg1 == 'truncate_ippan_view') or (
                    arg1 == 'truncate_chitan_view') or (
                    arg1 == 'truncate_hojo_view') or (
                    arg1 == 'truncate_koeki_view') or (
                    arg1 == 'truncate_weather_view'):
                    template = loader.get_template('P0150Truncate/index.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                else:
                    pass
        
        return inner_wrapper
            
    return outer_wrapper

###############################################################################
### 
###############################################################################
def get_count_from_table():
    try:
        cursor = connection.cursor()

        cursor.execute("""SELECT COUNT(1) FROM IPPAN_HEADER""")
        ippan_header_list = cursor.fetchall()

        cursor.execute("""SELECT COUNT(1) FROM IPPAN""")
        ippan_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM IPPAN_SUMMARY""")
        ippan_summary_list = cursor.fetchall()

        cursor.execute("""SELECT COUNT(1) FROM IPPAN_HISTORY""")
        ippan_history_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM IPPAN_TRIGGER""")
        ippan_trigger_list = cursor.fetchall()

        
        cursor.execute("""SELECT COUNT(1) FROM CHITAN_HEADER""")
        chitan_header_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM CHITAN""")
        chitan_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM CHITAN_SUMMARY""")
        chitan_summary_list = cursor.fetchall()

        cursor.execute("""SELECT COUNT(1) FROM CHITAN_HISTORY""")
        chitan_history_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM CHITAN_TRIGGER""")
        chitan_trigger_list = cursor.fetchall()

        
        cursor.execute("""SELECT COUNT(1) FROM HOJO_HEADER""")
        hojo_header_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM HOJO""")
        hojo_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM HOJO_SUMMARY""")
        hojo_summary_list = cursor.fetchall()

        cursor.execute("""SELECT COUNT(1) FROM HOJO_HISTORY""")
        hojo_history_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM HOJO_TRIGGER""")
        hojo_trigger_list = cursor.fetchall()

        
        cursor.execute("""SELECT COUNT(1) FROM KOEKI_HEADER""")
        koeki_header_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM KOEKI""")
        koeki_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM KOEKI_SUMMARY""")
        koeki_summary_list = cursor.fetchall()

        cursor.execute("""SELECT COUNT(1) FROM KOEKI_HISTORY""")
        koeki_history_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM KOEKI_TRIGGER""")
        koeki_trigger_list = cursor.fetchall()
        
        cursor.execute("""SELECT COUNT(1) FROM WEATHER""")
        weather_list = cursor.fetchall()

        return [True,
               ippan_header_list, ippan_list, ippan_summary_list, ippan_history_list, ippan_trigger_list,
               chitan_header_list, chitan_list, chitan_summary_list, chitan_history_list, chitan_trigger_list,
               hojo_header_list, hojo_list, hojo_summary_list, hojo_history_list, hojo_trigger_list,
               koeki_header_list, koeki_list, koeki_summary_list, koeki_history_list, koeki_trigger_list,
               weather_list]
    
    except:
        return False

    finally:
        cursor.close()

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### データ消去【済】
### urlpattern：path('/', views.index_view, name='index_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='index_view')
def index_view(request):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.index_view()関数 STEP 1/3.', 'DEBUG')
        cursor = connection.cursor()
        try:
            cursor.execute("""SELECT COUNT(1) FROM IPPAN_HEADER""")
            ippan_header_list = cursor.fetchall()
    
            cursor.execute("""SELECT COUNT(1) FROM IPPAN""")
            ippan_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM IPPAN_SUMMARY""")
            ippan_summary_list = cursor.fetchall()

            cursor.execute("""SELECT COUNT(1) FROM IPPAN_HISTORY""")
            ippan_history_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM IPPAN_TRIGGER""")
            ippan_trigger_list = cursor.fetchall()

            
            cursor.execute("""SELECT COUNT(1) FROM CHITAN_HEADER""")
            chitan_header_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM CHITAN""")
            chitan_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM CHITAN_SUMMARY""")
            chitan_summary_list = cursor.fetchall()

            cursor.execute("""SELECT COUNT(1) FROM CHITAN_HISTORY""")
            chitan_history_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM CHITAN_TRIGGER""")
            chitan_trigger_list = cursor.fetchall()

            
            cursor.execute("""SELECT COUNT(1) FROM HOJO_HEADER""")
            hojo_header_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM HOJO""")
            hojo_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM HOJO_SUMMARY""")
            hojo_summary_list = cursor.fetchall()

            cursor.execute("""SELECT COUNT(1) FROM HOJO_HISTORY""")
            hojo_history_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM HOJO_TRIGGER""")
            hojo_trigger_list = cursor.fetchall()

            
            cursor.execute("""SELECT COUNT(1) FROM KOEKI_HEADER""")
            koeki_header_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM KOEKI""")
            koeki_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM KOEKI_SUMMARY""")
            koeki_summary_list = cursor.fetchall()

            cursor.execute("""SELECT COUNT(1) FROM KOEKI_HISTORY""")
            koeki_history_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM KOEKI_TRIGGER""")
            koeki_trigger_list = cursor.fetchall()
            
            cursor.execute("""SELECT COUNT(1) FROM WEATHER""")
            weather_list = cursor.fetchall()

        finally:
            cursor.close()

        print_log('[DEBUG] P0150Truncate.index_view()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(ippan_header_list)={}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 ippan_list={}'.format(ippan_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(ippan_list)={}'.format(len(ippan_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 ippan_summary_list={}'.format(ippan_summary_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(ippan_summary_list)={}'.format(len(ippan_summary_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 ippan_history_list={}'.format(ippan_history_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(ippan_history_list)={}'.format(len(ippan_history_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 ippan_trigger_list={}'.format(ippan_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(ippan_trigger_list)={}'.format(len(ippan_trigger_list)), 'DEBUG')
        
        print_log('[DEBUG] P0150Truncate.index_view()関数 chitan_header_list={}'.format(chitan_header_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(chitan_header_list)={}'.format(len(chitan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 chitan_list={}'.format(chitan_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(chitan_list)={}'.format(len(chitan_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 chitan_summary_list={}'.format(chitan_summary_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(chitan_summary_list)={}'.format(len(chitan_summary_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 chitan_history_list={}'.format(chitan_history_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(chitan_history_list)={}'.format(len(chitan_history_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 chitan_trigger_list={}'.format(chitan_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(chitan_trigger_list)={}'.format(len(chitan_trigger_list)), 'DEBUG')

        print_log('[DEBUG] P0150Truncate.index_view()関数 hojo_header_list={}'.format(hojo_header_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(hojo_header_list)={}'.format(len(hojo_header_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 hojo_list={}'.format(hojo_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(hojo_list)={}'.format(len(hojo_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 hojo_summary_list={}'.format(hojo_summary_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(hojo_summary_list)={}'.format(len(hojo_summary_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 hojo_history_list={}'.format(hojo_history_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(hojo_history_list)={}'.format(len(hojo_history_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 hojo_trigger_list={}'.format(hojo_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(hojo_trigger_list)={}'.format(len(hojo_trigger_list)), 'DEBUG')

        print_log('[DEBUG] P0150Truncate.index_view()関数 koeki_header_list={}'.format(koeki_header_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(koeki_header_list)={}'.format(len(koeki_header_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 koeki_list={}'.format(koeki_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(koeki_list)={}'.format(len(koeki_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 koeki_summary_list={}'.format(koeki_summary_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(koeki_summary_list)={}'.format(len(koeki_summary_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 koeki_history_list={}'.format(koeki_history_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(koeki_history_list)={}'.format(len(koeki_history_list)), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 koeki_trigger_list={}'.format(koeki_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(koeki_trigger_list)={}'.format(len(koeki_trigger_list)), 'DEBUG')

        print_log('[DEBUG] P0150Truncate.index_view()関数 weather_list={}'.format(weather_list), 'DEBUG')
        print_log('[DEBUG] P0150Truncate.index_view()関数 len(weather_list)={}'.format(len(weather_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.index_view()関数 STEP 2/3.', 'DEBUG')
        if (ippan_header_list == False) or (ippan_list == False) or (ippan_summary_list == False) or (ippan_history_list == False) or (ippan_trigger_list == False) or (
            chitan_header_list == False) or (chitan_list == False) or (chitan_summary_list == False) or (chitan_history_list == False) or (chitan_trigger_list == False) or (
            hojo_header_list == False) or (hojo_list == False) or (hojo_summary_list == False) or (hojo_history_list == False) or (hojo_trigger_list == False) or (
            koeki_header_list == False) or (koeki_list == False) or (koeki_summary_list == False) or (koeki_history_list == False) or (koeki_trigger_list == False) or (
            weather_list == False):
            print_log('[WARN] P0150Truncate.index_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0150Truncate/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.index_view()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0150Truncate.index_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed, 
            'ippan_header_count': ippan_header_list[0][0],
            'ippan_count': ippan_list[0][0],
            'ippan_summary_count': ippan_summary_list[0][0],
            'ippan_history_count': ippan_history_list[0][0],
            'ippan_trigger_count': ippan_trigger_list[0][0],
            
            'chitan_header_count': chitan_header_list[0][0],
            'chitan_count': chitan_list[0][0],
            'chitan_summary_count': chitan_summary_list[0][0],
            'chitan_history_count': chitan_history_list[0][0],
            'chitan_trigger_count': chitan_trigger_list[0][0],
            
            'hojo_header_count': hojo_header_list[0][0],
            'hojo_count': hojo_list[0][0],
            'hojo_summary_count': hojo_summary_list[0][0],
            'hojo_history_count': hojo_history_list[0][0],
            'hojo_trigger_count': hojo_trigger_list[0][0],
            
            'koeki_header_count': koeki_header_list[0][0],
            'koeki_count': koeki_list[0][0],
            'koeki_summary_count': koeki_summary_list[0][0],
            'koeki_history_count': koeki_history_list[0][0],
            'koeki_trigger_count': koeki_trigger_list[0][0],
            
            'weather_count': weather_list[0][0],
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0150Truncate.index_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0150Truncate.index_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0150Truncate.index_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### 一般資産データ消去
### urlpattern：path('truncate/ippan/', views.truncate_ippan_view, name='truncate_ippan_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='truncate_ippan_view')
def truncate_ippan_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_ippan_view()関数 STEP 1_1/4.', 'DEBUG')
        if request.method != 'POST':
            print_log('[WARN] P0150Truncate.truncate_ippan_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0150Truncate/index.html')
            context = {
                'alert_log': get_alert_log(),
            }
            return HttpResponse(template.render(context, request))
        
        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_ippan_view()関数 STEP 2/4.', 'DEBUG')
        cursor = connection.cursor()
        try:
            cursor.execute("""BEGIN""")
            
            cursor.execute("""TRUNCATE TABLE IPPAN_HEADER""")
            cursor.execute("""TRUNCATE TABLE IPPAN""")
            cursor.execute("""TRUNCATE TABLE IPPAN_SUMMARY""")
            cursor.execute("""TRUNCATE TABLE IPPAN_HISTORY""")
            cursor.execute("""TRUNCATE TABLE IPPAN_TRIGGER""")
            
            cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0150Truncate.truncate_ippan_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0150Truncate.truncate_ippan_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            cursor.execute("""ROLLBACK""")
            
        finally:
            cursor.close()

        #######################################################################
        ### 関数コール処理(0030)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_ippan_view()関数 STEP 3/4.', 'DEBUG')
        [bool_return,
        ippan_header_list, ippan_list, ippan_summary_list, ippan_history_list, ippan_trigger_list,
        chitan_header_list, chitan_list, chitan_summary_list, chitan_history_list, chitan_trigger_list,
        hojo_header_list, hojo_list, hojo_summary_list, hojo_history_list, hojo_trigger_list,
        koeki_header_list, koeki_list, koeki_summary_list, koeki_history_list, koeki_trigger_list,
        weather_list] = get_count_from_table()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_ippan_view()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] P0150Truncate.truncate_ippan_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'truncate_ippan_info': 'truncate_ippan_info',
            'ippan_header_count': ippan_header_list[0][0],
            'ippan_count': ippan_list[0][0],
            'ippan_summary_count': ippan_summary_list[0][0],
            'ippan_history_count': ippan_history_list[0][0],
            'ippan_trigger_count': ippan_trigger_list[0][0],
            
            'chitan_header_count': chitan_header_list[0][0],
            'chitan_count': chitan_list[0][0],
            'chitan_summary_count': chitan_summary_list[0][0],
            'chitan_history_count': chitan_history_list[0][0],
            'chitan_trigger_count': chitan_trigger_list[0][0],
            
            'hojo_header_count': hojo_header_list[0][0],
            'hojo_count': hojo_list[0][0],
            'hojo_summary_count': hojo_summary_list[0][0],
            'hojo_history_count': hojo_history_list[0][0],
            'hojo_trigger_count': hojo_trigger_list[0][0],
            
            'koeki_header_count': koeki_header_list[0][0],
            'koeki_count': koeki_list[0][0],
            'koeki_summary_count': koeki_summary_list[0][0],
            'koeki_history_count': koeki_history_list[0][0],
            'koeki_trigger_count': koeki_trigger_list[0][0],
            
            'weather_count': weather_list[0][0],
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0150Truncate.truncate_ippan_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_ippan_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_ippan_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'alert_log': get_alert_log(),
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### 公共土木施設_地方単独事業データ消去
### urlpattern：path('truncate/chitan/', views.truncate_chitan_view, name='truncate_chitan_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='truncate_chitan_view')
def truncate_chitan_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_chitan_view()関数 STEP 1_1/4.', 'DEBUG')
        if request.method != 'POST':
            print_log('[WARN] P0150Truncate.truncate_chitan_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0150Truncate/index.html')
            context = {
                'alert_log': get_alert_log(),
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_chitan_view()関数 STEP 2/4.', 'DEBUG')
        cursor = connection.cursor()
        try:
            cursor.execute("""BEGIN""")
            
            cursor.execute("""TRUNCATE TABLE CHITAN_HEADER""")
            cursor.execute("""TRUNCATE TABLE CHITAN""")
            cursor.execute("""TRUNCATE TABLE CHITAN_SUMMARY""")
            cursor.execute("""TRUNCATE TABLE CHITAN_HISTORY""")
            cursor.execute("""TRUNCATE TABLE CHITAN_TRIGGER""")
            
            cursor.execute("""COMMIT""")

        except:
            print_log('[ERROR] P0150Truncate.truncate_chitan_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0150Truncate.truncate_chitan_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            cursor.execute("""ROLLBACK""")
            
        finally:
            cursor.close()

        #######################################################################
        ### 関数コール処理(0030)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_chitan_view()関数 STEP 3/4.', 'DEBUG')
        [bool_return,
        ippan_header_list, ippan_list, ippan_summary_list, ippan_history_list, ippan_trigger_list,
        chitan_header_list, chitan_list, chitan_summary_list, chitan_history_list, chitan_trigger_list,
        hojo_header_list, hojo_list, hojo_summary_list, hojo_history_list, hojo_trigger_list,
        koeki_header_list, koeki_list, koeki_summary_list, koeki_history_list, koeki_trigger_list,
        weather_list] = get_count_from_table()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_chitan_view()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] P0150Truncate.truncate_chitan_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'truncate_chitan_info': 'truncate_chitan_info',
            'ippan_header_count': ippan_header_list[0][0],
            'ippan_count': ippan_list[0][0],
            'ippan_summary_count': ippan_summary_list[0][0],
            'ippan_history_count': ippan_history_list[0][0],
            'ippan_trigger_count': ippan_trigger_list[0][0],
            
            'chitan_header_count': chitan_header_list[0][0],
            'chitan_count': chitan_list[0][0],
            'chitan_summary_count': chitan_summary_list[0][0],
            'chitan_history_count': chitan_history_list[0][0],
            'chitan_trigger_count': chitan_trigger_list[0][0],
            
            'hojo_header_count': hojo_header_list[0][0],
            'hojo_count': hojo_list[0][0],
            'hojo_summary_count': hojo_summary_list[0][0],
            'hojo_history_count': hojo_history_list[0][0],
            'hojo_trigger_count': hojo_trigger_list[0][0],
            
            'koeki_header_count': koeki_header_list[0][0],
            'koeki_count': koeki_list[0][0],
            'koeki_summary_count': koeki_summary_list[0][0],
            'koeki_history_count': koeki_history_list[0][0],
            'koeki_trigger_count': koeki_trigger_list[0][0],
            
            'weather_count': weather_list[0][0],
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0150Truncate.truncate_chitan_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_chitan_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_chitan_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'alert_log': get_alert_log(),
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### 公共土木施設_補助事業データ消去
### urlpattern：path('truncate/hojo/', views.truncate_hojo_view, name='truncate_hojo_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='truncate_hojo_view')
def truncate_hojo_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_hojo_view()関数 STEP 1_1/4.', 'DEBUG')
        if request.method != 'POST':
            print_log('[WARN] P0150Truncate.truncate_hojo_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0150Truncate/index.html')
            context = {
                'alert_log': get_alert_log(),
            }
            return HttpResponse(template.render(context, request))
        
        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_hojo_view()関数 STEP 2/4.', 'DEBUG')
        cursor = connection.cursor()
        try:
            cursor.execute("""BEGIN""")
            
            cursor.execute("""TRUNCATE TABLE HOJO_HEADER""")
            cursor.execute("""TRUNCATE TABLE HOJO""")
            cursor.execute("""TRUNCATE TABLE HOJO_SUMMARY""")
            cursor.execute("""TRUNCATE TABLE HOJO_HISTORY""")
            cursor.execute("""TRUNCATE TABLE HOJO_TRIGGER""")
            
            cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0150Truncate.truncate_hojo_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0150Truncate.truncate_hojo_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            cursor.execute("""ROLLBACK""")
            
        finally:
            cursor.close()

        #######################################################################
        ### 関数コール処理(0030)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_hojo_view()関数 STEP 3/4.', 'DEBUG')
        [bool_return,
        ippan_header_list, ippan_list, ippan_summary_list, ippan_history_list, ippan_trigger_list,
        chitan_header_list, chitan_list, chitan_summary_list, chitan_history_list, chitan_trigger_list,
        hojo_header_list, hojo_list, hojo_summary_list, hojo_history_list, hojo_trigger_list,
        koeki_header_list, koeki_list, koeki_summary_list, koeki_history_list, koeki_trigger_list,
        weather_list] = get_count_from_table()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_hojo_view()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] P0150Truncate.truncate_hojo_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'truncate_hojo_info': 'truncate_hojo_info',
            'ippan_header_count': ippan_header_list[0][0],
            'ippan_count': ippan_list[0][0],
            'ippan_summary_count': ippan_summary_list[0][0],
            'ippan_history_count': ippan_history_list[0][0],
            'ippan_trigger_count': ippan_trigger_list[0][0],
            
            'chitan_header_count': chitan_header_list[0][0],
            'chitan_count': chitan_list[0][0],
            'chitan_summary_count': chitan_summary_list[0][0],
            'chitan_history_count': chitan_history_list[0][0],
            'chitan_trigger_count': chitan_trigger_list[0][0],
            
            'hojo_header_count': hojo_header_list[0][0],
            'hojo_count': hojo_list[0][0],
            'hojo_summary_count': hojo_summary_list[0][0],
            'hojo_history_count': hojo_history_list[0][0],
            'hojo_trigger_count': hojo_trigger_list[0][0],
            
            'koeki_header_count': koeki_header_list[0][0],
            'koeki_count': koeki_list[0][0],
            'koeki_summary_count': koeki_summary_list[0][0],
            'koeki_history_count': koeki_history_list[0][0],
            'koeki_trigger_count': koeki_trigger_list[0][0],
            
            'weather_count': weather_list[0][0],
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0150Truncate.truncate_hojo_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_hojo_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_hojo_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'alert_log': get_alert_log(),
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### 公益事業等データ消去
### urlpattern：path('truncate/koeki/', views.truncate_koeki_view, name='truncate_koeki_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='truncate_koeki_view')
def truncate_koeki_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_koeki_view()関数 STEP 1_1/4.', 'DEBUG')
        if request.method != 'POST':
            print_log('[WARN] P0150Truncate.truncate_koeki_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0150Truncate/index.html')
            context = {
                'alert_log': get_alert_log(),
            }
            return HttpResponse(template.render(context, request))
        
        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_koeki_view()関数 STEP 2/4.', 'DEBUG')
        cursor = connection.cursor()
        try:
            cursor.execute("""BEGIN""")
            
            cursor.execute("""TRUNCATE TABLE KOEKI_HEADER""")
            cursor.execute("""TRUNCATE TABLE KOEKI""")
            cursor.execute("""TRUNCATE TABLE KOEKI_SUMMARY""")
            cursor.execute("""TRUNCATE TABLE KOEKI_HISTORY""")
            cursor.execute("""TRUNCATE TABLE KOEKI_TRIGGER""")
            
            cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0150Truncate.truncate_koeki_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0150Truncate.truncate_koeki_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            cursor.execute("""ROLLBACK""")
            
        finally:
            cursor.close()

        #######################################################################
        ### 関数コール処理(0030)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_koeki_view()関数 STEP 3/4.', 'DEBUG')
        [bool_return,
        ippan_header_list, ippan_list, ippan_summary_list, ippan_history_list, ippan_trigger_list,
        chitan_header_list, chitan_list, chitan_summary_list, chitan_history_list, chitan_trigger_list,
        hojo_header_list, hojo_list, hojo_summary_list, hojo_history_list, hojo_trigger_list,
        koeki_header_list, koeki_list, koeki_summary_list, koeki_history_list, koeki_trigger_list,
        weather_list] = get_count_from_table()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_koeki_view()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] P0150Truncate.truncate_koeki_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'truncate_koeki_info': 'truncate_koeki_info',
            'ippan_header_count': ippan_header_list[0][0],
            'ippan_count': ippan_list[0][0],
            'ippan_summary_count': ippan_summary_list[0][0],
            'ippan_history_count': ippan_history_list[0][0],
            'ippan_trigger_count': ippan_trigger_list[0][0],
            
            'chitan_header_count': chitan_header_list[0][0],
            'chitan_count': chitan_list[0][0],
            'chitan_summary_count': chitan_summary_list[0][0],
            'chitan_history_count': chitan_history_list[0][0],
            'chitan_trigger_count': chitan_trigger_list[0][0],
            
            'hojo_header_count': hojo_header_list[0][0],
            'hojo_count': hojo_list[0][0],
            'hojo_summary_count': hojo_summary_list[0][0],
            'hojo_history_count': hojo_history_list[0][0],
            'hojo_trigger_count': hojo_trigger_list[0][0],
            
            'koeki_header_count': koeki_header_list[0][0],
            'koeki_count': koeki_list[0][0],
            'koeki_summary_count': koeki_summary_list[0][0],
            'koeki_history_count': koeki_history_list[0][0],
            'koeki_trigger_count': koeki_trigger_list[0][0],
            
            'weather_count': weather_list[0][0],
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0150Truncate.truncate_koeki_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_koeki_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_koeki_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'alert_log': get_alert_log(),
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### 水害区域データ消去
### urlpattern：path('truncate/kuiki/', views.truncate_kuiki_view, name='truncate_kuiki_view')
###############################################################################
### @login_required(None, login_url='/P0100Login/')
### @custom_decorator(arg1='truncate_kuiki_view')
### def truncate_kuiki_view(request):
###     try:
###         #######################################################################
###         ### 引数チェック処理(0010)
###         #######################################################################
###         print_log('[DEBUG] P0150Truncate.truncate_kuiki_view()関数 STEP 1_1/4.', 'DEBUG')
###         if request.method != 'POST':
###             print_log('[WARN] P0150Truncate.truncate_kuiki_view()関数が警告終了しました。', 'WARN')
###             template = loader.get_template('P0150Truncate/index.html')
###             context = {
###                 'alert_log': get_alert_log(),
###             }
###             return HttpResponse(template.render(context, request))
###         #######################################################################
###         ### DBアクセス処理(0020)
###         #######################################################################
###         print_log('[DEBUG] P0150Truncate.truncate_kuiki_view()関数 STEP 2/4.', 'DEBUG')
###         cursor = connection.cursor()
###         try:
###             cursor.execute("""BEGIN""")
###             cursor.execute("""TRUNCATE TABLE KUIKI""")
###             cursor.execute("""TRUNCATE TABLE KUIKI_HISTORY""")
###             cursor.execute("""COMMIT""")
###         except:
###             print_log('[ERROR] P0150Truncate.truncate_kuiki_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
###             print_log('[ERROR] P0150Truncate.truncate_kuiki_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
###             cursor.execute("""ROLLBACK""")
###         finally:
###             cursor.close()
###         #######################################################################
###         ### 関数コール処理(0030)
###         #######################################################################
###         print_log('[DEBUG] P0150Truncate.truncate_kuiki_view()関数 STEP 3/4.', 'DEBUG')
###         [bool_return,
###         ippan_header_list, ippan_list, ippan_summary_list, ippan_history_list, ippan_trigger_list,
###         chitan_header_list, chitan_list, chitan_summary_list, chitan_history_list, chitan_trigger_list,
###         hojo_header_list, hojo_list, hojo_summary_list, hojo_history_list, hojo_trigger_list,
###         koeki_header_list, koeki_list, koeki_summary_list, koeki_history_list, koeki_trigger_list,
###         weather_list] = get_count_from_table()
###         if bool_return == False:
###             raise Exception
###         #######################################################################
###         ### 【正常】レスポンスセット処理(0040)
###         #######################################################################
###         print_log('[DEBUG] P0150Truncate.truncate_kuiki_view()関数 STEP 4/4.', 'DEBUG')
###         print_log('[INFO] P0150Truncate.truncate_kuiki_view()関数が正常終了しました。', 'INFO')
###         template = loader.get_template('P0150Truncate/index.html')
###         context = {
###             'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
###             'truncate_area_info': 'truncate_area_info',
###             'ippan_header_count': ippan_header_list[0][0],
###             'ippan_count': ippan_list[0][0],
###             'ippan_summary_count': ippan_summary_list[0][0],
###             'ippan_history_count': ippan_history_list[0][0],
###             'ippan_trigger_count': ippan_trigger_list[0][0],
###             'chitan_header_count': chitan_header_list[0][0],
###             'chitan_count': chitan_list[0][0],
###             'chitan_summary_count': chitan_summary_list[0][0],
###             'chitan_history_count': chitan_history_list[0][0],
###             'chitan_trigger_count': chitan_trigger_list[0][0],
###             'hojo_header_count': hojo_header_list[0][0],
###             'hojo_count': hojo_list[0][0],
###             'hojo_summary_count': hojo_summary_list[0][0],
###             'hojo_history_count': hojo_history_list[0][0],
###             'hojo_trigger_count': hojo_trigger_list[0][0],
###             'koeki_header_count': koeki_header_list[0][0],
###             'koeki_count': koeki_list[0][0],
###             'koeki_summary_count': koeki_summary_list[0][0],
###             'koeki_history_count': koeki_history_list[0][0],
###             'koeki_trigger_count': koeki_trigger_list[0][0],
###             'weather_count': weather_list[0][0],
###         }
###         return HttpResponse(template.render(context, request))
###     except:
###         print_log('[ERROR] P0150Truncate.truncate_kuiki_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
###         print_log('[ERROR] P0150Truncate.truncate_kuiki_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
###         print_log('[ERROR] P0150Truncate.truncate_kuiki_view()関数が異常終了しました。', 'ERROR')
###         template = loader.get_template('P0150Truncate/index.html')
###         context = {
###             'alert_log': get_alert_log(),
###         }
###         return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### 異常気象データ消去
### urlpattern：path('truncate/weather/', views.truncate_weather_view, name='truncate_weather_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='truncate_weather_view')
def truncate_weather_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_weather_view()関数 STEP 1_1/4.', 'DEBUG')
        if request.method != 'POST':
            print_log('[WARN] P0150Truncate.truncate_weather_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0150Truncate/index.html')
            context = {
                'alert_log': get_alert_log(),
            }
            return HttpResponse(template.render(context, request))
        
        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_weather_view()関数 STEP 2/4.', 'DEBUG')
        cursor = connection.cursor()
        try:
            cursor.execute("""BEGIN""")
            
            cursor.execute("""TRUNCATE TABLE WEATHER""")
            
            cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0150Truncate.truncate_weather_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0150Truncate.truncate_weather_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            cursor.execute("""ROLLBACK""")
            
        finally:
            cursor.close()

        #######################################################################
        ### 関数コール処理(0030)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_weather_view()関数 STEP 3/4.', 'DEBUG')
        [bool_return,
        ippan_header_list, ippan_list, ippan_summary_list, ippan_history_list, ippan_trigger_list,
        chitan_header_list, chitan_list, chitan_summary_list, chitan_history_list, chitan_trigger_list,
        hojo_header_list, hojo_list, hojo_summary_list, hojo_history_list, hojo_trigger_list,
        koeki_header_list, koeki_list, koeki_summary_list, koeki_history_list, koeki_trigger_list,
        weather_list] = get_count_from_table()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0150Truncate.truncate_weather_view()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] P0150Truncate.truncate_weather_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'truncate_weather_info': 'truncate_weather_info',
            'ippan_header_count': ippan_header_list[0][0],
            'ippan_count': ippan_list[0][0],
            'ippan_summary_count': ippan_summary_list[0][0],
            'ippan_history_count': ippan_history_list[0][0],
            'ippan_trigger_count': ippan_trigger_list[0][0],
            
            'chitan_header_count': chitan_header_list[0][0],
            'chitan_count': chitan_list[0][0],
            'chitan_summary_count': chitan_summary_list[0][0],
            'chitan_history_count': chitan_history_list[0][0],
            'chitan_trigger_count': chitan_trigger_list[0][0],
            
            'hojo_header_count': hojo_header_list[0][0],
            'hojo_count': hojo_list[0][0],
            'hojo_summary_count': hojo_summary_list[0][0],
            'hojo_history_count': hojo_history_list[0][0],
            'hojo_trigger_count': hojo_trigger_list[0][0],
            
            'koeki_header_count': koeki_header_list[0][0],
            'koeki_count': koeki_list[0][0],
            'koeki_summary_count': koeki_summary_list[0][0],
            'koeki_history_count': koeki_history_list[0][0],
            'koeki_trigger_count': koeki_trigger_list[0][0],
            
            'weather_count': weather_list[0][0],
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0150Truncate.truncate_weather_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_weather_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0150Truncate.truncate_weather_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0150Truncate/index.html')
        context = {
            'alert_log': get_alert_log(),
        }
        return HttpResponse(template.render(context, request))
