from django import forms

class WeatherSaveForm(forms.Form):
    weather_id = forms.CharField()
    weather_name = forms.CharField()
    begin_date = forms.CharField()
    end_date = forms.CharField()
    ken_code = forms.CharField(required=False)
    committed_at = forms.CharField(required=False)
    deleted_at = forms.CharField(required=False)

class WeatherDeleteForm(forms.Form):
    weather_id = forms.CharField()
    weather_name = forms.CharField()
    begin_date = forms.CharField()
    end_date = forms.CharField()
    ken_code = forms.CharField(required=False)
    committed_at = forms.CharField(required=False)
    deleted_at = forms.CharField(required=False)
