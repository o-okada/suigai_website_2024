from django.urls import path
from . import views

app_name = 'P0140Weather'
urlpatterns = [
    path('', views.index_view, name='index_view'),
    
    path('save/', views.save_view, name='save_view'),
    path('delete/', views.delete_view, name='delete_view'),
]
