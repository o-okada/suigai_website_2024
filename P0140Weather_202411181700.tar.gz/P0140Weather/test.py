import json
import requests

from django.test import TestCase

url = "http://172.17.67.242:8000/P0140Weather/add/"
sess = requests.session()

print(sess.get(url))

csrftoken = sess.cookies['csrftoken']
headers = {'Content-type': 'application/json', 'X-CSRFToken': csrftoken}

data = {'WEATHER_NAME': 'WEATHER_NAME_TEST'}

params = json.dumps(data)

res = sess.post(url, data=params, headers=headers)

print(json.loads(res.text))
