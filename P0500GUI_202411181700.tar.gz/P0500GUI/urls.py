from django.urls import path
from . import views

app_name = 'P0500GUI'

urlpatterns = [
    ### 「水害区域図作成画面」 初期表示 editor.html
    path('editor/', views.editor_view, name='editor_view'),                                  ### 「水害区域図様式出力画面」で「水害区域図作成画面へ戻るボタン」クリック時に呼ばれる。

    ### 「水害区域図様式出力画面」 初期表示 printout.html
    path('printout/', views.printout_view, name='printout_view'),                            ### 「水害区域図作成画面」で「貼付用紙作成・様式出力ボタン」クリック時に呼ばれる。

    ### 「水害区域図作成画面」 参照表示 editor.html
    ### path('editor/<slug:kuiki_id>/', views.kuiki_id_view, name='kuiki_id_view'),          ### 「ブラウザ画面」で「水害区域図編集ボタンまたはリンク」クリック時に呼ばれる。### 2024/11/10 comment out
    
    ### 「水害区域図作成画面」 アクションハンドラ editor.html
    path('editor/upload_temp_kml/', views.upload_temp_kml, name='upload_temp_kml'),          ### 「水害区域図作成画面」で「一時保存ファイルの読込ボタン」クリック時に呼ばれる。

    ### 「水害区域図様式出力画面」 アクションハンドラ printout.html New
    path('printout/upload_canvas/', views.upload_canvas, name='upload_canvas'),              ### 「水害区域図様式出力画面」で「様式および作図情報の出力ボタン」クリック時に呼ばれる。（第１ステップ）
    path('printout/upload_png/' , views.upload_png, name='upload_png'),                      ### 「水害区域図様式出力画面」で「様式および作図情報の出力ボタン」クリック時に呼ばれる。（第２ステップ）
    path('printout/download_kml/<slug:kuiki_id>/', views.download_kml, name='download_kml'), ### 「水害区域図様式出力画面」で「KMLダウンロードボタン」クリック時に呼ばれる。
    path('printout/download_pdf/<slug:kuiki_id>/', views.download_pdf, name='download_pdf'), ### 「水害区域図様式出力画面」で「PDFダウンロードボタン」クリック時に呼ばれる。
]
