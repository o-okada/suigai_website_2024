from django import forms
### from .models import KUIKI
from P0000Common.models import KUIKI

### class UploadKmlForm(forms.Form):
###     file = forms.FileField(widget=forms.FileInput(attrs={'accept':'application/kml'}))
### class UploadPdfForm(forms.Form):
###     file = forms.FileField(widget=forms.FileInput(attrs={'accept':'application/pdf'}))

### 水害区域フォーム
### class globalPostForm(forms.ModelForm):
###     gZoom = forms.IntegerField(required=False, widget=forms.HiddenInput())                          ### 倍率
###     gPrintSize = forms.CharField(max_length=2, required=False, widget=forms.HiddenInput())          ### 印刷サイズ(A3, A4)
###     gOrientation = forms.IntegerField(required=False, widget=forms.HiddenInput())                   ### ページの縦横(0=縦,1=横)
###     Id = forms.IntegerField(required=False, widget=forms.HiddenInput())                             ### ID 連番
###     gPrefecturalCode = forms.CharField(required=False, widget=forms.HiddenInput())                  ### 都道府県コード
###     gMunicipalityCode = forms.CharField(max_length=3, required=False, widget=forms.HiddenInput())   ### 市町村コード
###     gArea1 = forms.CharField(max_length=3, required=False, widget=forms.HiddenInput())              ### 水害区域番号1
###     gArea2 = forms.CharField(max_length=3, required=False, widget=forms.HiddenInput())              ### 水害区域番号2
###     gPrefecturalName = forms.CharField(max_length=6, required=False, widget=forms.HiddenInput())    ### 都道府県名
###     gMunicipalityName = forms.CharField(max_length=6, required=False, widget=forms.HiddenInput())   ### 市区町村名
###     gScale = forms.IntegerField(required=False, widget=forms.HiddenInput(), initial=0)              ### 縮尺
###     gBranchSub = forms.CharField(max_length=7, required=False, widget=forms.HiddenInput())          ### 枝番1
###     gBranchAll = forms.CharField(max_length=7, required=False, widget=forms.HiddenInput())          ### 枝番2
###     gYear1 = forms.IntegerField(required=False, widget=forms.HiddenInput())                         ### 水害区域発生年月日(年)1
###     gMonth1 = forms.IntegerField(required=False, widget=forms.HiddenInput())                        ### 水害区域発生年月日(月)1
###     gDay1 = forms.IntegerField(required=False, widget=forms.HiddenInput())                          ### 水害区域発生年月日(日)1
###     gYear2 = forms.IntegerField(required=False, widget=forms.HiddenInput())                         ### 水害区域発生年月日(年)2
###     gMonth2 = forms.IntegerField(required=False, widget=forms.HiddenInput())                        ### 水害区域発生年月日(月)2
###     gDay2 = forms.IntegerField(required=False, widget=forms.HiddenInput())                          ### 水害区域発生年月日(日)2
###     gAbnormalName = forms.CharField(max_length=16, required=False, widget=forms.HiddenInput())      ### 異常気象名
###     gRemark = forms.CharField(max_length=120, required=False, widget=forms.HiddenInput())           ### 備考
###     pdf_content = forms.CharField(required=False)
###     gKMLData = forms.CharField(required=False)
###     gOrientation = forms.IntegerField(required=False, widget=forms.HiddenInput())                   ### ページの縦横(0=縦,1=横)
###     class Meta:
###         ### model = SuigaiKuiki
###         model = SUIGAI_KUIKI
###         fields = '__all__'  

### 水害区域フォーム
class GLOBAL_POST_FORM(forms.Form):
    ### g_kuiki_id = forms.IntegerField(required=False, widget=forms.HiddenInput())                         ### ID連番
    g_kuiki_id = forms.CharField(required=False, widget=forms.HiddenInput())                                ### ID連番
    ### g_ken_code = forms.CharField(required=False, widget=forms.HiddenInput())                            ### 都道府県コード ### 2024/11/10 comment out
    ### g_city_code = forms.CharField(max_length=3, required=False, widget=forms.HiddenInput())             ### 市町村コード   ### 2024/11/10 comment out
    g_kuiki_code1 = forms.CharField(max_length=3, required=False, widget=forms.HiddenInput())               ### 水害区域番号1
    g_kuiki_code2 = forms.CharField(max_length=3, required=False, widget=forms.HiddenInput())               ### 水害区域番号2
    ### g_ken_name = forms.CharField(max_length=6, required=False, widget=forms.HiddenInput())              ### 都道府県名     ### 2024/11/10 comment out
    ### g_city_name = forms.CharField(max_length=6, required=False, widget=forms.HiddenInput())             ### 市区町村名     ### 2024/11/10 comment out
    g_scale = forms.IntegerField(required=False, widget=forms.HiddenInput(), initial=0)                     ### 縮尺
    g_branch_code1 = forms.CharField(max_length=7, required=False, widget=forms.HiddenInput())              ### 枝番1
    g_branch_code2 = forms.CharField(max_length=7, required=False, widget=forms.HiddenInput())              ### 枝番2
    g_year1 = forms.IntegerField(required=False, widget=forms.HiddenInput())                                ### 水害区域発生年月日(年)1
    g_month1 = forms.IntegerField(required=False, widget=forms.HiddenInput())                               ### 水害区域発生年月日(月)1
    g_day1 = forms.IntegerField(required=False, widget=forms.HiddenInput())                                 ### 水害区域発生年月日(日)1
    g_year2 = forms.IntegerField(required=False, widget=forms.HiddenInput())                                ### 水害区域発生年月日(年)2
    g_month2 = forms.IntegerField(required=False, widget=forms.HiddenInput())                               ### 水害区域発生年月日(月)2
    g_day2 = forms.IntegerField(required=False, widget=forms.HiddenInput())                                 ### 水害区域発生年月日(日)2
    g_abnormal_name = forms.CharField(max_length=16, required=False, widget=forms.HiddenInput())            ### 異常気象名
    g_remark = forms.CharField(max_length=120, required=False, widget=forms.HiddenInput())                  ### 備考
    g_pdf_data = forms.CharField(required=False)
    g_kml_data = forms.CharField(required=False)
    g_zoom = forms.IntegerField(required=False, widget=forms.HiddenInput())                                 ### 倍率
    g_orientation = forms.IntegerField(required=False, widget=forms.HiddenInput())                          ### ページの縦横(0=縦,1=横)
    g_print_size = forms.CharField(max_length=2, required=False, widget=forms.HiddenInput())                ### 印刷サイズ(A3, A4)

    ### class Meta:
    ###     model = KUIKI
    ###     fields = '__all__'  

### 一時ファイル読み取り用フォーム
class lKMLFileForm(forms.Form):
    temp_kml_file = forms.FileField()
