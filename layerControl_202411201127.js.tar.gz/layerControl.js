﻿///////////////////////////////////////////////////////////////////////////////
// 水害区域図作成支援システム Version 3 レイヤー制御
///////////////////////////////////////////////////////////////////////////////

// 固定値
var _fillOpacity = 1 - 0.75;        // ポリゴン内部透明度
var _polygonLineWidth = 2;          // ポリゴンの線の幅
var _pointRadius = 6;               // ポイントの半径
var _scalePositionRX = -150;        // スケール座標(ウィンドウ右端起点)

// 内部保持
var sel_polygon;                    // ポリゴン選択値(色)
var sel_line;                       // 線選択値(色)
var sz_line;                        // 線選択値(幅)
var sel_markUrl;                    // マーカーURL選択値
var sel_label_k;                    // 選択オブジェクトKML内部ラベル

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// BEGIN document ready
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
$(document).ready(function () {
    console.log('layerControl.js document.ready.function step 1');
    var drawControls;
    var currentControl;

    ///////////////////////////////////////////////////////////////////////////
    // レイヤー
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 2');
    var renderer = OpenLayers.Util.getParameters(window.location.href).renderer;
    renderer = (renderer) ? [renderer] : OpenLayers.Layer.Vector.prototype.renderers;

    // レイヤー1 (lineおよびpolygon用レイヤー)
    var layer1 = new OpenLayers.Layer.Vector("Vector Layer 1", {
        renderers: renderer
    });
    
    // レイヤー2 (マーカー用レイヤー)
    var layer2 = new OpenLayers.Layer.Vector("Vector Layer 2", {
        renderers: renderer
    });

    map.addLayers([layer1, layer2]);

    ///////////////////////////////////////////////////////////////////////////
    // スタイルlayer2_default_style
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 3');
    var layer1_default_style = new OpenLayers.Style(OpenLayers.Util.applyDefaults({
        strokeColor: "${color}",
        strokeOpacity: 1,
        strokeWidth: "${width}",
        fillColor: "${color}",
        fillOpacity: _fillOpacity,
        pointRadius: _pointRadius
    }));
    
    var layer1_select_style = new OpenLayers.Style({
        strokeColor: "${color}",
        strokeOpacity: 1 / 2,
        strokeWidth: "${width}",
        fillColor: "${color}",
        fillOpacity: _fillOpacity / 2,
        pointRadius: _pointRadius
    });

    var layer2_default_style = new OpenLayers.Style(OpenLayers.Util.applyDefaults({
        externalGraphic: "${marking}",
        graphicOpacity: 1,
        rotation: 0,
        pointRadius: 10
    }));
    
    var layer2_select_style = new OpenLayers.Style({
        externalGraphic: "${marking}",
        graphicOpacity: 1 / 2,
        rotation: 0,
        pointRadius: 10
    });

    ///////////////////////////////////////////////////////////////////////////
    // スタイルマップ
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 4');
    var layer1_style_map = new OpenLayers.StyleMap({
        'default': layer1_default_style,
        'select': layer1_select_style
    });

    var layer2_style_map = new OpenLayers.StyleMap({
        'default': layer2_default_style,
        'select': layer2_select_style
    });

    layer1.styleMap = layer1_style_map;
    layer2.styleMap = layer2_style_map;

    ///////////////////////////////////////////////////////////////////////////
    // コントロール
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 5');
    var drawControls = Array();

    ///////////////////////////////////////////////////////////////////////////
    // セレクトコントロール (layer1,layer2)
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 6');
    drawControls["select"] = new OpenLayers.Control.SelectFeature([layer1, layer2], {
        clickout: true, toggle: false,
        multiple: false, hover: false,
        toggleKey: "ctrlKey", // ctrl key removes from selection
        multipleKey: "shiftKey" // shift key adds to selection
    });

    ///////////////////////////////////////////////////////////////////////////
    // D&Dコントロール
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 7');
    // layer1用 D&Dコントロール
    drawControls["dd1"] = new OpenLayers.Control.DragFeature(layer1, { autoActivate: true });

    // layer2用 D&Dコントロール
    drawControls["dd2"] = new OpenLayers.Control.DragFeature(layer2, { autoActivate: true });

    ///////////////////////////////////////////////////////////////////////////
    // コントロール 
    // layer1 - line
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 8');
    drawControls["line"] = new OpenLayers.Control.DrawFeature(layer1, OpenLayers.Handler.Path, {
        callbacks: {
            create: function (vertex, feature) {
                // スタイル定義
                feature.style = {
                    strokeColor: sel_line,
                    strokeOpacity: 1,
                    strokeWidth: sz_line,
                    fillColor: sel_line,
                    fillOpacity: _fillOpacity,
                    pointRadius: _pointRadius
                };
                // スケッチ時のポイントスタイル
                this.handler.point.style = {
                    strokeColor: sel_line,
                    strokeOpacity: 1,
                    strokeWidth: 2,
                    fillColor: sel_line,
                    fillOpacity: 0,
                    pointRadius: _pointRadius
                };
                // スタイル反映(イベント)
                this.layer.events.triggerEvent("sketchstarted", { vertex: vertex, feature: feature });
            },
            done: function (geometry) {
                var feature = new OpenLayers.Feature.Vector(
                    geometry, {
                    'isLine': 1,
                    'color': sel_line,
                    'width': sz_line,
                    'label_k': sel_label_k
                });
                layer1.addFeatures([feature]);
            }
        }
    });
    // END layer1 - line

    ///////////////////////////////////////////////////////////////////////////
    // コントロール 
    // layer1 - polygon
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 9');
    drawControls["polygon"] = new OpenLayers.Control.DrawFeature(layer1, OpenLayers.Handler.Polygon, {
        callbacks: {
            create: function (vertex, feature) {
                // スタイル定義
                this.handler.polygon.style = {
                    strokeColor: sel_polygon,
                    strokeOpacity: 1,
                    strokeWidth: _polygonLineWidth,
                    fillColor: sel_polygon,
                    fillOpacity: _fillOpacity,
                    pointRadius: _pointRadius
                };
                // スケッチ時のポイントスタイル
                this.handler.point.style = {
                    strokeColor: sel_polygon,
                    strokeOpacity: 1,
                    strokeWidth: 2,
                    fillColor: sel_polygon,
                    fillOpacity: _fillOpacity,
                    pointRadius: _pointRadius
                };
                // スタイル反映(イベント)
                this.layer.events.triggerEvent("sketchstarted", { vertex: vertex, feature: feature });
            },
            done: function (geometry) {
                var feature = new OpenLayers.Feature.Vector(
                    geometry, {
                    'isPolygon': 1,
                    'color': sel_polygon,
                    'width': _polygonLineWidth,
                    'label_k': sel_label_k
                });
                layer1.addFeatures([feature]);
            }
        }
    });
    // END layer1 - polygon

    ///////////////////////////////////////////////////////////////////////////
    // コントロールの追加
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 10');
    map.addControl(drawControls["line"]);
    map.addControl(drawControls["polygon"]);
    map.addControl(drawControls["dd1"]);
    map.addControl(drawControls["dd2"]);
    map.addControl(drawControls["select"]);
    // END コントロールの追加

    ///////////////////////////////////////////////////////////////////////////
    // レイヤーイベント
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 11');
    layer1.events.on({
        "featureselected": function (e) {
        },
        "featureunselected": function (e) {
        }
    });
    
    layer2.events.on({
        "featureselected": function (e) {
        },
        "featureunselected": function (e) {
        }
    });
    // END レイヤーイベント

    ///////////////////////////////////////////////////////////////////////////
    // ズーム完了時
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 12');
    map.events.register("zoomend", map, function () {
        // ズームレベルによる背景地図切り替え
        setBaseMap();
        // 凡例の出力
        setLegend();
        // ズームバーハンドル位置ズレ調整
        setZoombarPos();
    });
    // END ズーム完了時
    
    ///////////////////////////////////////////////////////////////////////////
    // 線レイヤーアクティブ時
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 13');
    drawControls["line"].events.register(
        "activate", this, function (e) {
            // ズームレベルによる背景地図切り替え
            setBaseMap();
            // 凡例の出力
            setLegend();
            // ズームバーハンドル位置ズレ調整
            setZoombarPos();
        }
    );
    // END 線レイヤーアクティブ時
    
    ///////////////////////////////////////////////////////////////////////////
    // 線レイヤーデアクティブ時
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 14');
    drawControls["line"].events.register(
        // デアクティブ時
        "deactivate", this, function (e) {
            // ズームレベルによる背景地図切り替え
            setBaseMap();
            // 凡例の出力
            setLegend();
            // ズームバーハンドル位置ズレ調整
            setZoombarPos();
        }
    );
    // END 線レイヤーデアクティブ時
    
    ///////////////////////////////////////////////////////////////////////////
    // ポリゴンレイヤーアクティブ時
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 15');
    drawControls["polygon"].events.register(
        "activate", this, function (e) {
            // ズームレベルによる背景地図切り替え
            setBaseMap();
            // 凡例の出力
            setLegend();
            // ズームバーハンドル位置ズレ調整
            setZoombarPos();
        }
    );
    // END ポリゴンレイヤーアクティブ時
    
    ///////////////////////////////////////////////////////////////////////////
    // ポリゴンレイヤーデアクティブ時
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 16');
    drawControls["polygon"].events.register(
        // ディアクティブ時
        "deactivate", this, function (e) {
            // ズームレベルによる背景地図切り替え
            setBaseMap();
            // 凡例の出力
            setLegend();
            // ズームバーハンドル位置ズレ調整
            setZoombarPos();
        }
    );
    // END ポリゴンレイヤーデアクティブ時
    
    ///////////////////////////////////////////////////////////////////////////
    // 選択レイヤーアクティブ時
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 17');
    drawControls["select"].events.register(
        "activate", this, function (e) {
            // ズームレベルによる背景地図切り替え
            setBaseMap();
            // 凡例の出力
            setLegend();
            // ズームバーハンドル位置ズレ調整
            setZoombarPos();
        }
    );
    // END 選択レイヤーアクティブ時
    
    ///////////////////////////////////////////////////////////////////////////
    // 選択レイヤーデアクティブ時
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 18');
    drawControls["select"].events.register(
        "deactivate", this, function (e) {
            // ズームレベルによる背景地図切り替え
            setBaseMap();
            // 凡例の出力
            setLegend();
            // ズームバーハンドル位置ズレ調整
            setZoombarPos();
        }
    );
    // END 選択レイヤーデアクティブ時
    
    ///////////////////////////////////////////////////////////////////////////
    // Line/Polygon の Undo
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 19');
    OpenLayers.Event.observe(document, "keydown", function (evt) {
        if (currentControl == "line" || currentControl == "polygon") {
            if (evt.key == "Backspace" && !evt.altKey && !evt.ctrlKey && !evt.metaKey && !evt.shiftKey
                || evt.key == "z" && !evt.altKey && evt.ctrlKey && !evt.metaKey && !evt.shiftKey) {
                undoPoint();
                OpenLayers.Event.stop(evt);
                // drawControls[currentControl].redo();     // Redo
                // drawControls[currentControl].cancel();   // Cancel
            }
        }
    });
    // END Line/Polygon の Undo

    ///////////////////////////////////////////////////////////////////////////
    // マップイベント
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 20');
    map.events.register("click", map, function (e) {

        if (currentControl != "mark")
            return;

        var opx = map.getLonLatFromPixel(e.xy);
        var feature = new OpenLayers.Feature.Vector(
            new OpenLayers.Geometry.Point(opx.lon, opx.lat),
            {
                'isMarking': 1,
                'marking': sel_markUrl,
                'label_k': sel_label_k
            }
        );
        layer2.addFeatures([feature]);
    });
    // END マップイベント

    ///////////////////////////////////////////////////////////////////////////
    // 処理モード選択 ポリゴン描画モード
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 21');
    function startPolygon() {
        console.log('layerControl.js startPolygon function step 1');
        // 選択状態を取得する
        sel_polygon = areas[$("#sel_polygon option:selected").val()].color;
        sel_label_k = areas[$("#sel_polygon option:selected").val()].label_k;

        // 選択状態を解除する
        console.log('layerControl.js startPolygon function step 2');
        Unselect();

        // 図・番号選択モード以外は使用中のコントロールを停止する
        console.log('layerControl.js startPolygon function step 3');
        if (currentControl != "mark")
            drawControls[currentControl].deactivate();

        // D&Dモードを無効化
        console.log('layerControl.js startPolygon function step 4');
        drawControls["dd1"].deactivate();
        drawControls["dd2"].deactivate();

        // ポリゴン描画モードにする
        console.log('layerControl.js startPolygon function step 5');
        currentControl = "polygon";
        drawControls[currentControl].activate();
    }
    // END 処理モード選択 ポリゴン描画モード

    ///////////////////////////////////////////////////////////////////////////
    // 処理モード選択 線描画モード
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 22');
    function startLine() {
        console.log('layerControl.js startLine function step 1');
        // 選択状態を取得する
        sel_line = lines[$("#sel_line option:selected").val()].color;
        sel_label_k = lines[$("#sel_line option:selected").val()].label_k;
        sz_line = lineWidths[$("#sz_line option:selected").val()].width - 0;

        // 選択状態を解除する
        console.log('layerControl.js startLine function step 2');
        Unselect();

        // 図・番号選択モード以外は使用中のコントロールを停止する
        console.log('layerControl.js startLine function step 3');
        if (currentControl != "mark")
            drawControls[currentControl].deactivate();

        // D&Dモードを無効化
        console.log('layerControl.js startLine function step 4');
        drawControls["dd1"].deactivate();
        drawControls["dd2"].deactivate();

        // 線描画モードにする
        console.log('layerControl.js startLine function step 5');
        currentControl = "line";
        drawControls[currentControl].activate();
    }
    // END 処理モード選択 線描画モード

    ///////////////////////////////////////////////////////////////////////////
    // 処理モード選択 図・番号選択モード
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 23');
    function startMark() {
        console.log('layerControl.js startMark function step 1');
        // 選択状態を取得する
        sel_markUrl = markers[$("#sel_mark option:selected").val()].url;
        sel_label_k = markers[$("#sel_mark option:selected").val()].label_k;

        // 選択状態を解除する
        console.log('layerControl.js startMark function step 2');
        Unselect();

        // 図・番号選択モード以外は使用中のコントロールを停止する
        console.log('layerControl.js startMark function step 3');
        if (currentControl != "mark")
            drawControls[currentControl].deactivate();

        // D&Dモードを無効化
        console.log('layerControl.js startMark function step 4');
        drawControls["dd1"].deactivate();
        drawControls["dd2"].deactivate();

        // 図・番号選択モードにする
        console.log('layerControl.js startMark function step 5');
        currentControl = "mark";
    }
    // END 処理モード選択 図・番号選択モード

    ///////////////////////////////////////////////////////////////////////////
    // 選択・D&Dモード
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 24');
    function startSelect() {
        console.log('layerControl.js startSelect function step 1');
        // 選択状態を解除する
        Unselect();

        // 図・番号選択モード以外は使用中のコントロールを停止する
        console.log('layerControl.js startSelect function step 1');
        if (currentControl != null && currentControl != "mark")
            drawControls[currentControl].deactivate();

        // D&Dモードを有効化
        console.log('layerControl.js startSelect function step 1');
        drawControls["dd1"].activate();
        drawControls["dd2"].activate();

        // 選択モードにする
        console.log('layerControl.js startSelect function step 1');
        currentControl = "select";
        drawControls[currentControl].activate();
    }
    // END 選択・D&Dモード

    ///////////////////////////////////////////////////////////////////////////
    // 選択解除
    ///////////////////////////////////////////////////////////////////////////
    console.log('layerControl.js document.ready.function step 25');
    function Unselect() {
        console.log('layerControl.js Unselect function step 1');
        drawControls["select"].unselectAll();
    }
    // END 選択解除

    ///////////////////////////////////////////////////////////////////////////
    // ユーザが「貼付用紙作成・様式出力ボタン」をクリックしたときに呼ばれる。
    // JSのgetKML関数を呼んで、戻り値のKMLをglobalPostFormにセットする。
    // サーバの/P0500GUI/printout/のprintout_view関数を呼ぶ。
    // ※サーバのprintout_view関数では、printout.htmlをHttpResponseとして、都道府県コード等をコンテキストとして戻す。
    // ※結果として、貼付用紙作成・様式出力画面に遷移する
    ///////////////////////////////////////////////////////////////////////////
    $("#btnPrintout").click(function () {
        console.log('layerControl.js btnPrintout.click.function step 1');
    
        // 既に選択モードの時には、選択状態を解除する
        if (currentControl == "select") {
            Unselect();
        } else {
            startSelect();
        }
    
        // ズームレベルを保存
        console.log('layerControl.js btnPrintout.click.function step 2');
        $("#g_zoom").val(map.getZoom());

        // 用紙の縦横を保存
        console.log('layerControl.js btnPrintout.click.function step 3');
        $("#g_orientation").val($("input[name='i_orientation']:checked").val());
    
        // KMLへ変換して保存
        // ※kmlControl.jsのgetKML関数をコール
        // 2024/11/20 AWS環境で403 Forbiddenエラーが発生するため、原因の文字列を空に変換した。※2024/11/25デモ用の応急処置。
        console.log('layerControl.js btnPrintout.click.function step 4');
        var strKML = getKML(map, [layer1, layer2]);
        // $("#g_kml_data").val(strKML);                                       // 2024/11/20 COMMENT OUT
        $("#g_kml_data").val(strKML.replace('<kml xmlns="http://earth.google.com/kml/2.0">', '').replace('</kml>', '')); // 2024/11/20 ADD
    
        // CSRF tokenを取得し、フォームデータに追加20231209追加
        console.log('layerControl.js btnPrintout.click.function step 5');
        var csrf_token = $("[name=csrfmiddlewaretoken]").val();
        $("#global_post_form").append("<input type='hidden' name='csrfmiddlewaretoken' value='" + csrf_token + "'>"
        );
    
        // submitする
        console.log('layerControl.js btnPrintout.click.function step 6');
        $("#global_post_form").attr("action", "/P0500GUI/printout/");
        $("#global_post_form").submit();
        
    });
    // END 編集画面から印刷処理画面へ遷移する

    ///////////////////////////////////////////////////////////////////////////
    // ユーザが「水害区域図作成画面へ戻るボタン」をクリックしたときに呼ばれる。
    // HTMLのフォームからユーザが入力した情報を取得してglobalPostFormにセットする。
    // JSのgetKML関数を呼んで、戻り値のKMLをglobalPostFormにセットする。
    // サーバの/P0500GUI/editor/のeditor_view関数を呼ぶ。
    // ※サーバのeditor_view関数では、editor.htmlをHttpResponseとして、都道府県コード等をコンテキストとして戻す。
    // ※結果として、水害区域図作成画面に遷移する
    ///////////////////////////////////////////////////////////////////////////
    $("#btnEditor").click(function () {
        console.log('layerControl.js btnEditor.click.function step 1');

        // ズームレベルを保存
        $("#g_zoom").val(map.getZoom());

        // 入力値をPOSTデータに設定
        $("#g_ken_code").val($("#i_ken_code").val());                                               // 都道府県コード
        $("#g_city_code").val($("#i_city_code").val());                                             // 市区町村コード
        $("#g_kuiki_code1").val($("#i_kuiki_code1").val());                                         // 水害区域番号1
        $("#g_kuiki_code2").val($("#i_kuiki_code2").val());                                         // 水害区域番号2
        $("#g_ken_name").val($("#i_ken_name").val());                                               // 都道府県名
        $("#g_city_name").val($("#i_city_name").val());                                             // 市区町村名
        $("#g_scale").val($("#i_scale").val());                                                     // 縮尺
        $("#g_branch_code1").val($("#i_branch_code1").val());                                       // 枝番(分子)
        $("#g_branch_code2").val($("#i_branch_code2").val());                                       // 枝番(分母)
        $("#g_year1").val($("#i_year1").val());                                                     // 水害発生年月日1
        $("#g_month1").val($("#i_month1").val());                                                   // 水害発生年月日1
        $("#g_day1").val($("#i_day1").val());                                                       // 水害発生年月日1
        $("#g_year2").val($("#i_year2").val());                                                     // 水害発生年月日2
        $("#g_month2").val($("#i_month2").val());                                                   // 水害発生年月日2
        $("#g_day2").val($("#i_day2").val());                                                       // 水害発生年月日2
        $("#g_abnormal_name").val($("#i_abnormal_name").val());                                     // 異常気象名
        $("#g_remark").val($("#i_remark").val());                                                   // 備考
        $("#g_quality").val($("input[name='i_quality']:checked").val());                            // 画質
        $("#g_print_size").val($("input[name='i_print_size']:checked").val());                      // 用紙サイズ (A3,A4)

        // KMLへ変換して保存
        // ※kmlControl.jsのgetKML関数をコール
        // 2024/11/20 AWS環境で403 Forbiddenエラーが発生するため、原因の文字列を空に変換した。※2024/11/25デモ用の応急処置。
        console.log('layerControl.js btnEditor.click.function step 2');
        var strKML = getKML(map, [layer1, layer2]);
        // $("#g_kml_data").val(strKML);                                       // 2024/11/20 COMMENT OUT
        $("#g_kml_data").val(strKML.replace('<kml xmlns="http://earth.google.com/kml/2.0">', '').replace('</kml>', '')); // 2024/11/20 ADD

        // CSRF tokenを取得し、フォームデータに追加20231211追加
        console.log('layerControl.js btnEditor.click.function step 3');
        var csrftoken = $("[name=csrfmiddlewaretoken]").val();
        $("#global_post_form").append("<input type='hidden' name='csrfmiddlewaretoken' value='" + csrftoken + "'>");

        // submitする
        console.log('layerControl.js btnEditor.click.function step 4');
        $("#global_post_form").attr("action", "/P0500GUI/editor/");
        $("#global_post_form").submit();
        
    });
    // END 水害区域図作成画面へ戻るボタンクリック

    ///////////////////////////////////////////////////////////////////////////
    // 画面起動時KML文字列読み込み再生処理
    // g_kml_dataにKMLデータ、g_zoomにズームポジションが設定された状態で呼び出すことで、
    // その内容を地図上に再生する
    ///////////////////////////////////////////////////////////////////////////
    function InitKML() {
        console.log('layerControl.js InitKML function step 1');

        var g_kml_data = $("#g_kml_data").val();
        if (g_kml_data.length == 0)
            return; // 空なら何もしない

        // 既に選択モードの時には、選択状態を解除する
        console.log('layerControl.js InitKML function step 2');
        if (currentControl == "select") {
            Unselect();
        }
        else {
            startSelect();
        }

        // KMLの再生
        console.log('layerControl.js InitKML function step 3');

        var mapCenterLonLat = setKML(map, [layer1, layer2], decodeURIComponent(g_kml_data), false);

        // ズームレベルの切り替え
        console.log('layerControl.js InitKML function step 4');
            
        // changeZoomLevel($("#gZoom").val());
        changeZoomLevel($("#g_zoom").val());

        // mapのセンター位置を設定
        console.log('layerControl.js InitKML function step 5');
        if (mapCenterLonLat != null)
            map.setCenter(new OpenLayers.LonLat(mapCenterLonLat.Lon, mapCenterLonLat.Lat));

    };
    // END 画面起動時KML文字列読み込み再生処理

    ///////////////////////////////////////////////////////////////////////////
    // 作図ファイルの読込処理 (ファイル選択イベント)
    // 再登録を行うため、変数に登録しておく
    ///////////////////////////////////////////////////////////////////////////
    var KMLLoadStart = function () {
        console.log('layerControl.js KMLLoadStart step 1');
        // 一時保存ファイルパスファイル未選択の場合
        if ($("#lKMLFilePath").val().length == 0)
            return;

        // submit
        console.log('layerControl.js KMLLoadStart step 2');
        $("#lKMLFileForm").submit();

        // 一時保存ファイルパスの無効化
        // 一時保存ファイルの読込ボタン無効化
        console.log('layerControl.js KMLLoadStart step 3');
        $("#lKMLFilePath").attr("disabled", true);
        $("#lKMLFileButton").attr("disabled", true);

        // 作図ファイルの読み込みで再読み込みを可能にする
        console.log('layerControl.js KMLLoadStart step 4');
        this.value = null;
    }
    // END 作図ファイルの読込処理 (ファイル選択イベント)

    ///////////////////////////////////////////////////////////////////////////
    // 「一時保存ファイルパス」に変更があったときに呼ばれる。
    // JSのKMLLoadStart関数を呼ぶ。
    // ※KMLLoadStart関数では、サーバの/P0500GUI/kml_loader/のviews.kml_loader関数をPOSTで呼ぶ。
    // ※サーバから戻されたkml_loader.htmlでは、lKMLFileFrameにクリックイベントを発生させる。
    // ※クリックイベントについては、下のlKMLFileFrameクリックイベント参照
    ///////////////////////////////////////////////////////////////////////////
    $("#lKMLFilePath").on("change", KMLLoadStart);

    ///////////////////////////////////////////////////////////////////////////
    // 作図ファイルの読込処理 (ファイル読み込み完了イベント)
    // lKMLFilePath変更イベントでサーバから戻されたkml_loader.htmlから呼ばれる。
    // ※呼び出しもとについては、上のlKMLFilePath変更イベント参照
    // lKMLFileFrameにセットされたサーバ戻り値のKMLデータを地図にセットする。
    ///////////////////////////////////////////////////////////////////////////
    $('#lKMLFileFrame').on('click', function () {
        console.log('layerControl.js lKMLFileFrame.on.click.function step 1');
    
        var strKML = $("#lKMLData", $("#lKMLFileFrame").contents()).val();
        
        if (strKML.length != 0) {

            // 既に選択モードの時には、選択状態を解除する
            if (currentControl == "select") {
                Unselect();
            }
            else {
                startSelect();
            }

            // KMLの再生
            var data = unescape(strKML);
            var mapCenterLonLat = null;
            try {
                mapCenterLonLat = setKML(map, [layer1, layer2], strKML, true);
            } catch (e) {
                mapCenterLonLat = null;
            }

            // 正しく再生できた
            if (mapCenterLonLat != null) {
                $("#g_kml_data").val(strKML);
                
                // ズームレベルの切り替え
                changeZoomLevel($("#g_zoom").val());
                
                // mapのセンター位置を設定
                map.setCenter(new OpenLayers.LonLat(mapCenterLonLat.Lon, mapCenterLonLat.Lat));
            } else {
                alert("作図ファイルが不正です");
            }
        }

        // ファイル名のクリア
        console.log('layerControl.js lKMLFileFrame.on.click.function step 2');
        $("#lKMLFilePath").replaceWith($("#lKMLFilePath").clone());
        
        // ファイル名ハンドラー再登録
        console.log('layerControl.js lKMLFileFrame.on.click.function step 3');
        $("#lKMLFilePath").on("change", KMLLoadStart);

        // 一時保存ファイルパスの有効化
        // 一時保存ファイルの読込ボタン有効化
        console.log('layerControl.js lKMLFileFrame.on.click.function step 4');
        $("#lKMLFilePath").attr("disabled", false);
        $("#lKMLFileButton").attr("disabled", false);
        
    });
    // END 作図ファイルの読込処理 (ファイル読み込み完了イベント)

    ///////////////////////////////////////////////////////////////////////////
    // ユーザが「様式および作図情報の出力Newボタン」をクリックしたときに呼ばれる。
    ///////////////////////////////////////////////////////////////////////////
    $("#btnOutputNew").click(function () {
        console.log('layerControl.js btnOutputNew step 1');

        // 様式および作図情報の出力Newボタンを無効化する
        $("#btnOutputNew").attr("disabled", true);

        // ※表示Iフォームの値を非表示Gフォームの値にセットする
        $("#g_ken_code").val($("#i_ken_code").val());                           // 都道府県コード
        $("#g_city_code").val($("#i_city_code").val());                         // 市区町村コード
        $("#g_kuiki_code1").val($("#i_kuiki_code1").val());                     // 水害区域番号1
        $("#g_kuiki_code2").val($("#i_kuiki_code2").val());                     // 水害区域番号2
        $("#g_ken_name").val($("#i_ken_name").val());                           // 都道府県名
        $("#g_city_name").val($("#i_city_name").val());                         // 市区町村名
        $("#g_scale").val($("#i_scale").val());                                 // 縮尺
        $("#g_branch_code1").val($("#i_branch_code1").val());                   // 枝番(分子)
        $("#g_branch_code2").val($("#i_branch_code2").val());                   // 枝番(分母)
        $("#g_year1").val($("#i_year1").val());                                 // 水害発生年月日1
        $("#g_month1").val($("#i_month1").val());                               // 水害発生年月日1
        $("#g_day1").val($("#i_day1").val());                                   // 水害発生年月日1
        $("#g_year2").val($("#i_year2").val());                                 // 水害発生年月日2
        $("#g_month2").val($("#i_month2").val());                               // 水害発生年月日2
        $("#g_day2").val($("#i_day2").val());                                   // 水害発生年月日2
        $("#g_abnormal_name").val($("#i_abnormal_name").val());                 // 異常気象名
        $("#g_remark").val($("#i_remark").val());                               // 備考
        console.log('layerControl.js btnOutputNew i_remark=' + $("#i_remark").val()); // ADD 20240903 O.OKADA
        console.log('layerControl.js btnOutputNew g_remark=' + $("#g_remark").val()); // ADD 20240903 O.OKADA

        // ※kmlControl.jsのgetKML関数をコールする
        var strKML = getKML(map, [layer1, layer2]);
        $("#g_kml_data").val(strKML);

        $("#g_zoom").val(map.getZoom());
        $("#g_quality").val($("input[name='i_quality']:checked").val());        // 画質
        $("#g_print_size").val($("input[name='i_print_size']:checked").val());  // 用紙サイズ (A3,A4)
        
        console.log('i_ken_code=' + document.getElementById('i_ken_code').value);
        console.log('g_ken_code=' + document.getElementById('g_ken_code').value);

        // CSRFトークンのDIV要素の値を内部変数にセットする
        console.log('layerControl.js btnOutputNew step 2');
        const csrf_token = document.querySelector('[name=csrfmiddlewaretoken').value;
        
        // 条件分岐用の内部変数に初期値をセットする
        console.log('layerControl.js btnOutputNew step 3');
        var sendDataFlag = false;

        // 地図プレビューのDIV要素を内部変数にセットする
        console.log('layerControl.js btnOutputNew step 4');
        var mapElement = document.getElementById('map');

        // 入力されたフォーム内の各要素の値を取得
        console.log('layerControl.js btnOutputNew step 5');
        console.log('layerControl.js btnOutputNew g_kuiki_id=' + document.getElementById('g_kuiki_id').value)
        var form_data = {
            'g_kuiki_id': document.getElementById('g_kuiki_id').value ? document.getElementById('g_kuiki_id').value : null, // 新規でidがない場合はnullで返す
            'g_ken_code': document.getElementById('i_ken_code').value,                              // 都道府県コード
            'g_city_code': document.getElementById('i_city_code').value,                            // 市町村コード
            'g_kuiki_code1': document.getElementById('i_kuiki_code1').value,                        // 水害区域番号1
            'g_kuiki_code2': document.getElementById('i_kuiki_code2').value,                        // 水害区域番号2
            'g_ken_name': document.getElementById('i_ken_name').value,                              // 都道府県名
            'g_city_name': document.getElementById('i_city_name').value,                            // 市町村名
            'g_scale': document.getElementById('i_scale').value,                                    // 縮尺
            'g_branch_code1': document.getElementById('i_branch_code1').value,                      // 枝番(1)
            'g_branch_code2': document.getElementById('i_branch_code2').value,                      // 枝番(2)
            'g_year1': document.getElementById('i_year1').value,                                    // 水害区域発生年月日(年)1
            'g_month1': document.getElementById('i_month1').value,                                  // 水害区域発生年月日(月)1
            'g_day1': document.getElementById('i_day1').value,                                      // 水害区域発生年月日(日)1
            'g_year2': document.getElementById('i_year2').value,                                    // 水害区域発生年月日(年)2
            'g_month2': document.getElementById('i_month2').value,                                  // 水害区域発生年月日(月)2
            'g_day2': document.getElementById('i_day2').value,                                      // 水害区域発生年月日(日)2
            'g_abnormal_name': document.getElementById('i_abnormal_name').value,                    // 異常気象名
            'g_remark': document.getElementById('i_remark').value,                                  // 備考
            
            'g_kml_data': document.getElementById('g_kml_data').value,                              // KMLデータ
            
            'g_zoom': document.getElementById('g_zoom').value,                                      // 地図プレビューの縮尺
            'g_orientation': document.getElementById('g_orientation').value,                        // 印刷方向
            'g_print_size': document.querySelector('input[name="i_print_size"]:checked').value,     // 印刷サイズ
        };

        // 外部サーバのサービスを利用して地図プレビューmapElementをPNGに変換する ### クロスオリジン制約をくぐるためにuseCORSを使う
        console.log('layerControl.js btnOutputNew step 6');
        html2canvas(mapElement, {useCORS:true}).then(function (canvas) {
            // ダウンロードしたPNGを内部変数にセットする
            var image_data = canvas.toDataURL('image/png');

            // 条件分岐用の内部変数をTrueに更新する
            sendDataFlag = true;

            // ダウンロードしたPNGをBase64形式に変換する
            var binaryData = atob(image_data.split(',')[1]);
            var arrayBuffer = new ArrayBuffer(binaryData.length);
            var uint8Array = new Uint8Array(arrayBuffer);
            for (var i = 0; i < binaryData.length; i++) {
                uint8Array[i] = binaryData.charCodeAt(i);
            }
            
            // ダウンロードしてBase64形式に変換したPNGをDJANGOサーバにPOSTする
            // ※ここでアップロードしたPNGファイルのcaptured_image_map.pngを使って、
            // ※DJANGOサーバ側でReportLabライブラリを使用してPDFを生成する
            // ※画像ファイルのアップロードとフォームのPOSTを一度に行えないための代替処理
            fetch('/P0500GUI/printout/upload_canvas/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrf_token,
                },
                credentials: 'include',
                body: uint8Array,
            })
            .then(response => {
                console.log('layerControl.js btnOutputNew step 7');
                if (!response.ok) {
                    throw new Error(`HTTPエラー! ステータス: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                // console.log('返答:', data);
                // ※DJANGOサーバ側で画像ファイルが正常に作成された場合、DJANGOサーバからdata.file_pathに値がセットされてリターンされる
                console.log('layerControl.js btnOutputNew step 8');
                if (data.file_path) {
                    var download_Link = document.createElement('a');
                    download_Link.href = data.file_path;
                    download_Link.download = 'captured_image_map.png';
                    download_Link.addEventListener('click', function (event) {
                        event.preventDefault();
                    });
                    download_Link.click();

                    // POST準備 条件分岐用の内部変数がTrueの場合、フォームデータをDJANGOサーバにPOSTする
                    if (sendDataFlag) {
                        send_data = {
                            'g_kuiki_id': form_data.g_kuiki_id,
                            'g_ken_code': form_data.g_ken_code,
                            'g_city_code': form_data.g_city_code,
                            'g_kuiki_code1': form_data.g_kuiki_code1,
                            'g_kuiki_code2': form_data.g_kuiki_code2,
                            'g_ken_name': form_data.g_ken_name,
                            'g_city_name': form_data.g_city_name,
                            'g_scale': form_data.g_scale,
                            'g_branch_code1': form_data.g_branch_code1,
                            'g_branch_code2': form_data.g_branch_code2,
                            'g_year1': form_data.g_year1,
                            'g_month1': form_data.g_month1,
                            'g_day1': form_data.g_day1,
                            'g_year2': form_data.g_year2,
                            'g_month2': form_data.g_month2,
                            'g_day2': form_data.g_day2,
                            'g_abnormal_name': form_data.g_abnormal_name,
                            'g_remark': form_data.g_remark,
                            
                            'g_kml_data': form_data.g_kml_data,
                            
                            'g_zoom': form_data.g_zoom,
                            'g_orientation': form_data.g_orientation,
                            'g_print_size': form_data.g_print_size,
                        };

                        // POST準備 送信データをJSON形式からフォーム形式に変換する
                        var request_form_data= new FormData();
                        for (var key in send_data) {
                            request_form_data.append(key, send_data[key]);
                        }
                        // request_form_data.append('id', document.getElementById('id').value || null);
                        request_form_data.append('g_kuiki_id', document.getElementById('g_kuiki_id').value || null);

                        // フォーム形式の送信データをDJANGOサーバにPOSTする
                        // fetch('/P0500GUI/suigai_kuiki_input/', {
                        fetch('/P0500GUI/printout/upload_png/', {
                            method: 'POST',
                            headers: {
                                'X-CSRFToken': csrf_token,
                            },
                            body: request_form_data,
                        })
                        //.then(response => downloadPdf(response))
                        //.catch(error => console.error('POSTリクエストエラー:', error));
                        .then(response => response.json()) // ADD 20240903 O.OKADA
                        .then(data => {
                            console.log('layerControl.js btnOutputNew step 9');
                            console.log('layerControl.js btnOutputNew data.status' + data.status);
                            console.log('layerControl.js btnOutputNew data.message' + data.message);
                            console.log('layerControl.js btnOutputNew data.kuiki_id' + data.kuiki_id);
                            document.getElementById("g_kuiki_id").value = data.kuiki_id; // ADD 20240903 O.OKADA
                        })
                        
                        // 条件分岐用の内部変数に初期値をセットする（初期値に戻す）
                        sendDataFlag = false;
                    }
                } else {
                    // console.error('サーバーからの応答にfile_pathが含まれていません');
                    // 様式および作図情報の出力Newボタンを有効化する
                    console.log('layerControl.js btnOutputNew step 10');
                    $("#btnOutputNew").attr("disabled", false);
                }
            })
            // .catch(error => console.error('エラー:', error));
            // 様式および作図情報の出力Newボタンを有効化する
            $("#btnOutputNew").attr("disabled", false);
        });
    });
    // END 様式および作図情報の出力Newボタンをクリックしたときの処理

    ///////////////////////////////////////////////////////////////////////////
    // ユーザが「KMLダウンロードボタン」をクリックしたときに呼ばれる。
    ///////////////////////////////////////////////////////////////////////////
    // $("#btnKMLOutputNew").click(function () {
    //     console.log('layerControl.js btnKMLOutputNew step 1');
    //     kuiki_id = document.getElementById('g_kuiki_id').value ? document.getElementById('g_kuiki_id').value : null;
    //     // 「KMLダウンロードボタン」を無効化する。
    //     $("#btnKMLOutputNew").attr("disabled", true);
    //     // fetchを使用して非同期通信
    //     fetch("/P0500GUI/printout/download_kml/"+kuiki_id)
    //     .then(response => {
    //         if (response.ok) {
    //             return response.blob();
    //         }
    //         throw new Error("server error");
    //     })
    //     .then(data => {
    //         let a = document.createElement("a");
    //         a.href = window.URL.createObjectURL(data);
    //         a.download = "kuiki.kml";
    //         a.click();
    //     })
    //     .catch(error => {
    //         alert("server error");
    //     })
    //     // 「KMLダウンロードボタン」を有効にする。
    //     console.log('layerControl.js btnKMLOutputNew step 2');
    //     $("#btnKMLOutputNew").attr("disabled", false);
    // });
    // END 「KMLダウンロードボタン」をクリックしたときの処理

    $("#btnKMLOutputNew").click(function () {
    
        $("btnOutputNew").click();                                             // 2024/11/10 ADD

        console.log('layerControl.js btnKMLOutputNew step 1');

        kuiki_id = document.getElementById('g_kuiki_id').value ? document.getElementById('g_kuiki_id').value : null;

        // 「KMLダウンロードボタン」を無効化する。
        $("#btnKMLOutputNew").attr("disabled", true);
        
        // fetchを使用して非同期通信
        fetch("/P0500GUI/printout/download_kml/"+kuiki_id)
        .then(response => {
            if (response.ok) {
                return response.blob();
            }
            throw new Error("server error");
        })
        .then(data => {
            let a = document.createElement("a");
            a.href = window.URL.createObjectURL(data);
            a.download = "kuiki.kml";
            a.click();
        })
        .catch(error => {
            alert("server error");
        })

        // 「KMLダウンロードボタン」を有効にする。
        console.log('layerControl.js btnKMLOutputNew step 2');
        $("#btnKMLOutputNew").attr("disabled", false);
        
    });
    // END 「KMLダウンロードボタン」をクリックしたときの処理

    ///////////////////////////////////////////////////////////////////////////
    // ユーザが「PDFダウンロードボタン」をクリックしたときに呼ばれる。
    ///////////////////////////////////////////////////////////////////////////
    // $("#btnPDFOutputNew").click(function () {
    //     console.log('layerControl.js btnPDFOutputNew step 1');
    //     kuiki_id = document.getElementById('g_kuiki_id').value ? document.getElementById('g_kuiki_id').value : null;
    //     // 「PDFダウンロードボタン」を無効化する。
    //     $("#btnPDFOutputNew").attr("disabled", true);
    //     // fetchを使用して非同期通信
    //     fetch("/P0500GUI/printout/download_pdf/"+kuiki_id)
    //     .then(response => {
    //         if (response.ok) {
    //             return response.blob();
    //         }
    //         throw new Error("server error");
    //     })
    //     .then(data => {
    //         let a = document.createElement("a");
    //         a.href = window.URL.createObjectURL(data);
    //         a.download = "kuiki.pdf";
    //         a.click();
    //     })
    //     .catch(error => {
    //         alert("server error");
    //     })
    //     // 「PDFダウンロードボタン」を有効にする。
    //     console.log('layerControl.js btnPDFOutputNew step 2');
    //     $("#btnPDFOutputNew").attr("disabled", false);
    // });
    // END 「PDFダウンロードボタン」をクリックしたときの処理

    $("#btnPDFOutputNew").click(function () {

        $("btnOutputNew").click();                                             // 2024/11/10 ADD

        console.log('layerControl.js btnPDFOutputNew step 1');

        kuiki_id = document.getElementById('g_kuiki_id').value ? document.getElementById('g_kuiki_id').value : null;

        // 「PDFダウンロードボタン」を無効化する。
        $("#btnPDFOutputNew").attr("disabled", true);

        // fetchを使用して非同期通信
        fetch("/P0500GUI/printout/download_pdf/"+kuiki_id)
        .then(response => {
            if (response.ok) {
                return response.blob();
            }
            throw new Error("server error");
        })
        .then(data => {
            let a = document.createElement("a");
            a.href = window.URL.createObjectURL(data);
            a.download = "kuiki.pdf";
            a.click();
        })
        .catch(error => {
            alert("server error");
        })

        // 「PDFダウンロードボタン」を有効にする。
        console.log('layerControl.js btnPDFOutputNew step 2');
        $("#btnPDFOutputNew").attr("disabled", false);
        
    });
    // END 「PDFダウンロードボタン」をクリックしたときの処理







    ///////////////////////////////////////////////////////////////////////////
    // 水害区域描画ボタンクリックイベント
    ///////////////////////////////////////////////////////////////////////////
    $("#btn_polygon").click(function () {
        startPolygon();
    });
    // END 水害区域描画ボタンクリックイベント
    
    ///////////////////////////////////////////////////////////////////////////
    // 描画色選択セレクトボックス選択イベント
    ///////////////////////////////////////////////////////////////////////////
    $("#sel_polygon").change(function () {
        if (currentControl != "polygon")
            return;
        startPolygon();
    });
    // END 描画色選択セレクトボックス選択イベント

    ///////////////////////////////////////////////////////////////////////////
    // 直線描画ボタンクリックイベント
    ///////////////////////////////////////////////////////////////////////////
    $("#btn_line").click(function () {
        startLine();
    });
    // END 直線描画ボタンクリックイベント
    
    ///////////////////////////////////////////////////////////////////////////
    // 直線色セレクトボックス選択イベント
    ///////////////////////////////////////////////////////////////////////////
    $("#sel_line").change(function () {
        if (currentControl != "line")
            return;
        startLine();
    });
    // END 直線色セレクトボックス選択イベント
    
    ///////////////////////////////////////////////////////////////////////////
    // 直線サイズセレクトボックス選択イベント
    ///////////////////////////////////////////////////////////////////////////
    $("#sz_line").change(function () {
        if (currentControl != "line")
            return;
        startLine();
    });
    // END 直線サイズセレクトボックス選択イベント

    ///////////////////////////////////////////////////////////////////////////
    // 描画を元に戻すボタンクリックイベント
    ///////////////////////////////////////////////////////////////////////////
    $("#btn_undo").click(function () {
        if (currentControl == "line" || currentControl == "polygon") {
            undoPoint();
        }
    });
    // END 描画を元に戻すボタンクリックイベント

    ///////////////////////////////////////////////////////////////////////////
    // 図・番号描画ボタンクリックイベント
    ///////////////////////////////////////////////////////////////////////////
    $("#btn_mark").click(function () {
        startMark();
    });
    // END 図・番号描画ボタンクリックイベント
    
    ///////////////////////////////////////////////////////////////////////////
    // 図・番号描画セレクトボックス選択イベント
    ///////////////////////////////////////////////////////////////////////////
    $("#sel_mark").change(function () {
        if (currentControl != "mark")
            return;
        startMark();
    });
    // END 図・番号描画セレクトボックス選択イベント

    ///////////////////////////////////////////////////////////////////////////
    // 地図操作 (選択可能にする)
    ///////////////////////////////////////////////////////////////////////////
    $("#btn_select").click(function () {
        // 既に選択モードの時には、選択状態を解除する
        if (currentControl == "select") {
            Unselect();
            return;
        }
        startSelect();
    });
    // END 地図操作 (選択可能にする)

    ///////////////////////////////////////////////////////////////////////////
    // 選択したオブジェクトを削除
    ///////////////////////////////////////////////////////////////////////////
    $("#btn_remove").click(function () {
        var deleted = false;
        if (currentControl == "select" && layer1.selectedFeatures.length != 0) {
            layer1.removeFeatures(layer1.selectedFeatures);
            deleted = true;
        }
        
        if (currentControl == "select" && layer2.selectedFeatures.length != 0) {
            layer2.removeFeatures(layer2.selectedFeatures);
            deleted = true;
        }

        if (!deleted) {
            alert("削除したい図・画像を選択してください。");
        }
    });
    // END 選択したオブジェクトを削除
    
    ///////////////////////////////////////////////////////////////////////////
    // 面積計算
    ///////////////////////////////////////////////////////////////////////////
    $("#btn_area").click(function () {

        if (currentControl == "select" && layer1.selectedFeatures.length == 1 && layer2.selectedFeatures.length == 0 &&
            layer1.selectedFeatures[0].geometry instanceof OpenLayers.Geometry.Polygon) {
            var area = layer1.selectedFeatures[0].geometry.getGeodesicArea(map.getProjectionObject());
            var disp = Math.round(area); // 四捨五入
            $("#areaValue").html(disp);
        } else {
            $("#areaValue").html("-");
            alert("描画した水害区域を1つ選択してください。");
        }
    });
    // END 面積計算

    ///////////////////////////////////////////////////////////////////////////
    // 領域/線の元に戻す処理
    ///////////////////////////////////////////////////////////////////////////
    function undoPoint() {
        try {
            if (!drawControls[currentControl].undo()) {
                // undo出来なければキャンセル
                drawControls[currentControl].cancel();
            }
        }
        catch (e) {
            // キャンセル出来ない(描画対象が存在しない)
        }
    };
    // END 領域/線の元に戻す処理

    ///////////////////////////////////////////////////////////////////////////
    // ユーザが「描画オブジェクト全削除ボタン」をクリックしたときに呼ばれる。
    // 地図の描画（線、ポリゴン等）を削除する
    ///////////////////////////////////////////////////////////////////////////
    $("#btnDelAll").click(function () {

        if (layer1.features.length + layer2.features.length == 0) {
            alert("マップ上に図・画像は存在しません。");
            return;
        }

        // 地図操作モード中でなければエラー
        if (currentControl != "select") {
            alert("図・画像の描画中は削除できません。\n始めに地図操作ボタンを押してください。");
            return;
        }

        // 削除確認
        if (!confirm("全削除ボタンが押されました。\n本当に削除してもよろしいですか？"))
            return;

        // 選択状態を解除する
        drawControls["select"].unselectAll();

        // レイヤー1 (lineおよびpolygon用レイヤー) 内のfeatureを削除
        layer1.removeAllFeatures();
        
        // レイヤー1 (lineおよびpolygon用レイヤー) 内のfeatureを解放
        layer1.destroyFeatures();
        
        // レイヤー2 (マーカー用レイヤー) 内のfeatureを削除
        layer2.removeAllFeatures();
        
        // レイヤー2 (マーカー用レイヤー) 内のfeatureを解放
        layer2.destroyFeatures();
    });
    // END 描画オブジェクト全削除ボタンクリックイベント

    ///////////////////////////////////////////////////////////////////////////
    // 画面初期表示時の処理
    ///////////////////////////////////////////////////////////////////////////

    // 画面起動時KML文字列読み込み処理
    InitKML();
    initCompleted = true;

    // 初期モード
    currentControl = null;
    if (mapMode == "editor") {
        // 編集画面
        startSelect();
    } else {
        // 印刷系画面
        // 選択不可状態にする
        drawControls["select"].deactivate();
        drawControls["dd1"].deactivate();
        drawControls["dd2"].deactivate();
    }

    // 色指定(スケールと凡例の背景を半透明にする)
    $(".olControlScaleLine").css("background-color", 'rgba(255,255,255,0.75)');
    $(".olControlAttribution").css("background-color", 'rgba(255,255,255,0.75)');

    // END 画面初期表示時の処理
});
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// END document ready
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// ズームレベルの切り替え
///////////////////////////////////////////////////////////////////////////////
function changeZoomLevel(newZoomLevel) {

    var curZoom = map.getZoom();

    while (newZoomLevel - curZoom > 0) {
        //alert("-zoom=" + curZoom + ",newZoomLevel=" + newZoomLevel);
        map.zoomIn();
        curZoom++;
    }
    while (curZoom - newZoomLevel > 0) {
        //alert("+zoom=" + curZoom + ",newZoomLevel=" + newZoomLevel);
        map.zoomOut();
        curZoom--;
    }
    //alert("zoom=" + curZoom + ",newZoomLevel=" + newZoomLevel);
}
// END ズームレベルの切り替え

///////////////////////////////////////////////////////////////////////////////
// ズームレベルによる背景地図切り替え
///////////////////////////////////////////////////////////////////////////////
function setBaseMap(/*option*/zoomLevel) {

    if (typeof zoomLevel == "undefined")
        zoomLevel = map.getZoom();

    var newLayer = useBaseMap[zoomLevel] == "pale" ? paleLayer : stdLayer;

    if (currLayer != newLayer) {
        if (currLayer != null)
            map.removeLayer(currLayer);
        currLayer = newLayer;
        map.addLayer(currLayer);
        map.setBaseLayer(currLayer);
    }
}
// END ズームレベルによる背景地図切り替え

///////////////////////////////////////////////////////////////////////////////
// 凡例出力
///////////////////////////////////////////////////////////////////////////////
function setLegend(/*option*/zoomLevel) {

    if (typeof zoomLevel == "undefined")
        zoomLevel = map.getZoom();

    $("#legRB").html(getLegend(zoomLevel));

    // スケール位置調整
    // $(".olControlScaleLine").css("left", ($(window).width() + _scalePositionRX) + "px");
    // $(".olControlScaleLine").css("left", ($("#map").width() + _scalePositionRX) + "px");
}
// END 凡例出力

///////////////////////////////////////////////////////////////////////////////
// 凡例取得
///////////////////////////////////////////////////////////////////////////////
function getLegend(zoomLevel) {

    if (currLayer == null)
        return;

    var html = "<a href='http://portal.cyberjapan.jp/help/termsofuse.html' target='_blank'>国土地理院</a>";
    html += "&nbsp;";

    var name = zoomLevelInfo[zoomLevel][currLayer.name].name;   // 地図名
    var url = zoomLevelInfo[zoomLevel][currLayer.name].legendUrl;   // 凡例URL
    var html;

    html = "<a class='kokudo' href='" + kokudoURL + "' target='_blank'>国土地理院</a>";
    if (name != null) {
        html += "&nbsp;" + name;
    }
    if (mapMode == "editor" && url != null) {
        html += "&nbsp;<span class='hanrei'><a class='hanrei' href='" + url + "' target='_blank'>凡例</a></span>";
    }
    return html;
}
// END 凡例取得

///////////////////////////////////////////////////////////////////////////////
// ズームバーハンドル位置ズレ調整
///////////////////////////////////////////////////////////////////////////////
function setZoombarPos() {

    if (isDispZoomBar) {
        var id = zoomcontrol.id + "_" + map.id;
        $("#" + id).css("top", ((18 - map.getZoom()) * 11 + 80) + "px");
    }
}
// END ズームバーハンドル位置ズレ調整
