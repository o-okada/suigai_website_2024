###############################################################################
### ファイル名：P0400Online/views.py
### オンライン表示
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### def custom_decorator(arg1)
###
### ビュー関数：ブラウザから呼ばれる関数
### def index_view(request)
### def cat1_cat2_ken_city_view(request, cat1, cat2, ken_code, city_code)
###
### 更新履歴：
### 2024/10/13 画面制御用コード（暫定値、確報値）に対応した。
### 2024/11/15 一般資産調査員調査票のヘッダ部で水系種別、河川種別を表示できるように修正した。
### 2024/11/21 水系のリストを取得するSQLに県コードを追加した。
###############################################################################

import sys
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ
from P0000Common.models import PROVISIONED_CONFIRMED   ### 0000: 画面制御用コード（暫定値、確報値）

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### 局所定数 ※QueryStringのパラメータ値　※つまり、値を変えるとHTMLも変える必要がある。
_CAT0 = '0'
_CAT1 = '1'
_CAT2 = '2'
_CAT3 = '3'
_CAT4 = '4'

### 局所定数 ※QueryStringのパラメータ値　※つまり、値を変えるとHTMLも変える必要がある。
_BUILDING = 'BUILDING'
_KEN = 'KEN'
_CITY = 'CITY'
_KASEN_KAIGAN = 'KASEN_KAIGAN'
_SUIKEI = 'SUIKEI'
_SUIKEI_TYPE = 'SUIKEI_TYPE'
_KASEN = 'KASEN'
_KASEN_TYPE = 'KASEN_TYPE'
_CAUSE = 'CAUSE'
_UNDERGROUND = 'UNDERGROUND'
_USAGE = 'USAGE'
_FLOOD_SEDIMENT = 'FLOOD_SEDIMENT'
_GRADIENT = 'GRADIENT'
_INDUSTRY = 'INDUSTRY'
_BUSINESS = 'BUSINESS'
_HOUSE_ASSET = 'HOUSE_ASSET'
_HOUSE_RATE = 'HOUSE_RATE'
_HOUSE_ALT = 'HOUSE_ALT'
_HOUSE_CLEAN = 'HOUSE_CLEAN'
_HOUSEHOLD_ASSET = 'HOUSEHOLD_ASSET'
_HOUSEHOLD_RATE = 'HOUSEHOLD_RATE'
_CAR_ASSET = 'CAR_ASSET'
_CAR_RATE = 'CAR_RATE'
_OFFICE_ASSET = 'OFFICE_ASSET'
_OFFICE_RATE = 'OFFICE_RATE'
_OFFICE_SUSPEND = 'OFFICE_SUSPEND'
_OFFICE_STAGNATE = 'OFFICE_STAGNATE'
_OFFICE_ALT = 'OFFICE_ALT'
_FARMER_FISHER_ASSET = 'FARMER_FISHER_ASSET'
_FARMER_FISHER_RATE = 'FARMER_FISHER_RATE'
_WEATHER = 'WEATHER'
_IPPAN_HEADER = 'IPPAN_HEADER'
_IPPAN = 'IPPAN'
_CHITAN_HEADER = 'CHITAN_HEADER'
_CHITAN = 'CHITAN'
_HOJO_HEADER = 'HOJO_HEADER'
_HOJO = 'HOJO'
_KOEKI_HEADER = 'KOEKI_HEADER'
_KOEKI = 'KOEKI'
_IPPAN_SUMMARY = 'IPPAN_SUMMARY'
_CHITAN_SUMMARY = 'CHITAN_SUMMARY'
_HOJO_SUMMARY = 'HOJO_SUMMARY'
_KOEKI_SUMMARY = 'KOEKI_SUMMARY'
_ACTION = 'ACTION'
_STATUS = 'STATUS'
_IPPAN_TRIGGER = 'IPPAN_TRIGGER'
_CHITAN_TRIGGER = 'CHITAN_TRIGGER'
_HOJO_TRIGGER = 'HOJO_TRIGGER'
_KOEKI_TRIGGER = 'KOEKI_TRIGGER'

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def custom_decorator(arg1):

    def outer_wrapper(view_func):
        
        def inner_wrapper(request, *args, **kwargs):
            try:
                reset_log()
                print_log('[DEBUG] P0400Online.custom_decorator()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
                print_log('[DEBUG] P0400Online.custom_decorator()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
                print_log('[DEBUG] P0400Online.custom_decorator()関数 arg1={}'.format(arg1), 'DEBUG')
                PARAMS_SELECT_USER_PROXY = dict({
                    'USERNAME': str(request.user) 
                })
                SQL_SELECT_USER_PROXY = """
                    SELECT 
                        P1.ID, 
                        A1.USERNAME, 
                        P1.ROLE_CODE, 
                        P1.KEN_CODE, 
                        P1.CITY_CODE 
                    FROM USER_PROXY P1 
                    LEFT JOIN (
                        SELECT 
                            * 
                        FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                    WHERE 
                        A1.USERNAME=%(USERNAME)s"""
                SQL_SELECT_PROVISIONED_CONFIRMED = """
                    SELECT 
                        *
                    FROM PROVISIONED_CONFIRMED"""
                ### decoratorでビュー関数に変数を返す方法が不明のため、グローバル変数を使用した。
                global user_proxy_list
                global provisioned_confirmed_list
                user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
                provisioned_confirmed_list = PROVISIONED_CONFIRMED.objects.raw(SQL_SELECT_PROVISIONED_CONFIRMED)
        
                print_log('[DEBUG] P0400Online.custom_decorator()関数 user_proxy_list={}'.format(user_proxy_list), 'DEBUG')
                print_log('[DEBUG] P0400Online.custom_decorator()関数 len(user_proxy_list)={}'.format(len(user_proxy_list)), 'DEBUG')
                print_log('[DEBUG] P0400Online.custom_decorator()関数 provisioned_confirmed_list={}'.format(provisioned_confirmed_list), 'DEBUG')
                print_log('[DEBUG] P0400Online.custom_decorator()関数 len(provisioned_confirmed_list)={}'.format(len(provisioned_confirmed_list)), 'DEBUG')
                    
                ### デコレータの処理で警告が発生したら（user_proxy_listが正常に取得できなかったら）、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                if (user_proxy_list == False):
                    print_log('[WARN] P0400Online.custom_decorator()関数が警告終了しました。', 'WARN')
                    if (arg1 == 'index_view') or (
                        arg1 == 'cat1_cat2_ken_city_view'):
                        template = loader.get_template('P0400Online/index.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    else:
                        pass
                
                ### ここまで正常に処理できたら、ビュー関数を戻して、ビュー関数の処理に移行する。
                return view_func(request, *args, **kwargs)
            
            except:
                ### デコレータの処理で異常が発生したら、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                print_log('[WARN] P0400Online.custom_decorator()関数が異常終了しました。', 'WARN')
                if (arg1 == 'index_view') or (
                    arg1 == 'cat1_cat2_ken_city_view'):
                    template = loader.get_template('P0400Online/index.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                else:
                    pass
        
        return inner_wrapper
            
    return outer_wrapper

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### urlpattern：path('', views.index_view, name='index_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='index_view')
def index_view(request):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### KEN: 
        #######################################################################
        print_log('[DEBUG] P0400Online.index_view()関数 STEP 1/2.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0400Online.index_view()関数 STEP 2/2.', 'DEBUG')
        template = loader.get_template('P0400Online/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'role_code': user_proxy_list[0].role_code, 
            'ken_list': ken_list, 
        }
        print_log('[INFO] P0400Online.index_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0400Online.index_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0400Online.index_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0400Online.index_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0400Online/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数
### urlpattern：path('cat1/<slug:cat1>/cat2/<slug:cat2>/ken/<slug:ken_code>/city/<slug:city_code>/', views.cat1_cat2_ken_city_view, name='cat1_cat2_ken_city_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='cat1_cat2_ken_city_view')
def cat1_cat2_ken_city_view(request, cat1, cat2, ken_code, city_code):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[INFO] P0400Online.cat1_cat2_ken_city_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 cat1={}'.format(cat1), 'DEBUG')
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 cat2={}'.format(cat2), 'DEBUG')
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 ken_code={}'.format(ken_code), 'DEBUG')
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 city_code={}'.format(city_code), 'DEBUG')

        if cat1 not in [
                _CAT0, _CAT1, _CAT2, _CAT3, _CAT4
            ]:
            template = loader.get_template('P0400Online/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        ### if cat2 not in [
        ###         '0', _BUILDING, _KEN, _CITY, _KASEN_KAIGAN, _SUIKEI, _SUIKEI_TYPE, _KASEN, _KASEN_TYPE, _CAUSE, _UNDERGROUND,
        ###         _USAGE, _FLOOD_SEDIMENT, _GRADIENT, _INDUSTRY, _BUSINESS, _HOUSE_ASSET, _HOUSE_RATE, _HOUSE_ALT, _HOUSE_CLEAN, _HOUSEHOLD_ASSET,
        ###         _HOUSEHOLD_RATE, _CAR_ASSET, _CAR_RATE, _OFFICE_ASSET, _OFFICE_RATE, _OFFICE_SUSPEND, _OFFICE_STAGNATE, _OFFICE_ALT, _FARMER_FISHER_ASSET, _FARMER_FISHER_RATE,
        ###         _AREA, _WEATHER, _IPPAN_HEADER, _IPPAN, _CHITAN_HEADER, _CHITAN, _HOJO_HEADER, _HOJO, _KOEKI_HEADER, _KOEKI,
        ###         _IPPAN_SUMMARY, _CHITAN_SUMMARY, _HOJO_SUMMARY, _KOEKI_SUMMARY, _ACTION, _STATUS, _IPPAN_TRIGGER, _CHITAN_TRIGGER, _HOJO_TRIGGER, _KOEKI_TRIGGER
        ###         ]:
        ###     template = loader.get_template('P0400Online/index.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))
        if cat2 not in [
                '0', _BUILDING, _KEN, _CITY, _KASEN_KAIGAN, _SUIKEI, _SUIKEI_TYPE, _KASEN, _KASEN_TYPE, _CAUSE, _UNDERGROUND,
                _USAGE, _FLOOD_SEDIMENT, _GRADIENT, _INDUSTRY, _BUSINESS, _HOUSE_ASSET, _HOUSE_RATE, _HOUSE_ALT, _HOUSE_CLEAN, _HOUSEHOLD_ASSET,
                _HOUSEHOLD_RATE, _CAR_ASSET, _CAR_RATE, _OFFICE_ASSET, _OFFICE_RATE, _OFFICE_SUSPEND, _OFFICE_STAGNATE, _OFFICE_ALT, _FARMER_FISHER_ASSET, _FARMER_FISHER_RATE,
                _WEATHER, _IPPAN_HEADER, _IPPAN, _CHITAN_HEADER, _CHITAN, _HOJO_HEADER, _HOJO, _KOEKI_HEADER, _KOEKI,
                _IPPAN_SUMMARY, _CHITAN_SUMMARY, _HOJO_SUMMARY, _KOEKI_SUMMARY, _ACTION, _STATUS, _IPPAN_TRIGGER, _CHITAN_TRIGGER, _HOJO_TRIGGER, _KOEKI_TRIGGER
                ]:
            template = loader.get_template('P0400Online/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0020)
        ### CITY: 
        #######################################################################
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 STEP 2/5.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(ken_code AS INTEGER)""")
        
        if ken_code == '0':
            city_list = CITY.objects.raw("""
                SELECT 
                    CT1.city_code, 
                    CT1.city_name, 
                    CT1.ken_code, 
                    KE1.ken_name, 
                    CASE WHEN (CT1.city_population) IS NULL THEN 0.00 ELSE CAST(CT1.city_population AS NUMERIC(20,10)) END AS city_population, 
                    CASE WHEN (CT1.city_area) IS NULL THEN 0.00 ELSE CAST(CT1.city_area AS NUMERIC(20,10)) END AS city_area 
                FROM CITY CT1 
                LEFT JOIN KEN KE1 ON CT1.ken_code=KE1.ken_code 
                ORDER BY 
                    CAST(CT1.CITY_CODE AS INTEGER)""")
        else:
            params = dict({
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code
            })
            city_list = CITY.objects.raw("""
                SELECT 
                    CT1.city_code, 
                    CT1.city_name, 
                    CT1.ken_code, 
                    KE1.ken_name, 
                    CASE WHEN (CT1.city_population) IS NULL THEN 0.0 ELSE CAST(CT1.city_population AS NUMERIC(20,10)) END AS city_population, 
                    CASE WHEN (CT1.city_area) IS NULL THEN 0.0 ELSE CAST(CT1.city_area AS NUMERIC(20,10)) END AS city_area 
                FROM CITY CT1 
                LEFT JOIN KEN KE1 ON CT1.ken_code=KE1.ken_code 
                WHERE 
                    CT1.KEN_CODE=%(KEN_CODE)s 
                ORDER BY 
                    CAST(CT1.CITY_CODE AS INTEGER)""", params)
        
        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 STEP 3/5.', 'DEBUG')
        building_list = []                             ### 1000: マスタデータ_建物区分
        kasen_kaigan_list = []                         ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
        suikei_list = []                               ### 1040: マスタデータ_水系（水系・沿岸）
        suikei_type_list = []                          ### 1050: マスタデータ_水系種別（水系・沿岸種別）
        kasen_list = []                                ### 1060: マスタデータ_河川（河川・海岸）
        kasen_type_list = []                           ### 1070: マスタデータ_河川種別（河川・海岸種別）
        cause_list = []                                ### 1080: マスタデータ_水害原因
        underground_list = []                          ### 1090: マスタデータ_地上地下区分
        usage_list = []                                ### 1100: マスタデータ_地下空間の利用形態
        flood_sediment_list = []                       ### 1110: マスタデータ_浸水土砂区分
        gradient_list = []                             ### 1120: マスタデータ_地盤勾配区分
        industry_list = []                             ### 1130: マスタデータ_一般資産調査員調査票_産業分類
        business_list = []                             ### 1140: マスタデータ_公益事業等調査票_事業分類
        house_asset_list = []                          ### 2000: マスタデータ_家屋評価額
        house_rate_list = []                           ### 2010: マスタデータ_家屋被害率
        house_alt_list = []                            ### 2020: マスタデータ_家庭応急対策費_代替活動費
        house_clean_list = []                          ### 2030: マスタデータ_家庭応急対策費_清掃日数
        household_asset_list = []                      ### 3000: マスタデータ_家庭用品自動車以外所有額
        household_rate_list = []                       ### 3010: マスタデータ_家庭用品自動車以外被害率
        car_asset_list = []                            ### 4000: マスタデータ_家庭用品自動車所有額
        car_rate_list = []                             ### 4010: マスタデータ_家庭用品自動車被害率
        office_asset_list = []                         ### 5000: マスタデータ_事業所資産額
        office_rate_list = []                          ### 5010: マスタデータ_事業所被害率
        office_suspend_list = []                       ### 5020: マスタデータ_事業所営業停止日数
        office_stagnate_list = []                      ### 5030: マスタデータ_事業所営業停滞日数
        office_alt_list = []                           ### 5040: マスタデータ_事業所応急対策費_代替活動費
        farmer_fisher_asset_list = []                  ### 6000: マスタデータ_農漁家資産額
        farmer_fisher_rate_list = []                   ### 6010: マスタデータ_農漁家被害率
        ### area_list = []                             ### 7000: アップロードデータ_水害区域
        weather_list = []                              ### 7010: アップロードデータ_異常気象
        ippan_header_list = []                         ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
        ippan_list = []                                ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
        chitan_header_list = []                        ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
        chitan_list = []                               ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
        hojo_header_list = []                          ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
        hojo_list = []                                 ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
        koeki_header_list = []                         ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
        koeki_list = []                                ### 7100: アップロードデータ_公益事業等調査票_一覧表部分
        ippan_summary_list = []                        ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
        chitan_summary_list = []                       ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
        hojo_summary_list = []                         ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
        koeki_summary_list = []                        ### 8030: 集計データ_公益事業等調査票_一覧表部分
        action_list = []                               ### 10000: マスタデータ_アクション
        status_list = []                               ### 10010: マスタデータ_状態
        ippan_trigger_list = []                        ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
        chitan_trigger_list = []                       ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
        hojo_trigger_list = []                         ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
        koeki_trigger_list = []                        ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ
        
        #######################################################################
        ### DBアクセス処理(0040)
        #######################################################################
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 STEP 4/5.', 'DEBUG')
        ### 参照するデータの種別を選択してください。
        if cat2 == '0':
            pass
        
        ### マスタデータ_建物区分: BUILDING
        elif cat2 == _BUILDING:
            building_list = BUILDING.objects.raw("""
                SELECT 
                    building_code, 
                    building_name 
                FROM BUILDING 
                -- WHERE building_code='100'
                ORDER BY 
                    CAST(building_code AS INTEGER)""")
            
            ### if building_list is None: ### NG
            ###     print_log('[DEBUG] building_list is None', 'DEBUG')

            ### if building_list == None: ### NG
            ###     print_log('[DEBUG] building_list == None', 'DEBUG')

            ### if building_list == []: ### NG
            ###     print_log('[DEBUG] building_list == []', 'DEBUG')

            ### if not building_list: ### OK
            ###     print_log('[DEBUG] not building_list', 'DEBUG')

            ### if building_list: ### OK
            ###     print_log('[DEBUG] building_list', 'DEBUG')

            ### if bool(building_list) == False: ### OK
            ###     print_log('[DEBUG] bool(building_list) == False', 'DEBUG')

            ### if bool(building_list) == True: ### OK
            ###     print_log('[DEBUG] bool(building_list) == True', 'DEBUG')
            
        ### マスタデータ_都道府県: KEN
        elif cat2 == _KEN:
            pass
        
        ### マスタデータ_市区町村: CITY
        elif cat2 == _CITY:
            pass
        
        ### マスタデータ_水害発生地点工種（河川海岸区分）: KASEN_KAIGAN
        elif cat2 == _KASEN_KAIGAN:
            kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""
                SELECT 
                    kasen_kaigan_code, 
                    kasen_kaigan_name 
                FROM KASEN_KAIGAN 
                ORDER BY 
                    CAST(kasen_kaigan_code AS INTEGER)""")
            
        ### マスタデータ_水系（水系・沿岸）: SUIKEI
        elif cat2 == _SUIKEI:
            ### suikei_list = SUIKEI.objects.raw(""" ### 2024/11/21 COMMENT OUT
            ###     SELECT 
            ###         SK1.suikei_code, 
            ###         SK1.suikei_name, 
            ###         SK1.suikei_type_code, 
            ###         ST1.suikei_type_name 
            ###     FROM SUIKEI SK1 
            ###     LEFT JOIN SUIKEI_TYPE ST1 ON SK1.suikei_type_code=ST1.suikei_type_code 
            ###     ORDER BY 
            ###         CAST(SK1.suikei_code AS INTEGER)""")
            suikei_list = SUIKEI.objects.raw("""
                SELECT 
                    SK1.SUIKEI_CODE, 
                    SK1.SUIKEI_NAME, 
                    SK1.SUIKEI_TYPE_CODE, 
                    ST1.SUIKEI_TYPE_NAME,
                    SK1.KEN_CODE
                FROM SUIKEI SK1 
                LEFT JOIN SUIKEI_TYPE ST1 ON SK1.SUIKEI_TYPE_CODE=ST1.SUIKEI_TYPE_CODE 
                ORDER BY 
                    CAST(SK1.SUIKEI_CODE AS INTEGER)""") ### 2024/11/21 ADD
            
        ### マスタデータ_水系種別（水系・沿岸種別）: SUIKEI_TYPE
        elif cat2 == _SUIKEI_TYPE:
            suikei_type_list = SUIKEI_TYPE.objects.raw("""
                SELECT 
                    suikei_type_code, 
                    suikei_type_name 
                FROM SUIKEI_TYPE 
                ORDER BY 
                    CAST(suikei_type_code AS INTEGER)""")
            
        ### マスタデータ_河川（河川・海岸）: KASEN
        elif cat2 == _KASEN:
            kasen_list = KASEN.objects.raw("""
                SELECT 
                    KA1.kasen_code, 
                    KA1.kasen_name, 
                    KA1.kasen_type_code, 
                    KT1.kasen_type_name, 
                    SK1.suikei_code, 
                    SK1.suikei_name 
                FROM KASEN KA1 
                LEFT JOIN KASEN_TYPE KT1 ON KA1.kasen_type_code=KT1.kasen_type_code 
                LEFT JOIN SUIKEI SK1 ON KA1.suikei_code=SK1.suikei_code 
                ORDER BY 
                    CAST(KA1.kasen_code AS INTEGER)""")
            
        ### マスタデータ_河川種別（河川・海岸種別）: KASEN_TYPE
        elif cat2 == _KASEN_TYPE:
            kasen_type_list = KASEN_TYPE.objects.raw("""
                SELECT 
                    kasen_type_code, 
                    kasen_type_name 
                FROM KASEN_TYPE 
                ORDER BY 
                    CAST(kasen_type_code AS INTEGER)""")
            
        ### マスタデータ_水害原因: CAUSE
        elif cat2 == _CAUSE:
            cause_list = CAUSE.objects.raw("""
                SELECT 
                    cause_code, 
                    cause_name 
                FROM CAUSE 
                ORDER BY 
                    CAST(cause_code AS INTEGER)""")
            
        ### マスタデータ_地上地下区分: UNDERGROUND
        elif cat2 == _UNDERGROUND:
            underground_list = UNDERGROUND.objects.raw("""
                SELECT 
                    underground_code, 
                    underground_name 
                FROM UNDERGROUND 
                ORDER BY 
                    CAST(underground_code AS INTEGER)""")
            
        ### マスタデータ_地下空間の利用形態: USAGE
        elif cat2 == _USAGE:
            usage_list = USAGE.objects.raw("""
                SELECT 
                    usage_code, 
                    usage_name 
                FROM USAGE 
                ORDER BY 
                    CAST(usage_code AS INTEGER)""")
            
        ### マスタデータ_浸水土砂区分: FLOOD_SEDIMENT
        elif cat2 == _FLOOD_SEDIMENT:
            flood_sediment_list = FLOOD_SEDIMENT.objects.raw("""
                SELECT 
                    flood_sediment_code, 
                    flood_sediment_name 
                FROM FLOOD_SEDIMENT 
                ORDER BY 
                    CAST(flood_sediment_code AS INTEGER)""")
            
        ### マスタデータ_地盤勾配区分: GRADIENT
        elif cat2 == _GRADIENT:
            gradient_list = GRADIENT.objects.raw("""
                SELECT 
                    gradient_code, 
                    gradient_name 
                FROM GRADIENT 
                ORDER BY 
                    CAST(gradient_code AS INTEGER)""")
            
        ### マスタデータ_一般資産調査員調査票_産業分類: INDUSTRY
        elif cat2 == _INDUSTRY:
            industry_list = INDUSTRY.objects.raw("""
                SELECT 
                    industry_code, 
                    industry_name 
                FROM INDUSTRY 
                ORDER BY 
                    CAST(industry_code AS INTEGER)""")

        ### マスタデータ_公益事業等調査票_事業分類: BUSINESS
        elif cat2 == _BUSINESS:
            business_list = BUSINESS.objects.raw("""
                SELECT 
                    business_code, 
                    business_name 
                FROM BUSINESS 
                ORDER BY 
                    CAST(business_code AS INTEGER)""")
            
        ### マスタデータ_家屋評価額: HOUSE_ASSET
        elif cat2 == _HOUSE_ASSET:
            house_asset_list = HOUSE_ASSET.objects.raw("""
                SELECT 
                    HA1.house_asset_code, 
                    HA1.ken_code, 
                    KE1.ken_name, 
                    CAST(HA1.house_asset AS NUMERIC(20,10)) AS house_asset 
                FROM HOUSE_ASSET HA1 
                LEFT JOIN KEN KE1 ON HA1.ken_code=KE1.ken_code 
                ORDER BY 
                    CAST(HA1.house_asset_code AS INTEGER)""")
            
        ### マスタデータ_家屋被害率: HOUSE_RATE
        elif cat2 == _HOUSE_RATE:
            house_rate_list = HOUSE_RATE.objects.raw("""
                SELECT 
                    HR1.house_rate_code, 
                    HR1.flood_sediment_code, 
                    FS1.flood_sediment_name, 
                    HR1.gradient_code, 
                    GR1.gradient_name, 
                    CAST(HR1.house_rate_lv00 AS NUMERIC(20,10)) AS house_rate_lv00, 
                    CAST(HR1.house_rate_lv00_50 AS NUMERIC(20,10)) AS house_rate_lv00_50, 
                    CAST(HR1.house_rate_lv50_100 AS NUMERIC(20,10)) AS house_rate_lv50_100, 
                    CAST(HR1.house_rate_lv100_200 AS NUMERIC(20,10)) AS house_rate_lv100_200, 
                    CAST(HR1.house_rate_lv200_300 AS NUMERIC(20,10)) AS house_rate_lv200_300, 
                    CAST(HR1.house_rate_lv300 AS NUMERIC(20,10)) AS house_rate_lv300 
                FROM HOUSE_RATE HR1 
                LEFT JOIN FLOOD_SEDIMENT FS1 ON HR1.flood_sediment_code=FS1.flood_sediment_code 
                LEFT JOIN GRADIENT GR1 ON HR1.gradient_code=GR1.gradient_code 
                ORDER BY 
                    CAST(HR1.house_rate_code AS INTEGER)""")
            
        ### マスタデータ_家庭応急対策費_代替活動費: HOUSE_ALT
        elif cat2 == _HOUSE_ALT:
            house_alt_list = HOUSE_ALT.objects.raw("""
                SELECT 
                    house_alt_code, 
                    CAST(house_alt_lv00 AS NUMERIC(20,10)) AS house_alt_lv00, 
                    CAST(house_alt_lv00_50 AS NUMERIC(20,10)) AS house_alt_lv00_50, 
                    CAST(house_alt_lv50_100 AS NUMERIC(20,10)) AS house_alt_lv50_100, 
                    CAST(house_alt_lv100_200 AS NUMERIC(20,10)) AS house_alt_lv100_200, 
                    CAST(house_alt_lv200_300 AS NUMERIC(20,10)) AS house_alt_lv200_300, 
                    CAST(house_alt_lv300 AS NUMERIC(20,10)) AS house_alt_lv300 
                FROM HOUSE_ALT 
                ORDER BY 
                    CAST(house_alt_code AS INTEGER)""")
            
        ### マスタデータ_家庭応急対策費_清掃日数: HOUSE_CLEAN
        elif cat2 == _HOUSE_CLEAN:
            house_clean_list = HOUSE_CLEAN.objects.raw("""
                SELECT 
                    house_clean_code, 
                    CAST(house_clean_days_lv00 AS NUMERIC(20,10)) AS house_clean_days_lv00, 
                    CAST(house_clean_days_lv00_50 AS NUMERIC(20,10)) AS house_clean_days_lv00_50, 
                    CAST(house_clean_days_lv50_100 AS NUMERIC(20,10)) AS house_clean_days_lv50_100, 
                    CAST(house_clean_days_lv100_200 AS NUMERIC(20,10)) AS house_clean_days_lv100_200, 
                    CAST(house_clean_days_lv200_300 AS NUMERIC(20,10)) AS house_clean_days_lv200_300, 
                    CAST(house_clean_days_lv300 AS NUMERIC(20,10)) AS house_clean_days_lv300, 
                    CAST(house_clean_unit_cost  AS NUMERIC(20,10)) AS house_clean_unit_cost
                FROM HOUSE_CLEAN 
                ORDER BY 
                    CAST(house_clean_code AS INTEGER)""")
            
        ### マスタデータ_家庭用品自動車以外所有額: HOUSEHOLD_ASSET
        elif cat2 == _HOUSEHOLD_ASSET:
            household_asset_list = HOUSEHOLD_ASSET.objects.raw("""
                SELECT 
                    household_asset_code, 
                    CAST(household_asset AS NUMERIC(20,10)) AS household_asset  
                FROM HOUSEHOLD_ASSET 
                ORDER BY 
                    CAST(household_asset_code AS INTEGER)""")
            
        ### マスタデータ_家庭用品自動車以外被害率: HOUSEHOLD_RATE
        elif cat2 == _HOUSEHOLD_RATE:
            household_rate_list = HOUSEHOLD_RATE.objects.raw("""
                SELECT 
                    HR1.household_rate_code, 
                    HR1.flood_sediment_code, 
                    FS1.flood_sediment_name, 
                    CAST(HR1.household_rate_lv00 AS NUMERIC(20,10)) AS household_rate_lv00, 
                    CAST(HR1.household_rate_lv00_50 AS NUMERIC(20,10)) AS household_rate_lv00_50, 
                    CAST(HR1.household_rate_lv50_100 AS NUMERIC(20,10)) AS household_rate_lv50_100, 
                    CAST(HR1.household_rate_lv100_200 AS NUMERIC(20,10)) AS household_rate_lv100_200, 
                    CAST(HR1.household_rate_lv200_300 AS NUMERIC(20,10)) AS household_rate_lv200_300, 
                    CAST(HR1.household_rate_lv300 AS NUMERIC(20,10)) AS household_rate_lv300 
                FROM HOUSEHOLD_RATE HR1 
                LEFT JOIN FLOOD_SEDIMENT FS1 ON HR1.flood_sediment_code=FS1.flood_sediment_code 
                ORDER BY 
                    CAST(HR1.household_rate_code AS INTEGER)""")
            
        ### マスタデータ_家庭用品自動車所有額: CAR_ASSET
        elif cat2 == _CAR_ASSET:
            car_asset_list = CAR_ASSET.objects.raw("""
                SELECT 
                    car_asset_code, 
                    CAST(car_asset AS NUMERIC(20,10)) AS car_asset 
                FROM CAR_ASSET 
                ORDER BY 
                    CAST(car_asset_code AS INTEGER)""")
            
        ### マスタデータ_家庭用品自動車被害率: CAR_RATE
        elif cat2 == _CAR_RATE:
            car_rate_list = CAR_RATE.objects.raw("""
                SELECT 
                    car_rate_code, 
                    CAST(car_rate_lv00 AS NUMERIC(20,10)) AS car_rate_lv00, 
                    CAST(car_rate_lv00_50 AS NUMERIC(20,10)) AS car_rate_lv00_50, 
                    CAST(car_rate_lv50_100 AS NUMERIC(20,10)) AS car_rate_lv50_100, 
                    CAST(car_rate_lv100_200 AS NUMERIC(20,10)) AS car_rate_lv100_200, 
                    CAST(car_rate_lv200_300 AS NUMERIC(20,10)) AS car_rate_lv200_300, 
                    CAST(car_rate_lv300 AS NUMERIC(20,10)) AS car_rate_lv300 
                FROM CAR_RATE 
                ORDER BY 
                    CAST(car_rate_code AS INTEGER)""")
            
        ### マスタデータ_事業所資産額: OFFICE_ASSET
        elif cat2 == _OFFICE_ASSET:
            office_asset_list = OFFICE_ASSET.objects.raw("""
                SELECT 
                    OA1.office_asset_code, 
                    OA1.industry_code, 
                    ID1.industry_name, 
                    CAST(OA1.office_dep_asset AS NUMERIC(20,10)) AS office_dep_asset, 
                    CAST(OA1.office_inv_asset AS NUMERIC(20,10)) AS office_inv_asset, 
                    CAST(OA1.office_va_asset AS NUMERIC(20,10)) AS office_va_asset 
                FROM OFFICE_ASSET OA1 
                LEFT JOIN INDUSTRY ID1 ON OA1.industry_code=ID1.industry_code 
                ORDER BY 
                    CAST(OA1.office_asset_code AS INTEGER)""")

        ### マスタデータ_事業所被害率: OFFICE_RATE
        elif cat2 == _OFFICE_RATE:
            office_rate_list = OFFICE_RATE.objects.raw("""
                SELECT 
                    OR1.office_rate_code, 
                    OR1.flood_sediment_code, 
                    FS1.flood_sediment_name, 
                    CAST(OR1.office_dep_rate_lv00 AS NUMERIC(20,10)) AS office_dep_rate_lv00, 
                    CAST(OR1.office_dep_rate_lv00_50 AS NUMERIC(20,10)) AS office_dep_rate_lv00_50, 
                    CAST(OR1.office_dep_rate_lv50_100 AS NUMERIC(20,10)) AS office_dep_rate_lv50_100, 
                    CAST(OR1.office_dep_rate_lv100_200 AS NUMERIC(20,10)) AS office_dep_rate_lv100_200, 
                    CAST(OR1.office_dep_rate_lv200_300 AS NUMERIC(20,10)) AS office_dep_rate_lv200_300, 
                    CAST(OR1.office_dep_rate_lv300 AS NUMERIC(20,10)) AS office_dep_rate_lv300, 
                    CAST(OR1.office_inv_rate_lv00 AS NUMERIC(20,10)) AS office_inv_rate_lv00, 
                    CAST(OR1.office_inv_rate_lv00_50 AS NUMERIC(20,10)) AS office_inv_rate_lv00_50, 
                    CAST(OR1.office_inv_rate_lv50_100 AS NUMERIC(20,10)) AS office_inv_rate_lv50_100, 
                    CAST(OR1.office_inv_rate_lv100_200 AS NUMERIC(20,10)) AS office_inv_rate_lv100_200, 
                    CAST(OR1.office_inv_rate_lv200_300 AS NUMERIC(20,10)) AS office_inv_rate_lv200_300, 
                    CAST(OR1.office_inv_rate_lv300 AS NUMERIC(20,10)) AS office_inv_rate_lv300 
                FROM OFFICE_RATE OR1 
                LEFT JOIN FLOOD_SEDIMENT FS1 ON OR1.flood_sediment_code=FS1.flood_sediment_code 
                ORDER BY 
                    CAST(OR1.office_rate_code AS INTEGER)""")

        ### マスタデータ_事業所営業停止日数: OFFICE_SUSPEND
        elif cat2 == _OFFICE_SUSPEND:
            office_suspend_list = OFFICE_SUSPEND.objects.raw("""
                SELECT 
                    office_sus_code, 
                    CAST(office_sus_days_lv00 AS NUMERIC(20,10)) AS office_sus_days_lv00, 
                    CAST(office_sus_days_lv00_50 AS NUMERIC(20,10)) AS office_sus_days_lv00_50, 
                    CAST(office_sus_days_lv50_100 AS NUMERIC(20,10)) AS office_sus_days_lv50_100, 
                    CAST(office_sus_days_lv100_200 AS NUMERIC(20,10)) AS office_sus_days_lv100_200, 
                    CAST(office_sus_days_lv200_300 AS NUMERIC(20,10)) AS office_sus_days_lv200_300, 
                    CAST(office_sus_days_lv300 AS NUMERIC(20,10)) AS office_sus_days_lv300 
                FROM OFFICE_SUSPEND 
                ORDER BY 
                    CAST(office_sus_code AS INTEGER)""")
            
        ### マスタデータ_事業所営業停滞日数: OFFICE_STAGNATE
        elif cat2 == _OFFICE_STAGNATE:
            office_stagnate_list = OFFICE_STAGNATE.objects.raw("""
                SELECT 
                    office_stg_code, 
                    CAST(office_stg_days_lv00 AS NUMERIC(20,10)) AS office_stg_days_lv00, 
                    CAST(office_stg_days_lv00_50 AS NUMERIC(20,10)) AS office_stg_days_lv00_50, 
                    CAST(office_stg_days_lv50_100 AS NUMERIC(20,10)) AS office_stg_days_lv50_100, 
                    CAST(office_stg_days_lv100_200 AS NUMERIC(20,10)) AS office_stg_days_lv100_200, 
                    CAST(office_stg_days_lv200_300 AS NUMERIC(20,10)) AS office_stg_days_lv200_300, 
                    CAST(office_stg_days_lv300 AS NUMERIC(20,10)) AS office_stg_days_lv300 
                FROM OFFICE_STAGNATE 
                ORDER BY 
                    CAST(office_stg_code AS INTEGER)""")

        ### マスタデータ_事業所応急対策費_代替活動費: OFFICE_ALT
        elif cat2 == _OFFICE_ALT:
            office_alt_list = OFFICE_ALT.objects.raw("""
                SELECT 
                    office_alt_code, 
                    CAST(office_alt_lv00 AS NUMERIC(20,10)) AS office_alt_lv00, 
                    CAST(office_alt_lv00_50 AS NUMERIC(20,10)) AS office_alt_lv00_50, 
                    CAST(office_alt_lv50_100 AS NUMERIC(20,10)) AS office_alt_lv50_100, 
                    CAST(office_alt_lv100_200 AS NUMERIC(20,10)) AS office_alt_lv100_200, 
                    CAST(office_alt_lv200_300 AS NUMERIC(20,10)) AS office_alt_lv200_300, 
                    CAST(office_alt_lv300 AS NUMERIC(20,10)) AS office_alt_lv300 
                FROM OFFICE_ALT 
                ORDER BY 
                    CAST(office_alt_code AS INTEGER)""")
            
        ### マスタデータ_農漁家資産額: FARMER_FISHER_ASSET
        elif cat2 == _FARMER_FISHER_ASSET:
            farmer_fisher_asset_list = FARMER_FISHER_ASSET.objects.raw("""
                SELECT 
                    farmer_fisher_asset_code, 
                    CAST(farmer_fisher_dep_asset AS NUMERIC(20,10)) AS farmer_fisher_dep_asset, 
                    CAST(farmer_fisher_inv_asset AS NUMERIC(20,10)) AS farmer_fisher_inv_asset 
                FROM FARMER_FISHER_ASSET 
                ORDER BY 
                    CAST(farmer_fisher_asset_code AS INTEGER)""")

        ### マスタデータ_農漁家被害率: FARMER_FISHER_RATE
        elif cat2 == _FARMER_FISHER_RATE:
            farmer_fisher_rate_list = FARMER_FISHER_RATE.objects.raw("""
                SELECT 
                    FFR1.farmer_fisher_rate_code, 
                    FFR1.flood_sediment_code, 
                    FS1.flood_sediment_name, 
                    CAST(FFR1.farmer_fisher_dep_rate_lv00 AS NUMERIC(20,10)) AS farmer_fisher_dep_rate_lv00, 
                    CAST(FFR1.farmer_fisher_dep_rate_lv00_50 AS NUMERIC(20,10)) AS farmer_fisher_dep_rate_lv00_50, 
                    CAST(FFR1.farmer_fisher_dep_rate_lv50_100 AS NUMERIC(20,10)) AS farmer_fisher_dep_rate_lv50_100, 
                    CAST(FFR1.farmer_fisher_dep_rate_lv100_200 AS NUMERIC(20,10)) AS farmer_fisher_dep_rate_lv100_200, 
                    CAST(FFR1.farmer_fisher_dep_rate_lv200_300 AS NUMERIC(20,10)) AS farmer_fisher_dep_rate_lv200_300, 
                    CAST(FFR1.farmer_fisher_dep_rate_lv300 AS NUMERIC(20,10)) AS farmer_fisher_dep_rate_lv300, 
                    CAST(FFR1.farmer_fisher_inv_rate_lv00 AS NUMERIC(20,10)) AS farmer_fisher_inv_rate_lv00, 
                    CAST(FFR1.farmer_fisher_inv_rate_lv00_50 AS NUMERIC(20,10)) AS farmer_fisher_inv_rate_lv00_50, 
                    CAST(FFR1.farmer_fisher_inv_rate_lv50_100 AS NUMERIC(20,10)) AS farmer_fisher_inv_rate_lv50_100, 
                    CAST(FFR1.farmer_fisher_inv_rate_lv100_200 AS NUMERIC(20,10)) AS farmer_fisher_inv_rate_lv100_200, 
                    CAST(FFR1.farmer_fisher_inv_rate_lv200_300 AS NUMERIC(20,10)) ASfarmer_fisher_inv_rate_lv200_300, 
                    CAST(FFR1.farmer_fisher_inv_rate_lv300 AS NUMERIC(20,10)) AS farmer_fisher_inv_rate_lv300 
                FROM FARMER_FISHER_RATE FFR1 
                LEFT JOIN FLOOD_SEDIMENT FS1 ON FFR1.flood_sediment_code=FS1.flood_sediment_code 
                ORDER BY 
                    CAST(FFR1.farmer_fisher_rate_code AS INTEGER)""")

        ### アップロードデータ_水害区域: AREA
            
        ### アップロードデータ_異常気象: WEATHER
        elif cat2 == _WEATHER:
            weather_list = WEATHER.objects.raw("""
                SELECT 
                    WE1.weather_id, 
                    WE1.weather_name, 
                    TO_CHAR(timezone('JST', WE1.begin_date::timestamptz), 'yyyy/mm/dd') AS begin_date, 
                    TO_CHAR(timezone('JST', WE1.end_date::timestamptz), 'yyyy/mm/dd') AS end_date, 
                    WE1.ken_code, 
                    KE1.ken_name 
                FROM WEATHER WE1 
                LEFT JOIN KEN KE1 ON WE1.ken_code=KE1.ken_code 
                ORDER BY 
                    CAST(WE1.weather_id AS INTEGER)""")
            
        ### アップロードデータ_一般資産調査員調査票_ヘッダ部分: IPPAN_HEADER
        elif cat2 == _IPPAN_HEADER:
            if ken_code == '0' and city_code == '0': 
                ippan_header_list = IPPAN_HEADER.objects.raw("""
                    SELECT 
                        SG1.IPPAN_HEADER_ID, 
                        SG1.IPPAN_HEADER_NAME, 
                        SG1.KEN_CODE, 
                        KE1.KEN_NAME, 
                        SG1.CITY_CODE, 
                        CT1.CITY_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE, 
                        TO_CHAR(TIMEZONE('JST', SG1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE, 
                        SG1.CAUSE_1_CODE, 
                        CA1.CAUSE_NAME AS CAUSE_1_NAME, 
                        SG1.CAUSE_2_CODE, 
                        CA2.CAUSE_NAME AS CAUSE_2_NAME, 
                        SG1.CAUSE_3_CODE, 
                        CA3.CAUSE_NAME AS CAUSE_3_NAME, 
                        SG1.KUIKI_ID, 
                        SG1.SUIKEI_CODE, 
                        SK1.SUIKEI_NAME, 
                        SG1.SUIKEI_TYPE_CODE, -- 2024/11/15 ADD
                        ST1.SUIKEI_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.KASEN_CODE, 
                        KA1.KASEN_NAME, 
                        SG1.KASEN_TYPE_CODE, -- 2024/11/15 ADD
                        KT1.KASEN_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.GRADIENT_CODE, 
                        GR1.GRADIENT_NAME, 
                        CAST(SG1.RESIDENTIAL_AREA AS NUMERIC(20,10)) AS RESIDENTIAL_AREA, 
                        CAST(SG1.AGRICULTURAL_AREA AS NUMERIC(20,10)) AS AGRICULTURAL_AREA, 
                        CAST(SG1.UNDERGROUND_AREA AS NUMERIC(20,10)) AS UNDERGROUND_AREA, 
                        SG1.KASEN_KAIGAN_CODE, 
                        KK1.KASEN_KAIGAN_NAME, 
                        CAST(SG1.CROP_DAMAGE AS NUMERIC(20,10)) AS CROP_DAMAGE, 
                        SG1.WEATHER_ID, 
                        WE1.WEATHER_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                        TO_CHAR(TIMEZONE('JST', SG1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                        SG1.UPLOAD_FILE_PATH, 
                        SG1.UPLOAD_FILE_NAME, 
                        SG1.SUMMARY_FILE_PATH, 
                        SG1.SUMMARY_FILE_NAME 
                    FROM IPPAN_HEADER SG1 
                    LEFT JOIN KEN KE1 ON SG1.KEN_CODE=KE1.KEN_CODE 
                    LEFT JOIN CITY CT1 ON SG1.CITY_CODE=CT1.CITY_CODE 
                    LEFT JOIN CAUSE CA1 ON SG1.CAUSE_1_CODE=CA1.CAUSE_CODE 
                    LEFT JOIN CAUSE CA2 ON SG1.CAUSE_2_CODE=CA2.CAUSE_CODE 
                    LEFT JOIN CAUSE CA3 ON SG1.CAUSE_3_CODE=CA3.CAUSE_CODE 
                    LEFT JOIN SUIKEI SK1 ON SG1.SUIKEI_CODE=SK1.SUIKEI_CODE
                    LEFT JOIN SUIKEI_TYPE ST1 ON SG1.SUIKEI_TYPE_CODE=ST1.SUIKEI_TYPE_CODE -- 2024/11/15 ADD
                    LEFT JOIN KASEN KA1 ON SG1.KASEN_CODE=KA1.KASEN_CODE 
                    LEFT JOIN KASEN_TYPE KT1 ON SG1.KASEN_TYPE_CODE=KT1.KASEN_TYPE_CODE    -- 2024/11/15 ADD
                    LEFT JOIN GRADIENT GR1 ON SG1.GRADIENT_CODE=GR1.GRADIENT_CODE 
                    LEFT JOIN KASEN_KAIGAN KK1 ON SG1.KASEN_KAIGAN_CODE=KK1.KASEN_KAIGAN_CODE 
                    LEFT JOIN WEATHER WE1 ON SG1.WEATHER_ID=WE1.WEATHER_ID 
                    WHERE 
                        SG1.DELETED_AT IS NULL 
                    ORDER BY 
                        CAST(SG1.IPPAN_HEADER_ID AS INTEGER)""")
                
            elif ken_code == '0' and city_code != '0':
                params = dict({
                    'KEN_CODE': ken_code, 
                    'CITY_CODE': city_code
                })
                ippan_header_list = IPPAN_HEADER.objects.raw("""
                    SELECT 
                        SG1.IPPAN_HEADER_ID, 
                        SG1.IPPAN_HEADER_NAME, 
                        SG1.KEN_CODE, 
                        KE1.KEN_NAME, 
                        SG1.CITY_CODE, 
                        CT1.CITY_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE, 
                        TO_CHAR(TIMEZONE('JST', SG1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE, 
                        SG1.CAUSE_1_CODE, 
                        CA1.CAUSE_NAME AS CAUSE_1_NAME, 
                        SG1.CAUSE_2_CODE, 
                        CA2.CAUSE_NAME AS CAUSE_2_NAME, 
                        SG1.CAUSE_3_CODE, 
                        CA3.CAUSE_NAME AS CAUSE_3_NAME, 
                        SG1.KUIKI_ID, 
                        SG1.SUIKEI_CODE, 
                        SK1.SUIKEI_NAME, 
                        SG1.SUIKEI_TYPE_CODE, -- 2024/11/15 ADD
                        ST1.SUIKEI_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.KASEN_CODE, 
                        KA1.KASEN_NAME, 
                        SG1.KASEN_TYPE_CODE, -- 2024/11/15 ADD
                        KT1.KASEN_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.GRADIENT_CODE, 
                        GR1.GRADIENT_NAME, 
                        CAST(SG1.RESIDENTIAL_AREA AS NUMERIC(20,10)) AS RESIDENTIAL_AREA, 
                        CAST(SG1.AGRICULTURAL_AREA AS NUMERIC(20,10)) AS AGRICULTURAL_AREA, 
                        CAST(SG1.UNDERGROUND_AREA AS NUMERIC(20,10)) AS UNDERGROUND_AREA, 
                        SG1.KASEN_KAIGAN_CODE, 
                        KK1.KASEN_KAIGAN_NAME, 
                        CAST(SG1.CROP_DAMAGE AS NUMERIC(20,10)) AS CROP_DAMAGE, 
                        SG1.WEATHER_ID, 
                        WE1.WEATHER_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                        TO_CHAR(TIMEZONE('JST', SG1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                        SG1.UPLOAD_FILE_PATH, 
                        SG1.UPLOAD_FILE_NAME, 
                        SG1.SUMMARY_FILE_PATH, 
                        SG1.SUMMARY_FILE_NAME 
                    FROM IPPAN_HEADER SG1 
                    LEFT JOIN KEN KE1 ON SG1.KEN_CODE=KE1.KEN_CODE 
                    LEFT JOIN CITY CT1 ON SG1.CITY_CODE=CT1.CITY_CODE 
                    LEFT JOIN CAUSE CA1 ON SG1.CAUSE_1_CODE=CA1.CAUSE_CODE 
                    LEFT JOIN CAUSE CA2 ON SG1.CAUSE_2_CODE=CA2.CAUSE_CODE 
                    LEFT JOIN CAUSE CA3 ON SG1.CAUSE_3_CODE=CA3.CAUSE_CODE 
                    LEFT JOIN SUIKEI SK1 ON SG1.SUIKEI_CODE=SK1.SUIKEI_CODE
                    LEFT JOIN SUIKEI_TYPE ST1 ON SG1.SUIKEI_TYPE_CODE=ST1.SUIKEI_TYPE_CODE -- 2024/11/15 ADD
                    LEFT JOIN KASEN KA1 ON SG1.KASEN_CODE=KA1.KASEN_CODE 
                    LEFT JOIN KASEN_TYPE KT1 ON SG1.KASEN_TYPE_CODE=KT1.KASEN_TYPE_CODE    -- 2024/11/15 ADD
                    LEFT JOIN GRADIENT GR1 ON SG1.GRADIENT_CODE=GR1.GRADIENT_CODE 
                    LEFT JOIN KASEN_KAIGAN KK1 ON SG1.KASEN_KAIGAN_CODE=KK1.KASEN_KAIGAN_CODE 
                    LEFT JOIN WEATHER WE1 ON SG1.WEATHER_ID=WE1.WEATHER_ID 
                    WHERE 
                        SG1.CITY_CODE=%(CITY_CODE)S AND 
                        SG1.DELETED_AT IS NULL 
                    ORDER BY 
                        CAST(SG1.IPPAN_HEADER_ID AS INTEGER)""", PARAMS)
            
            elif ken_code != '0' and city_code == '0':
                params = dict({
                    'KEN_CODE': ken_code, 
                    'CITY_CODE': city_code
                })
                ippan_header_list = IPPAN_HEADER.objects.raw("""
                    SELECT 
                        SG1.IPPAN_HEADER_ID, 
                        SG1.IPPAN_HEADER_NAME, 
                        SG1.KEN_CODE, 
                        KE1.KEN_NAME, 
                        SG1.CITY_CODE, 
                        CT1.CITY_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE, 
                        TO_CHAR(TIMEZONE('JST', SG1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE, 
                        SG1.CAUSE_1_CODE, 
                        CA1.CAUSE_NAME AS CAUSE_1_NAME, 
                        SG1.CAUSE_2_CODE, 
                        CA2.CAUSE_NAME AS CAUSE_2_NAME, 
                        SG1.CAUSE_3_CODE, 
                        CA3.CAUSE_NAME AS CAUSE_3_NAME, 
                        SG1.KUIKI_ID, 
                        SG1.SUIKEI_CODE, 
                        SK1.SUIKEI_NAME, 
                        SG1.SUIKEI_TYPE_CODE, -- 2024/11/15 ADD
                        ST1.SUIKEI_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.KASEN_CODE, 
                        KA1.KASEN_NAME, 
                        SG1.KASEN_TYPE_CODE, -- 2024/11/15 ADD
                        KT1.KASEN_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.GRADIENT_CODE, 
                        GR1.GRADIENT_NAME, 
                        CAST(SG1.RESIDENTIAL_AREA AS NUMERIC(20,10)) AS RESIDENTIAL_AREA, 
                        CAST(SG1.AGRICULTURAL_AREA AS NUMERIC(20,10)) AS AGRICULTURAL_AREA, 
                        CAST(SG1.UNDERGROUND_AREA AS NUMERIC(20,10)) AS UNDERGROUND_AREA, 
                        SG1.KASEN_KAIGAN_CODE, 
                        KK1.KASEN_KAIGAN_NAME, 
                        CAST(SG1.CROP_DAMAGE AS NUMERIC(20,10)) AS CROP_DAMAGE, 
                        SG1.WEATHER_ID, 
                        WE1.WEATHER_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                        TO_CHAR(TIMEZONE('JST', SG1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                        SG1.UPLOAD_FILE_PATH, 
                        SG1.UPLOAD_FILE_NAME, 
                        SG1.SUMMARY_FILE_PATH, 
                        SG1.SUMMARY_FILE_NAME 
                    FROM IPPAN_HEADER SG1 
                    LEFT JOIN KEN KE1 ON SG1.KEN_CODE=KE1.KEN_CODE 
                    LEFT JOIN CITY CT1 ON SG1.CITY_CODE=CT1.CITY_CODE 
                    LEFT JOIN CAUSE CA1 ON SG1.CAUSE_1_CODE=CA1.CAUSE_CODE 
                    LEFT JOIN CAUSE CA2 ON SG1.CAUSE_2_CODE=CA2.CAUSE_CODE 
                    LEFT JOIN CAUSE CA3 ON SG1.CAUSE_3_CODE=CA3.CAUSE_CODE 
                    LEFT JOIN SUIKEI SK1 ON SG1.SUIKEI_CODE=SK1.SUIKEI_CODE
                    LEFT JOIN SUIKEI_TYPE ST1 ON SG1.SUIKEI_TYPE_CODE=ST1.SUIKEI_TYPE_CODE -- 2024/11/15 ADD
                    LEFT JOIN KASEN KA1 ON SG1.KASEN_CODE=KA1.KASEN_CODE 
                    LEFT JOIN KASEN_TYPE KT1 ON SG1.KASEN_TYPE_CODE=KT1.KASEN_TYPE_CODE    -- 2024/11/15 ADD
                    LEFT JOIN GRADIENT GR1 ON SG1.GRADIENT_CODE=GR1.GRADIENT_CODE 
                    LEFT JOIN KASEN_KAIGAN KK1 ON SG1.KASEN_KAIGAN_CODE=KK1.KASEN_KAIGAN_CODE 
                    LEFT JOIN WEATHER WE1 ON SG1.WEATHER_ID=WE1.WEATHER_ID 
                    WHERE 
                        SG1.KEN_CODE=%(KEN_CODE)S AND 
                        SG1.DELETED_AT IS NULL 
                    ORDER BY 
                        CAST(SG1.IPPAN_HEADER_ID AS INTEGER)""", PARAMS)
            
            elif ken_code != '0' and city_code != '0':
                params = dict({
                    'KEN_CODE': ken_code, 
                    'CITY_CODE': city_code
                })
                ippan_header_list = IPPAN_HEADER.objects.raw("""
                    SELECT 
                        SG1.IPPAN_HEADER_ID, 
                        SG1.IPPAN_HEADER_NAME, 
                        SG1.KEN_CODE, 
                        KE1.KEN_NAME, 
                        SG1.CITY_CODE, 
                        CT1.CITY_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE, 
                        TO_CHAR(TIMEZONE('JST', SG1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE, 
                        SG1.CAUSE_1_CODE, 
                        CA1.CAUSE_NAME AS CAUSE_1_NAME, 
                        SG1.CAUSE_2_CODE, 
                        CA2.CAUSE_NAME AS CAUSE_2_NAME, 
                        SG1.CAUSE_3_CODE, 
                        CA3.CAUSE_NAME AS CAUSE_3_NAME, 
                        SG1.KUIKI_ID, 
                        SG1.SUIKEI_CODE, 
                        SK1.SUIKEI_NAME, 
                        SG1.SUIKEI_TYPE_CODE, -- 2024/11/15 ADD
                        ST1.SUIKEI_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.KASEN_CODE, 
                        KA1.KASEN_NAME, 
                        SG1.KASEN_TYPE_CODE, -- 2024/11/15 ADD
                        KT1.KASEN_TYPE_NAME, -- 2024/11/15 ADD
                        SG1.GRADIENT_CODE, 
                        GR1.GRADIENT_NAME, 
                        CAST(SG1.RESIDENTIAL_AREA AS NUMERIC(20,10)) AS RESIDENTIAL_AREA, 
                        CAST(SG1.AGRICULTURAL_AREA AS NUMERIC(20,10)) AS AGRICULTURAL_AREA, 
                        CAST(SG1.UNDERGROUND_AREA AS NUMERIC(20,10)) AS UNDERGROUND_AREA, 
                        SG1.KASEN_KAIGAN_CODE, 
                        KK1.KASEN_KAIGAN_NAME, 
                        CAST(SG1.CROP_DAMAGE AS NUMERIC(20,10)) AS CROP_DAMAGE, 
                        SG1.WEATHER_ID, 
                        WE1.WEATHER_NAME, 
                        TO_CHAR(TIMEZONE('JST', SG1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                        TO_CHAR(TIMEZONE('JST', SG1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                        SG1.UPLOAD_FILE_PATH, 
                        SG1.UPLOAD_FILE_NAME, 
                        SG1.SUMMARY_FILE_PATH, 
                        SG1.SUMMARY_FILE_NAME 
                    FROM IPPAN_HEADER SG1 
                    LEFT JOIN KEN KE1 ON SG1.KEN_CODE=KE1.KEN_CODE 
                    LEFT JOIN CITY CT1 ON SG1.CITY_CODE=CT1.CITY_CODE 
                    LEFT JOIN CAUSE CA1 ON SG1.CAUSE_1_CODE=CA1.CAUSE_CODE 
                    LEFT JOIN CAUSE CA2 ON SG1.CAUSE_2_CODE=CA2.CAUSE_CODE 
                    LEFT JOIN CAUSE CA3 ON SG1.CAUSE_3_CODE=CA3.CAUSE_CODE 
                    LEFT JOIN SUIKEI SK1 ON SG1.SUIKEI_CODE=SK1.SUIKEI_CODE
                    LEFT JOIN SUIKEI_TYPE ST1 ON SG1.SUIKEI_TYPE_CODE=ST1.SUIKEI_TYPE_CODE -- 2024/11/15 ADD
                    LEFT JOIN KASEN KA1 ON SG1.KASEN_CODE=KA1.KASEN_CODE 
                    LEFT JOIN KASEN_TYPE KT1 ON SG1.KASEN_TYPE_CODE=KT1.KASEN_TYPE_CODE    -- 2024/11/15 ADD
                    LEFT JOIN GRADIENT GR1 ON SG1.GRADIENT_CODE=GR1.GRADIENT_CODE 
                    LEFT JOIN KASEN_KAIGAN KK1 ON SG1.KASEN_KAIGAN_CODE=KK1.KASEN_KAIGAN_CODE 
                    LEFT JOIN WEATHER WE1 ON SG1.WEATHER_ID=WE1.WEATHER_ID 
                    WHERE 
                        SG1.KEN_CODE=%(KEN_CODE)S AND 
                        SG1.CITY_CODE=%(CITY_CODE)S AND 
                        SG1.DELETED_AT IS NULL 
                    ORDER BY 
                        CAST(SG1.IPPAN_HEADER_ID AS INTEGER)""", PARAMS)
            
        ### アップロードデータ_一般資産調査員調査票_一覧表部分: IPPAN
        elif cat2 == _IPPAN:
            ippan_list = IPPAN.objects.raw("""
                SELECT 
                    IP1.IPPAN_ID, 
                    IP1.IPPAN_NAME, 
                    IP1.IPPAN_HEADER_ID, 
                    SG1.IPPAN_HEADER_NAME, 
                    IP1.BUILDING_CODE, 
                    BD1.BUILDING_NAME, 
                    IP1.UNDERGROUND_CODE, 
                    UD1.UNDERGROUND_NAME, 
                    IP1.FLOOD_SEDIMENT_CODE, 
                    FS1.FLOOD_SEDIMENT_NAME, 
                    CAST(IP1.BUILDING_LV00 AS NUMERIC(20,10)) AS BUILDING_LV00, 
                    CAST(IP1.BUILDING_LV01_49 AS NUMERIC(20,10)) AS BUILDING_LV01_49, 
                    CAST(IP1.BUILDING_LV50_99 AS NUMERIC(20,10)) AS BUILDING_LV50_99, 
                    CAST(IP1.BUILDING_LV100 AS NUMERIC(20,10)) AS BUILDING_LV100, 
                    CAST(IP1.BUILDING_HALF AS NUMERIC(20,10)) AS BUILDING_HALF, 
                    CAST(IP1.BUILDING_FULL AS NUMERIC(20,10)) AS BUILDING_FULL, 
                    CAST(IP1.FLOOR_AREA AS NUMERIC(20,10)) AS FLOOR_AREA, 
                    CAST(IP1.FAMILY AS NUMERIC(20,10)) AS FAMILY, 
                    CAST(IP1.OFFICE AS NUMERIC(20,10)) AS OFFICE, 
                    CAST(IP1.FARMER_FISHER_LV00 AS NUMERIC(20,10)) AS FARMER_FISHER_LV00, 
                    CAST(IP1.FARMER_FISHER_LV01_49 AS NUMERIC(20,10)) AS FARMER_FISHER_LV01_49, 
                    CAST(IP1.FARMER_FISHER_LV50_99 AS NUMERIC(20,10)) AS FARMER_FISHER_LV50_99, 
                    CAST(IP1.FARMER_FISHER_LV100 AS NUMERIC(20,10)) AS FARMER_FISHER_LV100, 
                    CAST(IP1.FARMER_FISHER_FULL AS NUMERIC(20,10)) AS FARMER_FISHER_FULL, 
                    CAST(IP1.EMPLOYEE_LV00 AS NUMERIC(20,10)) AS EMPLOYEE_LV00, 
                    CAST(IP1.EMPLOYEE_LV01_49 AS NUMERIC(20,10)) AS EMPLOYEE_LV01_49, 
                    CAST(IP1.EMPLOYEE_LV50_99 AS NUMERIC(20,10)) AS EMPLOYEE_LV50_99, 
                    CAST(IP1.EMPLOYEE_LV100 AS NUMERIC(20,10)) AS EMPLOYEE_LV100, 
                    CAST(IP1.EMPLOYEE_FULL AS NUMERIC(20,10)) AS EMPLOYEE_FULL, 
                    IP1.INDUSTRY_CODE, 
                    ID1.INDUSTRY_NAME, 
                    IP1.USAGE_CODE, 
                    US1.USAGE_NAME, 
                    IP1.COMMENT, 
                    TO_CHAR(TIMEZONE('JST', IP1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                    TO_CHAR(TIMEZONE('JST', IP1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
                FROM IPPAN IP1 
                LEFT JOIN IPPAN_HEADER SG1 ON IP1.IPPAN_HEADER_ID=SG1.IPPAN_HEADER_ID 
                LEFT JOIN BUILDING BD1 ON IP1.BUILDING_CODE=BD1.BUILDING_CODE 
                LEFT JOIN UNDERGROUND UD1 ON IP1.UNDERGROUND_CODE=UD1.UNDERGROUND_CODE 
                LEFT JOIN FLOOD_SEDIMENT FS1 ON IP1.FLOOD_SEDIMENT_CODE=FS1.FLOOD_SEDIMENT_CODE 
                LEFT JOIN INDUSTRY ID1 ON IP1.INDUSTRY_CODE=ID1.INDUSTRY_CODE 
                LEFT JOIN USAGE US1 ON IP1.USAGE_CODE=US1.USAGE_CODE 
                WHERE 
                    IP1.DELETED_AT IS NULL 
                ORDER BY 
                    CAST(IP1.IPPAN_ID AS INTEGER)""")

        ### アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分: CHITAN_HEADER
        elif cat2 == _CHITAN_HEADER:
            pass

        ### アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分: CHITAN
        elif cat2 == _CHITAN:
            pass

        ### アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分: HOJO_HEADER
        elif cat2 == _HOJO_HEADER:
            pass

        ### アップロードデータ_公共土木施設調査票_補助事業_一覧表部分: HOJO
        elif cat2 == _HOJO:
            pass

        ### アップロードデータ_公益事業等調査票_ヘッダ部分: KOEKI_HEADER
        elif cat2 == _KOEKI_HEADER:
            pass

        ### アップロードデータ_公益事業等調査票_一覧表部分: KOEKI
        elif cat2 == _KOEKI:
            pass

        ### 集計データ_一般資産調査員調査票_一覧表部分: IPPAN_SUMMARY
        elif cat2 == _IPPAN_SUMMARY:
            ippan_summary_list = IPPAN_SUMMARY.objects.raw("""
                SELECT 
                    IS1.id, 
                    IS1.ippan_id, 
                    IP1.ippan_name, 
                    IS1.ippan_header_id, 
                    SG1.ippan_header_name, 
                    SG1.ken_code, 
                    KE1.ken_name, 
                    SG1.city_code, 
                    CT1.city_name, 
                    CAST(IS1.house_summary_lv00 AS NUMERIC(20,10)) AS house_summary_lv00, 
                    CAST(IS1.house_summary_lv01_49 AS NUMERIC(20,10)) AS house_summary_lv01_49, 
                    CAST(IS1.house_summary_lv50_99 AS NUMERIC(20,10)) AS house_summary_lv50_99, 
                    CAST(IS1.house_summary_lv100 AS NUMERIC(20,10)) AS house_summary_lv100, 
                    CAST(IS1.house_summary_half AS NUMERIC(20,10)) AS house_summary_half, 
                    CAST(IS1.house_summary_full AS NUMERIC(20,10)) AS house_summary_full, 
                    CAST(IS1.household_summary_lv00 AS NUMERIC(20,10)) AS household_summary_lv00, 
                    CAST(IS1.household_summary_lv01_49 AS NUMERIC(20,10)) AS household_summary_lv01_49, 
                    CAST(IS1.household_summary_lv50_99 AS NUMERIC(20,10)) AS household_summary_lv50_99, 
                    CAST(IS1.household_summary_lv100 AS NUMERIC(20,10)) AS household_summary_lv100, 
                    CAST(IS1.household_summary_half AS NUMERIC(20,10)) AS household_summary_half, 
                    CAST(IS1.household_summary_full AS NUMERIC(20,10)) AS household_summary_full, 
                    CAST(IS1.car_summary_lv00 AS NUMERIC(20,10)) AS car_summary_lv00, 
                    CAST(IS1.car_summary_lv01_49 AS NUMERIC(20,10)) AS car_summary_lv01_49, 
                    CAST(IS1.car_summary_lv50_99 AS NUMERIC(20,10)) AS car_summary_lv50_99, 
                    CAST(IS1.car_summary_lv100 AS NUMERIC(20,10)) AS car_summary_lv100, 
                    CAST(IS1.car_summary_half AS NUMERIC(20,10)) AS car_summary_half, 
                    CAST(IS1.car_summary_full AS NUMERIC(20,10)) AS car_summary_full, 
                    CAST(IS1.house_alt_summary_lv00 AS NUMERIC(20,10)) AS house_alt_summary_lv00, 
                    CAST(IS1.house_alt_summary_lv01_49 AS NUMERIC(20,10)) AS house_alt_summary_lv01_49, 
                    CAST(IS1.house_alt_summary_lv50_99 AS NUMERIC(20,10)) AS house_alt_summary_lv50_99, 
                    CAST(IS1.house_alt_summary_lv100 AS NUMERIC(20,10)) AS house_alt_summary_lv100, 
                    CAST(IS1.house_alt_summary_half AS NUMERIC(20,10)) AS house_alt_summary_half, 
                    CAST(IS1.house_alt_summary_full AS NUMERIC(20,10)) AS house_alt_summary_full, 
                    CAST(IS1.house_clean_summary_lv00 AS NUMERIC(20,10)) AS house_clean_summary_lv00, 
                    CAST(IS1.house_clean_summary_lv01_49 AS NUMERIC(20,10)) AS house_clean_summary_lv01_49, 
                    CAST(IS1.house_clean_summary_lv50_99 AS NUMERIC(20,10)) AS house_clean_summary_lv50_99, 
                    CAST(IS1.house_clean_summary_lv100 AS NUMERIC(20,10)) AS house_clean_summary_lv100, 
                    CAST(IS1.house_clean_summary_half AS NUMERIC(20,10)) AS house_clean_summary_half, 
                    CAST(IS1.house_clean_summary_full AS NUMERIC(20,10)) AS house_clean_summary_full, 
                    CAST(IS1.office_dep_summary_lv00 AS NUMERIC(20,10)) AS office_dep_summary_lv00, 
                    CAST(IS1.office_dep_summary_lv01_49 AS NUMERIC(20,10)) AS office_dep_summary_lv01_49, 
                    CAST(IS1.office_dep_summary_lv50_99 AS NUMERIC(20,10)) AS office_dep_summary_lv50_99, 
                    CAST(IS1.office_dep_summary_lv100 AS NUMERIC(20,10)) AS office_dep_summary_lv100, 
                    CAST(IS1.office_dep_summary_full AS NUMERIC(20,10)) AS office_dep_summary_full, 
                    CAST(IS1.office_inv_summary_lv00 AS NUMERIC(20,10)) AS office_inv_summary_lv00, 
                    CAST(IS1.office_inv_summary_lv01_49 AS NUMERIC(20,10)) AS office_inv_summary_lv01_49, 
                    CAST(IS1.office_inv_summary_lv50_99 AS NUMERIC(20,10)) AS office_inv_summary_lv50_99, 
                    CAST(IS1.office_inv_summary_lv100 AS NUMERIC(20,10)) AS office_inv_summary_lv100, 
                    CAST(IS1.office_inv_summary_full AS NUMERIC(20,10)) AS office_inv_summary_full, 
                    CAST(IS1.office_sus_summary_lv00 AS NUMERIC(20,10)) AS office_sus_summary_lv00, 
                    CAST(IS1.office_sus_summary_lv01_49 AS NUMERIC(20,10)) AS office_sus_summary_lv01_49, 
                    CAST(IS1.office_sus_summary_lv50_99 AS NUMERIC(20,10)) AS office_sus_summary_lv50_99, 
                    CAST(IS1.office_sus_summary_lv100 AS NUMERIC(20,10)) AS office_sus_summary_lv100, 
                    CAST(IS1.office_sus_summary_full AS NUMERIC(20,10)) AS office_sus_summary_full, 
                    CAST(IS1.office_stg_summary_lv00 AS NUMERIC(20,10)) AS office_stg_summary_lv00, 
                    CAST(IS1.office_stg_summary_lv01_49 AS NUMERIC(20,10)) AS office_stg_summary_lv01_49, 
                    CAST(IS1.office_stg_summary_lv50_99 AS NUMERIC(20,10)) AS office_stg_summary_lv50_99, 
                    CAST(IS1.office_stg_summary_lv100 AS NUMERIC(20,10)) AS office_stg_summary_lv100, 
                    CAST(IS1.office_stg_summary_full AS NUMERIC(20,10)) AS office_stg_summary_full, 
                    CAST(IS1.farmer_fisher_dep_summary_lv00 AS NUMERIC(20,10)) AS farmer_fisher_dep_summary_lv00, 
                    CAST(IS1.farmer_fisher_dep_summary_lv01_49 AS NUMERIC(20,10)) AS farmer_fisher_dep_summary_lv01_49, 
                    CAST(IS1.farmer_fisher_dep_summary_lv50_99 AS NUMERIC(20,10)) AS farmer_fisher_dep_summary_lv50_99, 
                    CAST(IS1.farmer_fisher_dep_summary_lv100 AS NUMERIC(20,10)) AS farmer_fisher_dep_summary_lv100, 
                    CAST(IS1.farmer_fisher_dep_summary_full AS NUMERIC(20,10)) AS farmer_fisher_dep_summary_full, 
                    CAST(IS1.farmer_fisher_inv_summary_lv00 AS NUMERIC(20,10)) AS farmer_fisher_inv_summary_lv00, 
                    CAST(IS1.farmer_fisher_inv_summary_lv01_49 AS NUMERIC(20,10)) AS farmer_fisher_inv_summary_lv01_49, 
                    CAST(IS1.farmer_fisher_inv_summary_lv50_99 AS NUMERIC(20,10)) AS farmer_fisher_inv_summary_lv50_99, 
                    CAST(IS1.farmer_fisher_inv_summary_lv100 AS NUMERIC(20,10)) AS farmer_fisher_inv_summary_lv100, 
                    CAST(IS1.farmer_fisher_inv_summary_full AS NUMERIC(20,10)) AS farmer_fisher_inv_summary_full, 
                    CAST(IS1.office_alt_summary_lv00 AS NUMERIC(20,10)) AS office_alt_summary_lv00, 
                    CAST(IS1.office_alt_summary_lv01_49 AS NUMERIC(20,10)) AS office_alt_summary_lv01_49, 
                    CAST(IS1.office_alt_summary_lv50_99 AS NUMERIC(20,10)) AS office_alt_summary_lv50_99, 
                    CAST(IS1.office_alt_summary_lv100 AS NUMERIC(20,10)) AS office_alt_summary_lv100, 
                    CAST(IS1.office_alt_summary_half AS NUMERIC(20,10)) AS office_alt_summary_half, 
                    CAST(IS1.office_alt_summary_full AS NUMERIC(20,10)) AS office_alt_summary_full 
                FROM IPPAN_SUMMARY IS1 
                LEFT JOIN IPPAN IP1 ON IS1.ippan_id=IP1.ippan_id 
                LEFT JOIN IPPAN_HEADER SG1 ON IS1.ippan_header_id=SG1.ippan_header_id 
                LEFT JOIN KEN KE1 ON SG1.ken_code=KE1.ken_code 
                LEFT JOIN CITY CT1 ON SG1.city_code=CT1.city_code 
                WHERE 
                    IS1.deleted_at IS NULL 
                ORDER BY 
                    CAST(IS1.ippan_id AS INTEGER)""")

        ### 集計データ_公共土木施設調査票_地方単独事業_一覧表部分: CHITAN_SUMMARY
        elif cat2 == _CHITAN_SUMMARY:
            pass

        ### 集計データ_公共土木施設調査票_補助事業_一覧表部分: HOJO_SUMMARY
        elif cat2 == _HOJO_SUMMARY:
            pass

        ### 集計データ_公益事業等調査票_一覧表部分: KOEKI_SUMMARY
        elif cat2 == _KOEKI_SUMMARY:
            pass

        ### マスタデータ_アクション: ACTION
        elif cat2 == _ACTION:
            action_list = ACTION.objects.raw("""
                SELECT 
                    action_code, 
                    action_name 
                FROM ACTION 
                ORDER BY 
                    ACTION_CODE""")

        ### マスタデータ_状態: STATUS
        elif cat2 == _STATUS:
            status_list = STATUS.objects.raw("""
                SELECT 
                    status_code, 
                    status_name 
                FROM STATUS 
                ORDER BY 
                    STATUS_CODE""")

        ### キューデータ_一般資産調査員調査票_トリガーメッセージ: IPPAN_TRIGGER
        elif cat2 == _IPPAN_TRIGGER:
            ippan_trigger_list = IPPAN_TRIGGER.objects.raw("""
                SELECT 
                    TR1.ippan_trigger_id, 
                    TR1.ippan_header_id, 
                    SG1.ippan_header_name, 
                    SG1.ken_code, 
                    KE1.ken_name, 
                    SG1.city_code, 
                    CT1.city_name, 
                    TR1.action_code, 
                    AC1.action_name, 
                    TR1.status_code, 
                    ST1.status_name, 
                    TR1.info_count, 
                    TR1.warn_count, 
                    TO_CHAR(timezone('JST', TR1.published_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS published_at, 
                    TO_CHAR(timezone('JST', TR1.consumed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS consumed_at, 
                    TO_CHAR(timezone('JST', TR1.deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at, 
                    TR1.info_log, 
                    TR1.warn_log 
                FROM IPPAN_TRIGGER TR1 
                LEFT JOIN IPPAN_HEADER SG1 ON TR1.ippan_header_id=SG1.ippan_header_id 
                LEFT JOIN ACTION AC1 ON TR1.action_code=AC1.action_code 
                LEFT JOIN STATUS ST1 ON TR1.status_code=ST1.status_code 
                LEFT JOIN KEN KE1 ON SG1.ken_code=KE1.ken_code 
                LEFT JOIN CITY CT1 ON SG1.city_code=CT1.city_code 
                WHERE 
                    TR1.deleted_at IS NULL 
                ORDER BY 
                    CAST(ippan_trigger_id AS INTEGER)""")

        ### キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ: CHITAN_TRIGGER
        elif cat2 == _CHITAN_TRIGGER:
            pass

        ### キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ: HOJO_TRIGGER
        elif cat2 == _HOJO_TRIGGER:
            pass

        ### キューデータ_公益事業等調査票_トリガーメッセージ: KOEKI_TRIGGER
        elif cat2 == _KOEKI_TRIGGER:
            pass

        else:
            pass
        
        #######################################################################
        ### 【正常】レスポンスセット処理(0050)
        #######################################################################
        print_log('[DEBUG] P0400Online.cat1_cat2_ken_city_view()関数 STEP 5/5.', 'DEBUG')
        template = loader.get_template('P0400Online/index.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'role_code': user_proxy_list[0].role_code, 
            'cat1': cat1,
            'cat2': cat2,
            'ken_code': ken_code,
            'city_code': city_code,
            'building_list': building_list,
            'ken_list': ken_list,
            'city_list': city_list,
            'kasen_kaigan_list': kasen_kaigan_list,
            'suikei_list': suikei_list,
            'suikei_type_list': suikei_type_list,
            'kasen_list': kasen_list,
            'kasen_type_list': kasen_type_list,
            'cause_list': cause_list,
            'underground_list': underground_list,
            'usage_list': usage_list,
            'flood_sediment_list': flood_sediment_list,
            'gradient_list': gradient_list,
            'industry_list': industry_list,
            'business_list': business_list,
            'house_asset_list': house_asset_list,
            'house_rate_list': house_rate_list,
            'house_alt_list': house_alt_list,
            'house_clean_list': house_clean_list,
            'household_asset_list': household_asset_list,
            'household_rate_list': household_rate_list,
            'car_asset_list': car_asset_list,
            'car_rate_list': car_rate_list,
            'office_asset_list': office_asset_list,
            'office_rate_list': office_rate_list,
            'office_suspend_list': office_suspend_list,
            'office_stagnate_list': office_stagnate_list,
            'office_alt_list': office_alt_list,
            'farmer_fisher_asset_list': farmer_fisher_asset_list,
            'farmer_fisher_rate_list': farmer_fisher_rate_list,
            'weather_list': weather_list,
            'ippan_header_list': ippan_header_list,
            'ippan_list': ippan_list,
            'chitan_header_list': chitan_header_list,
            'chitan_list': chitan_list,
            'hojo_header_list': hojo_header_list,
            'hojo_list': hojo_list,
            'koeki_header_list': koeki_header_list,
            'koeki_list': koeki_list,
            'ippan_summary_list': ippan_summary_list,
            'chitan_summary_list': chitan_summary_list,
            'hojo_summary_list': hojo_summary_list,
            'koeki_summary_list': koeki_summary_list,
            'action_list': action_list,
            'status_list': status_list,
            'ippan_trigger_list': ippan_trigger_list,
            'chitan_trigger_list': chitan_trigger_list,
            'hojo_trigger_list': hojo_trigger_list,
            'koeki_trigger_list': koeki_trigger_list,
        }
        print_log('[INFO] P0400Online.cat1_cat2_ken_city_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0400Online.cat1_cat2_ken_city_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0400Online.cat1_cat2_ken_city_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0400Online.cat1_cat2_ken_city_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0400Online/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
