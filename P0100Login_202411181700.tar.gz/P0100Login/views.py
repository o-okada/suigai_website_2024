###############################################################################
### ファイル名：P0100Login/views.py
### ログイン
###############################################################################

import json
import sys
import urllib

from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth import logout
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

###############################################################################
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
###############################################################################
def index_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0100Login.index_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 1/4.', 'DEBUG')
        print_log('[DEBUG] P0100Login.index_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0100Login.index_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### 認証処理(0010)
        ### ログイン中、ログアウト中にかかわらずに、ログアウトする。
        #######################################################################
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 2/4.', 'DEBUG')
        logout(request)
        
        #######################################################################
        ### 条件分岐処理(0020)
        ### GETのときログイン画面を表示する。
        ### ※ネストを浅くするため、GETの場合、テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 3/4.', 'DEBUG')
        if request.method == 'GET':
            template = loader.get_template('P0100Login/index.html')
            context = {
            }
            print_log('[INFO] P0100Login.index_view()関数が正常終了しました。', 'INFO')
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### 条件分岐処理(0030)
        ### POSTのときユーザを認証する。
        #######################################################################
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 4/4.', 'DEBUG')
        
        #######################################################################
        ### BEGIN RECAPTCHA
        #######################################################################
        if request.method == 'POST':
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_1/4.', 'DEBUG')
            print_log('[DEBUG] P0100Login.index_view()関数 recaptcha_response_token={}'.format(request.POST['recaptcha_response_token']), 'DEBUG')
            recaptcha_response_token = request.POST['recaptcha_response_token']

            data = {
                'secret': '6LczJSIqAAAAACGeV2ATH-VUPu3Y5XPJ2FgtpA_P',
                'response': recaptcha_response_token,
            }
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_2/4.', 'DEBUG')
            print_log('[DEBUG] P0100Login.index_view()関数 data={}'.format(data), 'DEBUG')

            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_3/4.', 'DEBUG')
            print_log('[DEBUG] P0100Login.index_view()関数 urllib.parse.urlencode(data).encode()={}'.format(urllib.parse.urlencode(data).encode()), 'DEBUG')
            parsed_data = urllib.parse.urlencode(data).encode()

            ### NG
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_4/4.', 'DEBUG')
            print_log('[DEBUG] P0100Login.index_view()関数 urllib.request.Request()={}'.format(urllib.request.Request('https://www.google.com/recaptcha/api/siteverify', data=parsed_data)), 'DEBUG')
            req = urllib.request.Request('https://www.google.com/recaptcha/api/siteverify', data=parsed_data)

            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_5/4.', 'DEBUG')
            ### print_log('[DEBUG] P0100Login.index_view()関数 urllib.request.urlopen(req)={}'.format(urllib.request.urlopen(req, context=ctx)), 'DEBUG')
            response = urllib.request.urlopen(req, context=ctx)

            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_6/4.', 'DEBUG')
            ### print_log('[DEBUG] P0100Login.index_view()関数 json.loads(response.read().decode())={}'.format(json.loads(response.read().decode())), 'DEBUG')
            recaptcha_results = json.loads(response.read().decode())
            print_log('[DEBUG] P0100Login.index_view()関数 recaptcha_results={}'.format(recaptcha_results), 'DEBUG')

            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_7/4.', 'DEBUG')
            print_log('[DEBUG] P0100Login.index_view()関数 recaptcha_results.get(success)={}'.format(recaptcha_results.get('success')), 'DEBUG')
            ### print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_8/4.', 'DEBUG')
            ### print_log('[DEBUG] P0100Login.index_view()関数 recaptcha_results.get(score)={}'.format(recaptcha_results.get('score')), 'DEBUG')
            if (recaptcha_results.get('success') == False):
                template = loader.get_template('P0100Login/index.html')
                context = {
                    'message': 'ログインに失敗しました。'
                }
                print_log('[WARN] P0100Login.index_view()関数が警告終了しました。', 'WARN')
                return HttpResponse(template.render(context, request))

            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_9/4.', 'DEBUG')
            
        #######################################################################
        ### END RECAPTCHA
        #######################################################################
        
        if request.method == 'POST':

            user = authenticate(
                username = request.POST['username'], 
                password = request.POST['password'])

            print_log('[DEBUG] P0100Login.index_view()関数 request.POST.username={}'.format(request.POST['username']), 'DEBUG')
            ### print_log('[DEBUG] P0100Login.index_view()関数 request.POST.password={}'.format(request.POST['password']), 'DEBUG')
            ### print_log('[DEBUG] P0100Login.index_view()関数 str(user=authenticate(username=, password=))={}'.format(str(user)), 'DEBUG')
            
            PARAMS_SELECT_USER_PROXY = dict({
                'USERNAME': str(user),
            })
            SQL_SELECT_USER_PROXY = """
                SELECT 
                    P1.ID, 
                    A1.USERNAME, 
                    P1.ROLE_CODE, 
                    P1.KEN_CODE, 
                    P1.CITY_CODE 
                FROM USER_PROXY P1 
                LEFT JOIN (
                    SELECT 
                        * 
                    FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                WHERE 
                    A1.USERNAME=%(USERNAME)s"""
            user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)

            print_log('[DEBUG] P0100Login.index_view()関数 user_proxy_list={}'.format(user_proxy_list), 'DEBUG')
            print_log('[DEBUG] P0100Login.index_view()関数 len(user_proxy_list)={}'.format(len(user_proxy_list)), 'DEBUG')
                
            ### 認証に成功した場合、、、
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_1/4.', 'DEBUG')
            if user is not None:
                if user.is_active:
                    ### ユーザが活性（有効）の場合、ログインして、ファイル管理画面にリダイレクトする。
                    login(request, user)
                    print_log('[INFO] P0100Login.index_view()関数が正常終了しました。', 'INFO')
                    if user_proxy_list[0].role_code == _ROLE_CITY:
                        return HttpResponseRedirect('/P0110City/')
                    elif user_proxy_list[0].role_code == _ROLE_KEN:
                        return HttpResponseRedirect('/P0120Ken/')
                    elif user_proxy_list[0].role_code == _ROLE_MANAGE:
                        return HttpResponseRedirect('/P0130Manage/')
                    else:
                        return HttpResponseRedirect('/P0110City/')
                
                else:
                    ### ユーザが非活性（無効）の場合、テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
                    template = loader.get_template('P0100Login/index.html')
                    context = {
                        'message': 'ログインに失敗しました。'
                    }
                    print_log('[WARN] P0100Login.index_view()関数が警告終了しました。', 'WARN')
                    return HttpResponse(template.render(context, request))

            ### 認証に失敗した場合、テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_2/4.', 'DEBUG')
            if user is None:
                template = loader.get_template('P0100Login/index.html')
                context = {
                    'message': 'ログインに失敗しました。'
                }
                print_log('[WARN] P0100Login.index_view()関数が警告終了しました。', 'WARN')
                return HttpResponse(template.render(context, request))
            
    except:
        print_log('[ERROR] P0100Login.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0100Login.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0100Login.index_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0100Login/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
        