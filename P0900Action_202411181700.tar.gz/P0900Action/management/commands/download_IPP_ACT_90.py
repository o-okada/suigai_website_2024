###############################################################################
### ファイル名：P0900Action/management/commands/IPP_ACT_90_download_ippan_chosa.py
### 一般資産調査員調査票ダウンロード
### 
### 更新履歴：
### 2024/11/14 P0000Common.services.pyのget_ippan_chosa_csv_excel(request, func_params)関数を使用するように変更した。
###############################################################################

from django.core.management.base import BaseCommand

import sys
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from decimal import Decimal

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: 家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: 家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.services import create_ippan_chosa_workbook                   ### 2024/11/15 ADD

from MessageQueue.views import get_message 
from MessageQueue.views import consume_message 

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_90 = 'IPP_ACT_90'

### STATUSテーブル.STATUS_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

### 局所定数 ※エクセルの列用
VLOOK_VALUE = [
    'B', 'G', 'L', 'Q', 'V', 'AA', 'AF', 'AK', 'AP', 'AU', 
    'AZ', 'BE', 'BJ', 'BO', 'BT', 'BY', 'CD', 'CI', 'CN', 'CS', 
    'CX', 'DC', 'DH', 'DM', 'DR', 'DW', 'EB', 'EG', 'EL', 'EQ', 
    'EV', 'FA', 'FF', 'FK', 'FP', 'FU', 'FZ', 'GE', 'GJ', 'GO', 
    'GT', 'GY', 'HD', 'HI', 'HN', 'HS', 'HX', 'IC', 'IH', 'IM', 
    'IR', 'IW', 'JB', 'JG', 'JL', 'JQ', 'JV', 'KA', 'KF', 'KK', 
    'KP', 'KU', 'KZ', 'LE', 'LJ', 'LO', 'LT', 'LY', 'MD', 'MI', 
    'MN', 'MS', 'MX', 'NC', 'NH', 'NM', 'NR', 'NW', 'OB', 'OG', 
    'OL', 'OQ', 'OV', 'PA', 'PF', 'PK', 'PP', 'PU', 'PZ', 'QE', 
    'QJ', 'QO', 'QT', 'QY', 'RD', 'RI', 'RN', 'RS', 'RX', 'SC', 
    'SH', 'SM', 'SR', 'SW', 'TB', 'TG', 'TL', 'TQ', 'TV', 'UA', 
    'UF', 'UK', 'UP', 'UU', 'UZ', 'VE', 'VJ', 'VO', 'VT', 'VY', 
    'WD', 'WI', 'WN', 'WS', 'WX', 'XC', 'XH', 'XM', 'XR', 'XW', 
    'YB', 'YG', 'YL', 'YQ', 'YV', 'ZA', 'ZF', 'ZK', 'ZP', 'ZU', 
    'ZZ', 'AAE', 'AAJ', 'AAO', 'AAT', 'AAY', 'ABD', 'ABI', 'ABN', 'ABS', 
    'ABX', 'ACC', 'ACH', 'ACM', 'ACR', 'ACW', 'ADB', 'ADG', 'ADL', 'ADQ', 
    'ADV', 'AEA', 'AEF', 'AEK', 'AEP', 'AEU', 'AEZ', 'AFE', 'AFJ', 'AFO', 
    'AFT', 'AFY', 'AGD', 'AGI', 'AGN', 'AGS', 'AGX', 'AHC', 'AHH', 'AHM', 
    'AHR', 'AHW', 'AIB', 'AIG', 'AIL', 'AIQ', 'AIV', 'AJA', 'AJF', 'AJK', 
    'AJP', 'AJU', 'AJZ', 'AKE', 'AKJ', 'AKO', 'AKT', 'AKY', 'ALD', 'ALI', 
    'ALN', 'ALS', 'ALX', 'AMC', 'AMH', 'AMM', 'AMR', 'AMW', 'ANB', 'ANG', 
    'ANL', 'ANQ', 'ANV', 'AOA', 'AOF', 'AOK', 'AOP', 'AOU', 'AOZ', 'APE', 
    'APJ', 'APO', 'APT', 'APY', 'AQD', 'AQI', 'AQN', 'AQS', 'AQX', 'ARC', 
    'ARH', 'ARM', 'ARR', 'ARW', 'ASB', 'ASG', 'ASL', 'ASQ', 'ASV', 'ATA', 
    'ATF', 'ATK', 'ATP', 'ATU', 'ATZ', 'AUE', 'AUJ', 'AUO', 'AUT', 'AUY', 
    'AVD', 'AVI', 'AVN', 'AVS', 'AVX', 'AWC', 'AWH', 'AWM', 'AWR', 'AWW', 
    'AXB', 'AXG', 'AXL', 'AXQ', 'AXV', 'AYA', 'AYF', 'AYK', 'AYP', 'AYU', 
    'AYZ', 'AZE', 'AZJ', 'AZO', 'AZT', 'AZY'
    ]

MAX_SHEET_NUMBER = 25                                                          ### IPPANシートの数の最大値 ex 25

###############################################################################
### クラス名：Command(BaseCommand)
###############################################################################
class Command(BaseCommand):
    
    ###########################################################################
    ### 関数名：handle(self, *args, **options)
    ###########################################################################
    def handle(self, *args, **options):
        try:
            ###################################################################
            ### 引数チェック処理(0010)
            ###################################################################
            reset_log()
            print_log('[INFO] download_IPP_ACT_90.handle()関数が開始しました。', 'INFO')
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 1/8.', 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0020)
            ### メッセージキューから当該アクションが対象とするメッセージを取得する。
            ### ※ネストを浅くするため、メッセージが発行されていなければ、処理を終了する。
            ###################################################################
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 2/8.', 'DEBUG')
            metadata = dict({
                'action_code': _IPP_ACT_90,
                'status_code': ''
            })
            bool_return, ippan_trigger_list = get_message(metadata)
            if bool_return == False:
                print_log('[WARN] get_message()関数が警告終了しました。', 'WARN')
                return 4
            
            if bool(ippan_trigger_list) == False:
                print_log('[INFO] download_IPP_ACT_90.handle()関数が正常終了しました。', 'INFO')
                return 0
            
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].ippan_trigger_id={}'.format(ippan_trigger_list[0].ippan_trigger_id), 'DEBUG')
            ### print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].ippan_header_id={}'.format(ippan_trigger_list[0].ippan_header_id), 'DEBUG') ### 2024/11/14 IPPAN_HEADER_IDはセットされていない。
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].city_code={}'.format(ippan_trigger_list[0].city_code), 'DEBUG')
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].ken_code={}'.format(ippan_trigger_list[0].ken_code), 'DEBUG')
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].download_file_path={}'.format(ippan_trigger_list[0].download_file_path), 'DEBUG')
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].download_file_name={}'.format(ippan_trigger_list[0].download_file_name), 'DEBUG')
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].upload_file_path={}'.format(ippan_trigger_list[0].upload_file_path), 'DEBUG')
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 ippan_trigger_list[0].upload_file_name={}'.format(ippan_trigger_list[0].upload_file_name), 'DEBUG')
    
            ###################################################################
            ### DBアクセス処理(0030)
            ### IPPAN_TRIGGERのCITY_CODEから県名、市区町村名を取得する。
            ### IPPAN_TRIGGERのCITY_CODEから、あれば、IPPAN_HEADERのリストを取得する。※0件も正常。
            ###################################################################
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 3/8.', 'DEBUG')
            PARAMS_SELECT = dict({
                'CITY_CODE': ippan_trigger_list[0].city_code
            })
            SQL_SELECT_CITY = """
                SELECT 
                    CT1.CITY_CODE AS CITY_CODE, 
                    CT1.CITY_NAME AS CITY_NAME, 
                    CT1.KEN_CODE AS KEN_CODE, 
                    KE1.KEN_NAME AS KEN_NAME 
                FROM CITY CT1 
                LEFT JOIN KEN KE1 ON CT1.KEN_CODE=KE1.KEN_CODE 
                WHERE 
                    CT1.CITY_CODE=%(CITY_CODE)s LIMIT 1"""
            SQL_SELECT_IPPAN_HEADER = """
                SELECT 
                    * 
                FROM IPPAN_HEADER 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL 
                ORDER BY 
                    CAST(IPPAN_HEADER_ID AS INTEGER)"""

            city_list = CITY.objects.raw(SQL_SELECT_CITY, PARAMS_SELECT)
            ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS_SELECT)
                
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 city_list[0].ken_name={}'.format(city_list[0].ken_name), 'DEBUG')
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 city_list[0].city_name={}'.format(city_list[0].city_name), 'DEBUG')
    
            ###################################################################
            ### DBアクセス処理(0040)
            ###################################################################
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 4/8.', 'DEBUG')
            ### PARAMS_SELECT_SUIKEI = dict({
            ###     'KEN_CODE': '%' + str(ippan_trigger_list[0].ken_code) + '%',
            ### })
            ### building_list = BUILDING.objects.raw("""SELECT * FROM BUILDING ORDER BY CAST(BUILDING_CODE AS INTEGER)""")
            ### ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
            ### kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
            ### suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI WHERE KEN_CODE LIKE %(KEN_CODE)s ORDER BY CAST(SUIKEI_CODE AS INTEGER)""", PARAMS_SELECT_SUIKEI) ### 2024/11/14 ADD
            ### suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
            ### kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
            ### cause_list = CAUSE.objects.raw("""SELECT * FROM CAUSE ORDER BY CAST(CAUSE_CODE AS INTEGER)""")
            ### underground_list = UNDERGROUND.objects.raw("""SELECT * FROM UNDERGROUND ORDER BY CAST(UNDERGROUND_CODE AS INTEGER)""")
            ### usage_list = USAGE.objects.raw("""SELECT * FROM USAGE ORDER BY CAST(USAGE_CODE AS INTEGER)""")
            ### flood_sediment_list = FLOOD_SEDIMENT.objects.raw("""SELECT * FROM FLOOD_SEDIMENT ORDER BY CAST(FLOOD_SEDIMENT_CODE AS INTEGER)""")
            ### gradient_list = GRADIENT.objects.raw("""SELECT * FROM GRADIENT ORDER BY CAST(GRADIENT_CODE AS INTEGER)""")
            ### industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
            ### weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
            
            ###################################################################
            ### 局所変数セット処理(0050)
            ### ダウンロード用ファイルパスをセットする。
            ###################################################################
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 5/8.', 'DEBUG')
            template_file_path = 'static/template/template_ippan_chosa.xlsx'

            ###################################################################
            ### 関数内関数コール処理(0060)
            ### EXCELワークブックを生成する関数をコールする。
            ###################################################################
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 6/8.', 'DEBUG')
            ### bool_return, workbook_return = create_ippan_chosa_workbook(
            ###     ken_code = ippan_trigger_list[0].ken_code, 
            ###     ken_name = city_list[0].ken_name, 
            ###     city_code = ippan_trigger_list[0].city_code, 
            ###     city_name = city_list[0].city_name)
            bool_return, workbook_return = create_ippan_chosa_workbook(
                template_file_path = template_file_path,
                ippan_header_list = ippan_header_list,
                ken_code = ippan_trigger_list[0].ken_code,
                city_code = ippan_trigger_list[0].city_code,
                ken_name = city_list[0].ken_name,
                city_name = city_list[0].city_name,
                MAX_SHEET_NUMBER = MAX_SHEET_NUMBER
            )
            
            if bool_return == False:
                raise Exception

            workbook_return.save(ippan_trigger_list[0].download_file_path)

            ###################################################################
            ### DBアクセス処理(0070)
            ### トリガーデータを更新する。
            ###################################################################
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 7/8.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""", [])
                
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                    'action_code': _IPP_ACT_90, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log()
                })
                bool_return = consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                    connection_cursor.execute("""ROLLBACK""")
                    return 4
                
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] download_IPP_ACT_90.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] download_IPP_ACT_90.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] download_IPP_ACT_90.handle()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                return 8
            
            finally:
                ### try except finallyのtry文中でreturnを発生させた場合、
                ### finally文中のconnection_cursor.close()が実行されて、
                ### その後に関数を抜ける。
                ### したがって、finally文中でreturnする必要はない。
                connection_cursor.close()
                
            ###################################################################
            ### 戻り値セット処理(0080)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] download_IPP_ACT_90.handle()関数 STEP 8/8.', 'DEBUG')
            print_log('[INFO] download_IPP_ACT_90.handle()関数が正常終了しました。', 'INFO')
            return 0
        
        except:
            print_log('[ERROR] download_IPP_ACT_90.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] download_IPP_ACT_90.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] download_IPP_ACT_90.handle()関数が異常終了しました。', 'ERROR')
            return 8
            