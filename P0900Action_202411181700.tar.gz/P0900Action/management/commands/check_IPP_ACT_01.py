###############################################################################
### ファイル名：P0900Action/management/commands/check_IPP_ACT_01.py
### 自動集計・自動検証_差分検証
### 
### 更新履歴：
### 2024/09/24 IPP_ACT_03_verify_idb_by_diff.py IPP_ACT_05_verify_idb_by_reverse.pyをcheck_IPP_ACT_01.pyに統合した。
### 2024/11/15 P0000Commonのcreate_ippan_chosa_workbook()関数を使用するように修正した。
###############################################################################

import csv
import glob
import hashlib
import json
import os
import sys
import time
import shutil

from datetime import date, datetime, timedelta, timezone

from django.core.management.base import BaseCommand

import sys
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.services import create_ippan_chosa_workbook                   ### 2024/11/15 ADD

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import consume_message 

_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'

### _WAITING = 'WAITING'
### _RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
### _CANCEL = 'CANCEL'

MAX_SHEET_NUMBER = 25                                                          ### IPPANシートの数の最大値 ex 25

###############################################################################
### シートがNONE（NULL）か否かの判別処理
### ※NONE（NULL）ではないセルを見つけたら、False：NONE（NULL）ではないをリターンする。
###############################################################################
def is_sheet_none(ws):
    try:
        ### セル[7:2]: 都道府県がNONE（NULL）か否かを判別しない。
        ### セル[7:3]: 市区町村がNONE（NULL）か否かを判別しない。
        ### セル[7:4]: 水害発生月日がNONE（NULL）か否かを判別する。
        ### セル[7:5]: 水害終了月日がNONE（NULL）か否かを判別する。
        ### セル[7:6]: 水害原因1がNONE（NULL）か否かを判別する。
        ### セル[7:7]: 水害原因2がNONE（NULL）か否かを判別する。
        ### セル[7:8]: 水害原因3がNONE（NULL）か否かを判別する。
        ### セル[7:9]: 水害区域番号がNONE（NULL）か否かを判別する。
        ### セル[10:2]: 水系・沿岸名がNONE（NULL）か否かを判別する。
        ### セル[10:3]: 水系種別がNONE（NULL）か否かを判別する。
        ### セル[10:4]: 河川・海岸名がNONE（NULL）か否かを判別する。
        ### セル[10:5]: 河川種別がNONE（NULL）か否かを判別する。
        ### セル[10:6]: 地盤勾配区分がNONE（NULL）か否かを判別する。
        ### セル[14:2]: 水害区域面積の宅地がNONE（NULL）か否かを判別する。
        ### セル[14:3]: 水害区域面積の農地がNONE（NULL）か否かを判別する。
        ### セル[14:4]: 水害区域面積の地下がNONE（NULL）か否かを判別する。
        ### セル[14:6]: 工種がNONE（NULL）か否かを判別する。
        ### セル[14:8]: 農作物被害額がNONE（NULL）か否かを判別する。
        ### セル[14:10]: 異常気象コードがNONE（NULL）か否かを判別する。
        ### ※NONE（NULL）ではないセルを見つけたら、False：NONE（NULL）ではないをリターンする。
        if ws.cell(row=7, column=4).value is not None: return False
        if ws.cell(row=7, column=5).value is not None: return False
        if ws.cell(row=7, column=6).value is not None: return False
        if ws.cell(row=7, column=7).value is not None: return False
        if ws.cell(row=7, column=8).value is not None: return False
        if ws.cell(row=7, column=9).value is not None: return False

        if ws.cell(row=10, column=2).value is not None: return False
        if ws.cell(row=10, column=3).value is not None: return False
        if ws.cell(row=10, column=4).value is not None: return False
        if ws.cell(row=10, column=5).value is not None: return False
        if ws.cell(row=10, column=6).value is not None: return False

        if ws.cell(row=14, column=2).value is not None: return False
        if ws.cell(row=14, column=3).value is not None: return False
        if ws.cell(row=14, column=4).value is not None: return False
        if ws.cell(row=14, column=6).value is not None: return False
        if ws.cell(row=14, column=8).value is not None: return False
        if ws.cell(row=14, column=10).value is not None: return False

        ### セル[20:2] ws.max_rowから順番に20行までチェックする。
        max_row_temp = 19
        for i in range(ws.max_row + 1, 19, -1):
            if (ws.cell(row=i, column=2).value is not None) or (
                ws.cell(row=i, column=3).value is not None) or (
                ws.cell(row=i, column=4).value is not None) or (
                ws.cell(row=i, column=5).value is not None) or (
                ws.cell(row=i, column=6).value is not None) or (
                ws.cell(row=i, column=7).value is not None) or (
                ws.cell(row=i, column=8).value is not None) or (
                ws.cell(row=i, column=9).value is not None) or (
                ws.cell(row=i, column=10).value is not None) or (
                ws.cell(row=i, column=11).value is not None) or (
                ws.cell(row=i, column=12).value is not None) or (
                ws.cell(row=i, column=13).value is not None) or (
                ws.cell(row=i, column=14).value is not None) or (
                ws.cell(row=i, column=15).value is not None) or (
                ws.cell(row=i, column=16).value is not None) or (
                ws.cell(row=i, column=17).value is not None) or (
                ws.cell(row=i, column=18).value is not None) or (
                ws.cell(row=i, column=19).value is not None) or (
                ws.cell(row=i, column=20).value is not None) or (
                ws.cell(row=i, column=21).value is not None) or (
                ws.cell(row=i, column=22).value is not None) or (
                ws.cell(row=i, column=23).value is not None) or (
                ws.cell(row=i, column=24).value is not None) or (
                ws.cell(row=i, column=25).value is not None) or (
                ws.cell(row=i, column=26).value is not None) or (
                ws.cell(row=i, column=27).value is not None):
                max_row_temp = i
                break
        if max_row_temp >= 20: return False
        
        return True                                                            ### True：NONE（NULL）をリターンする。
    
    except:
        return None                                                            ### NONE：エラーをリターンする。

###############################################################################
### チェック処理 DB VS EXCEL
### ※複数シート対応版
### [I] input_file_path: アップロードされたエクセルのファイルパス
### [I] output_file_path: DBから出力したエクセルのファイルパス
### [O] bool_return: True: 正常、False: 警告または異常 ※突合せ結果の正常、警告または異常ではない。EXCEPTIONの有無を意味している。
### [O] info_count_by_compare_check: 突合せで正常としたデータ数
### [O] warn_count_by_compare_check: 突合せで警告としたデータ数
###############################################################################
def compare_check(input_file_path, output_file_path):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[INFO] check_IPP_ACT_01.compare_check()関数が開始しました。', 'INFO')
        print_log('[DEBUG] check_IPP_ACT_01.compare_check()関数 STEP 1/7.', 'DEBUG')
        print_log('[DEBUG] check_IPP_ACT_01.compare_check()関数 input_file_path={}'.format(input_file_path), 'DEBUG')
        print_log('[DEBUG] check_IPP_ACT_01.compare_check()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        info_count = 0
        warn_count = 0

        #######################################################################
        ### EXCEL入出力処理(0020)
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.compare_check()関数 STEP 2/7.', 'DEBUG')
        wb_input = openpyxl.load_workbook(input_file_path)
        wb_output = openpyxl.load_workbook(output_file_path)

        #######################################################################
        ### EXCEL入出力処理(0030)
        ### 該当するワークシートを探索して、局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.handle.compare_check()関数 STEP 3/7.', 'DEBUG')
        ws_input = []
        for ws_temp in wb_input.worksheets:
            if 'IPPAN' in ws_temp.title:
                ### シートがNON（NULL）でない場合、リストに追加する。
                if is_sheet_none(ws_temp) == False:
                    ws_input.append(ws_temp)
            
        ws_output = []
        for ws_temp in wb_output.worksheets:
            if 'IPPAN' in ws_temp.title:
                ### シートがNON（NULL）でない場合、リストに追加する。
                if is_sheet_none(ws_temp) == False:
                    ws_output.append(ws_temp)

        #######################################################################
        ### 検証処理(0040)
        ### 検証の心臓部、データが入力されているシート数を突合せチェックする。
        ### ※シート数が異なる場合、以降の詳細なチェックに意味がないため、関数を抜ける。
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.handle.compare_check()関数 STEP 4/7.', 'DEBUG')
        if len(ws_input) != len(ws_output):
            warn_count += 1
            return True, info_count, warn_count
        else:
            info_count += 1

        #######################################################################
        ### 検証処理(0050)
        ### 検証の心臓部、ヘッダー部のセルの値をチェックする。
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.handle.compare_check()関数 STEP 5/7.', 'DEBUG')
        for ws_idx, _ in enumerate(ws_input):
            ### 7行目をチェックする。
            for col_idx in [2, 3, 6, 7, 8, 9]:
                if str(ws_input[ws_idx].cell(row=7, column=col_idx).value) != str(ws_output[ws_idx].cell(row=7, column=col_idx).value):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input[ws_idx].title, 
                        ws_output[ws_idx].title, 
                        7, col_idx, 
                        ws_input[ws_idx].cell(row=7, column=col_idx).value, 
                        ws_output[ws_idx].cell(row=7, column=col_idx).value), 'WARN')
                    warn_count += 1
                else:
                    info_count += 1
                    
            ### 7行目、4列目の水害発生年月日をチェックする。※日付の形式が2024-09-01、2024/09/01等があり特別な扱いが必要なため。
            ### 7行目、4列目の水害終了年月日をチェックする。※日付の形式が2024-09-01、2024/09/01等があり特別な扱いが必要なため。
            for col_idx in [4, 5]:
                if (ws_input[ws_idx].cell(row=7, column=col_idx).value == None and ws_output[ws_idx].cell(row=7, column=col_idx).value == None):
                    info_count += 1
                elif (ws_input[ws_idx].cell(row=7, column=col_idx).value == None and ws_output[ws_idx].cell(row=7, column=col_idx).value != None) or (
                      ws_input[ws_idx].cell(row=7, column=col_idx).value != None and ws_output[ws_idx].cell(row=7, column=col_idx).value == None):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input[ws_idx].title, 
                        ws_output[ws_idx].title, 
                        7, col_idx, 
                        ws_input[ws_idx].cell(row=7, column=col_idx).value, 
                        ws_output[ws_idx].cell(row=7, column=col_idx).value), 'WARN')
                    warn_count += 1
                else:
                    if str(ws_input[ws_idx].cell(row=7, column=col_idx).value).replace('-','/').replace('00:00:00','').replace(' ','') != str(ws_output[ws_idx].cell(row=7, column=col_idx).value).replace('-','/').replace('00:00:00','').replace(' ',''):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input[ws_idx].title, 
                            ws_output[ws_idx].title, 
                            7, col_idx, 
                            ws_input[ws_idx].cell(row=7, column=col_idx).value, 
                            ws_output[ws_idx].cell(row=7, column=col_idx).value), 'WARN')
                        warn_count += 1
            
            ### 10行目をチェックする。
            for col_idx in [2, 3, 4, 5, 6]:
                if str(ws_input[ws_idx].cell(row=10, column=col_idx).value) != str(ws_output[ws_idx].cell(row=10, column=col_idx).value):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input[ws_idx].title, 
                        ws_output[ws_idx].title, 
                        10, col_idx, 
                        ws_input[ws_idx].cell(row=10, column=col_idx).value, 
                        ws_output[ws_idx].cell(row=10, column=col_idx).value), 'WARN')
                    warn_count += 1
                else:
                    info_count += 1
    
            ### 14行目をチェックする。
            for col_idx in [2, 3, 4, 8]:
                if (ws_input[ws_idx].cell(row=14, column=col_idx).value == None and 
                    ws_output[ws_idx].cell(row=14, column=col_idx).value == None):
                    info_count += 1
                elif (ws_input[ws_idx].cell(row=14, column=col_idx).value == None and 
                    ws_output[ws_idx].cell(row=14, column=col_idx).value != None):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input[ws_idx].title, 
                        ws_output[ws_idx].title, 
                        14, col_idx, 
                        ws_input[ws_idx].cell(row=14, column=col_idx).value, 
                        ws_output[ws_idx].cell(row=14, column=col_idx).value), 'WARN')
                    warn_count += 1
                elif (ws_input[ws_idx].cell(row=14, column=col_idx).value != None and 
                    ws_output[ws_idx].cell(row=14, column=col_idx).value == None):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input[ws_idx].title, 
                        ws_output[ws_idx].title, 
                        14, col_idx, 
                        ws_input[ws_idx].cell(row=14, column=col_idx).value, 
                        ws_output[ws_idx].cell(row=14, column=col_idx).value), 'WARN')
                    warn_count += 1
                else:
                    if abs(float(ws_input[ws_idx].cell(row=14, column=col_idx).value) - float(ws_output[ws_idx].cell(row=14, column=col_idx).value)) > 1e-5:
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input[ws_idx].title, 
                            ws_output[ws_idx].title, 
                            14, col_idx, 
                            ws_input[ws_idx].cell(row=14, column=col_idx).value, 
                            ws_output[ws_idx].cell(row=14, column=col_idx).value), 'WARN')
                        warn_count += 1
                    else:
                        info_count += 1
    
            for col_idx in [6, 10]:
                if str(ws_input[ws_idx].cell(row=14, column=col_idx).value) != str(ws_output[ws_idx].cell(row=14, column=col_idx).value):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input[ws_idx].title, 
                        ws_output[ws_idx].title, 
                        14, col_idx, 
                        ws_input[ws_idx].cell(row=14, column=col_idx).value, 
                        ws_output[ws_idx].cell(row=14, column=col_idx).value), 'WARN')
                    warn_count += 1
                else:
                    info_count += 1

        #######################################################################
        ### 検証処理(0060)
        ### 検証の心臓部、max_rowをチェックする。
        ### 検証の心臓部、一覧部のセルの値をチェックする。
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.handle.compare_check()関数 STEP 6/7.', 'DEBUG')
        for ws_idx, _ in enumerate(ws_input):
            ### max_rowを比較する。
            ### max_rowが異なる場合、以降の詳細なチェックに意味がないため、次のシートのチェックに進む。
            if ws_input[ws_idx].max_row != ws_output[ws_idx].max_row:
                warn_count += 1
                continue
            else:
                info_count += 1

            ### 20行目以降をチェックする。
            for row_idx in range(20, ws_input[ws_idx].max_row + 1):
                for col_idx in range(1, 6):
                    if str(ws_input[ws_idx].cell(row=row_idx, column=col_idx).value) != str(ws_output[ws_idx].cell(row=row_idx, column=col_idx).value):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input[ws_idx].title, 
                            ws_output[ws_idx].title, 
                            row_idx, col_idx, 
                            ws_input[ws_idx].cell(row=row_idx, column=col_idx).value, 
                            ws_output[ws_idx].cell(row=row_idx, column=col_idx).value), 'WARN')
                        warn_count += 1
                    else:
                        info_count += 1
    
                for col_idx in range(6, 26):
                    if (ws_input[ws_idx].cell(row=row_idx, column=col_idx).value == None and 
                        ws_output[ws_idx].cell(row=row_idx, column=col_idx).value == None):
                        info_count += 1
                    elif (ws_input[ws_idx].cell(row=row_idx, column=col_idx).value == None and 
                        ws_output[ws_idx].cell(row=row_idx, column=col_idx).value != None):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input[ws_idx].title, 
                            ws_output[ws_idx].title, 
                            row_idx, col_idx, 
                            ws_input[ws_idx].cell(row=row_idx, column=col_idx).value, 
                            ws_output[ws_idx].cell(row=row_idx, column=col_idx).value), 'WARN')
                        warn_count += 1
                    elif (ws_input[ws_idx].cell(row=row_idx, column=col_idx).value != None and 
                        ws_output[ws_idx].cell(row=row_idx, column=col_idx).value == None):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input[ws_idx].title, 
                            ws_output[ws_idx].title, 
                            row_idx, col_idx, 
                            ws_input[ws_idx].cell(row=row_idx, column=col_idx).value, 
                            ws_output[ws_idx].cell(row=row_idx, column=col_idx).value), 'WARN')
                        warn_count += 1
                    else:
                        print_log('[DEBUG] 55_2_4 TO-DO COMMENT OUT BELOW LINE, BUT ERROR OCCURRED 情報通信業:5', 'DEBUG')
                        ### if abs(float(ws_input[ws_idx].cell(row=row_idx, column=col_idx).value) - float(ws_output[ws_idx].cell(row=row_idx, column=col_idx).value)) > 1e-5:
                        ###     print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(ws_input[ws_idx].title, ws_output[ws_idx].title, row_idx, col_idx, ws_input[ws_idx].cell(row=row_idx, column=col_idx).value, ws_output[ws_idx].cell(row=row_idx, column=col_idx).value), 'WARN')
                        ###     warn_count += 1
                        ### else:
                        ###     info_count += 1
    
                for col_idx in range(26, 28):
                    if str(ws_input[ws_idx].cell(row=row_idx, column=col_idx).value) != str(ws_output[ws_idx].cell(row=row_idx, column=col_idx).value):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input[ws_idx].title, 
                            ws_output[ws_idx].title, 
                            row_idx, col_idx, 
                            ws_input[ws_idx].cell(row=row_idx, column=col_idx).value, 
                            ws_output[ws_idx].cell(row=row_idx, column=col_idx).value), 'WARN')
                        warn_count += 1
                    else:
                        info_count += 1

        ###############################################################
        ### 戻り値セット処理(0070)
        ###############################################################
        print_log('[DEBUG] check_IPP_ACT_01.handle.compare_check()関数 STEP 7/7.', 'DEBUG')
        print_log('[INFO] check_IPP_ACT_01.handle.compare_check()関数が正常終了しました。', 'INFO')
        return True, info_count, warn_count
    
    except:
        print_log('[ERROR] check_IPP_ACT_01.handle.compare_check()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] check_IPP_ACT_01.handle.compare_check()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] check_IPP_ACT_01.handle.compare_check()関数が異常終了しました。', 'ERROR')
        return False, 0, 0

###############################################################################
### 逆計算チェック処理 DB VS DB
### [I] ippan_header_id: 一般資産調査員調査票ヘッダID
### [O] bool_return: True: 正常、False: 警告または異常 ※逆計算チェック結果の正常、警告または異常ではない。EXCEPTIONの有無を意味している。
### [O] info_count_by_compare_check: 逆計算チェックで正常としたデータ数
### [O] warn_count_by_compare_check: 逆計算チェックで警告としたデータ数
###############################################################################
def reverse_check(ippan_header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[INFO] check_IPP_ACT_01.reverse_check()関数が開始しました。', 'INFO')
        print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 STEP 1/4.', 'DEBUG')
        print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 ippan_header_id={}'.format(ippan_header_id), 'DEBUG')
        info_count = 0
        warn_count = 0

        #######################################################################
        ### DBアクセス処理(0020)
        ### (1)IPPAN_VIEWテーブルにアクセスして、按分計算結果から被害建物棟数等の逆計算結果を取得する。
        ### (2)被害建物の延床面積(入力DB)から逆計算により被害建物棟数を求めた結果
        ### (3)被災世帯数(入力DB)から逆計算により被害建物棟数を求めた結果
        ### (4)被災事業所数(入力DB)から逆計算により被害建物棟数を求めた結果
        ### トリガメッセージにアクションが発行されていなければ、処理を終了する。
        ### ※ネストを浅くするために、処理対象外の場合、処理を終了させる。
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 STEP 2/4.', 'DEBUG')
        PARAMS = dict({
            'IPPAN_HEADER_ID': ippan_header_id
        })
        SQL_SELECT_IPPAN_VIEW = """
            SELECT 
                IV1.IPPAN_ID, 
                IV1.IPPAN_NAME, 
                IV1.IPPAN_HEADER_ID, 
                IV1.IPPAN_HEADER_NAME, 
                IV1.KEN_CODE, 
                IV1.CITY_CODE, 
                TO_CHAR(TIMEZONE('JST', IV1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE, 
                TO_CHAR(TIMEZONE('JST', IV1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE, 
                IV1.CAUSE_1_CODE, 
                IV1.CAUSE_2_CODE, 
                IV1.CAUSE_3_CODE, 
                -- IV1.KUIKI_ID, 
                IV1.SUIKEI_CODE, 
                IV1.SUIKEI_TYPE_CODE, 
                IV1.KASEN_CODE, 
                IV1.KASEN_TYPE_CODE, 
                IV1.GRADIENT_CODE, 
                CASE WHEN (IV1.RESIDENTIAL_AREA) IS NULL THEN 0 ELSE CAST(IV1.RESIDENTIAL_AREA AS NUMERIC(20,10)) END AS RESIDENTIAL_AREA, 
                CASE WHEN (IV1.AGRICULTURAL_AREA) IS NULL THEN 0 ELSE CAST(IV1.AGRICULTURAL_AREA AS NUMERIC(20,10)) END AS AGRICULTURAL_AREA, 
                CASE WHEN (IV1.UNDERGROUND_AREA) IS NULL THEN 0 ELSE CAST(IV1.UNDERGROUND_AREA AS NUMERIC(20,10)) END AS UNDERGROUND_AREA, 
                IV1.KASEN_KAIGAN_CODE, 
                CASE WHEN (IV1.CROP_DAMAGE) IS NULL THEN 0 ELSE CAST(IV1.CROP_DAMAGE AS NUMERIC(20,10)) END AS CROP_DAMAGE, 
                IV1.WEATHER_ID, 
                IV1.BUILDING_CODE, 
                IV1.UNDERGROUND_CODE, 
                IV1.FLOOD_SEDIMENT_CODE, 
                CASE WHEN (IV1.BUILDING_LV00) IS NULL THEN 0 ELSE CAST(IV1.BUILDING_LV00 AS NUMERIC(20,10)) END AS BUILDING_LV00, 
                CASE WHEN (IV1.BUILDING_LV01_49) IS NULL THEN 0 ELSE CAST(IV1.BUILDING_LV01_49 AS NUMERIC(20,10)) END AS BUILDING_LV01_49, 
                CASE WHEN (IV1.BUILDING_LV50_99) IS NULL THEN 0 ELSE CAST(IV1.BUILDING_LV50_99 AS NUMERIC(20,10)) END AS BUILDING_LV50_99, 
                CASE WHEN (IV1.BUILDING_LV100) IS NULL THEN 0 ELSE CAST(IV1.BUILDING_LV100 AS NUMERIC(20,10)) END AS BUILDING_LV100, 
                CASE WHEN (IV1.BUILDING_HALF) IS NULL THEN 0 ELSE CAST(IV1.BUILDING_HALF AS NUMERIC(20,10)) END AS BUILDING_HALF, 
                CASE WHEN (IV1.BUILDING_FULL) IS NULL THEN 0 ELSE CAST(IV1.BUILDING_FULL AS NUMERIC(20,10)) END AS BUILDING_FULL, 
                CASE WHEN (IV1.BUILDING_TOTAL) IS NULL THEN 0 ELSE CAST(IV1.BUILDING_TOTAL AS NUMERIC(20,10)) END AS BUILDING_TOTAL, 
                CASE WHEN (IV1.FLOOR_AREA) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA AS NUMERIC(20,10)) END AS FLOOR_AREA, 
                CASE WHEN (IV1.FAMILY) IS NULL THEN 0 ELSE CAST(IV1.FAMILY AS NUMERIC(20,10)) END AS FAMILY, 
                CASE WHEN (IV1.OFFICE) IS NULL THEN 0 ELSE CAST(IV1.OFFICE AS NUMERIC(20,10)) END AS OFFICE, 
                CASE WHEN (IV1.FLOOR_AREA_LV00) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA_LV00 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV00, 
                CASE WHEN (IV1.FLOOR_AREA_LV01_49) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA_LV01_49 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV01_49, 
                CASE WHEN (IV1.FLOOR_AREA_LV50_99) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA_LV50_99 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV50_99, 
                CASE WHEN (IV1.FLOOR_AREA_LV100) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA_LV100 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV100, 
                CASE WHEN (IV1.FLOOR_AREA_HALF) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA_HALF AS NUMERIC(20,10)) END AS FLOOR_AREA_HALF, 
                CASE WHEN (IV1.FLOOR_AREA_FULL) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA_FULL AS NUMERIC(20,10)) END AS FLOOR_AREA_FULL, 
                CASE WHEN (IV1.FLOOR_AREA_TOTAL) IS NULL THEN 0 ELSE CAST(IV1.FLOOR_AREA_TOTAL AS NUMERIC(20,10)) END AS FLOOR_AREA_TOTAL, 
                CASE WHEN (IV1.FAMILY_LV00) IS NULL THEN 0 ELSE CAST(IV1.FAMILY_LV00 AS NUMERIC(20,10)) END AS FAMILY_LV00, 
                CASE WHEN (IV1.FAMILY_LV01_49) IS NULL THEN 0 ELSE CAST(IV1.FAMILY_LV01_49 AS NUMERIC(20,10)) END AS FAMILY_LV01_49, 
                CASE WHEN (IV1.FAMILY_LV50_99) IS NULL THEN 0 ELSE CAST(IV1.FAMILY_LV50_99 AS NUMERIC(20,10)) END AS FAMILY_LV50_99, 
                CASE WHEN (IV1.FAMILY_LV100) IS NULL THEN 0 ELSE CAST(IV1.FAMILY_LV100 AS NUMERIC(20,10)) END AS FAMILY_LV100, 
                CASE WHEN (IV1.FAMILY_HALF) IS NULL THEN 0 ELSE CAST(IV1.FAMILY_HALF AS NUMERIC(20,10)) END AS FAMILY_HALF, 
                CASE WHEN (IV1.FAMILY_FULL) IS NULL THEN 0 ELSE CAST(IV1.FAMILY_FULL AS NUMERIC(20,10)) END AS FAMILY_FULL, 
                CASE WHEN (IV1.FAMILY_TOTAL) IS NULL THEN 0 ELSE CAST(IV1.FAMILY_TOTAL AS NUMERIC(20,10)) END AS FAMILY_TOTAL, 
                CASE WHEN (IV1.OFFICE_LV00) IS NULL THEN 0 ELSE CAST(IV1.OFFICE_LV00 AS NUMERIC(20,10)) END AS OFFICE_LV00, 
                CASE WHEN (IV1.OFFICE_LV01_49) IS NULL THEN 0 ELSE CAST(IV1.OFFICE_LV01_49 AS NUMERIC(20,10)) END AS OFFICE_LV01_49, 
                CASE WHEN (IV1.OFFICE_LV50_99) IS NULL THEN 0 ELSE CAST(IV1.OFFICE_LV50_99 AS NUMERIC(20,10)) END AS OFFICE_LV50_99, 
                CASE WHEN (IV1.OFFICE_LV100) IS NULL THEN 0 ELSE CAST(IV1.OFFICE_LV100 AS NUMERIC(20,10)) END AS OFFICE_LV100, 
                CASE WHEN (IV1.OFFICE_HALF) IS NULL THEN 0 ELSE CAST(IV1.OFFICE_HALF AS NUMERIC(20,10)) END AS OFFICE_HALF, 
                CASE WHEN (IV1.OFFICE_FULL) IS NULL THEN 0 ELSE CAST(IV1.OFFICE_FULL AS NUMERIC(20,10)) END AS OFFICE_FULL, 
                CASE WHEN (IV1.OFFICE_TOTAL) IS NULL THEN 0 ELSE CAST(IV1.OFFICE_TOTAL AS NUMERIC(20,10)) END AS OFFICE_TOTAL, 
                CASE WHEN (IV1.FARMER_FISHER_LV00) IS NULL THEN 0 ELSE CAST(IV1.FARMER_FISHER_LV00 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV00, 
                CASE WHEN (IV1.FARMER_FISHER_LV01_49) IS NULL THEN 0 ELSE CAST(IV1.FARMER_FISHER_LV01_49 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV01_49, 
                CASE WHEN (IV1.FARMER_FISHER_LV50_99) IS NULL THEN 0 ELSE CAST(IV1.FARMER_FISHER_LV50_99 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV50_99, 
                CASE WHEN (IV1.FARMER_FISHER_LV100) IS NULL THEN 0 ELSE CAST(IV1.FARMER_FISHER_LV100 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV100, 
                -- CASE WHEN (IV1.FARMER_FISHER_HALF) IS NULL THEN 0 ELSE CAST(IV1.FARMER_FISHER_HALF AS NUMERIC(20,10)) END AS FARMER_FISHER_HALF, 
                CASE WHEN (IV1.FARMER_FISHER_FULL) IS NULL THEN 0 ELSE CAST(IV1.FARMER_FISHER_FULL AS NUMERIC(20,10)) END AS FARMER_FISHER_FULL, 
                CASE WHEN (IV1.FARMER_FISHER_TOTAL) IS NULL THEN 0 ELSE CAST(IV1.FARMER_FISHER_TOTAL AS NUMERIC(20,10)) END AS FARMER_FISHER_TOTAL, 
                CASE WHEN (IV1.EMPLOYEE_LV00) IS NULL THEN 0 ELSE CAST(IV1.EMPLOYEE_LV00 AS NUMERIC(20,10)) END AS EMPLOYEE_LV00, 
                CASE WHEN (IV1.EMPLOYEE_LV01_49) IS NULL THEN 0 ELSE CAST(IV1.EMPLOYEE_LV01_49 AS NUMERIC(20,10)) END AS EMPLOYEE_LV01_49, 
                CASE WHEN (IV1.EMPLOYEE_LV50_99) IS NULL THEN 0 ELSE CAST(IV1.EMPLOYEE_LV50_99 AS NUMERIC(20,10)) END AS EMPLOYEE_LV50_99, 
                CASE WHEN (IV1.EMPLOYEE_LV100) IS NULL THEN 0 ELSE CAST(IV1.EMPLOYEE_LV100 AS NUMERIC(20,10)) END AS EMPLOYEE_LV100, 
                -- CASE WHEN (IV1.EMPLOYEE_HALF) IS NULL THEN 0 ELSE CAST(IV1.EMPLOYEE_HALF AS NUMERIC(20,10)) END AS EMPLOYEE_HALF, 
                CASE WHEN (IV1.EMPLOYEE_FULL) IS NULL THEN 0 ELSE CAST(IV1.EMPLOYEE_FULL AS NUMERIC(20,10)) END AS EMPLOYEE_FULL,
                CASE WHEN (IV1.EMPLOYEE_TOTAL) IS NULL THEN 0 ELSE CAST(IV1.EMPLOYEE_TOTAL AS NUMERIC(20,10)) END AS EMPLOYEE_TOTAL, 
                IV1.INDUSTRY_CODE, 
                IV1.USAGE_CODE,
                IV1.COMMENT, 
                TO_CHAR(TIMEZONE('JST', IV1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', IV1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                -- 被害建物の延床面積(入力DB)から逆計算により被害建物棟数を求めた結果
                CASE WHEN ABS(IV1.FLOOR_AREA_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FLOOR_AREA_LV00 / IV1.FLOOR_AREA_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV00_REVERSE_FLOOR_AREA, 
                CASE WHEN ABS(IV1.FLOOR_AREA_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FLOOR_AREA_LV01_49 / IV1.FLOOR_AREA_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV01_49_REVERSE_FLOOR_AREA, 
                CASE WHEN ABS(IV1.FLOOR_AREA_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FLOOR_AREA_LV50_99 / IV1.FLOOR_AREA_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV50_99_REVERSE_FLOOR_AREA, 
                CASE WHEN ABS(IV1.FLOOR_AREA_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FLOOR_AREA_LV100 / IV1.FLOOR_AREA_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV100_REVERSE_FLOOR_AREA, 
                CASE WHEN ABS(IV1.FLOOR_AREA_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FLOOR_AREA_HALF / IV1.FLOOR_AREA_TOTAL AS NUMERIC(20,10)) END AS BUILDING_HALF_REVERSE_FLOOR_AREA, 
                CASE WHEN ABS(IV1.FLOOR_AREA_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FLOOR_AREA_FULL / IV1.FLOOR_AREA_TOTAL AS NUMERIC(20,10)) END AS BUILDING_FULL_REVERSE_FLOOR_AREA, 
                -- 被災世帯数(入力DB)から逆計算により被害建物棟数を求めた結果
                CASE WHEN ABS(IV1.FAMILY_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FAMILY_LV00 / IV1.FAMILY_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV00_REVERSE_FAMILY, 
                CASE WHEN ABS(IV1.FAMILY_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FAMILY_LV01_49 / IV1.FAMILY_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV01_49_REVERSE_FAMILY, 
                CASE WHEN ABS(IV1.FAMILY_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FAMILY_LV50_99 / IV1.FAMILY_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV50_99_REVERSE_FAMILY, 
                CASE WHEN ABS(IV1.FAMILY_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FAMILY_LV100 / IV1.FAMILY_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV100_REVERSE_FAMILY, 
                CASE WHEN ABS(IV1.FAMILY_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FAMILY_HALF / IV1.FAMILY_TOTAL AS NUMERIC(20,10)) END AS BUILDING_HALF_REVERSE_FAMILY, 
                CASE WHEN ABS(IV1.FAMILY_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.FAMILY_FULL / IV1.FAMILY_TOTAL AS NUMERIC(20,10)) END AS BUILDING_FULL_REVERSE_FAMILY, 
                -- 被災事業所数(入力DB)から逆計算により被害建物棟数を求めた結果
                CASE WHEN ABS(IV1.OFFICE_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.OFFICE_LV00 / IV1.OFFICE_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV00_REVERSE_OFFICE, 
                CASE WHEN ABS(IV1.OFFICE_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.OFFICE_LV01_49 / IV1.OFFICE_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV01_49_REVERSE_OFFICE, 
                CASE WHEN ABS(IV1.OFFICE_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.OFFICE_LV50_99 / IV1.OFFICE_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV50_99_REVERSE_OFFICE, 
                CASE WHEN ABS(IV1.OFFICE_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.OFFICE_LV100 / IV1.OFFICE_TOTAL AS NUMERIC(20,10)) END AS BUILDING_LV100_REVERSE_OFFICE, 
                CASE WHEN ABS(IV1.OFFICE_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.OFFICE_HALF / IV1.OFFICE_TOTAL AS NUMERIC(20,10)) END AS BUILDING_HALF_REVERSE_OFFICE, 
                CASE WHEN ABS(IV1.OFFICE_TOTAL) <= 0.0000001 THEN 0 ELSE CAST(IV1.BUILDING_TOTAL * IV1.OFFICE_FULL / IV1.OFFICE_TOTAL AS NUMERIC(20,10)) END AS BUILDING_FULL_REVERSE_OFFICE 
            FROM IPPAN_VIEW IV1 
            WHERE 
                IV1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                IV1.DELETED_AT IS NULL 
            ORDER BY 
                CAST(IV1.IPPAN_ID AS INTEGER)"""
                
        ippan_reverse_list = IPPAN_VIEW.objects.raw(SQL_SELECT_IPPAN_VIEW, PARAMS)

        if bool(ippan_reverse_list) == False:
            print_log('[WARN] check_IPP_ACT_01.reverse_check()関数が警告終了しました。', 'WARN')
            return False, 0, 0

        #######################################################################
        ### 検証処理(0030)
        ### 検証の心臓部
        ### 成功、失敗の行数、レコード数をカウントする。
        ### 成功:按分計算結果から逆計算した結果と入力DBに登録されている被害建物棟数が同じ場合、成功とする。
        ### 失敗:按分計算結果から逆計算した結果と入力DBに登録されている被害建物棟数が異なる場合、失敗とする。
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 STEP 3/4.', 'DEBUG')
        for ippan in ippan_reverse_list:
            ###################################################################
            ### 被害建物の延床面積(入力DB)から逆計算により被害建物棟数を求めた結果
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 STEP 3_1/4.', 'DEBUG')
            ### FOR DEBUG
            ### print_log('ippan.building_lv00_reverse_floor_area={}'.format(ippan.building_lv00_reverse_floor_area), 'DEBUG') ### NONE
            ### print_log('str(ippan.building_lv00_reverse_floor_area)={}'.format(str(ippan.building_lv00_reverse_floor_area)), 'DEBUG') ### NONE
            ### print_log('bool(str(ippan.building_lv00_reverse_floor_area))={}'.format(bool(str(ippan.building_lv00_reverse_floor_area))), 'DEBUG') ### TRUE
            
            ### print_log('ippan.building_lv00_reverse_floor_area == None={}'.format(ippan.building_lv00_reverse_floor_area == None), 'DEBUG') ### True
            ### print_log('ippan.building_lv00_reverse_floor_area != None={}'.format(ippan.building_lv00_reverse_floor_area != None), 'DEBUG') ### False
            ### print_log('ippan.building_lv00_reverse_floor_area is None={}'.format(ippan.building_lv00_reverse_floor_area is None), 'DEBUG') ### True
            ### print_log('ippan.building_lv00_reverse_floor_area is not None={}'.format(ippan.building_lv00_reverse_floor_area is not None), 'DEBUG') ### False

            ### print_log('ippan.building_lv00 == None={}'.format(ippan.building_lv00 == None), 'DEBUG') ### False
            ### print_log('ippan.building_lv00 != None={}'.format(ippan.building_lv00 != None), 'DEBUG') ### True
            ### print_log('ippan.building_lv00 is None={}'.format(ippan.building_lv00 is None), 'DEBUG') ### False
            ### print_log('ippan.building_lv00 is not None={}'.format(ippan.building_lv00 is not None), 'DEBUG') ### True
            ### FOR DEBUG

            print(1)
            if (ippan.building_lv00_reverse_floor_area == None and ippan.building_lv00 == None):
                info_count += 1
            elif (ippan.building_lv00_reverse_floor_area == None and ippan.building_lv00 != None) or (
                   ippan.building_lv00_reverse_floor_area != None and ippan.building_lv00 == None):
                print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_floor_area, ippan.building_lv00), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv00_reverse_floor_area) - float(ippan.building_lv00)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_floor_area, ippan.building_lv00), 'WARN')
                    warn_count += 1
                    
            print(2)
            if (ippan.building_lv01_49_reverse_floor_area == None and ippan.building_lv01_49 == None):
                info_count += 1
            elif (ippan.building_lv01_49_reverse_floor_area == None and ippan.building_lv01_49 != None) or (
                  ippan.building_lv01_49_reverse_floor_area != None and ippan.building_lv01_49 == None):
                print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_floor_area, ippan.building_lv01_49), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv01_49_reverse_floor_area) - float(ippan.building_lv01_49)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_floor_area, ippan.building_lv01_49), 'WARN')
                    warn_count += 1
                    
            print(3)
            if (ippan.building_lv50_99_reverse_floor_area == None and ippan.building_lv50_99 == None):
                info_count += 1
            elif (ippan.building_lv50_99_reverse_floor_area == None and ippan.building_lv50_99 != None) or (
                  ippan.building_lv50_99_reverse_floor_area != None and ippan.building_lv50_99 == None):
                print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_floor_area, ippan.building_lv50_99), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv50_99_reverse_floor_area) - float(ippan.building_lv50_99)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_floor_area, ippan.building_lv50_99), 'WARN')
                    warn_count += 1
                    
            print(4)
            if (ippan.building_lv100_reverse_floor_area == None and ippan.building_lv100 == None):
                info_count += 1
            elif (ippan.building_lv100_reverse_floor_area == None and ippan.building_lv100 != None) or (
                  ippan.building_lv100_reverse_floor_area != None and ippan.building_lv100 == None):
                print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_floor_area, ippan.building_lv100), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv100_reverse_floor_area) - float(ippan.building_lv100)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_floor_area, ippan.building_lv100), 'WARN')
                    warn_count += 1
                    
            print(5)
            if (ippan.building_half_reverse_floor_area == None and ippan.building_half == None):
                info_count += 1
            elif (ippan.building_half_reverse_floor_area == None and ippan.building_half != None) or (
                  ippan.building_half_reverse_floor_area != None and ippan.building_half == None):
                print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_floor_area, ippan.building_half), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_half_reverse_floor_area) - float(ippan.building_half)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_floor_area, ippan.building_half), 'WARN')
                    warn_count += 1
                    
            print(6)
            if (ippan.building_full_reverse_floor_area == None and ippan.building_full == None):
                info_count += 1
            elif (ippan.building_full_reverse_floor_area == None and ippan.building_full != None) or (
                  ippan.building_full_reverse_floor_area != None and ippan.building_full == None):
                print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_floor_area, ippan.building_full), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_full_reverse_floor_area) - float(ippan.building_full)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_floor_area, ippan.building_full), 'WARN')
                    warn_count += 1

            ###################################################################
            ### 被災世帯数(入力DB)から逆計算により被害建物棟数を求めた結果
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 STEP 3_2/4.', 'DEBUG')
            if (ippan.building_lv00_reverse_family == None and ippan.building_lv00 == None):
                info_count += 1
            elif (ippan.building_lv00_reverse_family == None and ippan.building_lv00 != None) or (
                  ippan.building_lv00_reverse_family != None and ippan.building_lv00 == None):
                print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_family, ippan.building_lv00), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv00_reverse_family) - float(ippan.building_lv00)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_family, ippan.building_lv00), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_lv01_49_reverse_family == None and ippan.building_lv01_49 == None):
                info_count += 1
            elif (ippan.building_lv01_49_reverse_family == None and ippan.building_lv01_49 != None) or (
                  ippan.building_lv01_49_reverse_family != None and ippan.building_lv01_49 == None):
                print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_family, ippan.building_lv01_49), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv01_49_reverse_family) - float(ippan.building_lv01_49)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_family, ippan.building_lv01_49), 'WARN')
                    warn_count += 1

            if (ippan.building_lv50_99_reverse_family == None and ippan.building_lv50_99 == None):
                info_count += 1
            elif (ippan.building_lv50_99_reverse_family == None and ippan.building_lv50_99 != None) or (
                  ippan.building_lv50_99_reverse_family != None and ippan.building_lv50_99 == None):
                print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_family, ippan.building_lv50_99), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv50_99_reverse_family) - float(ippan.building_lv50_99)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_family, ippan.building_lv50_99), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_lv100_reverse_family == None and ippan.building_lv100 == None):
                info_count += 1
            elif (ippan.building_lv100_reverse_family == None and ippan.building_lv100 != None) or (
                  ippan.building_lv100_reverse_family != None and ippan.building_lv100 == None):
                print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_family, ippan.building_lv100), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv100_reverse_family) - float(ippan.building_lv100)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_family, ippan.building_lv100), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_half_reverse_family == None and ippan.building_half == None):
                info_count += 1
            elif (ippan.building_half_reverse_family == None and ippan.building_half != None)  or (
                  ippan.building_half_reverse_family != None and ippan.building_half == None):
                print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_family, ippan.building_half), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_half_reverse_family) - float(ippan.building_half)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_family, ippan.building_half), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_full_reverse_family == None and ippan.building_full == None):
                info_count += 1
            elif (ippan.building_full_reverse_family == None and ippan.building_full != None) or (
                  ippan.building_full_reverse_family != None and ippan.building_full == None):
                print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_family, ippan.building_full), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_full_reverse_family) - float(ippan.building_full)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_family, ippan.building_full), 'WARN')
                    warn_count += 1

            ###################################################################
            ### 被災事業所数(入力DB)から逆計算により被害建物棟数を求めた結果
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 STEP 3_3/4.', 'DEBUG')
            if (ippan.building_lv00_reverse_office == None and ippan.building_lv00 == None):
                info_count += 1
            elif (ippan.building_lv00_reverse_office == None and ippan.building_lv00 != None) or (
                  ippan.building_lv00_reverse_office != None and ippan.building_lv00 == None):
                print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_office, ippan.building_lv00), 'WARN')
                warn_count += 1
            else: 
                if abs(float(ippan.building_lv00_reverse_office) - float(ippan.building_lv00)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_office, ippan.building_lv00), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_lv01_49_reverse_office == None and ippan.building_lv01_49 == None):
                info_count += 1
            elif (ippan.building_lv01_49_reverse_office == None and ippan.building_lv01_49 != None) or (
                  ippan.building_lv01_49_reverse_office != None and ippan.building_lv01_49 == None):
                print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_office, ippan.building_lv01_49), 'WARN')
                warn_count += 1
            else: 
                if abs(float(ippan.building_lv01_49_reverse_office) - float(ippan.building_lv01_49)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_office, ippan.building_lv01_49), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_lv50_99_reverse_office == None and ippan.building_lv50_99 == None):
                info_count += 1
            elif (ippan.building_lv50_99_reverse_office == None and ippan.building_lv50_99 != None) or (
                  ippan.building_lv50_99_reverse_office != None and ippan.building_lv50_99 == None):
                print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_office, ippan.building_lv50_99), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv50_99_reverse_office) - float(ippan.building_lv50_99)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_office, ippan.building_lv50_99), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_lv100_reverse_office == None and ippan.building_lv100 == None):
                info_count += 1
            elif (ippan.building_lv100_reverse_office == None and ippan.building_lv100 != None) or (
                  ippan.building_lv100_reverse_office != None and ippan.building_lv100 == None):
                print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_office, ippan.building_lv100), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_lv100_reverse_office) - float(ippan.building_lv100)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_office, ippan.building_lv100), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_half_reverse_office == None and ippan.building_half == None):
                info_count += 1
            elif (ippan.building_half_reverse_office == None and ippan.building_half != None) or (
                  ippan.building_half_reverse_office != None and ippan.building_half == None):
                print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_office, ippan.building_half), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_half_reverse_office) - float(ippan.building_half)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_office, ippan.building_half), 'WARN')
                    warn_count += 1
                    
            if (ippan.building_full_reverse_office == None and ippan.building_full == None):
                info_count += 1
            elif (ippan.building_full_reverse_office == None and ippan.building_full != None) or (
                  ippan.building_full_reverse_office != None and ippan.building_full == None):
                print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_office, ippan.building_full), 'WARN')
                warn_count += 1
            else:
                if abs(float(ippan.building_full_reverse_office) - float(ippan.building_full)) <= 1e-7:
                    info_count += 1
                else:
                    print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_office, ippan.building_full), 'WARN')
                    warn_count += 1

        #######################################################################
        ### 戻り値セット処理(0040)
        #######################################################################
        print_log('[DEBUG] check_IPP_ACT_01.reverse_check()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] check_IPP_ACT_01.reverse_check()関数が正常終了しました。', 'INFO')
        return True, info_count, warn_count
    
    except:
        print_log('[ERROR] check_IPP_ACT_01.reverse_check()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] check_IPP_ACT_01.reverse_check()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] check_IPP_ACT_01.reverse_check()関数が異常終了しました。', 'ERROR')
        return False, 0, 0

###############################################################################
### クラス名：Command(BaseCommand)
### (1)家屋被害額 = 延床面積 x 家屋評価額 x 浸水または土砂ごとの勾配差による被害率
### (2)家庭用品自動車以外被害額 = 世帯数 x 浸水または土砂ごとの家庭用品被害率 x 家庭用品自動車以外所有額
### (3)家庭用品自動車被害額 = 世帯数 x 自動車被害率 x 家庭用品自動車所有額
### (4)家庭応急対策費 = (世帯数 x 活動費) + (世帯数 x 清掃日数 x 清掃労働単価)
### (5)事業所被害額 = 従業者数 x 産業分類ごとの償却資産 x 浸水または土砂ごとの被害率 + 
### 　　　　　　　　　従業者数 x 産業分類ごとの在庫資産 x 浸水または土砂ごとの被害率
### (6)事業所営業損失額 = 従業者数 x (営業停止日数 + 停滞日数/2) x 付加価値額
### (7)農漁家被害額 = 農漁家戸数 x 農漁家の償却資産 x 浸水または土砂ごとの被害率 + 
###                   農漁家戸数 x 農漁家の在庫資産 x 浸水または土砂ごとの被害率
### (8)事業所応急対策費 = 事業所数 x 代替活動費
###############################################################################
class Command(BaseCommand):
    
    ###########################################################################
    ### 関数名：handle(self, *args, **options)
    ### チェックOKの場合、トリガーの状態を成功に更新、消費日時をカレントに更新、新たなトリガーを生成する。
    ### チェックNGの場合、トリガーの状態を失敗に更新、消費日時をカレントに更新する。
    ### チェックNGの場合、当該水害IDについて、以降の処理を止めて、手動？で再実行、または、入力データから再登録するイメージである。
    ### 上記は、このアプリの共通の考え方とする。
    ###########################################################################
    def handle(self, *args, **options):
        try:
            ###################################################################
            ### 引数チェック処理(0010)
            ###################################################################
            reset_log()
            print_log('[INFO] check_IPP_ACT_01.handle()関数が開始しました。', 'INFO')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 1/9.', 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0020)
            ### メッセージキューから当該アクションが対象とするメッセージを取得する。
            ### ※ネストを浅くするため、メッセージが発行されていなければ、処理を終了する。
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 2/9.', 'DEBUG')
            metadata = dict({
                'action_code': _IPP_ACT_01,
                'status_code': ''
            })
            bool_return, ippan_trigger_list = get_message(metadata)
            if bool_return == False:
                print_log('[WARN] get_message()関数が警告終了しました。', 'WARN')
                return 4
            
            if bool(ippan_trigger_list) == False:
                print_log('[INFO] check_IPP_ACT_01.handle()関数が正常終了しました。', 'INFO')
                return 0
            
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].ippan_trigger_id={}'.format(ippan_trigger_list[0].ippan_trigger_id), 'DEBUG')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].ippan_header_id={}'.format(ippan_trigger_list[0].ippan_header_id), 'DEBUG') ### 2024/11/14 IPPAN_HEADER_IDはセットされていない。
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].city_code={}'.format(ippan_trigger_list[0].city_code), 'DEBUG')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].ken_code={}'.format(ippan_trigger_list[0].ken_code), 'DEBUG')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].download_file_path={}'.format(ippan_trigger_list[0].download_file_path), 'DEBUG')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].download_file_name={}'.format(ippan_trigger_list[0].download_file_name), 'DEBUG')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].upload_file_path={}'.format(ippan_trigger_list[0].upload_file_path), 'DEBUG')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 ippan_trigger_list[0].upload_file_name={}'.format(ippan_trigger_list[0].upload_file_name), 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0030)
            ### IPPAN_TRIGGERのCITY_CODEから県名、市区町村名を取得する。
            ### IPPAN_TRIGGERのCITY_CODEから、あれば、IPPAN_HEADERのリストを取得する。※0件も正常。
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 3/9.', 'DEBUG')
            PARAMS_SELECT = dict({
                'CITY_CODE': ippan_trigger_list[0].city_code
            })
            SQL_SELECT_CITY = """
                SELECT 
                    CT1.CITY_CODE AS CITY_CODE, 
                    CT1.CITY_NAME AS CITY_NAME, 
                    CT1.KEN_CODE AS KEN_CODE, 
                    KE1.KEN_NAME AS KEN_NAME 
                FROM CITY CT1 
                LEFT JOIN KEN KE1 ON CT1.KEN_CODE=KE1.KEN_CODE 
                WHERE 
                    CT1.CITY_CODE=%(CITY_CODE)s LIMIT 1"""
            SQL_SELECT_IPPAN_HEADER = """
                SELECT 
                    * 
                FROM IPPAN_HEADER 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL 
                ORDER BY 
                    CAST(IPPAN_HEADER_ID AS INTEGER)"""

            city_list = CITY.objects.raw(SQL_SELECT_CITY, PARAMS_SELECT)
            ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS_SELECT)
                
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 city_list[0].ken_name={}'.format(city_list[0].ken_name), 'DEBUG')
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 city_list[0].city_name={}'.format(city_list[0].city_name), 'DEBUG')

            #######################################################################
            ### 局所変数セット処理(0040)
            ### ハッシュコードを生成する。
            ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
            #######################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 4/9.', 'DEBUG')
            JST = timezone(timedelta(hours=9), 'JST')
            datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
            hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
            print_log('[DEBUG] check_IPP_ACT_01.handle()()関数 hash_code={}'.format(hash_code), 'DEBUG')
    
            #######################################################################
            ### 局所変数セット処理(0050)
            ### 出力用ファイルパスに値をセットする。
            ### 出力用ディレクトリを生成する。
            ### ※ダウンロード用ファイルパスは一括ダウンロード時にしかセットされていないので、ここでは使用しないこと。
            #######################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 5/9.', 'DEBUG')
            excel_file_path = 'static/tmp/' + str(hash_code) + '/ippan_chosa_'+ str(hash_code) + '.xlsx'
            dir_path = 'static/tmp/' + str(hash_code)
            os.makedirs(dir_path, exist_ok=True)

            ###################################################################
            ### 局所変数セット処理(0060)
            ### テンプレート用ファイルパスをセットする。
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 6/9.', 'DEBUG')
            template_file_path = 'static/template/template_ippan_chosa.xlsx'

            ###################################################################
            ### 関数コール処理(0070)
            ### EXCELワークブックを生成する関数をコールする。
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 7/9.', 'DEBUG')
            bool_return, workbook_return = create_ippan_chosa_workbook(
                template_file_path = template_file_path,
                ippan_header_list = ippan_header_list,
                ken_code = ippan_trigger_list[0].ken_code,
                city_code = ippan_trigger_list[0].city_code,
                ken_name = city_list[0].ken_name,
                city_name = city_list[0].city_name,
                MAX_SHEET_NUMBER = MAX_SHEET_NUMBER
            )
            if bool_return == False:
                raise Exception

            print_log('excel_file_path={}'.format(excel_file_path), 'DEBUG')
            workbook_return.save(excel_file_path)

            ###################################################################
            ### 関数コール処理(0060)
            ### アップロードされたエクセルファイルとDBから出力したエクセルファイルを突合せチェックする。
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 6/9.', 'DEBUG')
            bool_return, info_count_by_compare_check, warn_count_by_compare_check = compare_check(
                input_file_path = ippan_trigger_list[0].upload_file_path, 
                output_file_path = excel_file_path)

            ###################################################################
            ### 関数コール処理(0070)
            ### アップロードされたエクセルファイルとDBから出力したエクセルファイルを突合せチェックする。
            ###################################################################
            ### print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 7/9.', 'DEBUG')
            ### bool_return, info_count_by_reverse_check, warn_count_by_reverse_check = reverse_check(
            ###     ippan_header_id = ippan_trigger_list[0].ippan_header_id)
            info_count_by_reverse_check = 0
            warn_count_by_reverse_check = 0

            ###################################################################
            ### DBアクセス処理(0080)
            ### トリガーデータを更新する。
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 8/9.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                ### チェックで問題が見つからなかった
                if (warn_count_by_compare_check == 0) and (warn_count_by_reverse_check == 0):
                    PARAMS_MESSAGE = dict({
                        'connection_cursor': connection_cursor, 
                        'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                        'action_code': _IPP_ACT_01, 
                        'status_code': _SUCCESS, 
                        'info_count': info_count_by_compare_check + info_count_by_reverse_check, 
                        'warn_count': warn_count_by_compare_check + warn_count_by_reverse_check, 
                        'info_log': get_info_log(), 
                        'warn_log': get_warn_log()
                    })
                ### チェックで問題が見つかった
                else:
                    PARAMS_MESSAGE = dict({
                        'connection_cursor': connection_cursor, 
                        'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                        'action_code': _IPP_ACT_01, 
                        'status_code': _FAILURE, 
                        'info_count': info_count_by_compare_check + info_count_by_reverse_check, 
                        'warn_count': warn_count_by_compare_check + warn_count_by_reverse_check, 
                        'info_log': get_info_log(), 
                        'warn_log': get_warn_log()
                    })
                bool_return = consume_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                    connection_cursor.execute("""ROLLBACK""")
                    return 4
    
                ### チェックで問題が見つからなかった
                ### 次のトリガーメッセージ（集計）を発行する。
                if (warn_count_by_compare_check == 0) and (warn_count_by_reverse_check == 0):
                    print_log('[DEBUG] header_id={}'.format(ippan_trigger_list[0].ippan_header_id), 'DEBUG')
                    print_log('[DEBUG] ken_code={}'.format(ippan_trigger_list[0].ken_code), 'DEBUG')
                    print_log('[DEBUG] city_code={}'.format(ippan_trigger_list[0].city_code), 'DEBUG')
                    print_log('[DEBUG] action_code={}'.format(_IPP_ACT_02), 'DEBUG')
                    print_log('[DEBUG] upload_file_path={}'.format(ippan_trigger_list[0].upload_file_path), 'DEBUG')
                    print_log('[DEBUG] upload_file_name={}'.format(ippan_trigger_list[0].upload_file_name), 'DEBUG')
                    PARAMS_MESSAGE = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': str(ippan_trigger_list[0].ippan_header_id), 
                        'ken_code': str(ippan_trigger_list[0].ken_code), 
                        'city_code': str(ippan_trigger_list[0].city_code), 
                        'action_code': _IPP_ACT_02, 
                        'status_code': '',
                        'upload_file_path': str(ippan_trigger_list[0].upload_file_path), 
                        'upload_file_name': str(ippan_trigger_list[0].upload_file_name),
                        'download_file_path': '',
                        'download_file_name': ''
                    })
                    bool_return = publish_message(PARAMS_MESSAGE)
                    if bool_return == False:
                        print_log('[WARN] publish_message()関数が警告終了しました。', 'WARN')
                        connection_cursor.execute("""ROLLBACK""")
                        return 4
                        
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] check_IPP_ACT_01.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] check_IPP_ACT_01.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] check_IPP_ACT_01.handle()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                return 8
                
            finally:
                ### try except finallyのtry文中でreturnを発生させた場合、
                ### finally文中のconnection_cursor.close()が実行されて、
                ### その後に関数を抜ける。
                ### したがって、finally文中でreturnする必要はない。
                connection_cursor.close()
                
            ###################################################################
            ### 戻り値セット処理(0090)
            ###################################################################
            print_log('[DEBUG] check_IPP_ACT_01.handle()関数 STEP 9/9.', 'DEBUG')
            print_log('[INFO] check_IPP_ACT_01.handle()関数が正常終了しました。', 'INFO')
            return 0
        
        except:
            print_log('[ERROR] check_IPP_ACT_01.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] check_IPP_ACT_01.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] check_IPP_ACT_01.handle()関数が異常終了しました。', 'ERROR')
            return 8
            