###############################################################################
### ファイル名：P0900Action/management/commands/summarize_IPP_ACT_02.py
### 自動集計・自動検証_集計処理
### 更新履歴：
### 2024/09/24 IPP_ACT_06_summarize_sdb.py IPP_ACT_07_verify_sdb_by_reverse.pyをsummarize_IPP_ACT_02.pyに統合した。
###############################################################################

from django.core.management.base import BaseCommand

import sys
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from MessageQueue.views import get_message 
from MessageQueue.views import consume_message 

_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'

_SUCCESS = 'SUCCESS'

###############################################################################
### クラス名：Command(BaseCommand)
### (1)家屋被害額 = 延床面積 x 家屋評価額 x 浸水または土砂ごとの勾配差による被害率
### (2)家庭用品自動車以外被害額 = 世帯数 x 浸水または土砂ごとの家庭用品被害率 x 家庭用品自動車以外所有額
### (3)家庭用品自動車被害額 = 世帯数 x 自動車被害率 x 家庭用品自動車所有額
### (4)家庭応急対策費 = (世帯数 x 活動費) + (世帯数 x 清掃日数 x 清掃労働単価)
### (5)事業所被害額 = 従業者数 x 産業分類ごとの償却資産 x 浸水または土砂ごとの被害率 + 
### 　　　　　　　　　従業者数 x 産業分類ごとの在庫資産 x 浸水または土砂ごとの被害率
### (6)事業所営業損失額 = 従業者数 x (営業停止日数 + 停滞日数/2) x 付加価値額
### (7)農漁家被害額 = 農漁家戸数 x 農漁家の償却資産 x 浸水または土砂ごとの被害率 + 
###                   農漁家戸数 x 農漁家の在庫資産 x 浸水または土砂ごとの被害率
### (8)事業所応急対策費 = 事業所数 x 代替活動費
###############################################################################
class Command(BaseCommand):
    
    ###########################################################################
    ### 関数名：handle(self, *args, **options)
    ### 集計OKの場合、トリガーの状態を成功に更新、消費日時をカレントに更新、新たなトリガーを生成する。
    ### 集計NGの場合、トリガーの状態を失敗に更新、消費日時をカレントに更新する。
    ### 集計NGの場合、当該水害IDについて、以降の処理を止めて、手動？で再実行、または、入力データから再登録するイメージである。
    ### 上記は、このアプリの共通の考え方とする。
    ###########################################################################
    def handle(self, *args, **options):
        try:
            ###################################################################
            ### 引数チェック処理(0010)
            ###################################################################
            reset_log()
            print_log('[INFO] summarize_IPP_ACT_02.handle()関数が開始しました。', 'INFO')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 STEP 1/4.', 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0020)
            ### メッセージキューから当該アクションが対象とするメッセージを取得する。
            ### ※ネストを浅くするため、メッセージが発行されていなければ、処理を終了する。
            ###################################################################
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 STEP 2/4.', 'DEBUG')
            PARAMS_MESSAGE = dict({
                'action_code': _IPP_ACT_02, 
                'status_code': ''
            })
            bool_return, ippan_trigger_list = get_message(PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[WARN] get_message()関数が警告終了しました。', 'WARN')
                return 4

            if bool(ippan_trigger_list) == False:
                print_log('[INFO] summarize_IPP_ACT_02.handle()関数が正常終了しました。', 'INFO')
                return 0

            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].ippan_trigger_id={}'.format(ippan_trigger_list[0].ippan_trigger_id), 'DEBUG')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].ippan_header_id={}'.format(ippan_trigger_list[0].ippan_header_id), 'DEBUG')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].city_code={}'.format(ippan_trigger_list[0].city_code), 'DEBUG')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].ken_code={}'.format(ippan_trigger_list[0].ken_code), 'DEBUG')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].download_file_path={}'.format(ippan_trigger_list[0].download_file_path), 'DEBUG')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].download_file_name={}'.format(ippan_trigger_list[0].download_file_name), 'DEBUG')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].upload_file_path={}'.format(ippan_trigger_list[0].upload_file_path), 'DEBUG')
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 ippan_trigger_list[0].upload_file_name={}'.format(ippan_trigger_list[0].upload_file_name), 'DEBUG')
            
            ###################################################################
            ### DBアクセス処理(0030)
            ### DBから集計データを1件削除する。
            ###################################################################
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 STEP 3/4.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                PARAMS = dict({
                    'IPPAN_HEADER_ID': ippan_trigger_list[0].ippan_header_id
                })
                SQL_UPDATE_IPPAN_SUMMARY = """
                    UPDATE IPPAN_SUMMARY SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE 
                        IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                        DELETED_AT IS NULL"""
                SQL_INSERT_IPPAN_SUMMARY = """
                    INSERT INTO IPPAN_SUMMARY (
                        IPPAN_ID, 
                        IPPAN_HEADER_ID, 
                        HOUSE_SUMMARY_LV00, 
                        HOUSE_SUMMARY_LV01_49, 
                        HOUSE_SUMMARY_LV50_99, 
                        HOUSE_SUMMARY_LV100, 
                        HOUSE_SUMMARY_HALF, 
                        HOUSE_SUMMARY_FULL, 
                        HOUSEHOLD_SUMMARY_LV00, 
                        HOUSEHOLD_SUMMARY_LV01_49, 
                        HOUSEHOLD_SUMMARY_LV50_99, 
                        HOUSEHOLD_SUMMARY_LV100, 
                        HOUSEHOLD_SUMMARY_HALF, 
                        HOUSEHOLD_SUMMARY_FULL, 
                        CAR_SUMMARY_LV00, 
                        CAR_SUMMARY_LV01_49, 
                        CAR_SUMMARY_LV50_99, 
                        CAR_SUMMARY_LV100, 
                        CAR_SUMMARY_HALF, 
                        CAR_SUMMARY_FULL, 
                        HOUSE_ALT_SUMMARY_LV00, 
                        HOUSE_ALT_SUMMARY_LV01_49, 
                        HOUSE_ALT_SUMMARY_LV50_99, 
                        HOUSE_ALT_SUMMARY_LV100, 
                        HOUSE_ALT_SUMMARY_HALF, 
                        HOUSE_ALT_SUMMARY_FULL, 
                        HOUSE_CLEAN_SUMMARY_LV00, 
                        HOUSE_CLEAN_SUMMARY_LV01_49, 
                        HOUSE_CLEAN_SUMMARY_LV50_99, 
                        HOUSE_CLEAN_SUMMARY_LV100, 
                        HOUSE_CLEAN_SUMMARY_HALF, 
                        HOUSE_CLEAN_SUMMARY_FULL, 
                        OFFICE_DEP_SUMMARY_LV00, 
                        OFFICE_DEP_SUMMARY_LV01_49, 
                        OFFICE_DEP_SUMMARY_LV50_99, 
                        OFFICE_DEP_SUMMARY_LV100, 
                        -- OFFICE_DEP_SUMMARY_HALF, 
                        OFFICE_DEP_SUMMARY_FULL, 
                        OFFICE_INV_SUMMARY_LV00, 
                        OFFICE_INV_SUMMARY_LV01_49, 
                        OFFICE_INV_SUMMARY_LV50_99, 
                        OFFICE_INV_SUMMARY_LV100, 
                        -- OFFICE_INV_SUMMARY_HALF, 
                        OFFICE_INV_SUMMARY_FULL, 
                        OFFICE_SUS_SUMMARY_LV00, 
                        OFFICE_SUS_SUMMARY_LV01_49, 
                        OFFICE_SUS_SUMMARY_LV50_99, 
                        OFFICE_SUS_SUMMARY_LV100, 
                        -- OFFICE_SUS_SUMMARY_HALF, 
                        OFFICE_SUS_SUMMARY_FULL, 
                        OFFICE_STG_SUMMARY_LV00, 
                        OFFICE_STG_SUMMARY_LV01_49, 
                        OFFICE_STG_SUMMARY_LV50_99, 
                        OFFICE_STG_SUMMARY_LV100, 
                        -- OFFICE_STG_SUMMARY_HALF, 
                        OFFICE_STG_SUMMARY_FULL, 
                        FARMER_FISHER_DEP_SUMMARY_LV00, 
                        FARMER_FISHER_DEP_SUMMARY_LV01_49, 
                        FARMER_FISHER_DEP_SUMMARY_LV50_99, 
                        FARMER_FISHER_DEP_SUMMARY_LV100, 
                        -- FARMER_FISHER_DEP_SUMMARY_HALF, 
                        FARMER_FISHER_DEP_SUMMARY_FULL, 
                        FARMER_FISHER_INV_SUMMARY_LV00, 
                        FARMER_FISHER_INV_SUMMARY_LV01_49, 
                        FARMER_FISHER_INV_SUMMARY_LV50_99, 
                        FARMER_FISHER_INV_SUMMARY_LV100, 
                        -- FARMER_FISHER_INV_SUMMARY_HALF, 
                        FARMER_FISHER_INV_SUMMARY_FULL, 
                        OFFICE_ALT_SUMMARY_LV00, 
                        OFFICE_ALT_SUMMARY_LV01_49, 
                        OFFICE_ALT_SUMMARY_LV50_99, 
                        OFFICE_ALT_SUMMARY_LV100, 
                        OFFICE_ALT_SUMMARY_HALF, 
                        OFFICE_ALT_SUMMARY_FULL 
                        -- COMMITTED_AT 
                        -- DELETED_AT 
                    ) 
                    SELECT 
                        IV1.IPPAN_ID AS IPPAN_ID, 
                        IV1.IPPAN_HEADER_ID AS IPPAN_HEADER_ID, 
                        IV1.FLOOR_AREA_LV00 * HA1.HOUSE_ASSET * HR1.HOUSE_RATE_LV00 AS HOUSE_SUMMARY_LV00, 
                        IV1.FLOOR_AREA_LV01_49 * HA1.HOUSE_ASSET * HR1.HOUSE_RATE_LV00_50 AS HOUSE_SUMMARY_LV01_49, 
                        IV1.FLOOR_AREA_LV50_99 * HA1.HOUSE_ASSET * HR1.HOUSE_RATE_LV50_100 AS HOUSE_SUMMARY_LV50_99, 
                        IV1.FLOOR_AREA_LV100 * HA1.HOUSE_ASSET * HR1.HOUSE_RATE_LV100_200 AS HOUSE_SUMMARY_LV100, 
                        IV1.FLOOR_AREA_HALF * HA1.HOUSE_ASSET * HR1.HOUSE_RATE_LV200_300 AS HOUSE_SUMMARY_HALF, 
                        IV1.FLOOR_AREA_FULL * HA1.HOUSE_ASSET * HR1.HOUSE_RATE_LV300 AS HOUSE_SUMMARY_FULL, 
                        IV1.FAMILY_LV00 * HHA1.HOUSEHOLD_ASSET * HHR1.HOUSEHOLD_RATE_LV00 AS HOUSEHOLD_SUMMARY_LV00, 
                        IV1.FAMILY_LV01_49 * HHA1.HOUSEHOLD_ASSET * HHR1.HOUSEHOLD_RATE_LV00_50 AS HOUSEHOLD_SUMMARY_LV01_49, 
                        IV1.FAMILY_LV50_99 * HHA1.HOUSEHOLD_ASSET * HHR1.HOUSEHOLD_RATE_LV50_100 AS HOUSEHOLD_SUMMARY_LV50_99, 
                        IV1.FAMILY_LV100 * HHA1.HOUSEHOLD_ASSET * HHR1.HOUSEHOLD_RATE_LV100_200 AS HOUSEHOLD_SUMMARY_LV100, 
                        IV1.FAMILY_HALF * HHA1.HOUSEHOLD_ASSET * HHR1.HOUSEHOLD_RATE_LV200_300 AS HOUSEHOLD_SUMMARY_HALF, 
                        IV1.FAMILY_FULL * HHA1.HOUSEHOLD_ASSET * HHR1.HOUSEHOLD_RATE_LV300 AS HOUSEHOLD_SUMMARY_FULL, 
                        IV1.FAMILY_LV00 * CA1.CAR_ASSET * CR1.CAR_RATE_LV00 AS CAR_SUMMARY_LV00, 
                        IV1.FAMILY_LV01_49 * CA1.CAR_ASSET * CR1.CAR_RATE_LV00_50 AS CAR_SUMMARY_LV01_49, 
                        IV1.FAMILY_LV50_99 * CA1.CAR_ASSET * CR1.CAR_RATE_LV50_100 AS CAR_SUMMARY_LV50_99, 
                        IV1.FAMILY_LV100 * CA1.CAR_ASSET * CR1.CAR_RATE_LV100_200 AS CAR_SUMMARY_LV100, 
                        IV1.FAMILY_HALF * CA1.CAR_ASSET * CR1.CAR_RATE_LV200_300 AS CAR_SUMMARY_HALF, 
                        IV1.FAMILY_FULL * CA1.CAR_ASSET * CR1.CAR_RATE_LV300 AS CAR_SUMMARY_FULL, 
                        IV1.FAMILY_LV00 * HALT1.HOUSE_ALT_LV00 AS HOUSE_ALT_SUMMARY_LV00, 
                        IV1.FAMILY_LV01_49 * HALT1.HOUSE_ALT_LV00_50 AS HOUSE_ALT_SUMMARY_LV01_49, 
                        IV1.FAMILY_LV50_99 * HALT1.HOUSE_ALT_LV50_100 AS HOUSE_ALT_SUMMARY_LV50_99, 
                        IV1.FAMILY_LV100 * HALT1.HOUSE_ALT_LV100_200 AS HOUSE_ALT_SUMMARY_LV100, 
                        IV1.FAMILY_HALF * HALT1.HOUSE_ALT_LV200_300 AS HOUSE_ALT_SUMMARY_HALF, 
                        IV1.FAMILY_FULL * HALT1.HOUSE_ALT_LV300 AS HOUSE_ALT_SUMMARY_FULL, 
                        IV1.FAMILY_LV00 * HCL1.HOUSE_CLEAN_DAYS_LV00 * HCL1.HOUSE_CLEAN_UNIT_COST AS HOUSE_CLEAN_SUMMARY_LV00, 
                        IV1.FAMILY_LV01_49 * HCL1.HOUSE_CLEAN_DAYS_LV00_50 * HCL1.HOUSE_CLEAN_UNIT_COST AS HOUSE_CLEAN_SUMMARY_LV01_49, 
                        IV1.FAMILY_LV50_99 * HCL1.HOUSE_CLEAN_DAYS_LV50_100 * HCL1.HOUSE_CLEAN_UNIT_COST AS HOUSE_CLEAN_SUMMARY_LV50_99, 
                        IV1.FAMILY_LV100 * HCL1.HOUSE_CLEAN_DAYS_LV100_200 * HCL1.HOUSE_CLEAN_UNIT_COST AS HOUSE_CLEAN_SUMMARY_LV100, 
                        IV1.FAMILY_HALF * HCL1.HOUSE_CLEAN_DAYS_LV200_300 * HCL1.HOUSE_CLEAN_UNIT_COST AS HOUSE_CLEAN_SUMMARY_HALF, 
                        IV1.FAMILY_FULL * HCL1.HOUSE_CLEAN_DAYS_LV300 * HCL1.HOUSE_CLEAN_UNIT_COST AS HOUSE_CLEAN_SUMMARY_FULL, 
                        IV1.EMPLOYEE_LV00 * OA1.OFFICE_DEP_ASSET * OR1.OFFICE_DEP_RATE_LV00 AS OFFICE_DEP_SUMMARY_LV00, 
                        IV1.EMPLOYEE_LV01_49 * OA1.OFFICE_DEP_ASSET * OR1.OFFICE_DEP_RATE_LV00_50 AS OFFICE_DEP_SUMMARY_LV01_49, 
                        IV1.EMPLOYEE_LV50_99 * OA1.OFFICE_DEP_ASSET * OR1.OFFICE_DEP_RATE_LV50_100 AS OFFICE_DEP_SUMMARY_LV50_99, 
                        IV1.EMPLOYEE_LV100 * OA1.OFFICE_DEP_ASSET * OR1.OFFICE_DEP_RATE_LV100_200 AS OFFICE_DEP_SUMMARY_LV100, 
                        -- IV1.EMPLOYEE_HALF * OA1.OFFICE_DEP_ASSET * OR1.OFFICE_DEP_RATE_LV200_300 AS OFFICE_DEP_SUMMARY_HALF, 
                        IV1.EMPLOYEE_FULL * OA1.OFFICE_DEP_ASSET * OR1.OFFICE_DEP_RATE_LV300 AS OFFICE_DEP_SUMMARY_FULL, 
                        IV1.EMPLOYEE_LV00 * OA1.OFFICE_INV_ASSET * OR1.OFFICE_INV_RATE_LV00 AS OFFICE_INV_SUMMARY_LV00, 
                        IV1.EMPLOYEE_LV01_49 * OA1.OFFICE_INV_ASSET * OR1.OFFICE_INV_RATE_LV00_50 AS OFFICE_INV_SUMMARY_LV01_49, 
                        IV1.EMPLOYEE_LV50_99 * OA1.OFFICE_INV_ASSET * OR1.OFFICE_INV_RATE_LV50_100 AS OFFICE_INV_SUMMARY_LV50_99, 
                        IV1.EMPLOYEE_LV100 * OA1.OFFICE_INV_ASSET * OR1.OFFICE_INV_RATE_LV100_200 AS OFFICE_INV_SUMMARY_LV100, 
                        -- IV1.EMPLOYEE_HALF * OA1.OFFICE_INV_ASSET * OR1.OFFICE_INV_RATE_LV200_300 AS OFFICE_INV_SUMMARY_HALF, 
                        IV1.EMPLOYEE_FULL * OA1.OFFICE_INV_ASSET * OR1.OFFICE_INV_RATE_LV300 AS OFFICE_INV_SUMMARY_FULL, 
                        IV1.EMPLOYEE_LV00 * OA1.OFFICE_VA_ASSET * OSUS1.OFFICE_SUS_DAYS_LV00 AS OFFICE_SUS_SUMMARY_LV00, 
                        IV1.EMPLOYEE_LV01_49 * OA1.OFFICE_VA_ASSET * OSUS1.OFFICE_SUS_DAYS_LV00_50 AS OFFICE_SUS_SUMMARY_LV00_50, 
                        IV1.EMPLOYEE_LV50_99 * OA1.OFFICE_VA_ASSET * OSUS1.OFFICE_SUS_DAYS_LV50_100 AS OFFICE_SUS_SUMMARY_LV50_100, 
                        IV1.EMPLOYEE_LV100 * OA1.OFFICE_VA_ASSET * OSUS1.OFFICE_SUS_DAYS_LV100_200 AS OFFICE_SUS_SUMMARY_LV100_200, 
                        -- IV1.EMPLOYEE_HALF * OA1.OFFICE_VA_ASSET * OSUS1.OFFICE_SUS_DAYS_LV200_300 AS OFFICE_SUS_SUMMARY_LV200_300, 
                        IV1.EMPLOYEE_FULL * OA1.OFFICE_VA_ASSET * OSUS1.OFFICE_SUS_DAYS_LV300 AS OFFICE_SUS_SUMMARY_LV300, 
                        IV1.EMPLOYEE_LV00 * OA1.OFFICE_VA_ASSET * OSTG1.OFFICE_STG_DAYS_LV00 / 2.0 AS OFFICE_STG_SUMMARY_LV00, 
                        IV1.EMPLOYEE_LV01_49 * OA1.OFFICE_VA_ASSET * OSTG1.OFFICE_STG_DAYS_LV00_50 / 2.0 AS OFFICE_STG_SUMMARY_LV01_49, 
                        IV1.EMPLOYEE_LV50_99 * OA1.OFFICE_VA_ASSET * OSTG1.OFFICE_STG_DAYS_LV50_100 / 2.0 AS OFFICE_STG_SUMMARY_LV50_99, 
                        IV1.EMPLOYEE_LV100 * OA1.OFFICE_VA_ASSET * OSTG1.OFFICE_STG_DAYS_LV100_200 / 2.0 AS OFFICE_STG_SUMMARY_LV100, 
                        -- IV1.EMPLOYEE_HALF * OA1.OFFICE_VA_ASSET * OSTG1.OFFICE_STG_DAYS_LV200_300 / 2.0 AS OFFICE_STG_SUMMARY_HALF, 
                        IV1.EMPLOYEE_FULL * OA1.OFFICE_VA_ASSET * OSTG1.OFFICE_STG_DAYS_LV300 / 2.0 AS OFFICE_STG_SUMMARY_FULL, 
                        IV1.FARMER_FISHER_LV00 * FFA1.FARMER_FISHER_DEP_ASSET * FFR1.FARMER_FISHER_DEP_RATE_LV00 AS FARMER_FISHER_DEP_SUMMARY_LV00, 
                        IV1.FARMER_FISHER_LV01_49 * FFA1.FARMER_FISHER_DEP_ASSET * FFR1.FARMER_FISHER_DEP_RATE_LV00_50 AS FARMER_FISHER_DEP_SUMMARY_LV01_49, 
                        IV1.FARMER_FISHER_LV50_99 * FFA1.FARMER_FISHER_DEP_ASSET * FFR1.FARMER_FISHER_DEP_RATE_LV50_100 AS FARMER_FISHER_DEP_SUMMARY_LV50_99, 
                        IV1.FARMER_FISHER_LV100 * FFA1.FARMER_FISHER_DEP_ASSET * FFR1.FARMER_FISHER_DEP_RATE_LV100_200 AS FARMER_FISHER_DEP_SUMMARY_LV100, 
                        --IV1.FARMER_FISHER_HALF * FFA1.FARMER_FISHER_DEP_ASSET * FFR1.FARMER_FISHER_DEP_RATE_LV200_300 AS FARMER_FISHER_DEP_SUMMARY_HALF, 
                        IV1.FARMER_FISHER_FULL * FFA1.FARMER_FISHER_DEP_ASSET * FFR1.FARMER_FISHER_DEP_RATE_LV300 AS FARMER_FISHER_DEP_SUMMARY_FULL, 
                        IV1.FARMER_FISHER_LV00 * FFA1.FARMER_FISHER_INV_ASSET * FFR1.FARMER_FISHER_INV_RATE_LV00 AS FARMER_FISHER_INV_SUMMARY_LV00, 
                        IV1.FARMER_FISHER_LV01_49 * FFA1.FARMER_FISHER_INV_ASSET * FFR1.FARMER_FISHER_INV_RATE_LV00_50 AS FARMER_FISHER_INV_SUMMARY_LV01_49, 
                        IV1.FARMER_FISHER_LV50_99 * FFA1.FARMER_FISHER_INV_ASSET * FFR1.FARMER_FISHER_INV_RATE_LV50_100 AS FARMER_FISHER_INV_SUMMARY_LV50_99, 
                        IV1.FARMER_FISHER_LV100 * FFA1.FARMER_FISHER_INV_ASSET * FFR1.FARMER_FISHER_INV_RATE_LV100_200 AS FARMER_FISHER_INV_SUMMARY_LV100, 
                        -- IV1.FARMER_FISHER_HALF * FFA1.FARMER_FISHER_INV_ASSET * FFR1.FARMER_FISHER_INV_RATE_LV200_300 AS FARMER_FISHER_INV_SUMMARY_HALF, 
                        IV1.FARMER_FISHER_FULL * FFA1.FARMER_FISHER_INV_ASSET * FFR1.FARMER_FISHER_INV_RATE_LV300 AS FARMER_FISHER_INV_SUMMARY_FULL, 
                        IV1.OFFICE_LV00 * OALT1.OFFICE_ALT_LV00 AS OFFICE_ALT_SUMMARY_LV00, 
                        IV1.OFFICE_LV01_49 * OALT1.OFFICE_ALT_LV00_50 AS OFFICE_ALT_SUMMARY_LV01_49, 
                        IV1.OFFICE_LV50_99 * OALT1.OFFICE_ALT_LV50_100 AS OFFICE_ALT_SUMMARY_LV50_99, 
                        IV1.OFFICE_LV100 * OALT1.OFFICE_ALT_LV100_200 AS OFFICE_ALT_SUMMARY_LV100, 
                        IV1.OFFICE_HALF * OALT1.OFFICE_ALT_LV200_300 AS OFFICE_ALT_SUMMARY_HALF, 
                        IV1.OFFICE_FULL * OALT1.OFFICE_ALT_LV300 AS OFFICE_ALT_SUMMARY_FULL 
                    FROM 
                        IPPAN_VIEW IV1 
                        LEFT JOIN HOUSE_ASSET HA1 ON IV1.KEN_CODE=HA1.KEN_CODE 
                        LEFT JOIN HOUSE_RATE HR1 ON IV1.FLOOD_SEDIMENT_CODE=HR1.FLOOD_SEDIMENT_CODE AND IV1.GRADIENT_CODE=HR1.GRADIENT_CODE 
                        LEFT JOIN HOUSEHOLD_RATE HHR1 ON IV1.FLOOD_SEDIMENT_CODE=HHR1.FLOOD_SEDIMENT_CODE 
                        LEFT JOIN OFFICE_ASSET OA1 ON IV1.INDUSTRY_CODE=OA1.INDUSTRY_CODE 
                        LEFT JOIN OFFICE_RATE OR1 ON IV1.FLOOD_SEDIMENT_CODE=OR1.FLOOD_SEDIMENT_CODE 
                        LEFT JOIN FARMER_FISHER_RATE FFR1 ON IV1.FLOOD_SEDIMENT_CODE=FFR1.FLOOD_SEDIMENT_CODE, 
                        HOUSEHOLD_ASSET HHA1, 
                        CAR_ASSET CA1, 
                        CAR_RATE CR1, 
                        HOUSE_ALT HALT1, 
                        HOUSE_CLEAN HCL1, 
                        OFFICE_SUSPEND OSUS1, 
                        OFFICE_STAGNATE OSTG1, 
                        FARMER_FISHER_ASSET FFA1, 
                        OFFICE_ALT OALT1 
                    WHERE 
                        IV1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                        IV1.DELETED_AT IS NULL"""
                
                connection_cursor.execute(SQL_UPDATE_IPPAN_SUMMARY, PARAMS)
                connection_cursor.execute(SQL_INSERT_IPPAN_SUMMARY, PARAMS)
    
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                    'action_code': _IPP_ACT_02, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log()
                })
                bool_return = consume_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                    connection_cursor.execute("""ROLLBACK""")
                    return 4
                
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] summarize_IPP_ACT_02.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] summarize_IPP_ACT_02.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] summarize_IPP_ACT_02.handle()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                return 8
            
            finally:
                ### try except finallyのtry文中でreturnを発生させた場合、
                ### finally文中のconnection_cursor.close()が実行されて、
                ### その後に関数を抜ける。
                ### したがって、finally文中でreturnする必要はない。
                connection_cursor.close()
            
            ###################################################################
            ### 戻り値セット処理(0040)
            ###################################################################
            print_log('[DEBUG] summarize_IPP_ACT_02.handle()関数 STEP 4/4.', 'DEBUG')
            print_log('[INFO] summarize_IPP_ACT_02.handle()関数が正常終了しました。', 'INFO')
            return 0
        
        except:
            print_log('[ERROR] summarize_IPP_ACT_02.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] summarize_IPP_ACT_02.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] summarize_IPP_ACT_02.handle()関数が異常終了しました。', 'ERROR')
            return 8
