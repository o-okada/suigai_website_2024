///////////////////////////////////////////////////////////////////////////////
// 水害区域図作成支援システム Version 3 基本的な初期処理 (電子国土用基本設定)
// 履歴
// 2024/11/10 printout.htmlのSetQuality関数では引数0以外を処理できないので、g_qualityの如何に関わらず引数を0に変更した。
///////////////////////////////////////////////////////////////////////////////

// グローバル変数の宣言ここから
// 地図インスタンス
var map = null;

// 真球メルカトル投影(電子国土WebシステムVer.4もこれに準拠)を定義
var projection900913 = new OpenLayers.Projection("EPSG:900913");

// 等経緯度投影を定義
var projection4326 = new OpenLayers.Projection("EPSG:4326");
// グローバル変数の宣言ここまで

// 地図用キーボード
var KeyboardDefaultsControl = null;

// 標準地図
var stdLayer;

// 淡色地図
var paleLayer;

// 現在の地図
var currLayer = null;

// ズームバー
var zoomcontrol;

var initCompleted = false;

// 地図の初期表示設定ここから
$(document).ready(function () {
    console.log('initMap.js document.ready.function step 1');
    // 真球メルカトル投影のときの最大範囲(単位はm)
    var maxExtent = new OpenLayers.Bounds(-20037508, -20037508, 20037508, 20037508);

    // 真球メルカトル投影のときの最大範囲に範囲を制限
    var restrictedExtent = maxExtent.clone();

    // 真球メルカトル投影のときの最大解像度
    var maxResolution = 156543.0339;

    // キーボード操作
    KeyboardDefaultsControl = new webtis.Control.GsiKeyboard();

    // 地図表示画面のオプション設定
    var controls = [];
    // 地図マウスイベントのハンドル設定。ここではマウスホイールでのズームを100ms後に実行するように設定(一度にズームレベルを上げたいときに有効)
    controls[0] = new OpenLayers.Control.Navigation({ mouseWheelOptions: { interval: 100 } });
    
    // 国土地理院著作表示
    // ※OpenLayrsサイトを作るときは必ずこれを書くこと
    controls[1] = new OpenLayers.Control.Attribution();
    
    // キーボード操作を有効にする
    controls[2] = KeyboardDefaultsControl;

    console.log('initMap.js document.ready.function step 2');
    var options = {
        // 「controls」を設定することで、デフォルトのコントロールを破棄してコントロールを再設定
        controls: controls,

        // 背景地図の地理座標系
        projection: projection900913,

        // 表示の地理座標系
        displayProjection: projection4326,

        // 背景地図の単位
        units: "m",

        // 背景地図の最大解像度
        maxResolution: maxResolution,

        // レイヤの順番を指定
        Z_INDEX_BASE: {
            BaseLayer: 100,
            Overlay: 325,
            Feature: 725,
            Popup: 101750,
            Control: 102000
        }
    };

    // OpenLayers APIのMapクラスからインスタンスを作成
    console.log('initMap.js document.ready.function step 3');
    map = new OpenLayers.Map('map', options);

    // ズームレベルを制限
    console.log('initMap.js document.ready.function step 4');
    map.isValidZoomLevel = function (zoomLevel) {
        return (zoomLevel != null &&
                 zoomLevel >= 5 && zoomLevel <= 18);
    }

    // ズームバーを設定
    console.log('initMap.js document.ready.function step 5');
    if (isDispZoomBar) {
        zoomcontrol = new webtis.Control.PanZoomBar({
            slideFactor: 100,
            minZoomLevel: 5,
            showShukushaku: function () {
                var h = 198;
                var w = 67;

                if (!this.shukushakuDiv) {
                    var id = this.id + "_" + this.map.id + "_shukushakuDiv";
                    this.shukushakuDiv =
                        OpenLayers.Util.createAlphaImageDiv(id, new OpenLayers.Pixel(35, 80),
                            new OpenLayers.Size(w, h),
                            rootUrl + "script/mark/zoomscale.png",
                            "absolute", null, "scale");

                    this.div.appendChild(this.shukushakuDiv);
                }

                this.shukushakuDiv.style.display = "block";
            }
        });
    }

    // 編集画面でのみ表示する
    console.log('initMap.js document.ready.function step 6');
    if (isDispZoomBar) {
        map.addControl(zoomcontrol);
    }

    // 標準地図を設定
    console.log('initMap.js document.ready.function step 7');
    stdLayer = new OpenLayers.Layer.XYZ("標準地図",
        "https://cyberjapandata.gsi.go.jp/xyz/std/${z}/${x}/${y}.png",
        {
            attribution: "<div id='legRB' style='font-size: small;'>" + getLegend(initZoomLv) + "</div>",
            maxZoomLevel: 18
        });
    //map.addLayer(stdLayer);

    // 淡色地図を設定
    console.log('initMap.js document.ready.function step 8');
    paleLayer = new OpenLayers.Layer.XYZ("淡色地図",
        "https://cyberjapandata.gsi.go.jp/xyz/pale/${z}/${x}/${y}.png",
        {
            attribution: "<div id='legRB' style='font-size: small;'>" + getLegend(initZoomLv) + "</div>",
            maxZoomLevel: 18
        });
    //map.addLayer(paleLayer);

    // 印刷時、コンテナへ完了を通知
    console.log('initMap.js document.ready.function step 9');
    if (mapMode == "capture" && typeof window.external.jsLog !== "undefined") {

        var curTiles = 0;
        var ttlTiles = -1;
        var isMapLoaded = false;

        stdLayer.events.register("tileloaded", stdLayer, function () {
            if (!initCompleted) {
                return;
            }
            curTiles++;
        });

        paleLayer.events.register("tileloaded", paleLayer, function () {
            if (!initCompleted) {
                return;
            }
            curTiles++;
        });

        stdLayer.events.register("loadend", stdLayer, function () {
            if (!initCompleted) {
                return;
            }
            if (ttlTiles == -1) {
                ttlTiles = this.grid.length * this.grid[0].length;
            }
            if (!isMapLoaded && ttlTiles == curTiles) {
                isMapLoaded = true;
            }
        });

        paleLayer.events.register("loadend", paleLayer, function () {
            if (!initCompleted) {
                return;
            }
            if (ttlTiles == -1) {
                ttlTiles = this.grid.length * this.grid[0].length;
            }
            if (!isMapLoaded && ttlTiles == curTiles) {
                isMapLoaded = true;
            }
        });

    }

    // 背景地図を設定
    console.log('initMap.js document.ready.function step 10');
    setBaseMap(initZoomLv);

    // 尺度スケールを表示
    console.log('initMap.js document.ready.function step 11');
    map.addControl(new OpenLayers.Control.ScaleLine({ maxWidth: 150, bottomOutUnits: "", bottomInUnits: "", geodesic: true }));

    // 初期の中心座標を指定（経緯度で入力して、内部的に真球メルカトル座標に変換して表示）
    console.log('initMap.js document.ready.function step 12');
    map.setCenter(new OpenLayers.LonLat(initCX, initCY).transform(projection4326, map.getProjectionObject()), initZoomLv);

    // 品質の設定
    console.log('initMap.js document.ready.function step 13');
    // if (mapMode == "preview" && typeof SetQuality !== "undefined") { // 2024/11/10 comment out 様式出力画面で縦横に白い線が描画されるため、printout.htmlのSetQuality関数の品質倍率を1.0に変更した。
    //     if ($("#g_quality") != null && $("#g_quality").val() != "")
    //         SetQuality($("#g_quality").val());
    //     else
    //         SetQuality(0);
    // }
    if (mapMode == "preview" && typeof SetQuality !== "undefined") { // 2024/11/10 comment out 様式出力画面で縦横に白い線が描画されるため、printout.htmlのSetQuality関数の品質倍率を1.0に変更した。
        SetQuality();
    }

    ///////////////////////////////////////////////////////////////////////////
    // SetQuality(0); // 2024/11/10 add printout.html SetQuality関数では引数0以外を処理できないので、g_qualityの如何に関わらず引数を0に変更した。
    ///////////////////////////////////////////////////////////////////////////

    // 右クリックでブラウザのデフォルトのメニューが開かないようにする
    console.log('initMap.js document.ready.function step 14');
    document.getElementById('map').oncontextmenu = function (e) {
        e = e ? e : window.event;
        if (e.preventDefault) {
            e.preventDefault(); // For non-IE browsers.
        } else {
            return false; // For IE browsers.
        }
    }

    console.log('initMap.js document.ready.function step 15');

});

