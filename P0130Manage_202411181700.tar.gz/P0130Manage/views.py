###############################################################################
### ファイル名：P0130Manage/views.py
### 管理者用ファイル管理
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### def custom_decorator(arg1)
### 
### ビュー関数：ブラウザから呼ばれる関数
### def index_view(request)
### def bucket_view(request)
### def bucket_ken_code_view(request, ken_code)
### def browser_city_code_view(request, city_code)
### 
### def slide_ippan_header_id_view(request, header_id)
### def slide_chitan_header_id_view(request, header_id)
### def slide_hojo_header_id_view(request, header_id)
### def slide_koeki_header_id_view(request, header_id)
### 
### def approve_ippan_header_id_view(request, header_id)
### def approve_chitan_header_id_view(request, header_id)
### def approve_hojo_header_id_view(request, header_id)
### def approve_koeki_header_id_view(request, header_id)
### 
### def disapprove_ippan_header_id_view(request, header_id)                    ### ADD 2024/09/11 O.OKADA
### def disapprove_chitan_header_id_view(request, header_id)                   ### ADD 2024/09/11 O.OKADA
### def disapprove_hojo_header_id_view(request, header_id)                     ### ADD 2024/09/11 O.OKADA
### def disapprove_koeki_header_id_view(request, header_id)                    ### ADD 2024/09/11 O.OKADA
### 
### def download_ippan_chosa_excel_header_id_view(request, header_id)
### def download_ippan_chosa_csv_header_id_view(request, header_id)
### def download_ippan_summary_excel_header_id_view(request, header_id)
### def download_ippan_summary_csv_header_id_view(request, header_id)
### def download_ippan_export_csv_header_id_view(request, header_id)           ### ADD 2024/09/11 O.OKADA
### def download_chitan_chosa_excel_header_id_view(request, header_id)
### def download_chitan_chosa_csv_header_id_view(request, header_id)
### def download_chitan_summary_excel_header_id_view(request, header_id)
### def download_chitan_summary_csv_header_id_view(request, header_id)
### def download_chitan_export_csv_header_id_view(request, header_id)          ### ADD 2024/09/11 O.OKADA
### def download_hojo_chosa_excel_header_id_view(request, header_id)
### def download_hojo_chosa_csv_header_id_view(request, header_id)
### def download_hojo_summary_excel_header_id_view(request, header_id)
### def download_hojo_summary_csv_header_id_view(request, header_id)
### def download_hojo_export_csv_header_id_view(request, header_id)            ### ADD 2024/09/11 O.OKADA
### def download_koeki_chosa_excel_header_id_view(request, header_id)
### def download_koeki_chosa_csv_header_id_view(request, header_id)
### def download_koeki_summary_excel_header_id_view(request, header_id)
### def download_koeki_summary_csv_header_id_view(request, header_id)
### def download_koeki_export_csv_header_id_view(request, header_id)           ### ADD 2024/09/11 O.OKADA
### 更新履歴：
### 2024/07/25 custom_decorator 追加 requestをチェックしてUSER_PROXYからcity_codeを取得する処理を共通化した。
### 2024/09/09 PARAM、SQL文をEXECUTEと別にセットして、EXECUTE周辺のコードを読みやすくした。
### 2024/09/09 水害区域図DB版との統合のため、AREAをKUIKIに変更した。
### 2024/09/11 ワークフローの見直しに伴い関数を追加削除名前変更した。
### 2024/09/12 LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
### 2024/09/26 システム間連携ファイル出力機能を追加した。
### 2024/10/13 画面制御用コード（暫定値、確報値）に対応した。
### 2024/11/06 水害区域図DB化をDB化対象外とするように修正した。
###############################################################################

import json
import os
import sys

from datetime import date, datetime
from datetime import timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound
from django.http.response import JsonResponse
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView
from django.views.decorators.csrf import csrf_exempt

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ
from P0000Common.models import PROVISIONED_CONFIRMED   ### 0000: 画面制御用コード（暫定値、確報値）

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

### from P0000Common.models import KUIKI               ### 7000: アップロードデータ_水害区域 ### 2024/11/06 comment out
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ
### from P0000Common.models import KUIKI_TRIGGER       ### 10060: キューデータ_水害区域図_トリガーメッセージ ### 2024/11/06 comment out

from P0000Common.models import IPPAN_HISTORY           ### 11000: ヒストリーデータ_一般資産調査票_調査員用
from P0000Common.models import CHITAN_HISTORY          ### 11010: ヒストリーデータ_公共土木施設調査票_地方単独事業
from P0000Common.models import HOJO_HISTORY            ### 11020: ヒストリーデータ_公共土木施設調査票_補助事業
from P0000Common.models import KOEKI_HISTORY           ### 11030: ヒストリーデータ_公益事業等調査票
### from P0000Common.models import KUIKI_HISTORY       ### 11040: ヒストリーデータ_水害区域図 ### 2024/11/06 comment out

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.services import get_ippan_chosa_csv_excel
from P0000Common.services import get_ippan_summary_csv_excel
from P0000Common.services import get_ippan_export_csv                          ### ADD 2024/09/26
from P0000Common.services import get_chitan_chosa_csv_excel
from P0000Common.services import get_chitan_summary_csv_excel
from P0000Common.services import get_hojo_chosa_csv_excel
from P0000Common.services import get_hojo_summary_csv_excel
from P0000Common.services import get_koeki_chosa_csv_excel
from P0000Common.services import get_koeki_summary_csv_excel

_KEN01 = '01'
_KEN02 = '02'
_KEN03 = '03'
_KEN04 = '04'
_KEN05 = '05'
_KEN06 = '06'
_KEN07 = '07'
_KEN08 = '08'
_KEN09 = '09'
_KEN10 = '10'
_KEN11 = '11'
_KEN12 = '12'
_KEN13 = '13'
_KEN14 = '14'
_KEN15 = '15'
_KEN16 = '16'
_KEN17 = '17'
_KEN18 = '18'
_KEN19 = '19'
_KEN20 = '20'
_KEN21 = '21'
_KEN22 = '22'
_KEN23 = '23'
_KEN24 = '24'
_KEN25 = '25'
_KEN26 = '26'
_KEN27 = '27'
_KEN28 = '28'
_KEN29 = '29'
_KEN30 = '30'
_KEN31 = '31'
_KEN32 = '32'
_KEN33 = '33'
_KEN34 = '34'
_KEN35 = '35'
_KEN36 = '36'
_KEN37 = '37'
_KEN38 = '38'
_KEN39 = '39'
_KEN40 = '40'
_KEN41 = '41'
_KEN42 = '42'
_KEN43 = '43'
_KEN44 = '44'
_KEN45 = '45'
_KEN46 = '46'
_KEN47 = '47'

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'

_CHI_ACT_01 = 'CHI_ACT_01'
_CHI_ACT_02 = 'CHI_ACT_02'
_CHI_ACT_03 = 'CHI_ACT_03'

_HOJ_ACT_01 = 'HOJ_ACT_01'
_HOJ_ACT_02 = 'HOJ_ACT_02'
_HOJ_ACT_03 = 'HOJ_ACT_03'

_KOE_ACT_01 = 'KOE_ACT_01'
_KOE_ACT_02 = 'KOE_ACT_02'
_KOE_ACT_03 = 'KOE_ACT_03'

### 局所定数 ※DELETE関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP = 'IPP'
_CHI = 'CHI'
_HOJ = 'HOJ'
_KOE = 'KOE'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'
_IPP_EXP_CSV = 'IPP_EXP_CSV' ### ADD 2024/09/26

_CHI_CHO_EXC = 'CHI_CHO_EXC'
_CHI_CHO_CSV = 'CHI_CHO_CSV'
_CHI_SUM_EXC = 'CHI_SUM_EXC'
_CHI_SUM_CSV = 'CHI_SUM_CSV'

_HOJ_CHO_EXC = 'HOJ_CHO_EXC'
_HOJ_CHO_CSV = 'HOJ_CHO_CSV'
_HOJ_SUM_EXC = 'HOJ_SUM_EXC'
_HOJ_SUM_CSV = 'HOJ_SUM_CSV'

_KOE_CHO_EXC = 'KOE_CHO_EXC'
_KOE_CHO_CSV = 'KOE_CHO_CSV'
_KOE_SUM_EXC = 'KOE_SUM_EXC'
_KOE_SUM_CSV = 'KOE_SUM_CSV'

### 局所定数 暫定値確報値
_PROVISIONED = 'PROVISIONED'
_CONFIRMED = 'CONFIRMED'

### 局所定数 ワークフロー履歴
_PROVISIONED_IPPAN_CITY_UPLOAD = 'PROVISIONED_IPPAN_CITY_UPLOAD'
_PROVISIONED_IPPAN_CITY_APPLY = 'PROVISIONED_IPPAN_CITY_APPLY'
_PROVISIONED_IPPAN_CITY_DELETE = 'PROVISIONED_IPPAN_CITY_DELETE'
_PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER = 'PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER'
_PROVISIONED_IPPAN_KEN_APPROVE = 'PROVISIONED_IPPAN_KEN_APPROVE'
_PROVISIONED_IPPAN_KEN_DISAPPROVE = 'PROVISIONED_IPPAN_KEN_DISAPPROVE'
_PROVISIONED_IPPAN_MANAGE_APPROVE = 'PROVISIONED_IPPAN_MANAGE_APPROVE'
_PROVISIONED_IPPAN_MANAGE_DISAPPROVE = 'PROVISIONED_IPPAN_MANAGE_DISAPPROVE'

_CONFIRMED_IPPAN_CITY_UPLOAD = 'CONFIRMED_IPPAN_CITY_UPLOAD'
_CONFIRMED_IPPAN_CITY_APPLY = 'CONFIRMED_IPPAN_CITY_APPLY'
_CONFIRMED_IPPAN_CITY_DELETE = 'CONFIRMED_IPPAN_CITY_DELETE'
_CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER = 'CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER'
_CONFIRMED_IPPAN_KEN_APPROVE = 'CONFIRMED_IPPAN_KEN_APPROVE'
_CONFIRMED_IPPAN_KEN_DISAPPROVE = 'CONFIRMED_IPPAN_KEN_DISAPPROVE'
_CONFIRMED_IPPAN_MANAGE_APPROVE = 'CONFIRMED_IPPAN_MANAGE_APPROVE'
_CONFIRMED_IPPAN_MANAGE_DISAPPROVE = 'CONFIRMED_IPPAN_MANAGE_DISAPPROVE'

_PROVISIONED_CHITAN_KEN_UPLOAD = 'PROVISIONED_CHITAN_KEN_UPLOAD'
_PROVISIONED_CHITAN_KEN_APPLY = 'PROVISIONED_CHITAN_KEN_APPLY'
_PROVISIONED_CHITAN_KEN_DELETE = 'PROVISIONED_CHITAN_KEN_DELETE'
_PROVISIONED_CHITAN_MANAGE_APPROVE = 'PROVISIONED_CHITAN_MANAGE_APPROVE'
_PROVISIONED_CHITAN_MANAGE_DISAPPROVE = 'PROVISIONED_CHITAN_MANAGE_DISAPPROVE'

_CONFIRMED_CHITAN_KEN_UPLOAD = 'CONFIRMED_CHITAN_KEN_UPLOAD'
_CONFIRMED_CHITAN_KEN_APPLY = 'CONFIRMED_CHITAN_KEN_APPLY'
_CONFIRMED_CHITAN_KEN_DELETE = 'CONFIRMED_CHITAN_KEN_DELETE'
_CONFIRMED_CHITAN_MANAGE_APPROVE = 'CONFIRMED_CHITAN_MANAGE_APPROVE'
_CONFIRMED_CHITAN_MANAGE_DISAPPROVE = 'CONFIRMED_CHITAN_MANAGE_DISAPPROVE'

_PROVISIONED_HOJO_KEN_UPLOAD = 'PROVISIONED_HOJO_KEN_UPLOAD'
_PROVISIONED_HOJO_KEN_APPLY = 'PROVISIONED_HOJO_KEN_APPLY'
_PROVISIONED_HOJO_KEN_DELETE = 'PROVISIONED_HOJO_KEN_DELETE'
_PROVISIONED_HOJO_MANAGE_APPROVE = 'PROVISIONED_HOJO_MANAGE_APPROVE'
_PROVISIONED_HOJO_MANAGE_DISAPPROVE = 'PROVISIONED_HOJO_MANAGE_DISAPPROVE'

_CONFIRMED_HOJO_KEN_UPLOAD = 'CONFIRMED_HOJO_KEN_UPLOAD'
_CONFIRMED_HOJO_KEN_APPLY = 'CONFIRMED_HOJO_KEN_APPLY'
_CONFIRMED_HOJO_KEN_DELETE = 'CONFIRMED_HOJO_KEN_DELETE'
_CONFIRMED_HOJO_MANAGE_APPROVE = 'CONFIRMED_HOJO_MANAGE_APPROVE'
_CONFIRMED_HOJO_MANAGE_DISAPPROVE = 'CONFIRMED_HOJO_MANAGE_DISAPPROVE'

_PROVISIONED_KOEKI_KEN_UPLOAD = 'PROVISIONED_KOEKI_KEN_UPLOAD'
_PROVISIONED_KOEKI_KEN_APPLY = 'PROVISIONED_KOEKI_KEN_APPLY'
_PROVISIONED_KOEKI_KEN_DELETE = 'PROVISIONED_KOEKI_KEN_DELETE'
_PROVISIONED_KOEKI_MANAGE_APPROVE = 'PROVISIONED_KOEKI_MANAGE_APPROVE'
_PROVISIONED_KOEKI_MANAGE_DISAPPROVE = 'PROVISIONED_KOEKI_MANAGE_DISAPPROVE'

_CONFIRMED_KOEKI_KEN_UPLOAD = 'CONFIRMED_KOEKI_KEN_UPLOAD'
_CONFIRMED_KOEKI_KEN_APPLY = 'CONFIRMED_KOEKI_KEN_APPLY'
_CONFIRMED_KOEKI_KEN_DELETE = 'CONFIRMED_KOEKI_KEN_DELETE'
_CONFIRMED_KOEKI_MANAGE_APPROVE = 'CONFIRMED_KOEKI_MANAGE_APPROVE'
_CONFIRMED_KOEKI_MANAGE_DISAPPROVE = 'CONFIRMED_KOEKI_MANAGE_DISAPPROVE'

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def custom_decorator(arg1):

    def outer_wrapper(view_func):
        
        def inner_wrapper(request, *args, **kwargs):
            try:
                reset_log()
                print_log('[DEBUG] P0130Manage.custom_decorator()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
                print_log('[DEBUG] P0130Manage.custom_decorator()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
                print_log('[DEBUG] P0130Manage.custom_decorator()関数 arg1={}'.format(arg1), 'DEBUG')
                PARAMS_SELECT_USER_PROXY = dict({
                    'USERNAME': str(request.user), 
                    'ROLE_CODE': _ROLE_MANAGE
                })
                SQL_SELECT_USER_PROXY = """
                    SELECT 
                        P1.ID, 
                        A1.USERNAME, 
                        P1.ROLE_CODE, 
                        P1.KEN_CODE, 
                        P1.CITY_CODE 
                    FROM USER_PROXY P1 
                    LEFT JOIN (
                        SELECT 
                            * 
                        FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                    WHERE 
                        A1.USERNAME=%(USERNAME)s AND 
                        P1.ROLE_CODE=%(ROLE_CODE)s"""
                SQL_SELECT_PROVISIONED_CONFIRMED = """
                    SELECT 
                        *
                    FROM PROVISIONED_CONFIRMED"""
                ### decoratorでビュー関数に変数を返す方法が不明のため、グローバル変数を使用した。
                global user_proxy_list
                global provisioned_confirmed_list
                user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
                provisioned_confirmed_list = PROVISIONED_CONFIRMED.objects.raw(SQL_SELECT_PROVISIONED_CONFIRMED)
        
                print_log('[DEBUG] P0130Manage.custom_decorator()関数 user_proxy_list={}'.format(user_proxy_list), 'DEBUG')
                print_log('[DEBUG] P0130Manage.custom_decorator()関数 len(user_proxy_list)={}'.format(len(user_proxy_list)), 'DEBUG')
                print_log('[DEBUG] P0130Manage.custom_decorator()関数 provisioned_confirmed_list={}'.format(provisioned_confirmed_list), 'DEBUG')
                print_log('[DEBUG] P0130Manage.custom_decorator()関数 len(provisioned_confirmed_list)={}'.format(len(provisioned_confirmed_list)), 'DEBUG')

                ### デコレータの処理で警告が発生したら（user_proxy_listが正常に取得できなかったら）、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                if (user_proxy_list == False):
                    print_log('[WARN] P0130Manage.custom_decorator()関数が警告終了しました。', 'WARN')
                    if (arg1 == 'bucket_view') or (
                        arg1 == 'bucket_ken_code_view'):
                        template = loader.get_template('P0130Manage/bucket/bucket.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'browser_view'):
                        template = loader.get_template('P0130Manage/browser/browser.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'browser_city_code_view'):
                        template = loader.get_template('P0130Manage/browser/browser_city_code.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'slide_ippan_header_id_view') or (
                          arg1 == 'slide_chitan_header_id_view') or (
                          arg1 == 'slide_hojo_header_id_view') or (
                          arg1 == 'slide_koeki_header_id_view') or (
                                  
                          arg1 == 'approve_ippan_header_id_view') or (
                          arg1 == 'approve_chitan_header_id_view') or (
                          arg1 == 'approve_hojo_header_id_view') or (
                          arg1 == 'approve_koeki_header_id_view') or (
                                  
                          arg1 == 'disapprove_ippan_header_id_view') or (
                          arg1 == 'disapprove_chitan_header_id_view') or (
                          arg1 == 'disapprove_hojo_header_id_view') or (
                          arg1 == 'disapprove_koeki_header_id_view'):
                        data = {
                            'return_code': ["FALSE"], 
                        }
                        response = JsonResponse(data)
                        response['Access-Control-Allow-Origin'] = 'localhost:8000'
                        response['Access-Control-Allow-Credentials'] = 'true'
                        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
                        response['Access-Control-Allow-Methods'] = 'GET'
                        return response
                    elif (arg1 == 'download_ippan_chosa_excel_header_id_view') or (
                          arg1 == 'download_ippan_chosa_csv_header_id_view') or (
                          arg1 == 'download_ippan_summary_excel_header_id_view') or (
                          arg1 == 'download_ippan_summary_csv_header_id_view') or (
                          arg1 == 'download_ippan_export_csv_header_id_view') or (
                          arg1 == 'download_chitan_chosa_excel_header_id_view') or (
                          arg1 == 'download_chitan_chosa_csv_header_id_view') or (
                          arg1 == 'download_chitan_summary_excel_header_id_view') or (
                          arg1 == 'download_chitan_summary_csv_header_id_view') or (
                          arg1 == 'download_chitan_export_csv_header_id_view') or (
                          arg1 == 'download_hojo_chosa_excel_header_id_view') or (
                          arg1 == 'download_hojo_chosa_csv_header_id_view') or (
                          arg1 == 'download_hojo_summary_excel_header_id_view') or (
                          arg1 == 'download_hojo_summary_csv_header_id_view') or (
                          arg1 == 'download_hojo_export_csv_header_id_view') or (
                          arg1 == 'download_koeki_chosa_excel_header_id_view') or (
                          arg1 == 'download_koeki_chosa_csv_header_id_view') or (
                          arg1 == 'download_koeki_summary_excel_header_id_view') or (
                          arg1 == 'download_koeki_summary_csv_header_id_view') or (
                          arg1 == 'download_koeki_export_csv_header_id_view'):
                        return HttpResponseNotFound("")
                
                ### ここまで正常に処理できたら、ビュー関数を戻して、ビュー関数の処理に移行する。
                return view_func(request, *args, **kwargs)
            
            except:
                ### デコレータの処理で異常が発生したら、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                print_log('[ERROR] P0130Manage.custom_decorator()関数が異常終了しました。', 'WARN')
                if (arg1 == 'bucket_view') or (
                    arg1 == 'bucket_ken_code_view'):
                    template = loader.get_template('P0130Manage/bucket/bucket.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'browser_view'):
                    template = loader.get_template('P0130Manage/browser/browser.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'browser_city_code_view'):
                    template = loader.get_template('P0130Manage/browser/browser_city_code.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'slide_ippan_header_id_view') or (
                      arg1 == 'slide_chitan_header_id_view') or (
                      arg1 == 'slide_hojo_header_id_view') or (
                      arg1 == 'slide_koeki_header_id_view') or (
                              
                      arg1 == 'approve_ippan_header_id_view') or (
                      arg1 == 'approve_chitan_header_id_view') or (
                      arg1 == 'approve_hojo_header_id_view') or (
                      arg1 == 'approve_koeki_header_id_view') or (
                              
                      arg1 == 'disapprove_ippan_header_id_view') or (
                      arg1 == 'disapprove_chitan_header_id_view') or (
                      arg1 == 'disapprove_hojo_header_id_view') or (
                      arg1 == 'disapprove_koeki_header_id_view'):
                    data = {
                        'return_code': ["FALSE"], 
                    }
                    response = JsonResponse(data)
                    response['Access-Control-Allow-Origin'] = 'localhost:8000'
                    response['Access-Control-Allow-Credentials'] = 'true'
                    response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
                    response['Access-Control-Allow-Methods'] = 'GET'
                    return response
                elif (arg1 == 'download_ippan_chosa_excel_header_id_view') or (
                      arg1 == 'download_ippan_chosa_csv_header_id_view') or (
                      arg1 == 'download_ippan_summary_excel_header_id_view') or (
                      arg1 == 'download_ippan_summary_csv_header_id_view') or (
                      arg1 == 'download_ippan_export_csv_header_id_view') or (
                      arg1 == 'download_chitan_chosa_excel_header_id_view') or (
                      arg1 == 'download_chitan_chosa_csv_header_id_view') or (
                      arg1 == 'download_chitan_summary_excel_header_id_view') or (
                      arg1 == 'download_chitan_summary_csv_header_id_view') or (
                      arg1 == 'download_chitan_export_csv_header_id_view') or (
                      arg1 == 'download_hojo_chosa_excel_header_id_view') or (
                      arg1 == 'download_hojo_chosa_csv_header_id_view') or (
                      arg1 == 'download_hojo_summary_excel_header_id_view') or (
                      arg1 == 'download_hojo_summary_csv_header_id_view') or (
                      arg1 == 'download_hojo_export_csv_header_id_view') or (
                      arg1 == 'download_koeki_chosa_excel_header_id_view') or (
                      arg1 == 'download_koeki_chosa_csv_header_id_view') or (
                      arg1 == 'download_koeki_summary_excel_header_id_view') or (
                      arg1 == 'download_koeki_summary_csv_header_id_view') or (
                      arg1 == 'download_koeki_export_csv_header_id_view'):
                    return HttpResponseNotFound("")
        
        return inner_wrapper
            
    return outer_wrapper

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### /P0130Manage/ => /P0130Manage/bucket/ リダイレクト用
### urlpattern：path('', views.index_view, name='index_view')
### ※リダイレクトのみのため、custom_decoratorはセットしない。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    return redirect('bucket/')

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 都道府県バケット
### urlpattern：path('bucket/', views.bucket_view, name='bucket_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='bucket_view')
def bucket_view(request):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### KEN_BUCKET: バケットデータ_都道府県
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 1/3.', 'DEBUG')
        PARAMS = dict({
        })
        SQL_SELECT_KEN_BUCKET = """
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, 
                FILES 
            FROM KEN_BUCKET 
            ORDER BY 
                CAST(KEN_CODE AS INTEGER)"""
        ken_bucket_list = KEN_BUCKET.objects.raw(SQL_SELECT_KEN_BUCKET, PARAMS)

        print_log('[DEBUG] P0130Manage.bucket_view()関数 ken_bucket_list={}'.format(ken_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_view()関数 len(ken_bucket_list)={}'.format(len(ken_bucket_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 2/3.', 'DEBUG')
        if ken_bucket_list == False:
            print_log('[WARN] P0130Manage.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0130Manage.bucket_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0130Manage/bucket/bucket.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'ken_bucket_list': ken_bucket_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0130Manage.bucket_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0130Manage/bucket/bucket.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 市区町村バケット
### urlpattern：path('bucket/ken/<slug:ken_code>/', views.bucket_ken_code_view, name='bucket_ken_code_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='bucket_ken_code_view')
def bucket_ken_code_view(request, ken_code):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### KEN_BUCKET: 
        ### CITY_BUCKET: 
        ### CHITAN_HEADER: 
        ### HOJO_HEADER: 
        ### KOEKI_HEADER: 
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 1/3.', 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KEN_CODE': ken_code,
                'CHITAN_KEN_UPLOAD': _PROVISIONED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _PROVISIONED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _PROVISIONED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _PROVISIONED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _PROVISIONED_CHITAN_MANAGE_DISAPPROVE,
                'HOJO_KEN_UPLOAD': _PROVISIONED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _PROVISIONED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _PROVISIONED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _PROVISIONED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _PROVISIONED_HOJO_MANAGE_DISAPPROVE,
                'KOEKI_KEN_UPLOAD': _PROVISIONED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _PROVISIONED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _PROVISIONED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _PROVISIONED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _PROVISIONED_KOEKI_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'KEN_CODE': ken_code,
                'CHITAN_KEN_UPLOAD': _CONFIRMED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _CONFIRMED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _CONFIRMED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _CONFIRMED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _CONFIRMED_CHITAN_MANAGE_DISAPPROVE,
                'HOJO_KEN_UPLOAD': _CONFIRMED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _CONFIRMED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _CONFIRMED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _CONFIRMED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _CONFIRMED_HOJO_MANAGE_DISAPPROVE,
                'KOEKI_KEN_UPLOAD': _CONFIRMED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _CONFIRMED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _CONFIRMED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _CONFIRMED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _CONFIRMED_KOEKI_MANAGE_DISAPPROVE,
            })
        SQL_SELECT_KEN_BUCKET = """
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, -- ディスク使用量
                FILES -- ファイル格納数
            FROM KEN_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s"""
        SQL_SELECT_CITY_BUCKET = """
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, -- ディスク使用量
                FILES -- ファイル格納数
            FROM CITY_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s 
            ORDER BY CAST(CITY_CODE AS INTEGER)"""
        SQL_SELECT_CHITAN_HEADER = """
            SELECT 
                C1.CHITAN_HEADER_ID, 
                C1.CHITAN_HEADER_NAME, 
                C1.KEN_CODE, 
                C1.UPLOAD_FILE_PATH, 
                C1.UPLOAD_FILE_NAME, 
                C1.UPLOAD_FILE_SIZE, 
                C1.SUMMARY_FILE_PATH, 
                C1.SUMMARY_FILE_NAME, 
                C1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', C1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', C1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT,
                S1.CHITAN_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM CHITAN_HEADER C1
            LEFT JOIN (
                SELECT
                    CHITAN_HISTORY_ID,
                    CHITAN_HEADER_ID,
                    WORKFLOW_CODE
                FROM CHITAN_HISTORY
                WHERE 
                    CHITAN_HISTORY_ID IN (
                        SELECT
                            MAX(CHITAN_HISTORY_ID)
                        FROM CHITAN_HISTORY
                        GROUP BY CHITAN_HEADER_ID
                    )
            ) S1 ON C1.CHITAN_HEADER_ID=S1.CHITAN_HEADER_ID
            WHERE 
                C1.KEN_CODE=%(KEN_CODE)s AND 
                C1.DELETED_AT IS NULL
            ORDER BY C1.CHITAN_HEADER_ID"""
        SQL_SELECT_HOJO_HEADER = """
            SELECT 
                H1.HOJO_HEADER_ID, 
                H1.HOJO_HEADER_NAME, 
                H1.KEN_CODE, 
                H1.UPLOAD_FILE_PATH, 
                H1.UPLOAD_FILE_NAME, 
                H1.UPLOAD_FILE_SIZE, 
                H1.SUMMARY_FILE_PATH, 
                H1.SUMMARY_FILE_NAME, 
                H1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', H1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', H1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                S1.HOJO_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM HOJO_HEADER H1
            LEFT JOIN (
                SELECT
                    HOJO_HISTORY_ID,
                    HOJO_HEADER_ID,
                    WORKFLOW_CODE
                FROM HOJO_HISTORY
                WHERE
                    HOJO_HISTORY_ID IN (
                        SELECT
                            MAX(HOJO_HISTORY_ID)
                        FROM HOJO_HISTORY
                        GROUP BY HOJO_HEADER_ID
                    )
            ) S1 ON H1.HOJO_HEADER_ID=S1.HOJO_HEADER_ID
            WHERE 
                H1.KEN_CODE=%(KEN_CODE)s AND 
                H1.DELETED_AT IS NULL
            ORDER BY H1.HOJO_HEADER_ID"""
        SQL_SELECT_KOEKI_HEADER = """
            SELECT 
                K1.KOEKI_HEADER_ID, 
                K1.KOEKI_HEADER_NAME, 
                K1.KEN_CODE, 
                K1.UPLOAD_FILE_PATH, 
                K1.UPLOAD_FILE_NAME, 
                K1.UPLOAD_FILE_SIZE, 
                K1.SUMMARY_FILE_PATH, 
                K1.SUMMARY_FILE_NAME, 
                K1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', K1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', K1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                S1.KOEKI_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM KOEKI_HEADER K1
            LEFT JOIN (
                SELECT
                    KOEKI_HISTORY_ID,
                    KOEKI_HEADER_ID,
                    WORKFLOW_CODE
                FROM KOEKI_HISTORY
                WHERE 
                    KOEKI_HISTORY_ID IN (
                        SELECT
                            MAX(KOEKI_HISTORY_ID)
                        FROM KOEKI_HISTORY
                        GROUP BY KOEKI_HEADER_ID
                    )
            ) S1 ON K1.KOEKI_HEADER_ID=S1.KOEKI_HEADER_ID
            WHERE 
                K1.KEN_CODE=%(KEN_CODE)s AND 
                K1.DELETED_AT IS NULL
            ORDER BY K1.KOEKI_HEADER_ID"""

        ### HTMLタイトル部分表示用
        ken_bucket_list = KEN_BUCKET.objects.raw(SQL_SELECT_KEN_BUCKET, PARAMS)
        ### HTML一覧部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw(SQL_SELECT_CITY_BUCKET, PARAMS)
        ### HTML一覧部分表示用
        chitan_header_list = CHITAN_HEADER.objects.raw(SQL_SELECT_CHITAN_HEADER, PARAMS)
        ### HTML一覧部分表示用
        hojo_header_list = HOJO_HEADER.objects.raw(SQL_SELECT_HOJO_HEADER, PARAMS)
        ### HTML一覧部分表示用
        koeki_header_list = KOEKI_HEADER.objects.raw(SQL_SELECT_KOEKI_HEADER, PARAMS)

        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 ken_bucket_list={}'.format(ken_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 len(ken_bucket_list)={}'.format(len(ken_bucket_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 city_bucket_list={}'.format(city_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 len(city_bucket_list)={}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 chitan_header_list={}'.format(chitan_header_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 len(chitan_header_list)={}'.format(len(chitan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 hojo_header_list={}'.format(hojo_header_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 len(hojo_header_list)={}'.format(len(hojo_header_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 koeki_header_list={}'.format(koeki_header_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 len(koeki_header_list)={}'.format(len(koeki_header_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 2/3.', 'DEBUG')
        if (ken_bucket_list == False) or (city_bucket_list == False):
            print_log('[WARN] P0130Manage.bucket_ken_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        ### 地方単独事業調査票ファイルの0件は正常であるため、
        ### 補助事業事業調査票ファイルの0件は正常であるため、
        ### 公益事業調査票ファイルの0件は正常であるため、

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0130Manage.bucket_ken_code_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'ken_bucket_list': ken_bucket_list, 
            'city_bucket_list': city_bucket_list, 
            'chitan_header_list': chitan_header_list, 
            'hojo_header_list': hojo_header_list, 
            'koeki_header_list': koeki_header_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0130Manage.bucket_ken_code_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_ken_code_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_ken_code_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 運用担当者用ブラウザ市アップロードファイル
### urlpattern：path('browser/city/<slug:city_code>/', views.browser_city_code_view, name='browser_city_code_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='browser_city_code_view')
def browser_city_code_view(request, city_code):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### CITY_BUCKET: 
        ### IPPAN_HEADER: 
        ### KUIKI: 
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 1_1/6.', 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'CITY_CODE': city_code,
                'IPPAN_CITY_UPLOAD': _PROVISIONED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _PROVISIONED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _PROVISIONED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _PROVISIONED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _PROVISIONED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _PROVISIONED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _PROVISIONED_IPPAN_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'CITY_CODE': city_code,
                'IPPAN_CITY_UPLOAD': _CONFIRMED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _CONFIRMED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _CONFIRMED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _CONFIRMED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _CONFIRMED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _CONFIRMED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _CONFIRMED_IPPAN_MANAGE_DISAPPROVE,
            })
        SQL_SELECT_CITY_BUCKET = """
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, -- ディスク使用量
                FILES -- ファイル格納数
            FROM CITY_BUCKET 
            WHERE 
                CITY_CODE=%(CITY_CODE)s"""
        SQL_SELECT_IPPAN_HEADER = """
            SELECT 
                I1.IPPAN_HEADER_ID, 
                I1.IPPAN_HEADER_NAME, 
                I1.KEN_CODE, 
                I1.CITY_CODE, 
                I1.KUIKI_ID, -- ADD 2024/10/02
                I1.WEATHER_ID, -- ADD 2024/10/02
                I1.UPLOAD_FILE_PATH, 
                I1.UPLOAD_FILE_NAME, 
                I1.UPLOAD_FILE_SIZE, 
                I1.SUMMARY_FILE_PATH, 
                I1.SUMMARY_FILE_NAME, 
                I1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', I1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', I1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT,
                S1.IPPAN_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM IPPAN_HEADER I1
            LEFT JOIN (
                SELECT
                    IPPAN_HISTORY_ID,
                    IPPAN_HEADER_ID,
                    WORKFLOW_CODE
                FROM IPPAN_HISTORY
                WHERE
                    IPPAN_HISTORY_ID IN (
                        SELECT
                            MAX(IPPAN_HISTORY_ID)
                        FROM IPPAN_HISTORY
                        GROUP BY IPPAN_HEADER_ID
                    )
            ) S1 ON I1.IPPAN_HEADER_ID=S1.IPPAN_HEADER_ID
            WHERE 
                I1.CITY_CODE=%(CITY_CODE)s AND 
                I1.DELETED_AT IS NULL
            ORDER BY I1.IPPAN_HEADER_ID"""

        ### HTMLタイトル部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw(SQL_SELECT_CITY_BUCKET, PARAMS)
        ### HTML一覧部分表示用
        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS)
        
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 city_bucket_list={}'.format(city_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 len(city_bucket_list)={}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 len(ippan_header_list)={}'.format(len(ippan_header_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 STEP 2/6.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0130Manage.browser_city_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/browser/browser_city_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        ### 一般資産調査員調査票ファイルの0件は正常であるため、

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0130Manage.browser_city_code_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0130Manage/browser/browser_city_code.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'city_bucket_list': city_bucket_list, 
            'ippan_header_list': ippan_header_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0130Manage.browser_city_code_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.browser_city_code_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.browser_city_code_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0130Manage/browser/browser_city_code.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 右スライドメニュー表示
### urlpattern：path('slide/ippan/header/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_ippan_header_id_view')
def slide_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### IPPAN_HEADER: 
        ### IPPAN_HISTORY:
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 STEP 1/3.', 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_UPLOAD': _PROVISIONED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _PROVISIONED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _PROVISIONED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _PROVISIONED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _PROVISIONED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _PROVISIONED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _PROVISIONED_IPPAN_MANAGE_DISAPPROVE,
                'IPP_ACT_01': _IPP_ACT_01,
                'IPP_ACT_02': _IPP_ACT_02,
                'IPP_ACT_03': _IPP_ACT_03,
            })
        else:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_UPLOAD': _CONFIRMED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _CONFIRMED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _CONFIRMED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _CONFIRMED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _CONFIRMED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _CONFIRMED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _CONFIRMED_IPPAN_MANAGE_DISAPPROVE,
                'IPP_ACT_01': _IPP_ACT_01,
                'IPP_ACT_02': _IPP_ACT_02,
                'IPP_ACT_03': _IPP_ACT_03,
            })
        SQL_SELECT_IPPAN_HEADER = """
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                KUIKI_ID, -- ADD 2024/10/02
                WEATHER_ID, -- ADD 2024/10/02
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s"""
        SQL_SELECT_IPPAN_HISTORY = """
            SELECT
                IPPAN_HISTORY_ID,
                IPPAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM IPPAN_HISTORY
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s
            ORDER BY IPPAN_HISTORY_ID"""
        SQL_SELECT_IPPAN_HISTORY_LATEST = """
            SELECT
                IPPAN_HISTORY_ID,
                IPPAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM IPPAN_HISTORY
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s
            ORDER BY IPPAN_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_IPPAN_TRIGGER = """
            SELECT
                IPPAN_TRIGGER_ID,
                IPPAN_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM IPPAN_TRIGGER
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND
                ACTION_CODE IN (%(IPP_ACT_01)s, %(IPP_ACT_02)s, %(IPP_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY IPPAN_TRIGGER_ID"""
                
        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS)
        ippan_history_list = IPPAN_HISTORY.objects.raw(SQL_SELECT_IPPAN_HISTORY, PARAMS)
        ippan_history_latest_list = IPPAN_HISTORY.objects.raw(SQL_SELECT_IPPAN_HISTORY_LATEST, PARAMS)
        ippan_trigger_list = IPPAN_TRIGGER.objects.raw(SQL_SELECT_IPPAN_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 len(ippan_header_list)={}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 ippan_history_list={}'.format(ippan_history_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 len(ippan_history_list)={}'.format(len(ippan_history_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 ippan_history_latest_list={}'.format(ippan_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 len(ippan_history_latest_list)={}'.format(len(ippan_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 ippan_trigger_list={}'.format(ippan_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 len(ippan_trigger_list)={}'.format(len(ippan_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if ippan_header_list == False:
            print_log('[WARN] P0130Manage.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'return_code': ["TRUE"], ### 2024/11/08 ADD
            'ippan_header_id': ippan_header_list[0].ippan_header_id, 
            'ippan_header_name': ippan_header_list[0].ippan_header_name, 
            'ken_code': ippan_header_list[0].ken_code, 
            'city_code': ippan_header_list[0].city_code, 
            'kuiki_id': ippan_header_list[0].kuiki_id, 
            'weather_id': ippan_header_list[0].weather_id, 
            'upload_file_path': ippan_header_list[0].upload_file_path, 
            'upload_file_name': ippan_header_list[0].upload_file_name, 
            'upload_file_size': ippan_header_list[0].upload_file_size, 
            'summary_file_path': ippan_header_list[0].summary_file_path, 
            'summary_file_name': ippan_header_list[0].summary_file_name, 
            'summary_file_size': ippan_header_list[0].summary_file_size, 
            'committed_at': ippan_header_list[0].committed_at, 
            'deleted_at': ippan_header_list[0].deleted_at, 
        }
        
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if ippan_history_latest_list:
            latest = {
                'latest_workflow_code': ippan_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if ippan_history_list:
            for ippan_history in ippan_history_list:
                history_list.append({'workflow_code': ippan_history.workflow_code, 'committed_at': ippan_history.committed_at})

        print_log('[DEBUG] P0130Manage.slide_ippan_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if ippan_trigger_list:
            for ippan_trigger in ippan_trigger_list:
                trigger_list.append({'action_code': ippan_trigger.action_code, 'status_code': ippan_trigger.status_code, 'consumed_at': ippan_trigger.consumed_at})
        
        print_log('[INFO] P0130Manage.slide_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0130Manage.slide_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 右スライドメニュー表示
### urlpattern：path('slide/chitan/header/<slug:header_id>/', views.slide_chitan_header_id_view, name='slide_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_chitan_header_id_view')
def slide_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### CHITAN_HEADER: 
        ### CHITAN_HISTORY:
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 STEP 1/3.', 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id, 
                'CHITAN_KEN_UPLOAD': _PROVISIONED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _PROVISIONED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _PROVISIONED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _PROVISIONED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _PROVISIONED_CHITAN_MANAGE_DISAPPROVE,
                'CHI_ACT_01': _CHI_ACT_01,
                'CHI_ACT_02': _CHI_ACT_02,
                'CHI_ACT_03': _CHI_ACT_03,
            })
        else:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id, 
                'CHITAN_KEN_UPLOAD': _CONFIRMED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _CONFIRMED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _CONFIRMED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _CONFIRMED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _CONFIRMED_CHITAN_MANAGE_DISAPPROVE,
                'CHI_ACT_01': _CHI_ACT_01,
                'CHI_ACT_02': _CHI_ACT_02,
                'CHI_ACT_03': _CHI_ACT_03,
            })
        SQL_SELECT_CHITAN_HEADER = """
            SELECT 
                CHITAN_HEADER_ID, 
                CHITAN_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM CHITAN_HEADER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s"""
        SQL_SELECT_CHITAN_HISTORY = """
            SELECT
                CHITAN_HISTORY_ID,
                CHITAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM CHITAN_HISTORY
            WHERE
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s
            ORDER BY CHITAN_HISTORY_ID"""
        SQL_SELECT_CHITAN_HISTORY_LATEST = """
            SELECT
                CHITAN_HISTORY_ID,
                CHITAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM CHITAN_HISTORY
            WHERE
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s
            ORDER BY CHITAN_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_CHITAN_TRIGGER = """
            SELECT
                CHITAN_TRIGGER_ID,
                CHITAN_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM CHITAN_TRIGGER
            WHERE
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND
                ACTION_CODE IN (%(CHI_ACT_01)s, %(CHI_ACT_02)s, %(CHI_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY CHITAN_TRIGGER_ID"""

        chitan_header_list = CHITAN_HEADER.objects.raw(SQL_SELECT_CHITAN_HEADER, PARAMS)
        chitan_history_list = CHITAN_HISTORY.objects.raw(SQL_SELECT_CHITAN_HISTORY, PARAMS)
        chitan_history_latest_list = CHITAN_HISTORY.objects.raw(SQL_SELECT_CHITAN_HISTORY_LATEST, PARAMS)
        chitan_trigger_list = CHITAN_TRIGGER.objects.raw(SQL_SELECT_CHITAN_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 chitan_header_list={}'.format(chitan_header_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 len(chitan_header_list)={}'.format(len(chitan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 chitan_history_list={}'.format(chitan_history_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 len(chitan_history_list)={}'.format(len(chitan_history_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 chitan_history_latest_list={}'.format(chitan_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 len(chitan_history_latest_list)={}'.format(len(chitan_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 chitan_trigger_list={}'.format(chitan_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 len(chitan_trigger_list)={}'.format(len(chitan_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if chitan_header_list == False:
            print_log('[WARN] P0130Manage.slide_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'chitan_header_id': chitan_header_list[0].chitan_header_id, 
            'chitan_header_name': chitan_header_list[0].chitan_header_name, 
            'ken_code': chitan_header_list[0].ken_code, 
            'upload_file_path': chitan_header_list[0].upload_file_path, 
            'upload_file_name': chitan_header_list[0].upload_file_name, 
            'upload_file_size': chitan_header_list[0].upload_file_size, 
            'summary_file_path': chitan_header_list[0].summary_file_path, 
            'summary_file_name': chitan_header_list[0].summary_file_name, 
            'summary_file_size': chitan_header_list[0].summary_file_size, 
            'committed_at': chitan_header_list[0].committed_at, 
            'deleted_at': chitan_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if chitan_history_latest_list:
            latest = {
                'latest_workflow_code': chitan_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if chitan_history_list:
            for chitan_history in chitan_history_list:
                history_list.append({'workflow_code': chitan_history.workflow_code, 'committed_at': chitan_history.committed_at})

        print_log('[DEBUG] P0130Manage.slide_chitan_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if chitan_trigger_list:
            for chitan_trigger in chitan_trigger_list:
                trigger_list.append({'action_code': chitan_trigger.action_code, 'status_code': chitan_trigger.status_code, 'consumed_at': chitan_trigger.consumed_at})

        print_log('[INFO] P0130Manage.slide_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0130Manage.slide_chitan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_chitan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 右スライドメニュー表示
### urlpattern：path('slide/hojo/header/<slug:header_id>/', views.slide_hojo_header_id_view, name='slide_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_hojo_header_id_view')
def slide_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### HOJO_HEADER: 
        ### HOJO_HISTORY:
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 STEP 1/3.', 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id, 
                'HOJO_KEN_UPLOAD': _PROVISIONED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _PROVISIONED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _PROVISIONED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _PROVISIONED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _PROVISIONED_HOJO_MANAGE_DISAPPROVE,
                'HOJ_ACT_01': _HOJ_ACT_01,
                'HOJ_ACT_02': _HOJ_ACT_02,
                'HOJ_ACT_03': _HOJ_ACT_03,
            })
        else:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id, 
                'HOJO_KEN_UPLOAD': _CONFIRMED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _CONFIRMED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _CONFIRMED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _CONFIRMED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _CONFIRMED_HOJO_MANAGE_DISAPPROVE,
                'HOJ_ACT_01': _HOJ_ACT_01,
                'HOJ_ACT_02': _HOJ_ACT_02,
                'HOJ_ACT_03': _HOJ_ACT_03,
            })
        SQL_SELECT_HOJO_HEADER = """
            SELECT 
                HOJO_HEADER_ID, 
                HOJO_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM HOJO_HEADER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s"""
        SQL_SELECT_HOJO_HISTORY = """
            SELECT
                HOJO_HISTORY_ID,
                HOJO_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM HOJO_HISTORY
            WHERE
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s
            ORDER BY HOJO_HISTORY_ID"""
        SQL_SELECT_HOJO_HISTORY_LATEST = """
            SELECT
                HOJO_HISTORY_ID,
                HOJO_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM HOJO_HISTORY
            WHERE
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s
            ORDER BY HOJO_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_HOJO_TRIGGER = """
            SELECT
                HOJO_TRIGGER_ID,
                HOJO_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM HOJO_TRIGGER
            WHERE
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND
                ACTION_CODE IN (%(HOJ_ACT_01)s, %(HOJ_ACT_02)s, %(HOJ_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY HOJO_TRIGGER_ID"""

        hojo_header_list = HOJO_HEADER.objects.raw(SQL_SELECT_HOJO_HEADER, PARAMS)
        hojo_history_list = HOJO_HISTORY.objects.raw(SQL_SELECT_HOJO_HISTORY, PARAMS)
        hojo_history_latest_list = HOJO_HISTORY.objects.raw(SQL_SELECT_HOJO_HISTORY_LATEST, PARAMS)
        hojo_trigger_list = HOJO_TRIGGER.objects.raw(SQL_SELECT_HOJO_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 hojo_header_list={}'.format(hojo_header_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 len(hojo_header_list)={}'.format(len(hojo_header_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 hojo_history_list={}'.format(hojo_history_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 len(hojo_history_list)={}'.format(len(hojo_history_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 hojo_history_latest_list={}'.format(hojo_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 len(hojo_history_latest_list)={}'.format(len(hojo_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 hojo_trigger_list={}'.format(hojo_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 len(hojo_trigger_list)={}'.format(len(hojo_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if hojo_header_list == False:
            print_log('[WARN] P0130Manage.slide_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'hojo_header_id': hojo_header_list[0].hojo_header_id, 
            'hojo_header_name': hojo_header_list[0].hojo_header_name, 
            'ken_code': hojo_header_list[0].ken_code, 
            'upload_file_path': hojo_header_list[0].upload_file_path, 
            'upload_file_name': hojo_header_list[0].upload_file_name, 
            'upload_file_size': hojo_header_list[0].upload_file_size, 
            'summary_file_path': hojo_header_list[0].summary_file_path, 
            'summary_file_name': hojo_header_list[0].summary_file_name, 
            'summary_file_size': hojo_header_list[0].summary_file_size, 
            'committed_at': hojo_header_list[0].committed_at, 
            'deleted_at': hojo_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if hojo_history_latest_list:
            latest = {
                'latest_workflow_code': hojo_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if hojo_history_list:
            for hojo_history in hojo_history_list:
                history_list.append({'workflow_code': hojo_history.workflow_code, 'committed_at': hojo_history.committed_at})

        print_log('[DEBUG] P0130Manage.slide_hojo_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if hojo_trigger_list:
            for hojo_trigger in hojo_trigger_list:
                trigger_list.append({'action_code': hojo_trigger.action_code, 'status_code': hojo_trigger.status_code, 'consumed_at': hojo_trigger.consumed_at})

        print_log('[INFO] P0130Manage.slide_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0130Manage.slide_hojo_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_hojo_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 右スライドメニュー表示
### urlpattern：path('slide/koeki/header/<slug:header_id>/', views.slide_koeki_header_id_view, name='slide_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_koeki_header_id_view')
def slide_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### KOEKI_HEADER: 
        ### KOEKI_HISTORY:
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 STEP 1/3.', 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id, 
                'KOEKI_KEN_UPLOAD': _PROVISIONED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _PROVISIONED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _PROVISIONED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _PROVISIONED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _PROVISIONED_KOEKI_MANAGE_DISAPPROVE,
                'KOE_ACT_01': _KOE_ACT_01,
                'KOE_ACT_02': _KOE_ACT_02,
                'KOE_ACT_03': _KOE_ACT_03,
            })
        else:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id, 
                'KOEKI_KEN_UPLOAD': _CONFIRMED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _CONFIRMED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _CONFIRMED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _CONFIRMED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _CONFIRMED_KOEKI_MANAGE_DISAPPROVE,
                'KOE_ACT_01': _KOE_ACT_01,
                'KOE_ACT_02': _KOE_ACT_02,
                'KOE_ACT_03': _KOE_ACT_03,
            })
        SQL_SELECT_KOEKI_HEADER = """
            SELECT 
                KOEKI_HEADER_ID, 
                KOEKI_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM KOEKI_HEADER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s"""
        SQL_SELECT_KOEKI_HISTORY = """
            SELECT
                KOEKI_HISTORY_ID,
                KOEKI_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM KOEKI_HISTORY
            WHERE
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s
            ORDER BY KOEKI_HISTORY_ID"""
        SQL_SELECT_KOEKI_HISTORY_LATEST = """
            SELECT
                KOEKI_HISTORY_ID,
                KOEKI_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM KOEKI_HISTORY
            WHERE
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s
            ORDER BY KOEKI_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_KOEKI_TRIGGER = """
            SELECT
                KOEKI_TRIGGER_ID,
                KOEKI_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM KOEKI_TRIGGER
            WHERE
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND
                ACTION_CODE IN (%(KOE_ACT_01)s, %(KOE_ACT_02)s, %(KOE_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY KOEKI_TRIGGER_ID"""

        koeki_header_list = KOEKI_HEADER.objects.raw(SQL_SELECT_KOEKI_HEADER, PARAMS)
        koeki_history_list = KOEKI_HISTORY.objects.raw(SQL_SELECT_KOEKI_HISTORY, PARAMS)
        koeki_history_latest_list = KOEKI_HISTORY.objects.raw(SQL_SELECT_KOEKI_HISTORY_LATEST, PARAMS)
        koeki_trigger_list = KOEKI_TRIGGER.objects.raw(SQL_SELECT_KOEKI_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 koeki_header_list={}'.format(koeki_header_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 len(koeki_header_list)={}'.format(len(koeki_header_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 koeki_history_list={}'.format(koeki_history_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 len(koeki_history_list)={}'.format(len(koeki_history_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 koeki_history_latest_list={}'.format(koeki_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 len(koeki_history_latest_list)={}'.format(len(koeki_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 koeki_trigger_list={}'.format(koeki_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 len(koeki_trigger_list)={}'.format(len(koeki_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if koeki_header_list == False:
            print_log('[WARN] P0130Manage.slide_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'koeki_header_id': koeki_header_list[0].koeki_header_id, 
            'koeki_header_name': koeki_header_list[0].koeki_header_name, 
            'ken_code': koeki_header_list[0].ken_code, 
            'upload_file_path': koeki_header_list[0].upload_file_path, 
            'upload_file_name': koeki_header_list[0].upload_file_name, 
            'upload_file_size': koeki_header_list[0].upload_file_size, 
            'summary_file_path': koeki_header_list[0].summary_file_path, 
            'summary_file_name': koeki_header_list[0].summary_file_name, 
            'summary_file_size': koeki_header_list[0].summary_file_size, 
            'committed_at': koeki_header_list[0].committed_at, 
            'deleted_at': koeki_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if koeki_history_latest_list:
            latest = {
                'latest_workflow_code': koeki_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if koeki_history_list:
            for koeki_history in koeki_history_list:
                history_list.append({'workflow_code': koeki_history.workflow_code, 'committed_at': koeki_history.committed_at})

        print_log('[DEBUG] P0130Manage.slide_koeki_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if koeki_trigger_list:
            for koeki_trigger in koeki_trigger_list:
                trigger_list.append({'action_code': koeki_trigger.action_code, 'status_code': koeki_trigger.status_code, 'consumed_at': koeki_trigger.consumed_at})

        print_log('[INFO] P0130Manage.slide_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0130Manage.slide_koeki_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_koeki_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 承認
### urlpattern：path('approve/ippan/header/<slug:header_id>/', views.approve_ippan_header_id_view, name='approve_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='approve_ippan_header_id_view')
def approve_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_MANAGE_APPROVE': _PROVISIONED_IPPAN_MANAGE_APPROVE,
            })
        else:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_MANAGE_APPROVE': _CONFIRMED_IPPAN_MANAGE_APPROVE,
            })
        SQL_INSERT_IPPAN_HISTORY = """
            INSERT INTO IPPAN_HISTORY (
                IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(IPPAN_HEADER_ID)s,
                %(IPPAN_MANAGE_APPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)

        #######################################################################
        ### レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 承認
### urlpattern：path('approve/chitan/header/<slug:header_id>/', views.approve_chitan_header_id_view, name='approve_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='approve_chitan_header_id_view')
def approve_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id,
                'CHITAN_MANAGE_APPROVE': _PROVISIONED_CHITAN_MANAGE_APPROVE,
            })
        else:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id,
                'CHITAN_MANAGE_APPROVE': _CONFIRMED_CHITAN_MANAGE_APPROVE,
            })
        SQL_INSERT_CHITAN_HISTORY = """
            INSERT INTO CHITAN_HISTORY (
                CHITAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(CHITAN_HEADER_ID)s,
                %(CHITAN_MANAGE_APPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_CHITAN_HISTORY, PARAMS)

        #######################################################################
        ### レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_chitan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_chitan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 承認
### urlpattern：path('approve/hojo/header/<slug:header_id>/', views.approve_hojo_header_id_view, name='approve_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='approve_hojo_header_id_view')
def approve_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id,
                'HOJO_MANAGE_APPROVE': _PROVISIONED_HOJO_MANAGE_APPROVE,
            })
        else:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id,
                'HOJO_MANAGE_APPROVE': _CONFIRMED_HOJO_MANAGE_APPROVE,
            })
        SQL_INSERT_HOJO_HISTORY = """
            INSERT INTO HOJO_HISTORY (
                HOJO_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(HOJO_HEADER_ID)s,
                %(HOJO_MANAGE_APPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_HOJO_HISTORY, PARAMS)

        #######################################################################
        ### レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_hojo_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_hojo_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 承認
### urlpattern：path('approve/koeki/header/<slug:header_id>/', views.approve_koeki_header_id_view, name='approve_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='approve_koeki_header_id_view')
def approve_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id,
                'KOEKI_MANAGE_APPROVE': _PROVISIONED_KOEKI_MANAGE_APPROVE,
            })
        else:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id,
                'KOEKI_MANAGE_APPROVE': _CONFIRMED_KOEKI_MANAGE_APPROVE,
            })
        SQL_INSERT_KOEKI_HISTORY = """
            INSERT INTO KOEKI_HISTORY (
                KOEKI_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(KOEKI_HEADER_ID)s,
                %(KOEKI_MANAGE_APPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_KOEKI_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_koeki_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_koeki_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 差し戻し
### urlpattern：path('disapprove/ippan/header/<slug:header_id>/', views.disapprove_ippan_header_id_view, name='disapprove_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='disapprove_ippan_header_id_view')
def disapprove_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_ippan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_MANAGE_DISAPPROVE': _PROVISIONED_IPPAN_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_MANAGE_DISAPPROVE': _CONFIRMED_IPPAN_MANAGE_DISAPPROVE,
            })
        SQL_INSERT_IPPAN_HISTORY = """
            INSERT INTO IPPAN_HISTORY (
                IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(IPPAN_HEADER_ID)s,
                %(IPPAN_MANAGE_DISAPPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)

        #######################################################################
        ### レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_ippan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.disapprove_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.disapprove_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 差し戻し
### urlpattern：path('disapprove/chitan/header/<slug:header_id>/', views.disapprove_chitan_header_id_view, name='disapprove_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='disapprove_chitan_header_id_view')
def disapprove_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_chitan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id,
                'CHITAN_MANAGE_DISAPPROVE': _PROVISIONED_CHITAN_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id,
                'CHITAN_MANAGE_DISAPPROVE': _CONFIRMED_CHITAN_MANAGE_DISAPPROVE,
            })
        SQL_INSERT_CHITAN_HISTORY = """
            INSERT INTO CHITAN_HISTORY (
                CHITAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(CHITAN_HEADER_ID)s,
                %(CHITAN_MANAGE_DISAPPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_CHITAN_HISTORY, PARAMS)

        #######################################################################
        ### レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_chitan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.disapprove_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.disapprove_chitan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_chitan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 差し戻し
### urlpattern：path('disapprove/hojo/header/<slug:header_id>/', views.disapprove_hojo_header_id_view, name='disapprove_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='disapprove_hojo_header_id_view')
def disapprove_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_hojo_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id,
                'HOJO_MANAGE_DISAPPROVE': _PROVISIONED_HOJO_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id,
                'HOJO_MANAGE_DISAPPROVE': _CONFIRMED_HOJO_MANAGE_DISAPPROVE,
            })
        SQL_INSERT_HOJO_HISTORY = """
            INSERT INTO HOJO_HISTORY (
                HOJO_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(HOJO_HEADER_ID)s,
                %(HOJO_MANAGE_DISAPPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_HOJO_HISTORY, PARAMS)

        #######################################################################
        ### レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_hojo_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.disapprove_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.disapprove_hojo_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_hojo_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 差し戻し
### urlpattern：path('disapprove/koeki/header/<slug:header_id>/', views.disapprove_koeki_header_id_view, name='disapprove_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='disapprove_koeki_header_id_view')
def disapprove_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_koeki_header_id_view()関数 STEP 1/2.', 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id,
                'KOEKI_MANAGE_DISAPPROVE': _PROVISIONED_KOEKI_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id,
                'KOEKI_MANAGE_DISAPPROVE': _CONFIRMED_KOEKI_MANAGE_DISAPPROVE,
            })
        SQL_INSERT_KOEKI_HISTORY = """
            INSERT INTO KOEKI_HISTORY (
                KOEKI_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(KOEKI_HEADER_ID)s,
                %(KOEKI_MANAGE_DISAPPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_KOEKI_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0130Manage.disapprove_koeki_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0130Manage.disapprove_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.disapprove_koeki_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_koeki_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.disapprove_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 EXCELダウンロード
### urlpattern：path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_chosa_excel_header_id_view')
def download_ippan_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_CHO_EXC
        })
        bool_return, file_path = get_ippan_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_ippan_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 CSVダウンロード
### urlpattern：path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_chosa_csv_header_id_view')
def download_ippan_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_CHO_CSV
        })
        bool_return, file_path = get_ippan_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_ippan_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産集計結果 EXCELダウンロード
### urlpattern：path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_summary_excel_header_id_view')
def download_ippan_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_SUM_EXC
        })
        bool_return, file_path = get_ippan_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_ippan_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産集計結果 CSVダウンロード
### urlpattern：path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_summary_csv_header_id_view')
def download_ippan_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_SUM_CSV
        })
        bool_return, file_path = get_ippan_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_ippan_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産サーバ間連携 CSVダウンロード
### urlpattern：path('download/ippan/export/csv/header/<slug:header_id>/', views.download_ippan_export_csv_header_id_view, name='download_ippan_export_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_export_csv_header_id_view')
def download_ippan_export_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_EXP_CSV
        })
        bool_return, file_path = get_ippan_export_csv(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_ippan_export_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_export_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_ippan_export_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 EXCELダウンロード
### urlpattern：path('download/chitan/chosa/excel/header/<slug:header_id>/', views.download_chitan_chosa_excel_header_id_view, name='download_chitan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_chosa_excel_header_id_view')
def download_chitan_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_CHO_EXC
        })
        bool_return, file_path = get_chitan_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_chitan_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 CSVダウンロード
### urlpattern：path('download/chitan/chosa/csv/header/<slug:header_id>/', views.download_chitan_chosa_csv_header_id_view, name='download_chitan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_chosa_csv_header_id_view')
def download_chitan_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_CHO_CSV
        })
        bool_return, file_path = get_chitan_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_chitan_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業集計結果 EXCELダウンロード
### urlpattern：path('download/chitan/summary/excel/header/<slug:header_id>/', views.download_chitan_summary_excel_header_id_view, name='download_chitan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_summary_excel_header_id_view')
def download_chitan_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_SUM_EXC
        })
        bool_return, file_path = get_chitan_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_chitan_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業集計結果 CSVダウンロード
### urlpattern：path('download/chitan/summary/csv/header/<slug:header_id>/', views.download_chitan_summary_csv_header_id_view, name='download_chitan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_summary_csv_header_id_view')
def download_chitan_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_SUM_CSV
        })
        bool_return, file_path = get_chitan_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_chitan_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_chitan_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 EXCELダウンロード
### urlpattern：path('download/hojo/chosa/excel/header/<slug:header_id>/', views.download_hojo_chosa_excel_header_id_view, name='download_hojo_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_chosa_excel_header_id_view')
def download_hojo_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_CHO_EXC
        })
        bool_return, file_path = get_hojo_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_hojo_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 CSVダウンロード
### urlpattern：path('download/hojo/chosa/csv/header/<slug:header_id>/', views.download_hojo_chosa_csv_header_id_view, name='download_hojo_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_chosa_csv_header_id_view')
def download_hojo_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_CHO_CSV
        })
        bool_return, file_path = get_hojo_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_hojo_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業集計結果 EXCELダウンロード
### urlpattern：path('download/hojo/summary/excel/header/<slug:header_id>/', views.download_hojo_summary_excel_header_id_view, name='download_hojo_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_summary_excel_header_id_view')
def download_hojo_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_SUM_EXC
        })
        bool_return, file_path = get_hojo_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_hojo_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業集計結果 CSVダウンロード
### urlpattern：path('download/hojo/summary/csv/header/<slug:header_id>/', views.download_hojo_summary_csv_header_id_view, name='download_hojo_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_summary_csv_header_id_view')
def download_hojo_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_SUM_CSV
        })
        bool_return, file_path = get_hojo_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_hojo_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_hojo_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 EXCELダウンロード
### urlpattern：path('download/koeki/chosa/excel/header/<slug:header_id>/', views.download_koeki_chosa_excel_header_id_view, name='download_koeki_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_chosa_excel_header_id_view')
def download_koeki_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_CHO_EXC
        })
        bool_return, file_path = get_koeki_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_koeki_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 CSVダウンロード
### urlpattern：path('download/koeki/chosa/csv/header/<slug:header_id>/', views.download_koeki_chosa_csv_header_id_view, name='download_koeki_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_chosa_csv_header_id_view')
def download_koeki_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_CHO_CSV
        })
        bool_return, file_path = get_koeki_chosa_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_koeki_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業集計結果 EXCELダウンロード
### urlpattern：path('download/koeki/summary/excel/header/<slug:header_id>/', views.download_koeki_summary_excel_header_id_view, name='download_koeki_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_summary_excel_header_id_view')
def download_koeki_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_SUM_EXC
        })
        bool_return, file_path = get_koeki_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_koeki_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業集計結果 CSVダウンロード
### urlpattern：path('download/koeki/summary/csv/header/<slug:header_id>/', views.download_koeki_summary_csv_header_id_view, name='download_koeki_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_summary_csv_header_id_view')
def download_koeki_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_SUM_CSV
        })
        bool_return, file_path = get_koeki_summary_csv_excel(request, PARAMS)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0130Manage.download_koeki_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_koeki_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")
