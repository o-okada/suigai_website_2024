from django.urls import path
from . import views

app_name = 'P0130Manage'
urlpatterns = [
    path('', views.index_view, name='index_view'),                                                                        ### /P0130Manage/ => /P0130Manage/bucket/ リダイレクト用
    path('bucket/', views.bucket_view, name='bucket_view'),                                                               ### 運用担当者用バケット都バケット Add 2023/01/27
    path('bucket/ken/<slug:ken_code>/', views.bucket_ken_code_view, name='bucket_ken_code_view'),                         ### 運用担当者用バケット市バケット Add 2023/01/27
    path('browser/city/<slug:city_code>/', views.browser_city_code_view, name='browser_city_code_view'),                  ### 運用担当者用オブジェクトブラウザ市アップロードファイル Add 2023/01/27

    path('slide/ippan/header/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view'),
    path('slide/chitan/header/<slug:header_id>/', views.slide_chitan_header_id_view, name='slide_chitan_header_id_view'),
    path('slide/hojo/header/<slug:header_id>/', views.slide_hojo_header_id_view, name='slide_hojo_header_id_view'),
    path('slide/koeki/header/<slug:header_id>/', views.slide_koeki_header_id_view, name='slide_koeki_header_id_view'),

    path('approve/ippan/header/<slug:header_id>/', views.approve_ippan_header_id_view, name='approve_ippan_header_id_view'),
    path('approve/chitan/header/<slug:header_id>/', views.approve_chitan_header_id_view, name='approve_chitan_header_id_view'),  ### ADD 2024/09/13 O.OKADA
    path('approve/hojo/header/<slug:header_id>/', views.approve_hojo_header_id_view, name='approve_hojo_header_id_view'),        ### ADD 2024/09/13 O.OKADA
    path('approve/koeki/header/<slug:header_id>/', views.approve_koeki_header_id_view, name='approve_koeki_header_id_view'),     ### ADD 2024/09/13 O.OKADA

    path('disapprove/ippan/header/<slug:header_id>/', views.disapprove_ippan_header_id_view, name='disapprove_ippan_header_id_view'),
    path('disapprove/chitan/header/<slug:header_id>/', views.disapprove_chitan_header_id_view, name='disapprove_chitan_header_id_view'),  ### ADD 2024/09/13 O.OKADA
    path('disapprove/hojo/header/<slug:header_id>/', views.disapprove_hojo_header_id_view, name='disapprove_hojo_header_id_view'),        ### ADD 2024/09/13 O.OKADA
    path('disapprove/koeki/header/<slug:header_id>/', views.disapprove_koeki_header_id_view, name='disapprove_koeki_header_id_view'),     ### ADD 2024/09/13 O.OKADA

    path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view'), 
    path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view'), 
    path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view'), 
    path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view'), 
    path('download/ippan/export/csv/header/<slug:header_id>/', views.download_ippan_export_csv_header_id_view, name='download_ippan_export_csv_header_id_view'), ### ADD 2024/10/02
    path('download/chitan/chosa/excel/header/<slug:header_id>/', views.download_chitan_chosa_excel_header_id_view, name='download_chitan_chosa_excel_header_id_view'), 
    path('download/chitan/chosa/csv/header/<slug:header_id>/', views.download_chitan_chosa_csv_header_id_view, name='download_chitan_chosa_csv_header_id_view'), 
    path('download/chitan/summary/excel/header/<slug:header_id>/', views.download_chitan_summary_excel_header_id_view, name='download_chitan_summary_excel_header_id_view'), 
    path('download/chitan/summary/csv/header/<slug:header_id>/', views.download_chitan_summary_csv_header_id_view, name='download_chitan_summary_csv_header_id_view'), 
    path('download/hojo/chosa/excel/header/<slug:header_id>/', views.download_hojo_chosa_excel_header_id_view, name='download_hojo_chosa_excel_header_id_view'), 
    path('download/hojo/chosa/csv/header/<slug:header_id>/', views.download_hojo_chosa_csv_header_id_view, name='download_hojo_chosa_csv_header_id_view'), 
    path('download/hojo/summary/excel/header/<slug:header_id>/', views.download_hojo_summary_excel_header_id_view, name='download_hojo_summary_excel_header_id_view'), 
    path('download/hojo/summary/csv/header/<slug:header_id>/', views.download_hojo_summary_csv_header_id_view, name='download_hojo_summary_csv_header_id_view'), 
    path('download/koeki/chosa/excel/header/<slug:header_id>/', views.download_koeki_chosa_excel_header_id_view, name='download_koeki_chosa_excel_header_id_view'), 
    path('download/koeki/chosa/csv/header/<slug:header_id>/', views.download_koeki_chosa_csv_header_id_view, name='download_koeki_chosa_csv_header_id_view'), 
    path('download/koeki/summary/excel/header/<slug:header_id>/', views.download_koeki_summary_excel_header_id_view, name='download_koeki_summary_excel_header_id_view'), 
    path('download/koeki/summary/csv/header/<slug:header_id>/', views.download_koeki_summary_csv_header_id_view, name='download_koeki_summary_csv_header_id_view'), 
]
