###############################################################################
### ファイル名：P0500GUI/views.py
### ビュー関数
### def editor_view 「水害区域図様式出力画面」で「水害区域図作成画面へ戻るボタン」クリック時に呼ばれる。
### def printout_view 「水害区域図作成画面」で「貼付用紙作成・様式出力ボタン」クリック時に呼ばれる。
### ### def kuiki_id_view 「ブラウザ画面」で「水害区域図編集ボタンまたはリンク」クリック時に呼ばれる。 ### 2024/11/10 comment out
### def upload_temp_kml 「水害区域図作成画面」で「一時保存ファイルの読込ボタン」クリック時に呼ばれる。
### def upload_canvas 「水害区域図様式出力画面」で「様式および作図情報の出力ボタン」クリック時に呼ばれる。（第１ステップ）
### def upload_png 「水害区域図様式出力画面」で「様式および作図情報の出力ボタン」クリック時に呼ばれる。（第２ステップ）
### def download_kml 「水害区域図様式出力画面」で「KMLダウンロードボタン」クリック時に呼ばれる。
### def download_pdf 「水害区域図様式出力画面」で「PDFダウンロードボタン」クリック時に呼ばれる。
### クラス形式メンバ関数：自クラス、別クラス等の関数、ビュー関数から呼ばれる
### class PDF_GENERATOR def draw_map_vertically_A3(self, p, png_file_path)
### class PDF_GENERATOR def draw_legend_vertically_A3(self, p)
### class PDF_GENERATOR def draw_form_vertically_A3(self, p, params)
### ...
### class PDF_GENERATOR def download_pdf_response(self, pdf_content, pdf_file_name)
### class KML_GENERATOR def generate_kml(self, params)
### 履歴
### 2024/11/10 都道府県コード、市区町村コード、都道府県名、市区町村名をユーザ入力不可とした。
### 2024/11/10 都道府県コード、市区町村コード、都道府県名、市区町村名をUSER_PROXYから取得するように変更した。
### 2024/11/10 def kuiki_id_view関数をコメントアウトした。
###############################################################################

import base64
import hashlib
import io
import json
import os
import sys

from datetime import date, datetime, timedelta, timezone
from io import BytesIO

### from PIL import Image
import PIL.Image ### Image.open() で Error:type object 'Image' has no attribute 'open'が発生するため import PIL.Image に変更 20240823 O.OKADA

from urllib.parse import quote
from urllib.parse import urlencode

from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.core.files.base import ContentFile
from django.db import connection
from django.db import connections
from django.http import FileResponse
from django.http import JsonResponse
from django.http import HttpResponse
from django.http import HttpResponseNotFound
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404
from django.template import loader
from django.urls import reverse
from django.views import View
from django.views.generic import TemplateView

### reportlab関連
from reportlab.lib import colors
from reportlab.lib.pagesizes import A3
from reportlab.lib.pagesizes import A4
from reportlab.lib.pagesizes import landscape
### from reportlab.lib.pagesizes import letter              ### 20240826 O.OKADA
### from reportlab.lib.pagesizes import portrait            ### 20240826 O.OKADA
### from reportlab.lib.styles import getSampleStyleSheet    ### 20240826 O.OKADA
from reportlab.lib.units import mm

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
### from reportlab.pdfbase.ttfonts import TTFont            ### 20240826 O.OKADA

from reportlab.pdfgen import canvas

from reportlab.platypus import Image
### from reportlab.platypus import Paragraph                ### 20240826 O.OKADA
### from reportlab.platypus import Spacer                   ### 20240826 O.OKADA
from reportlab.platypus import Table
from reportlab.platypus import TableStyle

from .forms import GLOBAL_POST_FORM

from P0000Common.models import USER_PROXY                   ### 0000: マスタデータ_ユーザプロキシ
from P0000Common.models import PROVISIONED_CONFIRMED        ### 0000: 画面制御用コード（暫定値、確報値） ### 2024/11/10 ADD
from P0000Common.models import KEN                          ### 1010: マスタデータ_都道府県              ### 2024/11/10 ADD
from P0000Common.models import CITY                         ### 1020: マスタデータ_市区町村              ### 2024/11/10 ADD
from P0000Common.models import KUIKI

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### 局所定数 暫定値確報値
_PROVISIONED = 'PROVISIONED'
_CONFIRMED = 'CONFIRMED'

### 局所定数 ワークフロー履歴
_PROVISIONED_IPPAN_CITY_UPLOAD = 'PROVISIONED_IPPAN_CITY_UPLOAD'
### _PROVISIONED_IPPAN_CITY_LINKAGE_KUIKI = 'PROVISIONED_IPPAN_CITY_LINKAGE_KUIKI' ### 2024/11/10 comment out
_PROVISIONED_IPPAN_CITY_APPLY = 'PROVISIONED_IPPAN_CITY_APPLY'
_PROVISIONED_IPPAN_CITY_DELETE = 'PROVISIONED_IPPAN_CITY_DELETE'
_PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER = 'PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER'
_PROVISIONED_IPPAN_KEN_APPROVE = 'PROVISIONED_IPPAN_KEN_APPROVE'
_PROVISIONED_IPPAN_KEN_DISAPPROVE = 'PROVISIONED_IPPAN_KEN_DISAPPROVE'
_PROVISIONED_IPPAN_MANAGE_APPROVE = 'PROVISIONED_IPPAN_MANAGE_APPROVE'
_PROVISIONED_IPPAN_MANAGE_DISAPPROVE = 'PROVISIONED_IPPAN_MANAGE_DISAPPROVE'

_CONFIRMED_IPPAN_CITY_UPLOAD = 'CONFIRMED_IPPAN_CITY_UPLOAD'
### _CONFIRMED_IPPAN_CITY_LINKAGE_KUIKI = 'CONFIRMED_IPPAN_CITY_LINKAGE_KUIKI' ### 2024/11/10 comment out
_CONFIRMED_IPPAN_CITY_APPLY = 'CONFIRMED_IPPAN_CITY_APPLY'
_CONFIRMED_IPPAN_CITY_DELETE = 'CONFIRMED_IPPAN_CITY_DELETE'
_CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER = 'CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER'
_CONFIRMED_IPPAN_KEN_APPROVE = 'CONFIRMED_IPPAN_KEN_APPROVE'
_CONFIRMED_IPPAN_KEN_DISAPPROVE = 'CONFIRMED_IPPAN_KEN_DISAPPROVE'
_CONFIRMED_IPPAN_MANAGE_APPROVE = 'CONFIRMED_IPPAN_MANAGE_APPROVE'
_CONFIRMED_IPPAN_MANAGE_DISAPPROVE = 'CONFIRMED_IPPAN_MANAGE_DISAPPROVE'

_PROVISIONED_CHITAN_KEN_UPLOAD = 'PROVISIONED_CHITAN_KEN_UPLOAD'
_PROVISIONED_CHITAN_KEN_APPLY = 'PROVISIONED_CHITAN_KEN_APPLY'
_PROVISIONED_CHITAN_KEN_DELETE = 'PROVISIONED_CHITAN_KEN_DELETE'
_PROVISIONED_CHITAN_MANAGE_APPROVE = 'PROVISIONED_CHITAN_MANAGE_APPROVE'
_PROVISIONED_CHITAN_MANAGE_DISAPPROVE = 'PROVISIONED_CHITAN_MANAGE_DISAPPROVE'

_CONFIRMED_CHITAN_KEN_UPLOAD = 'CONFIRMED_CHITAN_KEN_UPLOAD'
_CONFIRMED_CHITAN_KEN_APPLY = 'CONFIRMED_CHITAN_KEN_APPLY'
_CONFIRMED_CHITAN_KEN_DELETE = 'CONFIRMED_CHITAN_KEN_DELETE'
_CONFIRMED_CHITAN_MANAGE_APPROVE = 'CONFIRMED_CHITAN_MANAGE_APPROVE'
_CONFIRMED_CHITAN_MANAGE_DISAPPROVE = 'CONFIRMED_CHITAN_MANAGE_DISAPPROVE'

_PROVISIONED_HOJO_KEN_UPLOAD = 'PROVISIONED_HOJO_KEN_UPLOAD'
_PROVISIONED_HOJO_KEN_APPLY = 'PROVISIONED_HOJO_KEN_APPLY'
_PROVISIONED_HOJO_KEN_DELETE = 'PROVISIONED_HOJO_KEN_DELETE'
_PROVISIONED_HOJO_MANAGE_APPROVE = 'PROVISIONED_HOJO_MANAGE_APPROVE'
_PROVISIONED_HOJO_MANAGE_DISAPPROVE = 'PROVISIONED_HOJO_MANAGE_DISAPPROVE'

_CONFIRMED_HOJO_KEN_UPLOAD = 'CONFIRMED_HOJO_KEN_UPLOAD'
_CONFIRMED_HOJO_KEN_APPLY = 'CONFIRMED_HOJO_KEN_APPLY'
_CONFIRMED_HOJO_KEN_DELETE = 'CONFIRMED_HOJO_KEN_DELETE'
_CONFIRMED_HOJO_MANAGE_APPROVE = 'CONFIRMED_HOJO_MANAGE_APPROVE'
_CONFIRMED_HOJO_MANAGE_DISAPPROVE = 'CONFIRMED_HOJO_MANAGE_DISAPPROVE'

_PROVISIONED_KOEKI_KEN_UPLOAD = 'PROVISIONED_KOEKI_KEN_UPLOAD'
_PROVISIONED_KOEKI_KEN_APPLY = 'PROVISIONED_KOEKI_KEN_APPLY'
_PROVISIONED_KOEKI_KEN_DELETE = 'PROVISIONED_KOEKI_KEN_DELETE'
_PROVISIONED_KOEKI_MANAGE_APPROVE = 'PROVISIONED_KOEKI_MANAGE_APPROVE'
_PROVISIONED_KOEKI_MANAGE_DISAPPROVE = 'PROVISIONED_KOEKI_MANAGE_DISAPPROVE'

_CONFIRMED_KOEKI_KEN_UPLOAD = 'CONFIRMED_KOEKI_KEN_UPLOAD'
_CONFIRMED_KOEKI_KEN_APPLY = 'CONFIRMED_KOEKI_KEN_APPLY'
_CONFIRMED_KOEKI_KEN_DELETE = 'CONFIRMED_KOEKI_KEN_DELETE'
_CONFIRMED_KOEKI_MANAGE_APPROVE = 'CONFIRMED_KOEKI_MANAGE_APPROVE'
_CONFIRMED_KOEKI_MANAGE_DISAPPROVE = 'CONFIRMED_KOEKI_MANAGE_DISAPPROVE'

### _KUIKI_CITY_UPLOAD = 'KUIKI_CITY_UPLOAD' ### 2024/11/10 comment out
### _KUIKI_CITY_DELETE = 'KUIKI_CITY_DELETE' ### 2024/11/10 comment out

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def custom_decorator(arg1):

    def outer_wrapper(view_func):
        
        def inner_wrapper(request, *args, **kwargs):
            try:
                reset_log()
                print_log('[DEBUG] P0500Gui.custom_decorator()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
                print_log('[DEBUG] P0500Gui.custom_decorator()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
                print_log('[DEBUG] P0500Gui.custom_decorator()関数 arg1={}'.format(arg1), 'DEBUG')
                PARAMS_SELECT_USER_PROXY = dict({
                    'USERNAME': str(request.user), 
                    'ROLE_CODE': _ROLE_CITY
                })
                SQL_SELECT_USER_PROXY = """
                    SELECT 
                        P1.ID, 
                        A1.USERNAME, 
                        P1.ROLE_CODE, 
                        P1.KEN_CODE, 
                        P1.CITY_CODE, 
                        K1.KEN_NAME, 
                        C1.CITY_NAME 
                    FROM USER_PROXY P1 
                    LEFT JOIN (
                        SELECT 
                            * 
                        FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                    LEFT JOIN (
                        SELECT 
                            *
                        FROM KEN) K1 ON P1.KEN_CODE=K1.KEN_CODE
                    LEFT JOIN (
                        SELECT
                            *
                        FROM CITY) C1 ON P1.CITY_CODE=C1.CITY_CODE
                    WHERE 
                        A1.USERNAME=%(USERNAME)s AND 
                        P1.ROLE_CODE=%(ROLE_CODE)s"""
                SQL_SELECT_PROVISIONED_CONFIRMED = """
                    SELECT 
                        *
                    FROM PROVISIONED_CONFIRMED"""
                ### decoratorでビュー関数に変数を返す方法が不明のため、グローバル変数を使用した。
                global user_proxy_list
                global provisioned_confirmed_list
                user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
                provisioned_confirmed_list = PROVISIONED_CONFIRMED.objects.raw(SQL_SELECT_PROVISIONED_CONFIRMED)
        
                print_log('[DEBUG] P0500Gui.custom_decorator()関数 user_proxy_list={}'.format(user_proxy_list), 'DEBUG')
                print_log('[DEBUG] P0500Gui.custom_decorator()関数 len(user_proxy_list)={}'.format(len(user_proxy_list)), 'DEBUG')
                print_log('[DEBUG] P0500Gui.custom_decorator()関数 provisioned_confirmed_list={}'.format(provisioned_confirmed_list), 'DEBUG')
                print_log('[DEBUG] P0500Gui.custom_decorator()関数 len(provisioned_confirmed_list)={}'.format(len(provisioned_confirmed_list)), 'DEBUG')
                    
                ### デコレータの処理で警告が発生したら（user_proxy_listが正常に取得できなかったら）、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                if (user_proxy_list == False) or (
                    user_proxy_list == True and user_proxy_list[0].city_code == False):
                    print_log('[WARN] P0500Gui.custom_decorator()関数が警告終了しました。', 'WARN')
                    if (arg1 == 'editor_view') or (
                        arg1 == 'upload_temp_kml'):
                        template = loader.get_template('P0500Gui/editor/editor.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'printout_view') or (
                          arg1 == 'upload_canvas') or (
                          arg1 == 'upload_png') or (
                          arg1 == 'download_kml') or (
                          arg1 == 'download_pdf'):
                        template = loader.get_template('P0500Gui/printout/printout.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                
                ### ここまで正常に処理できたら、ビュー関数を戻して、ビュー関数の処理に移行する。
                return view_func(request, *args, **kwargs)
            
            except:
                ### デコレータの処理で異常が発生したら、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                print_log('[ERROR] P0500Gui.custom_decorator()関数が異常終了しました。', 'ERROR')
                if (arg1 == 'editor_view') or (
                    arg1 == 'upload_temp_kml'):
                    template = loader.get_template('P0500Gui/editor/editor.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'printout_view') or (
                      arg1 == 'upload_canvas') or (
                      arg1 == 'upload_png') or (
                      arg1 == 'download_kml') or (
                      arg1 == 'download_pdf'):
                    template = loader.get_template('P0500Gui/printout/printout.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
        
        return inner_wrapper
            
    return outer_wrapper

###############################################################################
### 「水害区域図様式出力画面」で「水害区域図作成画面へ戻るボタン」クリック時に呼ばれる
### GET時、「水害区域図作成画面（editor.html）」を戻す。
### POST時、リクエストに含まれている情報をコンテキストにコピーして、「水害区域図作成画面（editor.html）」を戻す。
### urlpattern：path('editor/', views.editor_view, name='editor_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='editor_view')
def editor_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0500GUI.editor_view()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0500GUI.editor_view()関数 request.method={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0500GUI.editor_view()関数 request.headers={}'.format(request.headers), 'DEBUG')
        print_log('[DEBUG] P0500GUI.editor_view()関数 request.body={}'.format(request.body), 'DEBUG')

        if request.method == 'GET':
            
            ###################################################################
            ### 【正常】レスポンスセット処理(0020)
            ### ※ネストを浅くするため、GETの場合、ここでレスポンスを戻す。
            ###################################################################
            print_log('[DEBUG] P0500GUI.editor_view()関数 STEP 2/5.', 'DEBUG')
            return render(request, 'P0500GUI/editor/editor.html')
        
        elif request.method == 'POST':
            
            ###################################################################
            ### POSTリクエスト読み込み処理(0030)
            ###################################################################
            print_log('[DEBUG] P0500GUI.editor_view()関数 STEP 3/5.', 'DEBUG')
            params = {
                'g_kuiki_id': request.POST.get('g_kuiki_id', ''),
                ### 'g_ken_code': request.POST.get('g_ken_code', ''),   ### 2024/11/10 comment out
                ### 'g_city_code': request.POST.get('g_city_code', ''), ### 2024/11/10 comment out
                'g_kuiki_code1': request.POST.get('g_kuiki_code1', ''),
                'g_kuiki_code2': request.POST.get('g_kuiki_code2', ''),
                ### 'g_ken_name': request.POST.get('g_ken_name', ''),   ### 2024/11/10 comment out
                ### 'g_city_name': request.POST.get('g_city_name', ''), ### 2024/11/10 comment out
                'g_scale': request.POST.get('g_scale', ''),
                'g_branch_code1': request.POST.get('g_branch_code1', ''),
                'g_branch_code2': request.POST.get('g_branch_code2', ''),
                'g_year1': request.POST.get('g_year1', ''),
                'g_month1': request.POST.get('g_month1', ''),
                'g_day1': request.POST.get('g_day1', ''),
                'g_year2': request.POST.get('g_year2', ''),
                'g_month2': request.POST.get('g_month2', ''),
                'g_day2': request.POST.get('g_day2', ''),
                'g_abnormal_name': request.POST.get('g_abnormal_name', ''),
                'g_remark': request.POST.get('g_remark', ''),
                ### 'g_kml_data': request.POST.get('g_kml_data', ''), ### 2024/11/20 COMMENT OUT AWS環境で403 Forbiddenエラーが発生するため、原因の文字列を空に変換したことへの対応。※2024/11/25デモ用の応急処置。
                'g_kml_data': '<kml xmlns="http://earth.google.com/kml/2.0">' + request.POST.get('g_kml_data', '') + '</kml>', ### 2024/11/20 ADD
                'g_zoom': request.POST.get('g_zoom', ''),
                'g_print_size': request.POST.get('g_print_size', ''),
                'g_orientation': request.POST.get('g_orientation', ''),
            }
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_kuiki_id)={}'.format(request.POST.get('g_kuiki_id')), 'DEBUG')
            ### print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_ken_code)={}'.format(request.POST.get('g_ken_code')), 'DEBUG')   ### 2024/11/10 comment out
            ### print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_city_code)={}'.format(request.POST.get('g_city_code')), 'DEBUG') ### 2024/11/10 comment out
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_kuiki_code1)={}'.format(request.POST.get('g_kuiki_code1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_kuiki_code2)={}'.format(request.POST.get('g_kuiki_code2')), 'DEBUG')
            ### print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_ken_name)={}'.format(request.POST.get('g_ken_name')), 'DEBUG')   ### 2024/11/10 comment out
            ### print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_city_name)={}'.format(request.POST.get('g_city_name')), 'DEBUG') ### 2024/11/10 comment out
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_scale)={}'.format(request.POST.get('g_scale')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_branch_code1)={}'.format(request.POST.get('g_branch_code1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_branch_code2)={}'.format(request.POST.get('g_branch_code2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_year1)={}'.format(request.POST.get('g_year1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_month1)={}'.format(request.POST.get('g_month1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_day1)={}'.format(request.POST.get('g_day1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_year2)={}'.format(request.POST.get('g_year2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_month2)={}'.format(request.POST.get('g_month2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_day2)={}'.format(request.POST.get('g_day2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_abnormal_name)={}'.format(request.POST.get('g_abnormal_name')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_remark)={}'.format(request.POST.get('g_remark')), 'DEBUG')
            ### print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_kml_data)={}'.format(request.POST.get('g_kml_data')), 'DEBUG') ### 2024/11/20 COMMENT OUT
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_kml_data)={}'.format('<kml xmlns="http://earth.google.com/kml/2.0">' + request.POST.get('g_kml_data') + '</kml>'), 'DEBUG') ### 2024/11/20 ADD
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_zoom)={}'.format(request.POST.get('g_zoom')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_print_size)={}'.format(request.POST.get('g_print_size')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.editor_view()関数 request.POST.get(g_orientation)={}'.format(request.POST.get('g_orientation')), 'DEBUG')
    
            ###################################################################
            ### フォームセット処理(0040)
            ###################################################################
            print_log('[DEBUG] P0500GUI.editor_view()関数 STEP 4/5.', 'DEBUG')
            global_post_form = GLOBAL_POST_FORM()
            global_post_form.fields['g_kuiki_id'].initial = params['g_kuiki_id']
            ### global_post_form.fields['g_ken_code'].initial = params['g_ken_code']   ### 2024/11/10 comment out
            ### global_post_form.fields['g_city_code'].initial = params['g_city_code'] ### 2024/11/10 comment out
            global_post_form.fields['g_kuiki_code1'].initial = params['g_kuiki_code1']
            global_post_form.fields['g_kuiki_code2'].initial = params['g_kuiki_code2']
            ### global_post_form.fields['g_ken_name'].initial = params['g_ken_name']   ### 2024/11/10 comment out
            ### global_post_form.fields['g_city_name'].initial = params['g_city_name'] ### 2024/11/10 comment out
            global_post_form.fields['g_scale'].initial = params['g_scale']
            global_post_form.fields['g_branch_code1'].initial = params['g_branch_code1']
            global_post_form.fields['g_branch_code2'].initial = params['g_branch_code2']
            global_post_form.fields['g_year1'].initial = params['g_year1']
            global_post_form.fields['g_month1'].initial = params['g_month1']
            global_post_form.fields['g_day1'].initial = params['g_day1']
            global_post_form.fields['g_year2'].initial = params['g_year2']
            global_post_form.fields['g_month2'].initial = params['g_month2']
            global_post_form.fields['g_day2'].initial = params['g_day2']
            global_post_form.fields['g_abnormal_name'].initial = params['g_abnormal_name']
            global_post_form.fields['g_remark'].initial = params['g_remark']
            global_post_form.fields['g_kml_data'].initial = params['g_kml_data']
            global_post_form.fields['g_zoom'].initial = params['g_zoom']
            global_post_form.fields['g_print_size'].initial = params['g_print_size']
            global_post_form.fields['g_orientation'].initial = params['g_orientation']
    
            ###################################################################
            ### 【正常】レスポンスセット処理(0050)
            ###################################################################
            print_log('[DEBUG] P0500GUI.editor_view()関数 STEP 5/5.', 'DEBUG')
            context = {
                'global_post_form': global_post_form,
                'g_kuiki_id': params['g_kuiki_id'],
                ### 'g_ken_code': params['g_ken_code'],   ### 2024/11/10 comment out
                ### 'g_city_code': params['g_city_code'], ### 2024/11/10 comment out
                'g_kuiki_code1': params['g_kuiki_code1'],
                'g_kuiki_code2': params['g_kuiki_code2'],
                ### 'g_ken_name': params['g_ken_name'],   ### 2024/11/10 comment out
                ### 'g_city_name': params['g_city_name'], ### 2024/11/10 comment out
                'g_scale': params['g_scale'],
                'g_branch_code1': params['g_branch_code1'],
                'g_branch_code2': params['g_branch_code2'],
                'g_year1': params['g_year1'],
                'g_month1': params['g_month1'],
                'g_day1': params['g_day1'],
                'g_year2': params['g_year2'],
                'g_month2': params['g_month2'],
                'g_day2': params['g_day2'],
                'g_abnormal_name': params['g_abnormal_name'],
                'g_remark': params['g_remark'],
                'g_kml_data': params['g_kml_data'],
                'g_zoom': params['g_zoom'],
                'g_orientation': params['g_orientation'],
                'g_print_size': params['g_print_size'],
            }
            return render(request, 'P0500GUI/editor/editor.html', context)
        
    except:
        print_log('[ERROR] P0500GUI.editor_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0500GUI.editor_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0500GUI.editor_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0500GUI/editor/editor.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 「水害区域図作成画面」で「貼付用紙作成・様式出力ボタン」クリック時に呼ばれる。
### GET時、「水害区域図様式出力画面（printout.html）」を戻す。
### POST時、リクエストに含まれる情報をコンテキストにコピーして、「水害区域図様式出力画面（printout.html）」を戻す。
### urlpattern：path('printout/', views.printout_view, name='printout_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='printout_view')
def printout_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0500GUI.printout_view()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0500GUI.printout_view()関数 request.method={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0500GUI.printout_view()関数 request.headers={}'.format(request.headers), 'DEBUG')
        print_log('[DEBUG] P0500GUI.printout_view()関数 request.body={}'.format(request.body), 'DEBUG')

        if request.method == 'GET':
    
            ###################################################################
            ### 【正常】レスポンスセット処理(0020)
            ### ※ネストを浅くするため、GETの場合、ここでレスポンスを戻す。
            ###################################################################
            print_log('[DEBUG] P0500GUI.printout_view()関数 STEP 2/5.', 'DEBUG')
            return render(request, 'P0500GUI/printout/printout.html')
        
        elif request.method == 'POST':
            
            ###################################################################
            ### POSTリクエスト読み込み処理(0030)
            ###################################################################
            print_log('[DEBUG] P0500GUI.printout_view()関数 STEP 3/5.', 'DEBUG')
            params = {
                'g_kuiki_id': request.POST.get('g_kuiki_id', ''),
                ### 'g_ken_code': request.POST.get('g_ken_code', ''),   ### 2024/11/10 comment out
                ### 'g_city_code': request.POST.get('g_city_code', ''), ### 2024/11/10 comment out
                'g_kuiki_code1': request.POST.get('g_kuiki_code1', ''),
                'g_kuiki_code2': request.POST.get('g_kuiki_code2', ''),
                ### 'g_ken_name': request.POST.get('g_ken_name', ''),   ### 2024/11/10 comment out
                ### 'g_city_name': request.POST.get('g_city_name', ''), ### 2024/11/10 comment out
                'g_scale': request.POST.get('g_scale', ''),
                'g_branch_code1': request.POST.get('g_branch_code1', ''),
                'g_branch_code2': request.POST.get('g_branch_code2', ''),
                'g_year1': request.POST.get('g_year1', ''),
                'g_month1': request.POST.get('g_month1', ''),
                'g_day1': request.POST.get('g_day1', ''),
                'g_year2': request.POST.get('g_year2', ''),
                'g_month2': request.POST.get('g_month2', ''),
                'g_day2': request.POST.get('g_day2', ''),
                'g_abnormal_name': request.POST.get('g_abnormal_name', ''),
                'g_remark': request.POST.get('g_remark', ''),
                ### 'g_kml_data': request.POST.get('g_kml_data', ''), ### 2024/11/20 COMMENT OUT AWS環境で403 Forbiddenエラーが発生するため、原因の文字列を空に変換したことへの対応。※2024/11/25デモ用の応急処置。
                'g_kml_data': '<kml xmlns="http://earth.google.com/kml/2.0">' + request.POST.get('g_kml_data', '') + '</kml>', ### 2024/11/20 ADD
                'g_zoom': request.POST.get('g_zoom', ''),
                'g_print_size': request.POST.get('g_print_size', ''),
                'g_orientation': request.POST.get('g_orientation', ''),
            }
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_kuiki_id)={}'.format(request.POST.get('g_kuiki_id')), 'DEBUG')
            ### print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_ken_code)={}'.format(request.POST.get('g_ken_code')), 'DEBUG')   ### 2024/11/10 comment out
            ### print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_city_code)={}'.format(request.POST.get('g_city_code')), 'DEBUG') ### 2024/11/10 comment out
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_kuiki_code1)={}'.format(request.POST.get('g_kuiki_code1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_kuiki_code2)={}'.format(request.POST.get('g_kuiki_code2')), 'DEBUG')
            ### print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_ken_name)={}'.format(request.POST.get('g_ken_name')), 'DEBUG')   ### 2024/11/10 comment out
            ### print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_city_name)={}'.format(request.POST.get('g_city_name')), 'DEBUG') ### 2024/11/10 comment out
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_scale)={}'.format(request.POST.get('g_scale')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_branch_code1)={}'.format(request.POST.get('g_branch_code1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_branch_code2)={}'.format(request.POST.get('g_branch_code2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_year1)={}'.format(request.POST.get('g_year1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_month1)={}'.format(request.POST.get('g_month1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_day1)={}'.format(request.POST.get('g_day1')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_year2)={}'.format(request.POST.get('g_year2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_month2)={}'.format(request.POST.get('g_month2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_day2)={}'.format(request.POST.get('g_day2')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_abnormal_name)={}'.format(request.POST.get('g_abnormal_name')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_remark)={}'.format(request.POST.get('g_remark')), 'DEBUG')
            ### print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_kml_data)={}'.format(request.POST.get('g_kml_data')), 'DEBUG') ### 2024/11/20 COMMENT OUT
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_kml_data)={}'.format('<kml xmlns="http://earth.google.com/kml/2.0">' + request.POST.get('g_kml_data') + '</kml>'), 'DEBUG') ### 2024/11/20 ADD
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_zoom)={}'.format(request.POST.get('g_zoom')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_print_size)={}'.format(request.POST.get('g_print_size')), 'DEBUG')
            print_log('[DEBUG] P0500GUI.printout_view()関数 request.POST.get(g_orientation)={}'.format(request.POST.get('g_orientation')), 'DEBUG')
    
            ###################################################################
            ### フォームセット処理(0040)
            ###################################################################
            print_log('[DEBUG] P0500GUI.printout_view()関数 STEP 4/5.', 'DEBUG')
            global_post_form = GLOBAL_POST_FORM()
            global_post_form.fields['g_kuiki_id'].initial = params['g_kuiki_id']
            ### global_post_form.fields['g_ken_code'].initial = params['g_ken_code']   ### 2024/11/10 comment out
            ### global_post_form.fields['g_city_code'].initial = params['g_city_code'] ### 2024/11/10 comment out
            global_post_form.fields['g_kuiki_code1'].initial = params['g_kuiki_code1']
            global_post_form.fields['g_kuiki_code2'].initial = params['g_kuiki_code2']
            ### global_post_form.fields['g_ken_name'].initial = params['g_ken_name']   ### 2024/11/10 comment out
            ### global_post_form.fields['g_city_name'].initial = params['g_city_name'] ### 2024/11/10 comment out
            ### global_post_form.fields['g_scale'].initial = int(params['g_scale']) if params['g_scale'] else None
            global_post_form.fields['g_scale'].initial = params['g_scale']
            global_post_form.fields['g_branch_code1'].initial = params['g_branch_code1']
            global_post_form.fields['g_branch_code2'].initial = params['g_branch_code2']
            global_post_form.fields['g_year1'].initial = params['g_year1']
            global_post_form.fields['g_month1'].initial = params['g_month1']
            global_post_form.fields['g_day1'].initial = params['g_day1']
            global_post_form.fields['g_year2'].initial = params['g_year2']
            global_post_form.fields['g_month2'].initial = params['g_month2']
            global_post_form.fields['g_day2'].initial = params['g_day2']
            global_post_form.fields['g_abnormal_name'].initial = params['g_abnormal_name']
            global_post_form.fields['g_remark'].initial = params['g_remark']
            global_post_form.fields['g_kml_data'].initial = params['g_kml_data']
            global_post_form.fields['g_zoom'].initial = params['g_zoom']
            global_post_form.fields['g_print_size'].initial = params['g_print_size']
            global_post_form.fields['g_orientation'].initial = params['g_orientation']
    
            ###################################################################
            ### 【正常】レスポンスセット処理(0050)
            ###################################################################
            print_log('[DEBUG] P0500GUI.printout_view()関数 STEP 5/5.', 'DEBUG')
            context = {
                'global_post_form': global_post_form,
                'g_kuiki_id': params['g_kuiki_id'],
                ### 'g_ken_code': params['g_ken_code'],   ### 2024/11/10 comment out
                ### 'g_city_code': params['g_city_code'], ### 2024/11/10 comment out
                'g_kuiki_code1': params['g_kuiki_code1'],
                'g_kuiki_code2': params['g_kuiki_code2'],
                ### 'g_ken_name': params['g_ken_name'],   ### 2024/11/10 comment out
                ### 'g_city_name': params['g_city_name'], ### 2024/11/10 comment out
                'g_scale': params['g_scale'],
                'g_branch_code1': params['g_branch_code1'],
                'g_branch_code2': params['g_branch_code2'],
                'g_year1': params['g_year1'],
                'g_month1': params['g_month1'],
                'g_day1': params['g_day1'],
                'g_year2': params['g_year2'],
                'g_month2': params['g_month2'],
                'g_day2': params['g_day2'],
                'g_abnormal_name': params['g_abnormal_name'],
                'g_remark': params['g_remark'],
                'g_kml_data': params['g_kml_data'],
                'g_zoom': params['g_zoom'],
                'g_orientation': params['g_orientation'],
                'g_print_size': params['g_print_size'],
                'ken_code': user_proxy_list[0].ken_code,   ### 2024/11/10 add
                'city_code': user_proxy_list[0].city_code, ### 2024/11/10 add
                'ken_name': user_proxy_list[0].ken_name,   ### 2024/11/10 add
                'city_name': user_proxy_list[0].city_name, ### 2024/11/10 add
            }
            return render(request, 'P0500GUI/printout/printout.html', context)
    
    except:
        print_log('[ERROR] P0500GUI.printout_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0500GUI.printout_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0500GUI.printout_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0500GUI/printout/printout.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 「水害区域図作成画面」で「一時保存ファイルの読込ボタン」クリック時に呼ばれる。
### GET時、「一時保存ファイル用非表示画面（temp_kml.html）」を戻す。
### POST時、リクエストに含まれている情報をコンテキストにコピーして、「一時保存ファイル用非表示画面（temp_kml.html）」を戻す。
### urlpattern：path('editor/upload_temp_kml/', views.upload_temp_kml, name='upload_temp_kml')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='upload_temp_kml')
def upload_temp_kml(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 request.method={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 request.headers={}'.format(request.headers), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 request.body={}'.format(request.body), 'DEBUG')

        if request.method == 'GET':
            
            ###################################################################
            ### 【正常】レスポンスセット処理(0020)
            ### ※ネストを浅くするため、GETの場合、ここでレスポンスを戻す。
            ###################################################################
            print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 STEP 2/6.', 'DEBUG')
            return render(request, 'P0500GUI/editor/kml_loader.html')
        
        elif request.method == 'POST':
            
            ###################################################################
            ### POSTリクエスト読み込み処理(0030)
            ###################################################################
            print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 STEP 3/6.', 'DEBUG')
            temp_kml_file = request.FILES.get('lKMLFilePath')
    
            if temp_kml_file:
                
                ###############################################################
                ### KMLファイル読み込みデコード処理(0040)
                ###############################################################
                print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 STEP 4/6.', 'DEBUG')
                try:
                    temp_kml_data = temp_kml_file.read().decode('utf-8')
                except UnicodeDecodeError:
                    context = {
                        'errmsg': "KMLファイルが読み取れません"
                    }
                    return render(request, 'P0500GUI/editor/kml_loader.html', context)
    
                ###############################################################
                ### 【正常】レスポンスセット処理(0050)
                ###############################################################
                print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 STEP 5/6.', 'DEBUG')
                context ={
                    'temp_kml_data': temp_kml_data
                }
                return render(request, 'P0500GUI/editor/kml_loader.html', context)
            
            else:
                
                ###############################################################
                ### 【警告】レスポンスセット処理(0060)
                ###############################################################
                print_log('[DEBUG] P0500GUI.upload_temp_kml()関数 STEP 6/6.', 'DEBUG')
                context = {
                    'errmsg': "KMLファイルが読み取れません"
                }
                return render(request, 'P0500GUI/editor/kml_loader.html', context)
    
    except:
        print_log('[ERROR] P0500GUI.upload_temp_kml()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0500GUI.upload_temp_kml()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0500GUI.upload_temp_kml()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0500GUI/editor/kml_loader.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 「水害区域図様式出力画面」で「様式および作図情報の出力ボタン」クリック時に呼ばれる。（第１ステップ）
### GET時、異常メッセージをコンテキストとして、「水害区域図様式出力画面（printout.html）」を戻す。
### POST時、リクエストに含まれる地図画像を一時ディレクトリに保存して、ファイル名をJSON形式で戻す。
### urlpattern：path('printout/upload_canvas/', views.upload_canvas, name='upload_canvas')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='upload_canvas')
def upload_canvas(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 request.method={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 request.headers={}'.format(request.headers), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 request.body={}'.format(request.body), 'DEBUG')
        
        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        ### ※ネストを浅くするため、警告ケースの場合、ここでレスポンスを戻す。
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 STEP 2/5.', 'DEBUG')
        if request.method != 'POST':
            print_log('[WARN] P0500GUI.upload_canvas()関数が異常終了しました。', 'WARN')
            template = loader.get_template('P0500GUI/printout/printout.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
            
        #######################################################################
        ### ディレクトリ生成処理(0030)
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 STEP 3/5.', 'DEBUG')
        image_data = request.body
        cache_dir = os.path.join(settings.MEDIA_ROOT, 'temp_images')
        os.makedirs(cache_dir, exist_ok=True)

        #######################################################################
        ### ファイル保存処理(0040)
        ### アップロードされた地図プレビューCANVASのPNG画像を一時ディレクトリに保存する
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 STEP 4/5.', 'DEBUG')
        temp_file_name = "captured_image_map.png"
        file_path = os.path.join(cache_dir, temp_file_name)

        with open(file_path, 'wb') as f:
            f.write(image_data)

        #######################################################################
        ### 【正常】レスポンスセット処理(0050)
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_canvas()関数 STEP 5/5.', 'DEBUG')
        response_data = {'file_path': 'temp_images/captured_image_map.png'}
        return JsonResponse(response_data, content_type='application/json')
        
    except:
        print_log('[ERROR] P0500GUI.upload_canvas()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0500GUI.upload_canvas()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0500GUI.upload_canvas()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0500GUI/printout/printout.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 「水害区域図様式出力画面」で「様式および作図情報の出力ボタン」クリック時に呼ばれる。（第２ステップ）
### GET時、異常メッセージをコンテキストとして、「水害区域図様式出力画面（printout.html）」を戻す。
### POST時、フォーム無効時、警告メッセージをJSON形式で戻す。
### POST時、フォーム正常時、地図画像ファイルからPDFデータを作成して、作図情報、PDFデータ、KMLテキストをKUIKIテーブルに登録する。
### urlpattern：path('printout/upload_png/', views.upload_png, name='upload_png')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='upload_png')
def upload_png(request):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 1/8.', 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 request.method={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 request.headers={}'.format(request.headers), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 request.body={}'.format(request.body), 'DEBUG')

        #######################################################################
        ### 【異常】レスポンスセット処理(0020)
        ### ※ネストを浅くするため、異常ケースの場合、ここでレスポンスを戻す。
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 2/8.', 'DEBUG')
        if request.method != 'POST':
            print_log('[ERROR] P0500GUI.upload_png()関数が異常終了しました。', 'ERROR')
            template = loader.get_template('P0500GUI/printout/printout.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### 【警告】レスポンスセット処理(0030)
        ### ※ネストを浅くするため、警告ケースの場合、ここでレスポンスを戻す。
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 3/8.', 'DEBUG')
        global_post_form = GLOBAL_POST_FORM(request.POST)
        if global_post_form.is_valid() == False:
            print_log('[WARN] P0500GUI.upload_png()関数が警告終了しました。', 'WARN')
            print_log('[WARN] P0500GUI.upload_png()関数 global_post_form.errors={}'.format(global_post_form.errors), 'WARN')
            response_data = {
                'status': 'error',
                'message': 'フォームが無効です。',
                'errors': global_post_form.errors,
            }
            return JsonResponse(response_data)

        #######################################################################
        ### 内部変数セット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 4/8.', 'DEBUG')
        g_kuiki_id = request.POST.get('g_kuiki_id')
        params = {
            'g_kuiki_id': global_post_form.cleaned_data['g_kuiki_id'],
            ### 'g_ken_code': global_post_form.cleaned_data['g_ken_code'],   ### 2024/11/10 comment out
            ### 'g_city_code': global_post_form.cleaned_data['g_city_code'], ### 2024/11/10 comment out
            'g_kuiki_code1': global_post_form.cleaned_data['g_kuiki_code1'],
            'g_kuiki_code2': global_post_form.cleaned_data['g_kuiki_code2'],
            ### 'g_ken_name': global_post_form.cleaned_data['g_ken_name'],   ### 2024/11/10 comment out
            ### 'g_city_name': global_post_form.cleaned_data['g_city_name'], ### 2024/11/10 comment out
            'g_scale': global_post_form.cleaned_data['g_scale'],
            'g_branch_code1': global_post_form.cleaned_data['g_branch_code1'],
            'g_branch_code2': global_post_form.cleaned_data['g_branch_code2'],
            'g_year1': global_post_form.cleaned_data['g_year1'],
            'g_month1': global_post_form.cleaned_data['g_month1'],
            'g_day1': global_post_form.cleaned_data['g_day1'],
            'g_year2': global_post_form.cleaned_data['g_year2'],
            'g_month2': global_post_form.cleaned_data['g_month2'],
            'g_day2': global_post_form.cleaned_data['g_day2'],
            'g_abnormal_name': global_post_form.cleaned_data['g_abnormal_name'],
            'g_remark': global_post_form.cleaned_data['g_remark'],
            'g_kml_data': global_post_form.cleaned_data['g_kml_data'],
            'g_zoom': global_post_form.cleaned_data['g_zoom'],
            'g_orientation': global_post_form.cleaned_data['g_orientation'],
            'g_print_size': global_post_form.cleaned_data['g_print_size'],
            'ken_code': str(user_proxy_list[0].ken_code),   ### 2024/11/10 add
            'city_code': str(user_proxy_list[0].city_code)[2, 5], ### 2024/11/10 add
            'ken_name': user_proxy_list[0].ken_name,   ### 2024/11/10 add
            'city_name': user_proxy_list[0].city_name, ### 2024/11/10 add
        }
        print_log('[DEBUG] P0500GUI.upload_png()関数 request.POST.get(g_kuiki_id)={}'.format(request.POST.get('g_kuiki_id')), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_kuiki_id]={}'.format(global_post_form.cleaned_data['g_kuiki_id']), 'DEBUG')
        ### print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_ken_code]={}'.format(global_post_form.cleaned_data['g_ken_code']), 'DEBUG')   ### 2024/11/10 comment out
        ### print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_city_code]={}'.format(global_post_form.cleaned_data['g_city_code']), 'DEBUG') ### 2024/11/10 comment out
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_kuiki_code1]={}'.format(global_post_form.cleaned_data['g_kuiki_code1']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_kuiki_code2]={}'.format(global_post_form.cleaned_data['g_kuiki_code2']), 'DEBUG')
        ### print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_ken_name]={}'.format(global_post_form.cleaned_data['g_ken_name']), 'DEBUG')   ### 2024/11/10 comment out
        ### print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_city_name]={}'.format(global_post_form.cleaned_data['g_city_name']), 'DEBUG') ### 2024/11/10 comment out
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_scale]={}'.format(global_post_form.cleaned_data['g_scale']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_branch_code1]={}'.format(global_post_form.cleaned_data['g_branch_code1']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_branch_code2]={}'.format(global_post_form.cleaned_data['g_branch_code2']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_year1]={}'.format(global_post_form.cleaned_data['g_year1']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_month1]={}'.format(global_post_form.cleaned_data['g_month1']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_day1]={}'.format(global_post_form.cleaned_data['g_day1']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_year2]={}'.format(global_post_form.cleaned_data['g_year2']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_month2]={}'.format(global_post_form.cleaned_data['g_month2']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_day2]={}'.format(global_post_form.cleaned_data['g_day2']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_abnormal_name]={}'.format(global_post_form.cleaned_data['g_abnormal_name']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_remark]={}'.format(global_post_form.cleaned_data['g_remark']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_kml_data]={}'.format(global_post_form.cleaned_data['g_kml_data']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_zoom]={}'.format(global_post_form.cleaned_data['g_zoom']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_orientation]={}'.format(global_post_form.cleaned_data['g_orientation']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 global_post_form.cleaned_data[g_print_size]={}'.format(global_post_form.cleaned_data['g_print_size']), 'DEBUG')
        print_log('[DEBUG] P0500GUI.upload_png()関数 ken_code={}'.format(str(user_proxy_list[0].ken_code)), 'DEBUG')   ### 2024/11/10 add
        print_log('[DEBUG] P0500GUI.upload_png()関数 city_code={}'.format(str(user_proxy_list[0].city_code)[2, 5]), 'DEBUG') ### 2024/11/10 add
        print_log('[DEBUG] P0500GUI.upload_png()関数 ken_name={}'.format(user_proxy_list[0].ken_name), 'DEBUG')   ### 2024/11/10 add
        print_log('[DEBUG] P0500GUI.upload_png()関数 city_name={}'.format(user_proxy_list[0].city_name), 'DEBUG') ### 2024/11/10 add
            
        #######################################################################
        ### 内部変数セット処理(0050)
        ### KMLファイル名を設定する。TODO TO-DO TO_DO 2024/11/10
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 5/8.', 'DEBUG')
        ### kml_file_name = f"{str(params['g_year1'])}-{str(params['g_month1']).zfill(2)}{str(params['g_day1']).zfill(2)}-{params['g_ken_code']}-{params['g_city_code']}-{params['g_kuiki_code1']}-{params['g_kuiki_code2']}.kml"
        kml_file_name = f"{str(params['g_year1'])}-{str(params['g_month1']).zfill(2)}{str(params['g_day1']).zfill(2)}-{params['ken_code']}-{params['city_code']}-{params['g_kuiki_code1']}-{params['g_kuiki_code2']}.kml"

        #######################################################################
        ### PDFデータ生成処理(0060)
        ### PDFデータを生成する。TODO TO-DO TO_DO 2024/11/10
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6/8.', 'DEBUG')
        png_file_path = 'temp_images/temp_images/captured_image_map.png'
        ### pdf_file_name = f"{str(params['g_year1'])}-{str(params['g_month1']).zfill(2)}{str(params['g_day1']).zfill(2)}-{params['g_ken_code']}-{params['g_city_code']}-{params['g_kuiki_code1']}-{params['g_kuiki_code2']}.pdf"
        pdf_file_name = f"{str(params['g_year1'])}-{str(params['g_month1']).zfill(2)}{str(params['g_day1']).zfill(2)}-{params['ken_code']}-{params['city_code']}-{params['g_kuiki_code1']}-{params['g_kuiki_code2']}.pdf"
        pdf_data = b''
        pdf_generator = PDF_GENERATOR()

        ### バッファを設定する
        buffer = BytesIO()

        ### ページサイズ、印刷方向を設定する
        page_size_mapping = {
            'A3': A3,
            'A4': A4,
        }
        page_size = page_size_mapping.get(params.get('g_print_size', 'A4'), A4)
        orientation = params.get('g_orientation', '0')

        ### バッファと関連付いたPDFキャンバスを生成する
        ### 印刷方向の分岐（0=縦, 1=横）
        if orientation == 1:
            ### 横向きの場合、ページを回転させる
            pdf_canvas = canvas.Canvas(buffer, pagesize=landscape(page_size))
        
        else:
            ### 縦向きの場合、ページはそのまま
            pdf_canvas = canvas.Canvas(buffer, pagesize=page_size)

        ### PDFキャンバスのタイトルを設定する
        pdf_canvas.setTitle("水害区域図作成支援システム")

        ### PDFキャンバスのフォントを設定する
        pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
        pdf_canvas.setFont('HeiseiKakuGo-W5', 1.5*mm)

        ### PDFキャンバスに画像等を描画する
        ### 印刷サイズと印刷方向で描画パターンを選択する
        ### A3　縦方向
        if page_size == A3 and orientation == 0:
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_1/8.', 'DEBUG')
            pdf_generator.draw_map_vertically_A3(pdf_canvas, png_file_path)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_2/8.', 'DEBUG')
            pdf_generator.draw_legend_vertically_A3(pdf_canvas)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_3/8.', 'DEBUG')
            pdf_generator.draw_form_vertically_A3(pdf_canvas, params)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_4/8.', 'DEBUG')
            pdf_generator.draw_remark_vertically_A3(pdf_canvas, params)

        ### A4 縦方向
        elif page_size == A4 and orientation == 0:
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_5/8.', 'DEBUG')
            pdf_generator.draw_map_vertically_A4(pdf_canvas, png_file_path)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_6/8.', 'DEBUG')
            pdf_generator.draw_legend_vertically_A4(pdf_canvas)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_7/8.', 'DEBUG')
            pdf_generator.draw_form_vertically_A4(pdf_canvas, params)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_8/8.', 'DEBUG')
            pdf_generator.draw_remark_vertically_A4(pdf_canvas, params)

        ### A3 横方向
        elif page_size == A3 and orientation == 1:
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_9/8.', 'DEBUG')
            pdf_generator.draw_map_horizontally_A3(pdf_canvas, png_file_path)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_10/8.', 'DEBUG')
            pdf_generator.draw_legend_horizontally_A3(pdf_canvas)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_11/8.', 'DEBUG')
            pdf_generator.draw_form_horizontally_A3(pdf_canvas, params)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_12/8.', 'DEBUG')
            pdf_generator.draw_remark_horizontally_A3(pdf_canvas, params)

        ### A4　横方向
        elif page_size == A4 and orientation == 1:
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_13/8.', 'DEBUG')
            pdf_generator.draw_map_horizontally_A4(pdf_canvas, png_file_path)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_14/8.', 'DEBUG')
            pdf_generator.draw_legend_horizontally_A4(pdf_canvas)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_15/8.', 'DEBUG')
            pdf_generator.draw_form_horizontally_A4(pdf_canvas, params)
            print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 6_16/8.', 'DEBUG')
            pdf_generator.draw_remark_horizontally_A4(pdf_canvas, params)

        pdf_canvas.save()

        ### バッファから値を取得してPDFデータにセットする
        pdf_data = buffer.getvalue()

        ### バッファを初期化する
        buffer.seek(0)
        buffer.truncate(0)

        #######################################################################
        ### データベースアクセス処理(0070)
        ### 作図情報、PDFデータ、KMLデータをデータベースに登録する。
        ### (1) 二重登録を防止するため、既存レコードの存在をチェックする
        ### (2) 既存レコードが存在している場合、更新する
        ### (3) 既存レコードが存在していない場合、新規作成する TODO TO-DO TO_DO
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 7/8.', 'DEBUG')
        PARAMS_KUIKI = dict({
            'KUIKI_ID': params['g_kuiki_id'],
            'KUIKI_NAME': None,
            ### 'KEN_CODE': params['g_ken_code'],   ### 2024/11/10 comment out
            ### 'CITY_CODE': params['g_city_code'], ### 2024/11/10 comment out
            'KUIKI_CODE1': params['g_kuiki_code1'],
            'KUIKI_CODE2': params['g_kuiki_code2'],
            ### 'KEN_NAME': params['g_ken_name'],   ### 2024/11/10 comment out
            ### 'CITY_NAME': params['g_city_name'], ### 2024/11/10 comment out
            'SCALE': params['g_scale'],
            'BRANCH_CODE1': params['g_branch_code1'],
            'BRANCH_CODE2': params['g_branch_code2'],
            'YEAR1': params['g_year1'],
            'MONTH1': params['g_month1'],
            'DAY1': params['g_day1'],
            'YEAR2': params['g_year2'],
            'MONTH2': params['g_month2'],
            'DAY2': params['g_day2'],
            'ABNORMAL_NAME': params['g_abnormal_name'],
            'REMARK': params['g_remark'],
            'PDF_DATA': pdf_data,
            'PDF_FILE_PATH': None,
            'PDF_FILE_NAME': pdf_file_name,
            'PDF_FILE_SIZE': None,
            'KML_DATA': params['g_kml_data'],
            'KML_FILE_PATH': None,
            'KML_FILE_NAME': kml_file_name,
            'KML_FILE_SIZE': None,
            'ZOOM': params['g_zoom'],
            'ORIENTATION': params['g_orientation'],
            'PRINT_SIZE': params['g_print_size'],
            'DELETED_AT': None,
            'KEN_CODE': user_proxy_list[0].ken_code,
            'CITY_CODE': user_proxy_list[0].city_code,
            'KEN_NAME': user_proxy_list[0].ken_name,
            'CITY_NAME': user_proxy_list[0].city_name,
        })
        SQL_SELECT_KUIKI = """
            SELECT 
                KUIKI_ID 
            FROM KUIKI
            WHERE
                KUIKI_ID=%(KUIKI_ID)s"""
        SQL_SELECT_KUIKI_MAX = """
            SELECT 
                MAX(KUIKI_ID) AS KUIKI_ID
            FROM KUIKI"""
        SQL_INSERT_KUIKI = """
            INSERT INTO KUIKI (
                KUIKI_NAME, KEN_CODE, CITY_CODE, KUIKI_CODE1, KUIKI_CODE2, KEN_NAME, CITY_NAME, SCALE, 
                BRANCH_CODE1, BRANCH_CODE2, YEAR1, MONTH1, DAY1, YEAR2, MONTH2, DAY2, ABNORMAL_NAME, REMARK,
                PDF_DATA, PDF_FILE_PATH, PDF_FILE_NAME, PDF_FILE_SIZE, KML_DATA, KML_FILE_PATH, KML_FILE_NAME, KML_FILE_SIZE,
                ZOOM, ORIENTATION, PRINT_SIZE, COMMITTED_AT, DELETED_AT
            ) VALUES (
                %(KUIKI_NAME)s,
                %(KEN_CODE)s,
                %(CITY_CODE)s,
                %(KUIKI_CODE1)s,
                %(KUIKI_CODE2)s,
                %(KEN_NAME)s,
                %(CITY_NAME)s,
                %(SCALE)s,
                %(BRANCH_CODE1)s,
                %(BRANCH_CODE2)s,
                %(YEAR1)s,
                %(MONTH1)s,
                %(DAY1)s,
                %(YEAR2)s,
                %(MONTH2)s,
                %(DAY2)s,
                %(ABNORMAL_NAME)s,
                %(REMARK)s,
                %(PDF_DATA)s,
                %(PDF_FILE_PATH)s,
                %(PDF_FILE_NAME)s,
                %(PDF_FILE_SIZE)s,
                %(KML_DATA)s,
                %(KML_FILE_PATH)s,
                %(KML_FILE_NAME)s,
                %(KML_FILE_SIZE)s,
                %(ZOOM)s,
                %(ORIENTATION)s,
                %(PRINT_SIZE)s,
                CURRENT_TIMESTAMP, -- COMMITTED_AT
                %(DELETED_AT)s)"""
        SQL_UPDATE_KUIKI = """
            UPDATE KUIKI SET
                KUIKI_NAME=%(KUIKI_NAME)s,
                KEN_CODE=%(KEN_CODE)s,
                CITY_CODE=%(CITY_CODE)s,
                KUIKI_CODE1=%(KUIKI_CODE1)s,
                KUIKI_CODE2=%(KUIKI_CODE2)s,
                KEN_NAME=%(KEN_NAME)s,
                CITY_NAME=%(CITY_NAME)s,
                SCALE=%(SCALE)s,
                BRANCH_CODE1=%(BRANCH_CODE1)s,
                BRANCH_CODE2=%(BRANCH_CODE2)s,
                YEAR1=%(YEAR1)s,
                MONTH1=%(MONTH1)s,
                DAY1=%(DAY1)s,
                YEAR2=%(YEAR2)s,
                MONTH2=%(MONTH2)s,
                DAY2=%(DAY2)s,
                ABNORMAL_NAME=%(ABNORMAL_NAME)s,
                REMARK=%(REMARK)s,
                PDF_DATA=%(PDF_DATA)s,
                PDF_FILE_PATH=%(PDF_FILE_PATH)s,
                PDF_FILE_NAME=%(PDF_FILE_NAME)s,
                PDF_FILE_SIZE=%(PDF_FILE_SIZE)s,
                KML_DATA=%(KML_DATA)s,
                KML_FILE_PATH=%(KML_FILE_PATH)s,
                KML_FILE_NAME=%(KML_FILE_NAME)s,
                KML_FILE_SIZE=%(KML_FILE_SIZE)s,
                ZOOM=%(ZOOM)s,
                ORIENTATION=%(ORIENTATION)s,
                PRINT_SIZE=%(PRINT_SIZE)s,
                COMMITTED_AT=CURRENT_TIMESTAMP, -- COMMITTED_AT
                DELETED_AT=%(DELETED_AT)s                
            WHERE
                KUIKI_ID=%(KUIKI_ID)s"""
        SQL_INSERT_KUIKI_HISTORY = """
            INSERT INTO KUIKI_HISTORY (
                KUIKI_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(KUIKI_ID)s,
                %(KUIKI_CITY_UPLOAD)s,
                CURRENT_TIMESTAMP)"""

        connection_cursor = connection.cursor()
        
        try:
            connection_cursor.execute("""BEGIN""")
            if params['g_kuiki_id'] != 'null':
                kuiki_list = KUIKI.objects.raw(SQL_SELECT_KUIKI, PARAMS_KUIKI)
            else:
                kuiki_list = None
            
            if kuiki_list and len(kuiki_list) > 0:
                connection_cursor.execute(SQL_UPDATE_KUIKI, PARAMS_KUIKI)
            else:
                connection_cursor.execute(SQL_INSERT_KUIKI, PARAMS_KUIKI)
                kuiki_list = KUIKI.objects.raw(SQL_SELECT_KUIKI_MAX)
                
            PARAMS_KUIKI_HISTORY = dict({
                'KUIKI_ID': kuiki_list[0].kuiki_id,
                'KUIKI_CITY_UPLOAD': _KUIKI_CITY_UPLOAD,
            })
                
            connection_cursor.execute(SQL_INSERT_KUIKI_HISTORY, PARAMS_KUIKI_HISTORY)
                
            connection_cursor.execute("""COMMIT""")
            
        except:
            connection_cursor.execute("""ROLLBACK""")

        #######################################################################
        ### 【正常】レスポンスセット処理(0080)
        #######################################################################
        print_log('[DEBUG] P0500GUI.upload_png()関数 STEP 8/8.', 'DEBUG')
        response_data = {
            'status': 'success',
            'message': 'データの保存に成功しました。',
            'kuiki_id': str(kuiki_list[0].kuiki_id),
        }
        return JsonResponse(response_data)

    except:
        ### 異常の場合、HttpResponseでブラウザの画面自体にエラーメッセージを表示させる
        ### 警告の場合、正常終了の場合に合わせてJsonResponseとする
        print_log('[ERROR] P0500GUI.upload_png()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0500GUI.upload_png()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0500GUI.upload_png()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0500GUI/printout/printout.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 「水害区域図様式出力画面」で「KMLダウンロードボタン」クリック時に呼ばれる。
### DBに正しく登録されたことの確認用のため、DBからKMLを取得してブラウザにKMLファイルを戻す。
### GET時、
### POST時、
### urlpattern：path('printout/download_kml/<int:kuiki_id>/', views.download_kml, name='download_kml')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_kml')
def download_kml(request, kuiki_id):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0500GUI.download_kml()関数 request.method={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0500GUI.download_kml()関数 kuiki_id={}'.format(kuiki_id), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 2/5.', 'DEBUG')
        if str(kuiki_id) == 'null':
            print_log('[ERROR] P0500GUI.download_kml()関数が警告終了しました。', 'ERROR')
            return HttpResponseNotFound("")

        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 3/5.', 'DEBUG')
        params = dict({
            'KUIKI_ID': str(kuiki_id),
        })
        kuiki_list = KUIKI.objects.raw("""
            SELECT 
                KUIKI_ID, 
                KML_DATA 
            FROM KUIKI 
            WHERE 
                KUIKI_ID=%(KUIKI_ID)s""", params)

        #######################################################################
        ### ファイル出力処理(0040)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 4/5.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        
        kml_file_path = 'static/tmp/' + str(hash_code) + '/kuiki_' + str(hash_code) + '.kml'
        kml_file_name = 'kuiki' + str(hash_code) + '.kml'
        
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)
        
        print_log('[DEBUG] P0500GUI.download_kml()関数 kuiki_list={}'.format(kuiki_list), 'DEBUG')
        print_log('[DEBUG] P0500GUI.download_kml()関数 len(kuiki_list)={}'.format(len(kuiki_list)), 'DEBUG')
        
        if len(kuiki_list) > 0:
            print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 4_1/5.', 'DEBUG')
            kml_data = kuiki_list[0].kml_data
        else:
            print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 4_2/5.', 'DEBUG')
            kml_data = None
            
        if kml_data:
            print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 4_3/5.', 'DEBUG')
            with open(kml_file_path, 'w') as kml_file:
                kml_file.write(kml_data)
        else:
            print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 4_4/5.', 'DEBUG')
            pass
        
        #######################################################################
        ### 【正常】レスポンスセット処理(0050)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_kml()関数 STEP 5/5.', 'DEBUG')
        response = HttpResponse(content=open(kml_file_path, 'rb').read(), content_type='text/kml')
        response['Content-Disposition'] = 'attachment; filename="test.kml"'
        return response
    
    except:
        print_log('[ERROR] P0500GUI.download_kml()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0500GUI.download_kml()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0500GUI.download_kml()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")
    
###############################################################################
### 「水害区域図様式出力画面」で「PDFダウンロードボタン」クリック時に呼ばれる。
### DBに正しく登録されたことの確認用のため、DBからPDFを取得してブラウザにPDFファイルを戻す。
### GET時、
### POST時、
### urlpattern：path('printout/download_pdf/<int:kuiki_id>/', views.download_pdf, name='download_pdf')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_pdf')
def download_pdf(request, kuiki_id):
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0500GUI.download_pdf()関数 request.method={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0500GUI.download_pdf()関数 kuiki_id={}'.format(kuiki_id), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 2/5.', 'DEBUG')
        if str(kuiki_id) == 'null':
            print_log('[ERROR] P0500GUI.download_pdf()関数が警告終了しました。', 'ERROR')
            return HttpResponseNotFound("")

        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 3/5.', 'DEBUG')
        params = dict({
            'KUIKI_ID': str(kuiki_id),
        })
        kuiki_list = KUIKI.objects.raw("""
            SELECT 
                KUIKI_ID, 
                PDF_DATA 
            FROM KUIKI 
            WHERE 
                KUIKI_ID=%(KUIKI_ID)s""", params)

        #######################################################################
        ### ファイル出力処理(0040)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 4/5.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        pdf_file_path = 'static/tmp/' + str(hash_code) + '/kuiki_' + str(hash_code) + '.pdf'
        pdf_file_name = 'kuiki' + str(hash_code) + '.pdf'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        print_log('[DEBUG] P0500GUI.download_pdf()関数 kuiki_list={}'.format(kuiki_list), 'DEBUG')
        print_log('[DEBUG] P0500GUI.download_pdf()関数 len(kuiki_list)={}'.format(len(kuiki_list)), 'DEBUG')
        
        if len(kuiki_list) > 0:
            print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 4_1/5.', 'DEBUG')
            pdf_data = kuiki_list[0].pdf_data
        else:
            print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 4_2/5.', 'DEBUG')
            pdf_data = None
            
        if pdf_data:
            print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 4_3/5.', 'DEBUG')
            with open(pdf_file_path, 'wb') as pdf_file:
                print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 4_4/5.', 'DEBUG')
                pdf_file.write(pdf_data)
        else:
            print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 4_5/5.', 'DEBUG')
            pass
        
        #######################################################################
        ### 【正常】レスポンスセット処理(0050)
        #######################################################################
        print_log('[DEBUG] P0500GUI.download_pdf()関数 STEP 5/5.', 'DEBUG')
        response = HttpResponse(content=open(pdf_file_path, 'rb').read(), content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="test.pdf"'
        ### response['X-PDFFileName'] = pdf_file_name
        return response
    
    except:
        print_log('[ERROR] P0500GUI.download_pdf()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0500GUI.download_pdf()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0500GUI.download_pdf()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### クラス名：PDF_GENERATOR(View)
### ※便宜的にビュークラスとしているが、類似の関数がバラバラにならないように管理するためのクラスである。
###############################################################################
class PDF_GENERATOR(View):

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_map_vertically_A3(self, p, png_file_path):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 STEP 1/7.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 png_file_path={}'.format(png_file_path), 'DEBUG')
            
            ### A3縦向きの地図描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 STEP 2/7.', 'DEBUG')
            ### img = Image.open(png_file_path) ### Error:type object 'Image' has no attribute 'open'が発生するため 20240823 O.OKADA
            img = PIL.Image.open(png_file_path)
    
            x_offset_map = 48  ### 地図画像情報のx軸座標
            y_offset_map = 160 ### 地図画像情報のy軸座標
           
            ### 画像のサイズを取得
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 STEP 3/7.', 'DEBUG')
            width, height = img.size
    
            ### 拡大（整数に変換）
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 STEP 4/7.', 'DEBUG')
            new_width = int(width * 1.7)
            new_height = int(height * 1.7)
            ### img = img.resize((new_width, new_height), Image.ANTIALIAS) ### Error:type object 'Image' has no attribute 'ANTIALIAS'が発生するため 20240823 O.OKADA
            img = img.resize((new_width, new_height), PIL.Image.ANTIALIAS)
    
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 STEP 5/7.', 'DEBUG')
            p.drawInlineImage(img, x_offset_map, y_offset_map)
    
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 STEP 6/7.', 'DEBUG')
            
        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_vertiacally_A3()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_legend_vertically_A3(self, p):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 STEP 1/7.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 p={}'.format(p), 'DEBUG')
            
            ### 凡例情報の描画 (A3縦向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 STEP 2/7.', 'DEBUG')
            x_offset_legend = 163  ### 凡例情報テーブルX軸
            y_offset_legend = 47   ### 凡例情報テーブルY軸
    
            ### 凡例情報のテーブルの描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 STEP 3/7.', 'DEBUG')
            p.rect(x_offset_legend, y_offset_legend, 70*mm, 36*mm)  ### 枠の描画
    
            ### 凡例情報のテキスト
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 STEP 4/7.', 'DEBUG')
            legend_text = """
            凡例
            ■水害区域                               ■水害発生原因
            浸水被害                                    破堤 ×
            土砂被害                                    有堤部溢水 ○
            
            ■                                           浸水・土砂被害 無堤部溢水 △
            地下浸水被害                            土石流、地すべり、急傾斜地崩壊 □
           
            ◆                                           その他 「内水」「窪地内水」
            ■                                           「洗掘・流出」「高潮」「津波」
            ■                                           「波浪」の文字  ■
            
            水害区域番号                         ■氾濫水又は土砂の移動状況
            ①～200                                          ←
            """
    
            ### テキスト描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 STEP 5/7.', 'DEBUG')
            text_object = p.beginText(10 + x_offset_legend, 35*mm + y_offset_legend)  # テキストの開始位置
            text_object.setFont('HeiseiKakuGo-W5', 2*mm)
    
            ### テキストを行ごとに描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 STEP 6/7.', 'DEBUG')
            lines = legend_text.split('\n')
            for line in lines:
                text_object.textLine(line.strip())  ### テキストの描画
    
            p.drawText(text_object)  ### ドキュメントにテキストを描画
            
        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A3()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_form_vertically_A3(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 1/14.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 params={}'.format(params), 'DEBUG')

            ### フォーム情報の描画 (A3縦向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 2/14.', 'DEBUG')
            x_offset_info = 354  ### テーブル描写位置のx座標
            y_offset_info = 115  ### テーブル描写位置のy座標
    
            ### 5つのテーブルのデータ(水害区域図作成図 ) 20240117追加 ### テーブル1から5を高さを合わせて合体する
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 3/14.', 'DEBUG')
            form_table1_data = [
                ["都道府県コード", "市町村コード", "水害区域番号"],
                ### [str(params['gPrefecturalCode']), str(params['gMunicipalityCode']), f"{params['gArea1']} 〜 {params['gArea2']}"],
                ### [str(params['g_ken_code']), str(params['g_city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
                [str(params['ken_code']), str(params['city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
            ]
    
            form_table2_data = [
                ### [f"{params['gPrefecturalName']}　　　{params['gMunicipalityName']}　　　　　水害区域図"],
                ### [f"{params['g_ken_name']}　　　{params['g_city_name']}　　　　　水害区域図"],
                [f"{params['ken_name']}　　　{params['city_name']}　　　　　水害区域図"],
            ]
    
            form_table3_data = [
                ### ["縮尺", f"1/{params['gScale']}", "枝番", f"{params['gBranchSub']}/{params['gBranchAll']}"],
                ["縮尺", f"1/{params['g_scale']}", "枝番", f"{params['g_branch_code1']}/{params['g_branch_code2']}"],
            ]
    
            form_table4_data = [
                ### [f"{params['gYear1']}年 {params['gMonth1']}月 {params['gDay1']}日 〜 {params['gYear2']}年 {params['gMonth2']}月 {params['gDay2']}日"],
                [f"{params['g_year1']}年 {params['g_month1']}月 {params['g_day1']}日 〜 {params['g_year2']}年 {params['g_month2']}月 {params['g_day2']}日"],
            ]
            form_table5_data =[
                ### ["異常気象名", f"{params['gAbnormalName']}"],
                ["異常気象名", f"{params['g_abnormal_name']}"],
            ]
    
            ### テーブル1の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 4/14.', 'DEBUG')
            form_table1 = Table(form_table1_data, colWidths=(15 * mm, 30 * mm, 30 * mm), rowHeights=6 * mm)
            form_table1.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (0, 0), 'HeiseiKakuGo-W5', 1.5 * mm),
                ('FONT', (1, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル1を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 5/14.', 'DEBUG')
            form_table1.wrapOn(p, 0, 0)
            form_table1.drawOn(p, 10 + x_offset_info, y_offset_info)
    
            ### テーブル2の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 6/14.', 'DEBUG')
            form_table2 = Table(form_table2_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table2.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル2を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 7/14.', 'DEBUG')
            form_table2.wrapOn(p, 0, 0)
            form_table2.drawOn(p, 10 + x_offset_info, y_offset_info - 6*mm)
    
            ### テーブル3の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 8/14.', 'DEBUG')
            form_table3 = Table(form_table3_data, colWidths=(15 * mm, 30 * mm, 10 * mm, 20 * mm), rowHeights=6 * mm)
            form_table3.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル3を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 9/14.', 'DEBUG')
            form_table3.wrapOn(p, 0, 0)
            form_table3.drawOn(p, 10 + x_offset_info, y_offset_info - 12*mm)
    
            ### テーブル4の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 10/14.', 'DEBUG')
            form_table4 = Table(form_table4_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table4.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル4を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 11/14.', 'DEBUG')
            form_table4.wrapOn(p, 0, 0)
            form_table4.drawOn(p, 10 + x_offset_info, y_offset_info - 18*mm)
    
            ### テーブル5の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 12/14.', 'DEBUG')
            form_table5 = Table(form_table5_data, colWidths=(20 * mm, 55 * mm), rowHeights=6 * mm)
            form_table5.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル5を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 STEP 13/14.', 'DEBUG')
            form_table5.wrapOn(p, 0, 0)
            form_table5.drawOn(p, 10 + x_offset_info, y_offset_info - 24*mm)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_vertically_A3()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_remark_vertically_A3(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数 STEP 1/4.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数 params={}'.format(params), 'DEBUG')

            ### 備考情報の描画 (A3縦向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数 STEP 2/4.', 'DEBUG')
            x_offset_remark = 580   ### テーブル描写位置のx座標
            y_offset_remark = 47    ### テーブル描写位置のy座標
    
            ### テーブルの描画(備考)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数 STEP 3/4.', 'DEBUG')
            remark_data = [
                ["備考"],
                [f"{params['g_remark']}"],
            ]

            table_style_remark = [
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (0, 0), 'MIDDLE'),
                ('VALIGN', (-1, -1), (-1, -1), 'TOP'),
                ('ALIGN', (0, 0), (0, 0), 'CENTER'),
                ('ALIGN', (-1, -1), (-1, -1), 'LEFT'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3*mm),
            ]

            table = Table(remark_data, style=table_style_remark, colWidths=(70*mm), rowHeights=(5*mm, 31*mm))
            table.wrapOn(p, 0, 0)
            table.drawOn(p, x_offset_remark, y_offset_remark)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A3()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_map_vertically_A4(self, p, png_file_path):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 STEP 1/5.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 png_file_path={}'.format(png_file_path), 'DEBUG')

            ### A4縦向きの地図描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 STEP 2/5.', 'DEBUG')
            ### img = Image.open(png_file_path)
            img = PIL.Image.open(png_file_path)
    
            x_offset_map = 45  ### 地図画像情報のx軸座標
            y_offset_map = 168 ### 地図画像情報のy軸座標
           
            ### 画像のサイズを取得
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 STEP 3/5.', 'DEBUG')
            width, height = img.size
    
            ### 拡大（整数に変換）
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 STEP 4/5.', 'DEBUG')
            new_width = int(width * 1.2)
            new_height = int(height * 1.1)
            ### img = img.resize((new_width, new_height), Image.ANTIALIAS)
            img = img.resize((new_width, new_height), PIL.Image.ANTIALIAS)
    
            p.drawInlineImage(img, x_offset_map, y_offset_map)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_vertically_A4()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_legend_vertically_A4(self, p):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 STEP 1/7.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 p={}'.format(p), 'DEBUG')

            ### 凡例情報の描画 (A4縦向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 STEP 2/7.', 'DEBUG')
            x_offset_legend = 46  ### 凡例情報テーブルX軸
            y_offset_legend = 48  ### 凡例情報テーブルY軸
    
            ### 凡例情報のテーブルの描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 STEP 3/7.', 'DEBUG')
            p.rect(x_offset_legend, y_offset_legend, 71*mm, 36*mm)  ### 枠の描画
    
            ### 凡例情報のテキスト
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 STEP 4/7.', 'DEBUG')
            legend_text = """
            凡例
            ■水害区域                                   ■水害発生原因
            浸水被害                                        破堤 ×
            土砂被害                                        有堤部溢水 ○
            
            ■                                               浸水・土砂被害 無堤部溢水 △
            地下浸水被害                                土石流、地すべり、急傾斜地崩壊 □
           
            ◆                                               その他 「内水」「窪地内水」
            ■                                               「洗掘・流出」「高潮」「津波」
            ■                                               「波浪」の文字  ■
            
            水害区域番号                                 ■氾濫水又は土砂の移動状況
            ①～200                                            ←
            """
    
            ### テキスト描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 STEP 5/7.', 'DEBUG')
            text_object = p.beginText(15 + x_offset_legend, 36*mm + y_offset_legend)  # テキストの開始位置
            text_object.setFont('HeiseiKakuGo-W5', 2*mm)
    
            ### テキストを行ごとに描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 STEP 6/7.', 'DEBUG')
            lines = legend_text.split('\n')
            for line in lines:
                text_object.textLine(line.strip())  ### テキストの描画
    
            p.drawText(text_object)  ### ドキュメントにテキストを描画

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_vertically_A4()関数が異常終了しました。', 'ERROR')
    
    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_form_vertically_A4(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 1/14.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 params={}'.format(params), 'DEBUG')

            ### フォーム情報の描画 (A4縦向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 2/14.', 'DEBUG')
            x_offset_info = 241  ### テーブル描写位置のx座標
            y_offset_info = 117  ### テーブル描写位置のy座標
    
            ### 5つのテーブルのデータ(水害区域図作成図 ) 20240117追加 ##テーブル1から5を高さを合わせて合体する
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 3/14.', 'DEBUG')
            form_table1_data = [
                ["都道府県コード", "市町村コード", "水害区域番号"],
                ### [str(params['gPrefecturalCode']), str(params['gMunicipalityCode']), f"{params['gArea1']} 〜 {params['gArea2']}"],
                ### [str(params['g_ken_code']), str(params['g_city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
                [str(params['ken_code']), str(params['city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
            ]
    
            form_table2_data = [
                ### [f"{params['gPrefecturalName']}　　　{params['gMunicipalityName']}　　　　　水害区域図"],
                ### [f"{params['g_ken_name']}　　　{params['g_city_name']}　　　　　水害区域図"],
                [f"{params['ken_name']}　　　{params['city_name']}　　　　　水害区域図"],
            ]
    
            form_table3_data = [
                ### ["縮尺", f"1/{params['gScale']}", "枝番", f"{params['gBranchSub']}/{params['gBranchAll']}"],
                ["縮尺", f"1/{params['g_scale']}", "枝番", f"{params['g_branch_code1']}/{params['g_branch_code2']}"],
            ]
    
            form_table4_data = [
                ### [f"{params['gYear1']}年 {params['gMonth1']}月 {params['gDay1']}日 〜 {params['gYear2']}年 {params['gMonth2']}月 {params['gDay2']}日"],
                [f"{params['g_year1']}年 {params['g_month1']}月 {params['g_day1']}日 〜 {params['g_year2']}年 {params['g_month2']}月 {params['g_day2']}日"],
            ]
            form_table5_data =[
                ### ["異常気象名", f"{params['gAbnormalName']}"],
                ["異常気象名", f"{params['g_abnormal_name']}"],
            ]
    
            ### テーブル1の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 4/14.', 'DEBUG')
            form_table1 = Table(form_table1_data, colWidths=(15 * mm, 30 * mm, 30 * mm), rowHeights=6 * mm)
            form_table1.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (0, 0), 'HeiseiKakuGo-W5', 1.5 * mm),
                ('FONT', (1, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル1を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 5/14.', 'DEBUG')
            form_table1.wrapOn(p, 0, 0)
            form_table1.drawOn(p, 10 + x_offset_info, y_offset_info)
    
            ### テーブル2の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 6/14.', 'DEBUG')
            form_table2 = Table(form_table2_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table2.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル2を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 7/14.', 'DEBUG')
            form_table2.wrapOn(p, 0, 0)
            form_table2.drawOn(p, 10 + x_offset_info, y_offset_info - 6*mm)
    
            ### テーブル3の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 8/14.', 'DEBUG')
            form_table3 = Table(form_table3_data, colWidths=(15 * mm, 30 * mm, 10 * mm, 20 * mm), rowHeights=6 * mm)
            form_table3.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル3を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 9/14.', 'DEBUG')
            form_table3.wrapOn(p, 0, 0)
            form_table3.drawOn(p, 10 + x_offset_info, y_offset_info - 12*mm)
    
            ### テーブル4の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 10/14.', 'DEBUG')
            form_table4 = Table(form_table4_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table4.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル4を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 11/14.', 'DEBUG')
            form_table4.wrapOn(p, 0, 0)
            form_table4.drawOn(p, 10 + x_offset_info, y_offset_info - 18*mm)
    
            ### テーブル5の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 12/14.', 'DEBUG')
            form_table5 = Table(form_table5_data, colWidths=(20 * mm, 55 * mm), rowHeights=6 * mm)
            form_table5.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル5を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 STEP 13/14.', 'DEBUG')
            form_table5.wrapOn(p, 0, 0)
            form_table5.drawOn(p, 10 + x_offset_info, y_offset_info - 24*mm)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_vertically_A4()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_remark_vertically_A4(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 STEP 1/5.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 params={}'.format(params), 'DEBUG')

            ### 備考情報の描画 (A4縦向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 STEP 2/5.', 'DEBUG')
            x_offset_remark = 467   ### テーブル描写位置のx座標
            y_offset_remark = 50    ### テーブル描写位置のy座標
    
            ### テーブルの描画(備考)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 STEP 3/5.', 'DEBUG')
            remark_data = [
                ["備考"],
                [f"{params['g_remark']}"],
            ]

            table_style_remark = [
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (0, 0), 'MIDDLE'),
                ('VALIGN', (-1, -1), (-1, -1), 'TOP'),
                ('ALIGN', (0, 0), (0, 0), 'CENTER'),
                ('ALIGN', (-1, -1), (-1, -1), 'LEFT'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 2*mm),
            ]

            table = Table(remark_data, style=table_style_remark, colWidths=(35*mm), rowHeights=(5*mm, 31*mm))
            table.wrapOn(p, 0, 0)
            
            ### テーブル描画位置を調整
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 STEP 4/5.', 'DEBUG')
            table.drawOn(p, x_offset_remark, y_offset_remark)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_vertically_A4()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_map_horizontally_A3(self, p, png_file_path):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 STEP 1/5.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 png_file_path={}'.format(png_file_path), 'DEBUG')

            ### A3横向きの地図描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 STEP 2/5.', 'DEBUG')
            ### img = Image.open(png_file_path)
            img = PIL.Image.open(png_file_path)
    
            x_offset_map = 80  ### 地図画像情報のx軸座標
            y_offset_map = 200 ### 地図画像情報のy軸座標
           
            ### 画像のサイズを取得
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 STEP 3/5.', 'DEBUG')
            width, height = img.size
    
            ### 拡大（整数に変換）
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 STEP 4/5.', 'DEBUG')
            new_width = int(width * 1.6)
            new_height = int(height * 1.5)
            ### img = img.resize((new_width, new_height), Image.ANTIALIAS)
            img = img.resize((new_width, new_height), PIL.Image.ANTIALIAS)
    
            p.drawInlineImage(img, x_offset_map, y_offset_map)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A3()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_legend_horizontally_A3(self, p):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 STEP 1/7.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 p={}'.format(p), 'DEBUG')

            ### 凡例情報の描画 (A3横向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 STEP 2/7.', 'DEBUG')
            x_offset_legend = 570  ### 凡例情報テーブルX軸
            y_offset_legend = 95   ### 凡例情報テーブルY軸
    
            ### 凡例情報のテーブルの描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 STEP 3/7.', 'DEBUG')
            p.rect(x_offset_legend, y_offset_legend, 50*mm, 36*mm)  ### 枠の描画
    
            ### 凡例情報のテキスト
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 STEP 4/7.', 'DEBUG')
            legend_text = """
            凡例
            ■水害区域               ■水害発生原因
            浸水被害                    破堤 ×
            土砂被害                    有堤部溢水 ○
            
            ■                              浸水・土砂被害 無堤部溢水 △
            地下浸水被害            土石流、地すべり、急傾斜地崩壊 □
           
            ◆                              その他 「内水」「窪地内水」
            ■                             「洗掘・流出」「高潮」「津波」
            ■                             「波浪」の文字  ■
            
            水害区域番号            ■氾濫水又は土砂の移動状況
            ①～200                          ←
            """
    
            ### テキスト描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 STEP 5/7.', 'DEBUG')
            text_object = p.beginText(15 + x_offset_legend,35*mm + y_offset_legend)  # テキストの開始位置
            text_object.setFont('HeiseiKakuGo-W5', 1.7*mm)
    
            ### テキストを行ごとに描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 STEP 6/7.', 'DEBUG')
            lines = legend_text.split('\n')
            for line in lines:
                text_object.textLine(line.strip())  ### テキストの描画
    
            p.drawText(text_object)  ### ドキュメントにテキストを描画

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A3()関数が異常終了しました。', 'ERROR')
    
    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_form_horizontally_A3(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 1/14.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 params={}'.format(params), 'DEBUG')

            ### フォーム情報の描画 (A3横向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 2/14.', 'DEBUG')
            x_offset_info = 705  ### テーブル描写位置のx座標
            y_offset_info = 163  ### テーブル描写位置のy座標
    
            ### 5つのテーブルのデータ(水害区域図作成図 ) 20240117追加 ##テーブル1から5を高さを合わせて合体する
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 3/14.', 'DEBUG')
            form_table1_data = [
                ["都道府県コード", "市町村コード", "水害区域番号"],
                ### [str(params['gPrefecturalCode']), str(params['gMunicipalityCode']), f"{params['gArea1']} 〜 {params['gArea2']}"],
                ### [str(params['g_ken_code']), str(params['g_city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
                [str(params['ken_code']), str(params['city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
            ]
    
            form_table2_data = [
                ### [f"{params['gPrefecturalName']}　　　{params['gMunicipalityName']}　　　　　水害区域図"],
                ### [f"{params['g_ken_name']}　　　{params['g_city_name']}　　　　　水害区域図"],
                [f"{params['ken_name']}　　　{params['city_name']}　　　　　水害区域図"],
            ]
    
            form_table3_data = [
                ### ["縮尺", f"1/{params['gScale']}", "枝番", f"{params['gBranchSub']}/{params['gBranchAll']}"],
                ["縮尺", f"1/{params['g_scale']}", "枝番", f"{params['g_branch_code1']}/{params['g_branch_code2']}"],
            ]
    
            form_table4_data = [
                ### [f"{params['gYear1']}年 {params['gMonth1']}月 {params['gDay1']}日 〜 {params['gYear2']}年 {params['gMonth2']}月 {params['gDay2']}日"],
                [f"{params['g_year1']}年 {params['g_month1']}月 {params['g_day1']}日 〜 {params['g_year2']}年 {params['g_month2']}月 {params['g_day2']}日"],
            ]
            form_table5_data =[
                ### ["異常気象名", f"{params['gAbnormalName']}"],
                ["異常気象名", f"{params['g_abnormal_name']}"],
            ]
    
            ### テーブル1の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 4/14.', 'DEBUG')
            form_table1 = Table(form_table1_data, colWidths=(15 * mm, 30 * mm, 30 * mm), rowHeights=6 * mm)
            form_table1.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (0, 0), 'HeiseiKakuGo-W5', 1.5 * mm),
                ('FONT', (1, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル1を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 5/14.', 'DEBUG')
            form_table1.wrapOn(p, 0, 0)
            form_table1.drawOn(p, 10 + x_offset_info, y_offset_info)
    
            ### テーブル2の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 6/14.', 'DEBUG')
            form_table2 = Table(form_table2_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table2.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル2を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 7/14.', 'DEBUG')
            form_table2.wrapOn(p, 0, 0)
            form_table2.drawOn(p, 10 + x_offset_info, y_offset_info - 6*mm)
    
            ### テーブル3の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 8/14.', 'DEBUG')
            form_table3 = Table(form_table3_data, colWidths=(15 * mm, 30 * mm, 10 * mm, 20 * mm), rowHeights=6 * mm)
            form_table3.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル3を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 9/14.', 'DEBUG')
            form_table3.wrapOn(p, 0, 0)
            form_table3.drawOn(p, 10 + x_offset_info, y_offset_info - 12*mm)
    
            ### テーブル4の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 10/14.', 'DEBUG')
            form_table4 = Table(form_table4_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table4.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル4を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 11/14.', 'DEBUG')
            form_table4.wrapOn(p, 0, 0)
            form_table4.drawOn(p, 10 + x_offset_info, y_offset_info - 18*mm)
    
            ### テーブル5の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 12/14.', 'DEBUG')
            form_table5 = Table(form_table5_data, colWidths=(20 * mm, 55 * mm), rowHeights=6 * mm)
            form_table5.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル5を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 STEP 13/14.', 'DEBUG')
            form_table5.wrapOn(p, 0, 0)
            form_table5.drawOn(p, 10 + x_offset_info, y_offset_info - 24*mm)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A3()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_remark_horizontally_A3(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数 STEP 1/4.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数 params={}'.format(params), 'DEBUG')

            ### 備考情報の描画 (A3横向き)       
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数 STEP 2/4.', 'DEBUG')
            x_offset_remark = 932   ### テーブル描写位置のx座標
            y_offset_remark = 97    ### テーブル描写位置のy座標
    
            ### テーブルの描画(備考)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数 STEP 3/4.', 'DEBUG')
            remark_data = [
                ["備考"],
                [f"{params['g_remark']}"],
            ]

            table_style_remark = [
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (0, 0), 'MIDDLE'),
                ('VALIGN', (-1, -1), (-1, -1), 'TOP'),
                ('ALIGN', (0, 0), (0, 0), 'CENTER'),
                ('ALIGN', (-1, -1), (-1, -1), 'LEFT'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3*mm),
            ]

            table = Table(remark_data, style=table_style_remark, colWidths=(70*mm), rowHeights=(5*mm, 30*mm))
            table.wrapOn(p, 0, 0)
            table.drawOn(p, x_offset_remark, y_offset_remark)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A3()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_map_horizontally_A4(self, p, png_file_path):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 STEP 1/5.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 png_file_path={}'.format(png_file_path), 'DEBUG')

            ### A4横向きの地図描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 STEP 2/5.', 'DEBUG')
            ### img = Image.open(png_file_path)
            img = PIL.Image.open(png_file_path)
           
            x_offset_map = 50  ### 地図画像情報のx軸座標
            y_offset_map = 150 ### 地図画像情報のy軸座標
    
            ### 画像のサイズを取得
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 STEP 3/5.', 'DEBUG')
            width, height = img.size
    
            ### 拡大（整数に変換）
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 STEP 4/5.', 'DEBUG')
            new_width = int(width * 1.1)
            new_height = int(height * 1.0)
            ### img = img.resize((new_width, new_height), Image.ANTIALIAS)
            img = img.resize((new_width, new_height), PIL.Image.ANTIALIAS)
    
            p.drawInlineImage(img, x_offset_map, y_offset_map)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_map_horizontally_A4()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_legend_horizontally_A4(self, p):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 STEP 1/7.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 p={}'.format(p), 'DEBUG')

            ### 凡例情報の描画 (A4横向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 STEP 2/7.', 'DEBUG')
            x_offset_legend = 215  ### 凡例情報テーブルX軸
            y_offset_legend = 47   ### 凡例情報テーブルY軸
    
            ### 凡例情報のテーブルの描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 STEP 3/7.', 'DEBUG')
            p.rect(x_offset_legend, y_offset_legend, 50*mm, 36*mm)  ### 枠の描画
    
            ### 凡例情報のテキスト
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 STEP 4/7.', 'DEBUG')
            legend_text = """
            凡例
    
            ■水害区域               ■水害発生原因
            浸水被害                    破堤 ×
            土砂被害                    有堤部溢水 ○
            
            ■                              浸水・土砂被害 無堤部溢水 △
            地下浸水被害            土石流、地すべり、急傾斜地崩壊 □
           
            ◆                              その他 「内水」「窪地内水」
            ■                             「洗掘・流出」「高潮」「津波」
            ■                             「波浪」の文字  ■
            
            水害区域番号            ■氾濫水又は土砂の移動状況
            ①～200                          ←
            """
    
            ### テキスト描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 STEP 5/7.', 'DEBUG')
            text_object = p.beginText(10 + x_offset_legend,33*mm + y_offset_legend)  # テキストの開始位置
            text_object.setFont('HeiseiKakuGo-W5', 1.7*mm)
    
            ### テキストを行ごとに描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 STEP 6/7.', 'DEBUG')
            lines = legend_text.split('\n')
            for line in lines:
                text_object.textLine(line.strip())  ### テキストの描画
    
            p.drawText(text_object)  ### ドキュメントにテキストを描画

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_legend_horizontally_A4()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_form_horizontally_A4(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 1/14.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 params={}'.format(params), 'DEBUG')

            ### フォーム情報の描画 (A4横向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 2/14.', 'DEBUG')
            x_offset_info = 350  ### テーブル描写位置のx座標
            y_offset_info = 115  ### テーブル描写位置のy座標
    
            ### 5つのテーブルのデータ(水害区域図作成図 ) 20240117追加 #### テーブル1から5を高さを合わせて合体する
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 3/14.', 'DEBUG')
            form_table1_data = [
                ["都道府県コード", "市町村コード", "水害区域番号"],
                ### [str(params['gPrefecturalCode']), str(params['gMunicipalityCode']), f"{params['gArea1']} 〜 {params['gArea2']}"],
                ### [str(params['g_ken_code']), str(params['g_city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
                [str(params['ken_code']), str(params['city_code']), f"{params['g_kuiki_code1']} 〜 {params['g_kuiki_code2']}"],
            ]
    
            form_table2_data = [
                ### [f"{params['gPrefecturalName']}　　　{params['gMunicipalityName']}　　　　　水害区域図"],
                ### [f"{params['g_ken_name']}　　　{params['g_city_name']}　　　　　水害区域図"],
                [f"{params['ken_name']}　　　{params['city_name']}　　　　　水害区域図"],
            ]
    
            form_table3_data = [
                ### ["縮尺", f"1/{params['gScale']}", "枝番", f"{params['gBranchSub']}/{params['gBranchAll']}"],
                ["縮尺", f"1/{params['g_scale']}", "枝番", f"{params['g_branch_code1']}/{params['g_branch_code2']}"],
            ]
    
            form_table4_data = [
                ### [f"{params['gYear1']}年 {params['gMonth1']}月 {params['gDay1']}日 〜 {params['gYear2']}年 {params['gMonth2']}月 {params['gDay2']}日"],
                [f"{params['g_year1']}年 {params['g_month1']}月 {params['g_day1']}日 〜 {params['g_year2']}年 {params['g_month2']}月 {params['g_day2']}日"],
            ]
            form_table5_data =[
                ### ["異常気象名", f"{params['gAbnormalName']}"],
                ["異常気象名", f"{params['g_abnormal_name']}"],
            ]
    
            ### テーブル1の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 4/14.', 'DEBUG')
            form_table1 = Table(form_table1_data, colWidths=(15 * mm, 30 * mm, 30 * mm), rowHeights=6 * mm)
            form_table1.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (0, 0), 'HeiseiKakuGo-W5', 1.5 * mm),
                ('FONT', (1, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル1を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 5/14.', 'DEBUG')
            form_table1.wrapOn(p, 0, 0)
            form_table1.drawOn(p, 10 + x_offset_info, y_offset_info)
    
            # テーブル2の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 6/14.', 'DEBUG')
            form_table2 = Table(form_table2_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table2.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル2を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 7/14.', 'DEBUG')
            form_table2.wrapOn(p, 0, 0)
            form_table2.drawOn(p, 10 + x_offset_info, y_offset_info - 6*mm)
    
            ### テーブル3の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 8/14.', 'DEBUG')
            form_table3 = Table(form_table3_data, colWidths=(15 * mm, 30 * mm, 10 * mm, 20 * mm), rowHeights=6 * mm)
            form_table3.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル3を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 9/14.', 'DEBUG')
            form_table3.wrapOn(p, 0, 0)
            form_table3.drawOn(p, 10 + x_offset_info, y_offset_info - 12*mm)
    
            ### テーブル4の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 10/14.', 'DEBUG')
            form_table4 = Table(form_table4_data, colWidths=(75 * mm), rowHeights=6 * mm)
            form_table4.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル4を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 11/14.', 'DEBUG')
            form_table4.wrapOn(p, 0, 0)
            form_table4.drawOn(p, 10 + x_offset_info, y_offset_info - 18*mm)
    
            ### テーブル5の作成
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 12/14.', 'DEBUG')
            form_table5 = Table(form_table5_data, colWidths=(20 * mm, 55 * mm), rowHeights=6 * mm)
            form_table5.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (0, -1), 'CENTER'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3 * mm),
            ]))
    
            ### テーブル5を描画
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 STEP 13/14.', 'DEBUG')
            form_table5.wrapOn(p, 0, 0)
            form_table5.drawOn(p, 10 + x_offset_info, y_offset_info - 24*mm)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_form_horizontally_A4()関数が異常終了しました。', 'ERROR')

    ###########################################################################
    ### クラス名：PDF_GENERATOR(View)
    ### upload_pdf()関数から呼ばれる
    ###########################################################################
    def draw_remark_horizontally_A4(self, p, params):
        try:
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 STEP 1/5.', 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 p={}'.format(p), 'DEBUG')
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 params={}'.format(params), 'DEBUG')

            ### 備考情報の描画 (A4横向き)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 STEP 2/5.', 'DEBUG')
            x_offset_remark = 575   ### テーブル描写位置のx座標
            y_offset_remark = 48    ### テーブル描写位置のy座標
    
            ### テーブルの描画(備考)
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 STEP 3/5.', 'DEBUG')
            remark_data = [
                ["備考"],
                [f"{params['g_remark']}"],
            ]

            table_style_remark = [
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('VALIGN', (0, 0), (0, 0), 'MIDDLE'),
                ('VALIGN', (-1, -1), (-1, -1), 'TOP'),
                ('ALIGN', (0, 0), (0, 0), 'CENTER'),
                ('ALIGN', (-1, -1), (-1, -1), 'LEFT'),
                ('FONT', (0, 0), (-1, -1), 'HeiseiKakuGo-W5', 3*mm),
            ]

            table = Table(remark_data, style=table_style_remark, colWidths=(70*mm), rowHeights=(5*mm, 31*mm))
            table.wrapOn(p, 0, 0)
            
            ### テーブル描画位置を調整
            print_log('[DEBUG] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 STEP 4/5.', 'DEBUG')
            table.drawOn(p, x_offset_remark, y_offset_remark)

        except:
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0500GUI.PDF_GENERATOR.draw_remark_horizontally_A4()関数が異常終了しました。', 'ERROR')
