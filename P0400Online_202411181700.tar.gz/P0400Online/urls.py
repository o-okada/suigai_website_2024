from django.urls import path
from . import views

app_name = 'P0400Online'
urlpatterns = [
    path('', views.index_view, name='index_view'),
    path('cat1/<slug:cat1>/cat2/<slug:cat2>/ken/<slug:ken_code>/city/<slug:city_code>/', views.cat1_cat2_ken_city_view, name='cat1_cat2_ken_city_view'),
]
