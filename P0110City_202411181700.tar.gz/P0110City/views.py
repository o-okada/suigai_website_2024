###############################################################################
### ファイル名：P0110City/views.py
### 市区町村用ファイル管理
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### def add_comment(ws, ws_result, row, column, fill, message_id, message)
### def custom_decorator(arg1)
### def browser_get(request)
### def browser_post_ippan(request)
### 
### ビュー関数：ブラウザから呼ばれる関数
### def index_view(request)
### def bucket_view(request)
### def browser_view(request)
### 
### def slide_ippan_header_id_view(request, header_id)
### 
### def apply_ippan_header_id_view(request, header_id)
### 
### def delete_ippan_header_id_view(request, header_id)
### 
### def download_ippan_chosa_excel_header_id_view(request, header_id)
### def download_ippan_chosa_csv_header_id_view(request, header_id, _IPP_CHO_CSV)
### def download_ippan_summary_excel_header_id_view(request, header_id, _IPP_SUM_EXC)
### def download_ippan_summary_csv_header_id_view(request, header_id, _IPP_SUM_CSV)
### 更新履歴：
### 2023/11/14 browser_post_ippan 関数において試行版用に水害区域番号のチェックをコメントアウトする。
### 2024/07/25 custom_decorator 追加 requestをチェックしてUSER_PROXYからcity_codeを取得する処理を共通化した。
### 2024/09/05 PARAM、SQL文をEXECUTEと別にセットして、EXECUTE周辺のコードを読みやすくした。
### 2024/09/05 水害区域図DB版との統合のため、AREAをKUIKIに変更した。
### 2024/09/05 水害区域図DB版との統合のため、browser_post_kuiki関数を削除した。
### 2024/10/13 画面制御用コード（暫定値、確報値）に対応した。
### 2024/10/15 一般資産調査員調査票エクセルのシート数を固定値の25にした。
### 2024/11/05 水害区域図DB化をDB化対象外とするように修正した。
### 2024/11/11 水害区域番号をエクセルから登録できるように修正した。※水害区域図の登録を中止したため、手動で登録できる道筋を再開する。
### 2024/11/15 水系種別、河川種別が登録できなかったため、SQLを修正した。#※水系種別、河川種別は水系、河川に従属としていたが、同じ河川でも場所によって種別が異なる。
### 2024/11/15 異常気象コードを登録していたが、オンラインで紐付けることにしたため、登録しないようにSQLを修正した。
###############################################################################

import json
import os
import sys

from datetime import date, datetime
from datetime import timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound
from django.http.response import JsonResponse
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views import View
from django.views.generic.base import TemplateView
from django.views.decorators.csrf import csrf_exempt

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ
from P0000Common.models import PROVISIONED_CONFIRMED   ### 0000: 画面制御用コード（暫定値、確報値）

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import IPPAN_HISTORY           ### 11000: ヒストリーデータ_一般資産調査票_調査員用
from P0000Common.models import CHITAN_HISTORY          ### 11010: ヒストリーデータ_公共土木施設調査票_地方単独事業
from P0000Common.models import HOJO_HISTORY            ### 11020: ヒストリーデータ_公共土木施設調査票_補助事業
from P0000Common.models import KOEKI_HISTORY           ### 11030: ヒストリーデータ_公益事業等調査票

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.common import split_name_code
from P0000Common.common import isdate
from P0000Common.common import convert_empty_to_none

from P0000Common.services import get_ippan_chosa_csv_excel
from P0000Common.services import get_ippan_summary_csv_excel
from P0000Common.services import get_chitan_chosa_csv_excel
from P0000Common.services import get_chitan_summary_csv_excel
from P0000Common.services import get_hojo_chosa_csv_excel
from P0000Common.services import get_hojo_summary_csv_excel
from P0000Common.services import get_koeki_chosa_csv_excel
from P0000Common.services import get_koeki_summary_csv_excel

from . import constants

from .forms import UploadIppanForm

from MessageQueue.views import publish_message 
from MessageQueue.views import delete_message 

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'

_CHI_ACT_01 = 'CHI_ACT_01'
_CHI_ACT_02 = 'CHI_ACT_02'
_CHI_ACT_03 = 'CHI_ACT_03'

_HOJ_ACT_01 = 'HOJ_ACT_01'
_HOJ_ACT_02 = 'HOJ_ACT_02'
_HOJ_ACT_03 = 'HOJ_ACT_03'

_KOE_ACT_01 = 'KOE_ACT_01'
_KOE_ACT_02 = 'KOE_ACT_02'
_KOE_ACT_03 = 'KOE_ACT_03'

### STATUSテーブル.STATUS_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_RUNNING = 'RUNNING'

### 局所定数 ※DELETE関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP = 'IPP'
_CHI = 'CHI'
_HOJ = 'HOJ'
_KOE = 'KOE'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'

### 局所定数 暫定値確報値
_PROVISIONED = 'PROVISIONED'
_CONFIRMED = 'CONFIRMED'

### 局所定数 ワークフロー履歴
_PROVISIONED_IPPAN_CITY_UPLOAD = 'PROVISIONED_IPPAN_CITY_UPLOAD'
_PROVISIONED_IPPAN_CITY_APPLY = 'PROVISIONED_IPPAN_CITY_APPLY'
_PROVISIONED_IPPAN_CITY_DELETE = 'PROVISIONED_IPPAN_CITY_DELETE'
_PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER = 'PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER'
_PROVISIONED_IPPAN_KEN_APPROVE = 'PROVISIONED_IPPAN_KEN_APPROVE'
_PROVISIONED_IPPAN_KEN_DISAPPROVE = 'PROVISIONED_IPPAN_KEN_DISAPPROVE'
_PROVISIONED_IPPAN_MANAGE_APPROVE = 'PROVISIONED_IPPAN_MANAGE_APPROVE'
_PROVISIONED_IPPAN_MANAGE_DISAPPROVE = 'PROVISIONED_IPPAN_MANAGE_DISAPPROVE'

_CONFIRMED_IPPAN_CITY_UPLOAD = 'CONFIRMED_IPPAN_CITY_UPLOAD'
_CONFIRMED_IPPAN_CITY_APPLY = 'CONFIRMED_IPPAN_CITY_APPLY'
_CONFIRMED_IPPAN_CITY_DELETE = 'CONFIRMED_IPPAN_CITY_DELETE'
_CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER = 'CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER'
_CONFIRMED_IPPAN_KEN_APPROVE = 'CONFIRMED_IPPAN_KEN_APPROVE'
_CONFIRMED_IPPAN_KEN_DISAPPROVE = 'CONFIRMED_IPPAN_KEN_DISAPPROVE'
_CONFIRMED_IPPAN_MANAGE_APPROVE = 'CONFIRMED_IPPAN_MANAGE_APPROVE'
_CONFIRMED_IPPAN_MANAGE_DISAPPROVE = 'CONFIRMED_IPPAN_MANAGE_DISAPPROVE'

_PROVISIONED_CHITAN_KEN_UPLOAD = 'PROVISIONED_CHITAN_KEN_UPLOAD'
_PROVISIONED_CHITAN_KEN_APPLY = 'PROVISIONED_CHITAN_KEN_APPLY'
_PROVISIONED_CHITAN_KEN_DELETE = 'PROVISIONED_CHITAN_KEN_DELETE'
_PROVISIONED_CHITAN_MANAGE_APPROVE = 'PROVISIONED_CHITAN_MANAGE_APPROVE'
_PROVISIONED_CHITAN_MANAGE_DISAPPROVE = 'PROVISIONED_CHITAN_MANAGE_DISAPPROVE'

_CONFIRMED_CHITAN_KEN_UPLOAD = 'CONFIRMED_CHITAN_KEN_UPLOAD'
_CONFIRMED_CHITAN_KEN_APPLY = 'CONFIRMED_CHITAN_KEN_APPLY'
_CONFIRMED_CHITAN_KEN_DELETE = 'CONFIRMED_CHITAN_KEN_DELETE'
_CONFIRMED_CHITAN_MANAGE_APPROVE = 'CONFIRMED_CHITAN_MANAGE_APPROVE'
_CONFIRMED_CHITAN_MANAGE_DISAPPROVE = 'CONFIRMED_CHITAN_MANAGE_DISAPPROVE'

_PROVISIONED_HOJO_KEN_UPLOAD = 'PROVISIONED_HOJO_KEN_UPLOAD'
_PROVISIONED_HOJO_KEN_APPLY = 'PROVISIONED_HOJO_KEN_APPLY'
_PROVISIONED_HOJO_KEN_DELETE = 'PROVISIONED_HOJO_KEN_DELETE'
_PROVISIONED_HOJO_MANAGE_APPROVE = 'PROVISIONED_HOJO_MANAGE_APPROVE'
_PROVISIONED_HOJO_MANAGE_DISAPPROVE = 'PROVISIONED_HOJO_MANAGE_DISAPPROVE'

_CONFIRMED_HOJO_KEN_UPLOAD = 'CONFIRMED_HOJO_KEN_UPLOAD'
_CONFIRMED_HOJO_KEN_APPLY = 'CONFIRMED_HOJO_KEN_APPLY'
_CONFIRMED_HOJO_KEN_DELETE = 'CONFIRMED_HOJO_KEN_DELETE'
_CONFIRMED_HOJO_MANAGE_APPROVE = 'CONFIRMED_HOJO_MANAGE_APPROVE'
_CONFIRMED_HOJO_MANAGE_DISAPPROVE = 'CONFIRMED_HOJO_MANAGE_DISAPPROVE'

_PROVISIONED_KOEKI_KEN_UPLOAD = 'PROVISIONED_KOEKI_KEN_UPLOAD'
_PROVISIONED_KOEKI_KEN_APPLY = 'PROVISIONED_KOEKI_KEN_APPLY'
_PROVISIONED_KOEKI_KEN_DELETE = 'PROVISIONED_KOEKI_KEN_DELETE'
_PROVISIONED_KOEKI_MANAGE_APPROVE = 'PROVISIONED_KOEKI_MANAGE_APPROVE'
_PROVISIONED_KOEKI_MANAGE_DISAPPROVE = 'PROVISIONED_KOEKI_MANAGE_DISAPPROVE'

_CONFIRMED_KOEKI_KEN_UPLOAD = 'CONFIRMED_KOEKI_KEN_UPLOAD'
_CONFIRMED_KOEKI_KEN_APPLY = 'CONFIRMED_KOEKI_KEN_APPLY'
_CONFIRMED_KOEKI_KEN_DELETE = 'CONFIRMED_KOEKI_KEN_DELETE'
_CONFIRMED_KOEKI_MANAGE_APPROVE = 'CONFIRMED_KOEKI_MANAGE_APPROVE'
_CONFIRMED_KOEKI_MANAGE_DISAPPROVE = 'CONFIRMED_KOEKI_MANAGE_DISAPPROVE'

### 必須チェック
IPP_REQ_KEN_CODE = 'W0000'
IPP_REQ_CITY_CODE = 'W0001'
IPP_REQ_BEGIN_DATE = 'W0002'
IPP_REQ_END_DATE = 'W0003'
IPP_REQ_CAUSE_1_CODE = 'W0004'
IPP_REQ_CAUSE_2_CODE = 'W0005'
IPP_REQ_CAUSE_3_CODE = 'W0006'
IPP_REQ_KUIKI_ID = 'W0007'
IPP_REQ_SUIKEI_CODE = 'W0008'
IPP_REQ_SUIKEI_TYPE_CODE = 'W0009'
IPP_REQ_KASEN_CODE = 'W0010'
IPP_REQ_KASEN_TYPE_CODE = 'W0011'
IPP_REQ_GRADIENT_CODE = 'W0012'
IPP_REQ_RESIDENTIAL_AREA = 'W0013'
IPP_REQ_AGRICULTURAL_AREA = 'W0014'
IPP_REQ_UNDERGROUND_AREA = 'W0015'
IPP_REQ_KASEN_KAIGAN_CODE = 'W0016'
IPP_REQ_CROP_DAMAGE = 'W0017'
IPP_REQ_WEATHER_ID = 'W0018'
IPP_REQ_IPPAN_NAME = 'W0019'
IPP_REQ_BUILDING_CODE = 'W0020'
IPP_REQ_UNDERGROUND_CODE = 'W0021'
IPP_REQ_FLOOD_SEDIMENT_CODE = 'W0022'
IPP_REQ_BUILDING_LV00 = 'W0023'
IPP_REQ_BUILDING_LV01_49 = 'W0024'
IPP_REQ_BUILDING_LV50_99 = 'W0025'
IPP_REQ_BUILDING_LV100 = 'W0026'
IPP_REQ_BUILDING_HALF = 'W0027'
IPP_REQ_BUILDING_FULL = 'W0028'
IPP_REQ_FLOOR_AREA = 'W0029'
IPP_REQ_FAMILY = 'W0030'
IPP_REQ_OFFICE = 'W0031'
IPP_REQ_FARMER_FISHER_LV00 = 'W0032'
IPP_REQ_FARMER_FISHER_LV01_49 = 'W0033'
IPP_REQ_FARMER_FISHER_LV50_99 = 'W0034'
IPP_REQ_FARMER_FISHER_LV100 = 'W0035'
IPP_REQ_FARMER_FISHER_FULL = 'W0036'
IPP_REQ_EMPLOYEE_LV00 = 'W0037'
IPP_REQ_EMPLOYEE_LV01_49 = 'W0038'
IPP_REQ_EMPLOYEE_LV50_99 = 'W0039'
IPP_REQ_EMPLOYEE_LV100 = 'W0040'
IPP_REQ_EMPLOYEE_FULL = 'W0041'
IPP_REQ_INDUSTRY_CODE = 'W0042'
IPP_REQ_USAGE_CODE = 'W0043'
IPP_REQ_COMMENT = 'W0044'

IPP_REQ_MSG = dict({
    IPP_REQ_KEN_CODE:               [IPP_REQ_KEN_CODE,              '必須', '都道府県が入力されていません。', '都道府県を入力してください。'],
    IPP_REQ_CITY_CODE:              [IPP_REQ_CITY_CODE,             '必須', '市区町村が入力されていません。', '市区町村を入力してください。'],
    IPP_REQ_BEGIN_DATE:             [IPP_REQ_BEGIN_DATE,            '必須', '水害発生月日が入力されていません。', '水害発生月日を入力してください。'],
    IPP_REQ_END_DATE:               [IPP_REQ_END_DATE,              '必須', '水害終了月日が入力されていません。', '水害終了月日を入力してください。'],
    IPP_REQ_CAUSE_1_CODE:           [IPP_REQ_CAUSE_1_CODE,          '必須', '水害原因1が入力されていません。', '水害原因1を入力してください。'],
    IPP_REQ_CAUSE_2_CODE:           [IPP_REQ_CAUSE_2_CODE,          '必須', '水害原因2が入力されていません。', '水害原因2を入力してください。'],
    IPP_REQ_CAUSE_3_CODE:           [IPP_REQ_CAUSE_3_CODE,          '必須', '水害原因3が入力されていません。', '水害原因3を入力してください。'],
    IPP_REQ_KUIKI_ID:               [IPP_REQ_KUIKI_ID,              '必須', '水害区域番号が入力されていません。', '水害区域番号を入力してください。'],
    IPP_REQ_SUIKEI_CODE:            [IPP_REQ_SUIKEI_CODE,           '必須', '水系・沿岸名が入力されていません。', '水系・沿岸名を入力してください。'],
    IPP_REQ_SUIKEI_TYPE_CODE:       [IPP_REQ_SUIKEI_TYPE_CODE,      '必須', '水系種別が入力されていません。', '水系種別を入力してください。'],
    IPP_REQ_KASEN_CODE:             [IPP_REQ_KASEN_CODE,            '必須', '河川・海岸名が入力されていません。', '河川・海岸名を入力してください。'],
    IPP_REQ_KASEN_TYPE_CODE:        [IPP_REQ_KASEN_TYPE_CODE,       '必須', '河川種別が入力されていません。', '河川種別を入力してください。'],
    IPP_REQ_GRADIENT_CODE:          [IPP_REQ_GRADIENT_CODE,         '必須', '地盤勾配区分が入力されていません。', '地盤勾配区分を入力してください。'],
    IPP_REQ_RESIDENTIAL_AREA:       [IPP_REQ_RESIDENTIAL_AREA,      '必須', '水害区域面積の宅地が入力されていません。', '水害区域面積の宅地を入力してください。'],
    IPP_REQ_AGRICULTURAL_AREA:      [IPP_REQ_AGRICULTURAL_AREA,     '必須', '水害区域面積の農地が入力されていません。', '水害区域面積の農地を入力してください。'],
    IPP_REQ_UNDERGROUND_AREA:       [IPP_REQ_UNDERGROUND_AREA,      '必須', '水害区域面積の地下が入力されていません。', '水害区域面積の地下を入力してください。'],
    IPP_REQ_KASEN_KAIGAN_CODE:      [IPP_REQ_KASEN_KAIGAN_CODE,     '必須', '工種が入力されていません。', '工種を入力してください。'],
    IPP_REQ_CROP_DAMAGE:            [IPP_REQ_CROP_DAMAGE,           '必須', '農作物被害額が入力されていません。', '農作物被害額を入力してください。'],
    IPP_REQ_WEATHER_ID:             [IPP_REQ_WEATHER_ID,            '必須', '異常気象コードが入力されていません。', '異常気象コードを入力してください。'],
    IPP_REQ_IPPAN_NAME:             [IPP_REQ_IPPAN_NAME,            '必須', '町丁名・大字名が入力されていません。', '町丁名・大字名を入力してください。'],
    IPP_REQ_BUILDING_CODE:          [IPP_REQ_BUILDING_CODE,         '必須', '名称が入力されていません。', '名称を入力してください。'],
    IPP_REQ_UNDERGROUND_CODE:       [IPP_REQ_UNDERGROUND_CODE,      '必須', '地上・地下被害の区分が入力されていません。', '地上・地下被害の区分を入力してください。'],
    IPP_REQ_FLOOD_SEDIMENT_CODE:    [IPP_REQ_FLOOD_SEDIMENT_CODE,   '必須', '浸水土砂被害の区分が入力されていません。', '浸水土砂被害の区分を入力してください。'],
    IPP_REQ_BUILDING_LV00:          [IPP_REQ_BUILDING_LV00,         '必須', '被害建物棟数, 床下浸水が入力されていません。', '被害建物棟数, 床下浸水を入力してください。'],
    IPP_REQ_BUILDING_LV01_49:       [IPP_REQ_BUILDING_LV01_49,      '必須', '被害建物棟数, 1cm〜49cmが入力されていません。', '被害建物棟数, 1cm〜49cmを入力してください。'],
    IPP_REQ_BUILDING_LV50_99:       [IPP_REQ_BUILDING_LV50_99,      '必須', '被害建物棟数, 50cm〜99cmが入力されていません。', '被害建物棟数, 50cm〜99cmを入力してください。'],
    IPP_REQ_BUILDING_LV100:         [IPP_REQ_BUILDING_LV100,        '必須', '被害建物棟数, 1m以上が入力されていません。', '被害建物棟数, 1m以上を入力してください。'],
    IPP_REQ_BUILDING_HALF:          [IPP_REQ_BUILDING_HALF,         '必須', '被害建物棟数, 半壊が入力されていません。', '被害建物棟数, 半壊を入力してください。'],
    IPP_REQ_BUILDING_FULL:          [IPP_REQ_BUILDING_FULL,         '必須', '被害建物棟数, 全壊・流失が入力されていません。', '被害建物棟数, 全壊・流失を入力してください。'],
    IPP_REQ_FLOOR_AREA:             [IPP_REQ_FLOOR_AREA,            '必須', '被害建物の延床面積が入力されていません。', '被害建物の延床面積を入力してください。'],
    IPP_REQ_FAMILY:                 [IPP_REQ_FAMILY,                '必須', '被災世帯数が入力されていません。', '被災世帯数を入力してください。'],
    IPP_REQ_OFFICE:                 [IPP_REQ_OFFICE,                '必須', '被災事業所数が入力されていません。', '被災事業所数を入力してください。'],
    IPP_REQ_FARMER_FISHER_LV00:     [IPP_REQ_FARMER_FISHER_LV00,    '必須', '農家・漁家戸数, 床下浸水が入力されていません。', '農家・漁家戸数, 床下浸水を入力してください。'],
    IPP_REQ_FARMER_FISHER_LV01_49:  [IPP_REQ_FARMER_FISHER_LV01_49, '必須', '農家・漁家戸数, 1cm〜49cmが入力されていません。', '農家・漁家戸数, 1cm〜49cmを入力してください。'],
    IPP_REQ_FARMER_FISHER_LV50_99:  [IPP_REQ_FARMER_FISHER_LV50_99, '必須', '農家・漁家戸数, 50cm〜99cmが入力されていません。', '農家・漁家戸数, 50cm〜99cmを入力してください。'],
    IPP_REQ_FARMER_FISHER_LV100:    [IPP_REQ_FARMER_FISHER_LV100,   '必須', '農家・漁家戸数, 1m以上・半壊が入力されていません。', '農家・漁家戸数, 1m以上・半壊を入力してください。'],
    IPP_REQ_FARMER_FISHER_FULL:     [IPP_REQ_FARMER_FISHER_FULL,    '必須', '農家・漁家戸数, 全壊・流失が入力されていません。', '農家・漁家戸数, 全壊・流失を入力してください。'],
    IPP_REQ_EMPLOYEE_LV00:          [IPP_REQ_EMPLOYEE_LV00,         '必須', '事業所従業者数, 床下浸水が入力されていません。', '事業所従業者数, 床下浸水を入力してください。'],
    IPP_REQ_EMPLOYEE_LV01_49:       [IPP_REQ_EMPLOYEE_LV01_49,      '必須', '事業所従業者数, 1cm〜49cmが入力されていません。', '事業所従業者数, 1cm〜49cmを入力してください。'],
    IPP_REQ_EMPLOYEE_LV50_99:       [IPP_REQ_EMPLOYEE_LV50_99,      '必須', '事業所従業者数, 50cm〜99cmが入力されていません。', '事業所従業者数, 50cm〜99cmを入力してください。'],
    IPP_REQ_EMPLOYEE_LV100:         [IPP_REQ_EMPLOYEE_LV100,        '必須', '事業所従業者数, 1m以上・半壊が入力されていません。', '事業所従業者数, 1m以上・半壊を入力してください。'],
    IPP_REQ_EMPLOYEE_FULL:          [IPP_REQ_EMPLOYEE_FULL,         '必須', '事業所従業者数, 全壊・流失が入力されていません。', '事業所従業者数, 全壊・流失を入力してください。'],
    IPP_REQ_INDUSTRY_CODE:          [IPP_REQ_INDUSTRY_CODE,         '必須', '事業所の産業区分が入力されていません。', '事業所の産業区分を入力してください。'],
    IPP_REQ_USAGE_CODE:             [IPP_REQ_USAGE_CODE,            '必須', '地下空間の利用形態が入力されていません。', '地下空間の利用形態を入力してください。'],
    IPP_REQ_COMMENT:                [IPP_REQ_COMMENT,               '必須', '備考が入力されていません。', '備考を入力してください。'],
})  

### 形式チェック
IPP_FOR_KEN_CODE = 'W0100'
IPP_FOR_CITY_CODE = 'W0101'
IPP_FOR_BEGIN_DATE = 'W0102'
IPP_FOR_END_DATE = 'W0103'
IPP_FOR_CAUSE_1_CODE = 'W0104'
IPP_FOR_CAUSE_2_CODE = 'W0105'
IPP_FOR_CAUSE_3_CODE = 'W0106'
IPP_FOR_KUIKI_ID = 'W0107'
IPP_FOR_SUIKEI_CODE = 'W0108'
IPP_FOR_SUIKEI_TYPE_CODE = 'W0109'
IPP_FOR_KASEN_CODE = 'W0110'
IPP_FOR_KASEN_TYPE_CODE = 'W0111'
IPP_FOR_GRADIENT_CODE = 'W0112'
IPP_FOR_RESIDENTIAL_AREA = 'W0113'
IPP_FOR_AGRICULTURAL_AREA = 'W0114'
IPP_FOR_UNDERGROUND_AREA = 'W0115'
IPP_FOR_KASEN_KAIGAN_CODE = 'W0116'
IPP_FOR_CROP_DAMAGE = 'W0117'
IPP_FOR_WEATHER_ID = 'W0118'
IPP_FOR_IPPAN_NAME = 'W0119'
IPP_FOR_BUILDING_CODE = 'W0120'
IPP_FOR_UNDERGROUND_CODE = 'W0121'
IPP_FOR_FLOOD_SEDIMENT_CODE = 'W0122'
IPP_FOR_BUILDING_LV00 = 'W0123'
IPP_FOR_BUILDING_LV01_49 = 'W0124'
IPP_FOR_BUILDING_LV50_99 = 'W0125'
IPP_FOR_BUILDING_LV100 = 'W0126'
IPP_FOR_BUILDING_HALF = 'W0127'
IPP_FOR_BUILDING_FULL = 'W0128'
IPP_FOR_FLOOR_AREA = 'W0129'
IPP_FOR_FAMILY = 'W0130'
IPP_FOR_OFFICE = 'W0131'
IPP_FOR_FARMER_FISHER_LV00 = 'W0132'
IPP_FOR_FARMER_FISHER_LV01_49 = 'W0133'
IPP_FOR_FARMER_FISHER_LV50_99 = 'W0134'
IPP_FOR_FARMER_FISHER_LV100 = 'W0135'
IPP_FOR_FARMER_FISHER_FULL = 'W0136'
IPP_FOR_EMPLOYEE_LV00 = 'W0137'
IPP_FOR_EMPLOYEE_LV01_49 ='W0138'
IPP_FOR_EMPLOYEE_LV50_99 = 'W0139'
IPP_FOR_EMPLOYEE_LV100 = 'W0140'
IPP_FOR_EMPLOYEE_FULL = 'W0141'
IPP_FOR_INDUSTRY_CODE = 'W0142'
IPP_FOR_USAGE_CODE = 'W0143'
IPP_FOR_COMMENT = 'W0144'

IPP_FOR_MSG = dict({
    IPP_FOR_KEN_CODE:               [IPP_FOR_KEN_CODE,              '形式', '都道府県に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_CITY_CODE:              [IPP_FOR_CITY_CODE,             '形式', '市区町村に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_BEGIN_DATE:             [IPP_FOR_BEGIN_DATE,            '形式', '水害発生月日に日付として無効な文字が入力されています。', '日付として有効な文字を入力してください。'],
    IPP_FOR_END_DATE:               [IPP_FOR_END_DATE,              '形式', '水害終了月日に日付として無効な文字が入力されています。', '日付として有効な文字を入力してください。'],
    IPP_FOR_CAUSE_1_CODE:           [IPP_FOR_CAUSE_1_CODE,          '形式', '水害原因1に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_CAUSE_2_CODE:           [IPP_FOR_CAUSE_2_CODE,          '形式', '水害原因2に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_CAUSE_3_CODE:           [IPP_FOR_CAUSE_3_CODE,          '形式', '水害原因3に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_KUIKI_ID:               [IPP_FOR_KUIKI_ID,              '形式', '水害区域番号に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_SUIKEI_CODE:            [IPP_FOR_SUIKEI_CODE,           '形式', '水系・沿岸名に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_SUIKEI_TYPE_CODE:       [IPP_FOR_SUIKEI_TYPE_CODE,      '形式', '水系種別に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_KASEN_CODE:             [IPP_FOR_KASEN_CODE,            '形式', '河川・海岸名に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_KASEN_TYPE_CODE:        [IPP_FOR_KASEN_TYPE_CODE,       '形式', '河川種別に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_GRADIENT_CODE:          [IPP_FOR_GRADIENT_CODE,         '形式', '地盤勾配区分に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_RESIDENTIAL_AREA:       [IPP_FOR_RESIDENTIAL_AREA,      '形式', '水害区域面積の宅地に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_AGRICULTURAL_AREA:      [IPP_FOR_AGRICULTURAL_AREA,     '形式', '水害区域面積の農地に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_UNDERGROUND_AREA:       [IPP_FOR_UNDERGROUND_AREA,      '形式', '水害区域面積の地下に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_KASEN_KAIGAN_CODE:      [IPP_FOR_KASEN_KAIGAN_CODE,     '形式', '工種に全角以外の無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_CROP_DAMAGE:            [IPP_FOR_CROP_DAMAGE,           '形式', '農作物被害額に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_WEATHER_ID:             [IPP_FOR_WEATHER_ID,            '形式', '異常気象コードに無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_IPPAN_NAME:             [IPP_FOR_IPPAN_NAME,            '形式', '町丁名・大字名に無効な文字が入力されています。', '全角文字の形式で入力してください。'],
    IPP_FOR_BUILDING_CODE:          [IPP_FOR_BUILDING_CODE,         '形式', '名称に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_UNDERGROUND_CODE:       [IPP_FOR_UNDERGROUND_CODE,      '形式', '地上・地下被害の区分に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_FLOOD_SEDIMENT_CODE:    [IPP_FOR_FLOOD_SEDIMENT_CODE,   '形式', '浸水土砂被害の区分に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_BUILDING_LV00:          [IPP_FOR_BUILDING_LV00,         '形式', '被害建物棟数, 床下浸水に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_BUILDING_LV01_49:       [IPP_FOR_BUILDING_LV01_49,      '形式', '被害建物棟数, 1cm〜49cmに無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_BUILDING_LV50_99:       [IPP_FOR_BUILDING_LV50_99,      '形式', '被害建物棟数, 50cm〜99cmに無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_BUILDING_LV100:         [IPP_FOR_BUILDING_LV100,        '形式', '被害建物棟数, 1m以上に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_BUILDING_HALF:          [IPP_FOR_BUILDING_HALF,         '形式', '被害建物棟数, 半壊に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_BUILDING_FULL:          [IPP_FOR_BUILDING_FULL,         '形式', '被害建物棟数, 全壊・流失に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_FLOOR_AREA:             [IPP_FOR_FLOOR_AREA,            '形式', '被害建物の延床面積に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_FAMILY:                 [IPP_FOR_FAMILY,                '形式', '被災世帯数に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_OFFICE:                 [IPP_FOR_OFFICE,                '形式', '被災事業所数に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_FARMER_FISHER_LV00:     [IPP_FOR_FARMER_FISHER_LV00,    '形式', '農家・漁家戸数, 床下浸水に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_FARMER_FISHER_LV01_49:  [IPP_FOR_FARMER_FISHER_LV01_49, '形式', '農家・漁家戸数, 1cm〜49cmに無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_FARMER_FISHER_LV50_99:  [IPP_FOR_FARMER_FISHER_LV50_99, '形式', '農家・漁家戸数, 50cm〜99cmに無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_FARMER_FISHER_LV100:    [IPP_FOR_FARMER_FISHER_LV100,   '形式', '農家・漁家戸数, 1m以上・半壊に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_FARMER_FISHER_FULL:     [IPP_FOR_FARMER_FISHER_FULL,    '形式', '農家・漁家戸数, 全壊・流失に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_EMPLOYEE_LV00:          [IPP_FOR_EMPLOYEE_LV00,         '形式', '事業所従業者数, 床下浸水に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_EMPLOYEE_LV01_49:       [IPP_FOR_EMPLOYEE_LV01_49,      '形式', '事業所従業者数, 1cm〜49cmに無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_EMPLOYEE_LV50_99:       [IPP_FOR_EMPLOYEE_LV50_99,      '形式', '事業所従業者数, 50cm〜99cmに無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_EMPLOYEE_LV100:         [IPP_FOR_EMPLOYEE_LV100,        '形式', '事業所従業者数, 1m以上・半壊に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_EMPLOYEE_FULL:          [IPP_FOR_EMPLOYEE_FULL,         '形式', '事業所従業者数, 全壊・流失に無効な文字が入力されています。', '半角数字の形式で入力してください。'],
    IPP_FOR_INDUSTRY_CODE:          [IPP_FOR_INDUSTRY_CODE,         '形式', '事業所の産業区分に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_USAGE_CODE:             [IPP_FOR_USAGE_CODE,            '形式', '地下空間の利用形態に無効な文字が入力されています。', '全角文字:半角数字の形式で入力してください。'],
    IPP_FOR_COMMENT:                [IPP_FOR_COMMENT,               '形式', '備考に無効な文字が入力されています。', '全角文字の形式で入力してください。'],
})

### 範囲チェック
IPP_RAN_KEN_CODE = 'W0200'
IPP_RAN_CITY_CODE = 'W0201'
IPP_RAN_BEGIN_DATE = 'W0202'
IPP_RAN_END_DATE = 'W0203'
IPP_RAN_CAUSE_1_CODE = 'W0204'
IPP_RAN_CAUSE_2_CODE = 'W0205'
IPP_RAN_CAUSE_3_CODE = 'W0206'
IPP_RAN_KUIKI_ID = 'W0207'
IPP_RAN_SUIKEI_CODE = 'W0208'
IPP_RAN_SUIKEI_TYPE_CODE = 'W0209'
IPP_RAN_KASEN_CODE = 'W0210'
IPP_RAN_KASEN_TYPE_CODE = 'W0211'
IPP_RAN_GRADIENT_CODE = 'W0212'
IPP_RAN_RESIDENTIAL_AREA = 'W0213'
IPP_RAN_AGRICULTURAL_AREA = 'W0214'
IPP_RAN_UNDERGROUND_AREA = 'W0215'
IPP_RAN_KASEN_KAIGAN_CODE = 'W0216'
IPP_RAN_CROP_DAMAGE = 'W0217'
IPP_RAN_WEATHER_ID = 'W0218'
IPP_RAN_IPPAN_NAME = 'W0219'
IPP_RAN_BUILDING_CODE = 'W0220'
IPP_RAN_UNDERGROUND_CODE = 'W0221'
IPP_RAN_FLOOD_SEDIMENT_CODE = 'W0222'
IPP_RAN_BUILDING_LV00 = 'W0223'
IPP_RAN_BUILDING_LV01_49 = 'W0224'
IPP_RAN_BUILDING_LV50_99 = 'W0225'
IPP_RAN_BUILDING_LV100 = 'W0226'
IPP_RAN_BUILDING_HALF = 'W0227'
IPP_RAN_BUILDING_FULL = 'W0228'
IPP_RAN_FLOOR_AREA = 'W0229'
IPP_RAN_FAMILY = 'W0230'
IPP_RAN_OFFICE = 'W0231'
IPP_RAN_FARMER_FISHER_LV00 = 'W0232'
IPP_RAN_FARMER_FISHER_LV01_49 = 'W0233'
IPP_RAN_FARMER_FISHER_LV50_99 = 'W0234'
IPP_RAN_FARMER_FISHER_LV100 = 'W0235'
IPP_RAN_FARMER_FISHER_FULL = 'W0236'
IPP_RAN_EMPLOYEE_LV00 = 'W0237'
IPP_RAN_EMPLOYEE_LV01_49 = 'W0238'
IPP_RAN_EMPLOYEE_LV50_99 = 'W0239'
IPP_RAN_EMPLOYEE_LV100 = 'W0240'
IPP_RAN_EMPLOYEE_FULL = 'W0241'
IPP_RAN_INDUSTRY_CODE = 'W0242'
IPP_RAN_USAGE_CODE = 'W0243'
IPP_RAN_COMMENT = 'W0244'

IPP_RAN_MSG = dict({
    IPP_RAN_KEN_CODE:               [IPP_RAN_KEN_CODE,              '範囲', '都道府県に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_CITY_CODE:              [IPP_RAN_CITY_CODE,             '範囲', '市区町村に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_BEGIN_DATE:             [IPP_RAN_BEGIN_DATE,            '範囲', '水害発生月日に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_END_DATE:               [IPP_RAN_END_DATE,              '範囲', '水害終了月日に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_CAUSE_1_CODE:           [IPP_RAN_CAUSE_1_CODE,          '範囲', '水害原因1に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_CAUSE_2_CODE:           [IPP_RAN_CAUSE_2_CODE,          '範囲', '水害原因2に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_CAUSE_3_CODE:           [IPP_RAN_CAUSE_3_CODE,          '範囲', '水害原因3に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_KUIKI_ID:               [IPP_RAN_KUIKI_ID,              '範囲', '水害区域番号に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_SUIKEI_CODE:            [IPP_RAN_SUIKEI_CODE,           '範囲', '水系・沿岸名に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_SUIKEI_TYPE_CODE:       [IPP_RAN_SUIKEI_TYPE_CODE,      '範囲', '水系種別に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_KASEN_CODE:             [IPP_RAN_KASEN_CODE,            '範囲', '河川・海岸名に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_KASEN_TYPE_CODE:        [IPP_RAN_KASEN_TYPE_CODE,       '範囲', '河川種別に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_GRADIENT_CODE:          [IPP_RAN_GRADIENT_CODE,         '範囲', '地盤勾配区分に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_RESIDENTIAL_AREA:       [IPP_RAN_RESIDENTIAL_AREA,      '範囲', '水害区域面積の宅地に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_AGRICULTURAL_AREA:      [IPP_RAN_AGRICULTURAL_AREA,     '範囲', '水害区域面積の農地に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_UNDERGROUND_AREA:       [IPP_RAN_UNDERGROUND_AREA,      '範囲', '水害区域面積の地下に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_KASEN_KAIGAN_CODE:      [IPP_RAN_KASEN_KAIGAN_CODE,     '範囲', '工種に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_CROP_DAMAGE:            [IPP_RAN_CROP_DAMAGE,           '範囲', '農作物被害額に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_WEATHER_ID:             [IPP_RAN_WEATHER_ID,            '範囲', '異常気象コードに範囲外の無効な値が入力されています。', ''],
    IPP_RAN_IPPAN_NAME:             [IPP_RAN_IPPAN_NAME,            '範囲', '町丁名・大字名に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_BUILDING_CODE:          [IPP_RAN_BUILDING_CODE,         '範囲', '名称に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_UNDERGROUND_CODE:       [IPP_RAN_UNDERGROUND_CODE,      '範囲', '地上・地下被害の区分に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_FLOOD_SEDIMENT_CODE:    [IPP_RAN_FLOOD_SEDIMENT_CODE,   '範囲', '浸水土砂被害の区分に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_BUILDING_LV00:          [IPP_RAN_BUILDING_LV00,         '範囲', '被害建物棟数, 床下浸水に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_BUILDING_LV01_49:       [IPP_RAN_BUILDING_LV01_49,      '範囲', '被害建物棟数, 1cm〜49cmに範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_BUILDING_LV50_99:       [IPP_RAN_BUILDING_LV50_99,      '範囲', '被害建物棟数, 50cm〜99cmに範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_BUILDING_LV100:         [IPP_RAN_BUILDING_LV100,        '範囲', '被害建物棟数, 1m以上に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_BUILDING_HALF:          [IPP_RAN_BUILDING_HALF,         '範囲', '被害建物棟数, 半壊に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_BUILDING_FULL:          [IPP_RAN_BUILDING_FULL,         '範囲', '被害建物棟数, 全壊・流失に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_FLOOR_AREA:             [IPP_RAN_FLOOR_AREA,            '範囲', '被害建物の延床面積に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_FAMILY:                 [IPP_RAN_FAMILY,                '範囲', '被災世帯数に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_OFFICE:                 [IPP_RAN_OFFICE,                '範囲', '被災事業所数に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_FARMER_FISHER_LV00:     [IPP_RAN_FARMER_FISHER_LV00,    '範囲', '農家・漁家戸数, 床下浸水に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_FARMER_FISHER_LV01_49:  [IPP_RAN_FARMER_FISHER_LV01_49, '範囲', '農家・漁家戸数, 1cm〜49cmに範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_FARMER_FISHER_LV50_99:  [IPP_RAN_FARMER_FISHER_LV50_99, '範囲', '農家・漁家戸数, 50cm〜99cmに範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_FARMER_FISHER_LV100:    [IPP_RAN_FARMER_FISHER_LV100,   '範囲', '農家・漁家戸数, 1m以上・半壊に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_FARMER_FISHER_FULL:     [IPP_RAN_FARMER_FISHER_FULL,    '範囲', '農家・漁家戸数, 全壊・流失に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_EMPLOYEE_LV00:          [IPP_RAN_EMPLOYEE_LV00,         '範囲', '事業所従業者数, 床下浸水に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_EMPLOYEE_LV01_49:       [IPP_RAN_EMPLOYEE_LV01_49,      '範囲', '事業所従業者数, 1cm〜49cmに範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_EMPLOYEE_LV50_99:       [IPP_RAN_EMPLOYEE_LV50_99,      '範囲', '事業所従業者数, 50cm〜99cmに範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_EMPLOYEE_LV100:         [IPP_RAN_EMPLOYEE_LV100,        '範囲', '事業所従業者数, 1m以上・半壊に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_EMPLOYEE_FULL:          [IPP_RAN_EMPLOYEE_FULL,         '範囲', '事業所従業者数, 全壊・流失に範囲外の無効な値が入力されています。', '正の値を入力してください。'],
    IPP_RAN_INDUSTRY_CODE:          [IPP_RAN_INDUSTRY_CODE,         '範囲', '事業所の産業区分に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_USAGE_CODE:             [IPP_RAN_USAGE_CODE,            '範囲', '地下空間の利用形態に範囲外の無効な値が入力されています。', ''],
    IPP_RAN_COMMENT:                [IPP_RAN_COMMENT,               '範囲', '備考に範囲外の無効な値が入力されています。', ''],
})

### 相関チェック
IPP_COR_BEGIN_DATE_END_DATE = 'W0300'
IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01 = 'W0301'
IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02 = 'W0302'
IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03 = 'W0303'
IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04 = 'W0304'
IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05 = 'W0305'
IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01 = 'W0306'
IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02 = 'W0307'
IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03 = 'W0308'
IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04 = 'W0309'
IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05 = 'W0310'
IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01 = 'W0311'
IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02 = 'W0312'
IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03 = 'W0313'
IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04 = 'W0314'
IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05 = 'W0315'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01 = 'W0316'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02 = 'W0317'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03 = 'W0318'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04 = 'W0319'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05 = 'W0320'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06 = 'W0321'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01 = 'W0322'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02 = 'W0323'
IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03 = 'W0324'
IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01 = 'W0325'
IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02 = 'W0326'
IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA = 'W0327'
IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01 = 'W0328'
IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02 = 'W0329'
IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03 = 'W0330'
IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04 = 'W0331'
IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01 = 'W0332'
IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02 = 'W0333'
IPP_COR_BUILDING_FLOOR_AREA_01 = 'W0334'
IPP_COR_BUILDING_FLOOR_AREA_02 = 'W0335'
IPP_COR_OFFICE_INDUSTRY_CODE_01 = 'W0336'
IPP_COR_OFFICE_INDUSTRY_CODE_02 = 'W0337'
IPP_COR_OFFICE_EMPLOYEE_01 = 'W0338'
IPP_COR_OFFICE_EMPLOYEE_02 = 'W0339'

IPP_COR_MSG = dict({
    IPP_COR_BEGIN_DATE_END_DATE:                                [IPP_COR_BEGIN_DATE_END_DATE,                                   '相関', '水害発生月日が水害終了月日より後に入力されています。', '水害発生月日と水害終了月日を正しく入力してください。'],
    IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01:                  [IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01,                     '相関', '水害原因1と工種の関係が正しく入力されていません。', '水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、工種は、「1:河川」を入力してください。'],
    IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02:                  [IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02,                     '相関', '水害原因1と工種の関係が正しく入力されていません。', '水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、工種は、「3:河川海岸以外」を入力してください。'],
    IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03:                  [IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03,                     '相関', '水害原因1と工種の関係が正しく入力されていません。', '水害原因が「93:波浪」の場合、工種は、「2:海岸」を入力してください。'],
    IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04:                  [IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04,                     '相関', '水害原因1と工種の関係が正しく入力されていません。', '水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、工種は、「1:河川」「2:海岸」のいずれかを入力してください。'],
    IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05:                  [IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05,                     '相関', '水害原因1と工種の関係が正しく入力されていません。', '水害原因が「70:土石流」の場合、工種は、「1:河川」「3:河川海岸以外」のいずれかを入力してください。'],
    IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01:                  [IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01,                     '相関', '水害原因2と工種の関係が正しく入力されていません。', '水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、工種は、「1:河川」を入力してください。'],
    IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02:                  [IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02,                     '相関', '水害原因2と工種の関係が正しく入力されていません。', '水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、工種は、「3:河川海岸以外」を入力してください。'],
    IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03:                  [IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03,                     '相関', '水害原因2と工種の関係が正しく入力されていません。', '水害原因が「93:波浪」の場合、工種は、「2:海岸」を入力してください。'],
    IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04:                  [IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04,                     '相関', '水害原因2と工種の関係が正しく入力されていません。', '水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、工種は、「1:河川」「2:海岸」のいずれかを入力してください。'],
    IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05:                  [IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05,                     '相関', '水害原因2と工種の関係が正しく入力されていません。', '水害原因が「70:土石流」の場合、工種は、「1:河川」「3:河川海岸以外」のいずれかを入力してください。'],
    IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01:                  [IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01,                     '相関', '水害原因3と工種の関係が正しく入力されていません。', '水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、工種は、「1:河川」を入力してください。'],
    IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02:                  [IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02,                     '相関', '水害原因3と工種の関係が正しく入力されていません。', '水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、工種は、「3:河川海岸以外」を入力してください。'],
    IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03:                  [IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03,                     '相関', '水害原因3と工種の関係が正しく入力されていません。', '水害原因が「93:波浪」の場合、工種は、「2:海岸」を入力してください。'],
    IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04:                  [IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04,                     '相関', '水害原因3と工種の関係が正しく入力されていません。', '水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、工種は、「1:河川」「2:海岸」のいずれかを入力してください。'],
    IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05:                  [IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05,                     '相関', '水害原因3と工種の関係が正しく入力されていません。', '水害原因が「70:土石流」の場合、工種は、「1:河川」「3:河川海岸以外」のいずれかを入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01:                [IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01,                   '相関', '水系種別と河川種別の関係が正しく入力されていません。', '水系種別が「1:一級」のときに、河川種別は、「1:直轄」「2:指定」「4:準用」「5:普通」のいずれかを入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02:                [IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02,                   '相関', '水系種別と河川種別の関係が正しく入力されていません。', '水系種別が「2:二級」のときに、河川種別は、「3:二級」「4:準用」「5:普通」のいずれかを入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03:                [IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03,                   '相関', '水系種別と河川種別の関係が正しく入力されていません。', '水系種別が「3:準用」のときに、河川種別は、「4:準用」「5:普通」のいずれかを入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04:                [IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04,                   '相関', '水系種別と河川種別の関係が正しく入力されていません。', '水系種別が「4:普通」のときに、河川種別は、「5:普通」を入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05:                [IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05,                   '相関', '水系種別と河川種別の関係が正しく入力されていません。', '水系種別が「5:沿岸」のときに、河川種別は、「6:海岸」を入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06:                [IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06,                   '相関', '水系種別と河川種別の関係が正しく入力されていません。', '水系種別が「6:河川海岸以外」のときに、河川種別は、「7:河川海岸以外」を入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01:              [IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01,                 '相関', '水系種別と工種の関係が正しく入力されていません。', '水系種別が「1:一級」「2:二級」「3:準用」「4:普通」のときに、工種は、「1:河川」を入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02:              [IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02,                 '相関', '水系種別と工種の関係が正しく入力されていません。', '水系種別が「5:沿岸」のときに、工種は、「2:海岸」を入力してください。'],
    IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03:              [IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03,                 '相関', '水系種別と工種の関係が正しく入力されていません。', '水系種別が「6:河川海岸以外」のときに、工種は、「3:河川海岸以外」を入力してください。'],
    IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01:                   [IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01,                      '相関', '水害区域面積の農地と農作物被害額の関係が正しく入力されていません。', '水害区域面積の農地を入力するときには、農作物被害額を入力してください。'],
    IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02:                   [IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02,                      '相関', '水害区域面積の農地と農作物被害額の関係が正しく入力されていません。', '水害区域面積の農地を入力しないときには、農作物被害額を入力しないでください。'],
    IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA:          [IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA,             '相関', '水害区域面積の宅地、農地、地下の関係が正しく入力されていません。', '少なくとも、水害区域面積の宅地、農地、地下のいずれかには、値を入力してください。'],
    IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01:  [IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01,     '相関', '地上・地下被害の区分と水害区域面積の宅地または農地の関係が正しく入力されていません。', '地上・地下被害の区分が「1:地上のみ」のときに、少なくとも、水害区域面積の宅地、水害区域面積の農地のいずれかを入力してください。'],
    IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02:  [IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02,     '相関', '地上・地下被害の区分と水害区域面積の宅地または農地の関係が正しく入力されていません。', '地上・地下被害の区分が「2:地上部分」のときに、少なくとも、水害区域面積の宅地、水害区域面積の農地のいずれかを入力してください。'],
    IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03:  [IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03,     '相関', '地上・地下被害の区分と水害区域面積の宅地または農地の関係が正しく入力されていません。', '地上・地下被害の区分が「3:地下部分」のときに、少なくとも、水害区域面積の地下を入力してください。'],
    IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04:  [IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04,     '相関', '地上・地下被害の区分と水害区域面積の宅地または農地の関係が正しく入力されていません。', '地上・地下被害の区分が「4:地下のみ」のときに、少なくとも、水害区域面積の地下を入力してください。'],
    IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01:                     [IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01,                        '相関', '地上・地下被害の区分と地下空間の利用形態の関係が正しく入力されていません。', '地上・地下被害の区分が「1:地上のみ」「2:地上部分」のときには、地下空間の利用形態を入力しないでください。'],
    IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02:                     [IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02,                        '相関', '地上・地下被害の区分と地下空間の利用形態の関係が正しく入力されていません。', '地上・地下被害の区分が「3:地下部分」「4:地下のみ」のときには、地下空間の利用形態を入力してください。'],
    IPP_COR_BUILDING_FLOOR_AREA_01:                             [IPP_COR_BUILDING_FLOOR_AREA_01,                                '相関', '被害建物棟数と延床面積の関係が正しく入力されていません。', '被害建物棟数を入力しないときには、延床面積を入力しないでください。'],
    IPP_COR_BUILDING_FLOOR_AREA_02:                             [IPP_COR_BUILDING_FLOOR_AREA_02,                                '相関', '被害建物棟数と延床面積の関係が正しく入力されていません。', '被害建物棟数を入力するときには、延床面積を入力してください。'],
    IPP_COR_OFFICE_INDUSTRY_CODE_01:                            [IPP_COR_OFFICE_INDUSTRY_CODE_01,                               '相関', '被災事業所数と事業所の産業区分の関係が正しく入力されていません。', '被災事業所数を入力しないときには、事業所の産業区分を入力しないでください。'],
    IPP_COR_OFFICE_INDUSTRY_CODE_02:                            [IPP_COR_OFFICE_INDUSTRY_CODE_02,                               '相関', '被災事業所数と事業所の産業区分の関係が正しく入力されていません。', '被災事業所数を入力するときには、事業所の産業区分を入力してください。'],
    IPP_COR_OFFICE_EMPLOYEE_01:                                 [IPP_COR_OFFICE_EMPLOYEE_01,                                    '相関', '被災事業所数と事業所従業者数の関係が正しく入力されていません。', '被災事業所数を入力しないときには、事業所従業者数を入力しないでください。'],
    IPP_COR_OFFICE_EMPLOYEE_02:                                 [IPP_COR_OFFICE_EMPLOYEE_02,                                    '相関', '被災事業所数と事業所従業者数の関係が正しく入力されていません。', '被災事業所数を入力するときには、事業所従業者数を入力してください。'],
})

### 突合チェック
IPP_COM_KEN_CODE = 'W0400'
IPP_COM_CITY_CODE = 'W0401'
IPP_COM_BEGIN_DATE = 'W0402'
IPP_COM_END_DATE = 'W0403'
IPP_COM_CAUSE_1_CODE = 'W0404'
IPP_COM_CAUSE_2_CODE = 'W0405'
IPP_COM_CAUSE_3_CODE = 'W0406'
IPP_COM_KUIKI_ID = 'W0407'
IPP_COM_SUIKEI_CODE = 'W0408'
IPP_COM_SUIKEI_TYPE_CODE = 'W0409'
IPP_COM_KASEN_CODE = 'W0410'
IPP_COM_KASEN_TYPE_CODE = 'W0411'
IPP_COM_GRADIENT_CODE = 'W0412'
IPP_COM_RESIDENTIAL_AREA = 'W0413'
IPP_COM_AGRICULTURAL_AREA = 'W0414'
IPP_COM_UNDERGROUND_AREA = 'W0415'
IPP_COM_KASEN_KAIGAN_CODE = 'W0416'
IPP_COM_CROP_DAMAGE = 'W0417'
IPP_COM_WEATHER_ID = 'W0418'
IPP_COM_IPPAN_NAME = 'W0419'
IPP_COM_BUILDING_CODE = 'W0420'
IPP_COM_UNDERGROUND_CODE = 'W0421'
IPP_COM_FLOOD_SEDIMENT_CODE = 'W0422'
IPP_COM_BUILDING_LV00 = 'W0423'
IPP_COM_BUILDING_LV01_49 = 'W0424'
IPP_COM_BUILDING_LV50_99 = 'W0425'
IPP_COM_BUILDING_LV100 = 'W0426'
IPP_COM_BUILDING_HALF = 'W0427'
IPP_COM_BUILDING_FULL = 'W0428'
IPP_COM_FLOOR_AREA = 'W0429'
IPP_COM_FAMILY = 'W0430'
IPP_COM_OFFICE = 'W0431'
IPP_COM_FARMER_FISHER_LV00 = 'W0432'
IPP_COM_FARMER_FISHER_LV01_49 = 'W0433'
IPP_COM_FARMER_FISHER_LV50_99 = 'W0434'
IPP_COM_FARMER_FISHER_LV100 = 'W0435'
IPP_COM_FARMER_FISHER_FULL = 'W0436'
IPP_COM_EMPLOYEE_LV00 = 'W0437'
IPP_COM_EMPLOYEE_LV01_49 = 'W0438'
IPP_COM_EMPLOYEE_LV50_99 = 'W0439'
IPP_COM_EMPLOYEE_LV100 = 'W0440'
IPP_COM_EMPLOYEE_FULL = 'W0441'
IPP_COM_INDUSTRY_CODE = 'W0442'
IPP_COM_USAGE_CODE = 'W0443'
IPP_COM_COMMENT = 'W0444'

IPP_COM_MSG = dict({
    IPP_COM_KEN_CODE:               [IPP_COM_KEN_CODE,              '突合', '都道府県がデータベースに登録されている都道府県と一致しません。', '正しい都道府県を入力してください。'],
    IPP_COM_CITY_CODE:              [IPP_COM_CITY_CODE,             '突合', '市区町村がデータベースに登録されている市区町村と一致しません。', '正しい市区町村を入力してください。'],
    IPP_COM_BEGIN_DATE:             [IPP_COM_BEGIN_DATE,            '突合', '水害発生月日がデータベースに登録されている水害発生月日と一致しません。', ''],
    IPP_COM_END_DATE:               [IPP_COM_END_DATE,              '突合', '水害終了月日がデータベースに登録されている水害終了月日と一致しません。', ''],
    IPP_COM_CAUSE_1_CODE:           [IPP_COM_CAUSE_1_CODE,          '突合', '水害原因1がデータベースに登録されている水害原因1と一致しません。', '正しい水害原因を入力してください。'],
    IPP_COM_CAUSE_2_CODE:           [IPP_COM_CAUSE_2_CODE,          '突合', '水害原因2がデータベースに登録されている水害原因2と一致しません。', '正しい水害原因を入力してください。'],
    IPP_COM_CAUSE_3_CODE:           [IPP_COM_CAUSE_3_CODE,          '突合', '水害原因3がデータベースに登録されている水害原因3と一致しません。', '正しい水害原因を入力してください。'],
    IPP_COM_KUIKI_ID:               [IPP_COM_KUIKI_ID,              '突合', '水害区域番号がデータベースに登録されている水害区域番号と一致しません。', '正しい水害区域番号を入力してください。'],
    IPP_COM_SUIKEI_CODE:            [IPP_COM_SUIKEI_CODE,           '突合', '水系・沿岸名がデータベースに登録されている水系・沿岸名と一致しません。', '正しい水系・沿岸名を入力してください。'],
    IPP_COM_SUIKEI_TYPE_CODE:       [IPP_COM_SUIKEI_TYPE_CODE,      '突合', '水系種別がデータベースに登録されている水系種別と一致しません。', '正しい水系種別を入力してください。'],
    IPP_COM_KASEN_CODE:             [IPP_COM_KASEN_CODE,            '突合', '河川・海岸名がデータベースに登録されている河川・海岸名と一致しません。', '正しい河川・海岸名を入力してください。'],
    IPP_COM_KASEN_TYPE_CODE:        [IPP_COM_KASEN_TYPE_CODE,       '突合', '河川種別がデータベースに登録されている河川種別と一致しません。', '正しい河川種別を入力してください。'],
    IPP_COM_GRADIENT_CODE:          [IPP_COM_GRADIENT_CODE,         '突合', '地盤勾配区分がデータベースに登録されている地盤勾配区分と一致しません。', '正しい地盤勾配区分を入力してください。'],
    IPP_COM_RESIDENTIAL_AREA:       [IPP_COM_RESIDENTIAL_AREA,      '突合', '水害区域面積の宅地がデータベースに登録されている水害区域面積の宅地と一致しません。', ''],
    IPP_COM_AGRICULTURAL_AREA:      [IPP_COM_AGRICULTURAL_AREA,     '突合', '水害区域面積の農地がデータベースに登録されている水害区域面積の農地と一致しません。', ''],
    IPP_COM_UNDERGROUND_AREA:       [IPP_COM_UNDERGROUND_AREA,      '突合', '水害区域面積の地下がデータベースに登録されている水害区域面積の地下と一致しません。', ''],
    IPP_COM_KASEN_KAIGAN_CODE:      [IPP_COM_KASEN_KAIGAN_CODE,     '突合', '工種がデータベースに登録されている工種と一致しません。', '正しい工種を入力してください。'],
    IPP_COM_CROP_DAMAGE:            [IPP_COM_CROP_DAMAGE,           '突合', '農作物被害額がデータベースに登録されている農作物被害額と一致しません。', ''],
    IPP_COM_WEATHER_ID:             [IPP_COM_WEATHER_ID,            '突合', '異常気象コードがデータベースに登録されている異常気象コードと一致しません。', '正しい異常気象コードを入力してください。'],
    IPP_COM_IPPAN_NAME:             [IPP_COM_IPPAN_NAME,            '突合', '町丁名・大字名がデータベースに登録されている町丁名・大字名と一致しません。', ''],
    IPP_COM_BUILDING_CODE:          [IPP_COM_BUILDING_CODE,         '突合', '名称がデータベースに登録されている名称と一致しません。', '正しい名称を入力してください。'],
    IPP_COM_UNDERGROUND_CODE:       [IPP_COM_UNDERGROUND_CODE,      '突合', '地上・地下被害の区分がデータベースに登録されている地上・地下被害の区分と一致しません。', '正しい地上・地下被害の区分を入力してください。'],
    IPP_COM_FLOOD_SEDIMENT_CODE:    [IPP_COM_FLOOD_SEDIMENT_CODE,   '突合', '浸水土砂被害の区分がデータベースに登録されている浸水土砂被害の区分と一致しません。', '正しい浸水土砂被害の区分を入力してください。'],
    IPP_COM_BUILDING_LV00:          [IPP_COM_BUILDING_LV00,         '突合', '被害建物棟数, 床下浸水がデータベースに登録されている被害建物棟数, 床下浸水と一致しません。', ''],
    IPP_COM_BUILDING_LV01_49:       [IPP_COM_BUILDING_LV01_49,      '突合', '被害建物棟数, 1cm〜49cmがデータベースに登録されている被害建物棟数, 1cm〜49cmと一致しません。', ''],
    IPP_COM_BUILDING_LV50_99:       [IPP_COM_BUILDING_LV50_99,      '突合', '被害建物棟数, 50cm〜99cmがデータベースに登録されている被害建物棟数, 50cm〜99cmと一致しません。', ''],
    IPP_COM_BUILDING_LV100:         [IPP_COM_BUILDING_LV100,        '突合', '被害建物棟数, 1m以上がデータベースに登録されている被害建物棟数, 1m以上と一致しません。', ''],
    IPP_COM_BUILDING_HALF:          [IPP_COM_BUILDING_HALF,         '突合', '被害建物棟数, 半壊がデータベースに登録されている被害建物棟数, 半壊と一致しません。', ''],
    IPP_COM_BUILDING_FULL:          [IPP_COM_BUILDING_FULL,         '突合', '被害建物棟数, 全壊・流失がデータベースに登録されている被害建物棟数, 全壊・流失と一致しません。', ''],
    IPP_COM_FLOOR_AREA:             [IPP_COM_FLOOR_AREA,            '突合', '被害建物の延床面積がデータベースに登録されている被害建物の延床面積と一致しません。', ''],
    IPP_COM_FAMILY:                 [IPP_COM_FAMILY,                '突合', '被災世帯数がデータベースに登録されている被災世帯数と一致しません。', ''],
    IPP_COM_OFFICE:                 [IPP_COM_OFFICE,                '突合', '被災事業所数がデータベースに登録されている被災事業所数と一致しません。', ''],
    IPP_COM_FARMER_FISHER_LV00:     [IPP_COM_FARMER_FISHER_LV00,    '突合', '農家・漁家戸数, 床下浸水がデータベースに登録されている農家・漁家戸数, 床下浸水と一致しません。', ''],
    IPP_COM_FARMER_FISHER_LV01_49:  [IPP_COM_FARMER_FISHER_LV01_49, '突合', '農家・漁家戸数, 1cm〜49cmがデータベースに登録されている農家・漁家戸数, 1cm〜49cmと一致しません。', ''],
    IPP_COM_FARMER_FISHER_LV50_99:  [IPP_COM_FARMER_FISHER_LV50_99, '突合', '農家・漁家戸数, 50cm〜99cmがデータベースに登録されている農家・漁家戸数, 50cm〜99cmと一致しません。', ''],
    IPP_COM_FARMER_FISHER_LV100:    [IPP_COM_FARMER_FISHER_LV100,   '突合', '農家・漁家戸数, 1m以上・半壊がデータベースに登録されている農家・漁家戸数, 1m以上・半壊と一致しません。', ''],
    IPP_COM_FARMER_FISHER_FULL:     [IPP_COM_FARMER_FISHER_FULL,    '突合', '農家・漁家戸数, 全壊・流失がデータベースに登録されている農家・漁家戸数, 全壊・流失と一致しません。', ''],
    IPP_COM_EMPLOYEE_LV00:          [IPP_COM_EMPLOYEE_LV00,         '突合', '事業所従業者数, 床下浸水がデータベースに登録されている事業所従業者数, 床下浸水と一致しません。', ''],
    IPP_COM_EMPLOYEE_LV01_49:       [IPP_COM_EMPLOYEE_LV01_49,      '突合', '事業所従業者数, 1cm〜49cmがデータベースに登録されている事業所従業者数, 1cm〜49cmと一致しません。', ''],
    IPP_COM_EMPLOYEE_LV50_99:       [IPP_COM_EMPLOYEE_LV50_99,      '突合', '事業所従業者数, 50cm〜99cmがデータベースに登録されている事業所従業者数, 50cm〜99cmと一致しません。', ''],
    IPP_COM_EMPLOYEE_LV100:         [IPP_COM_EMPLOYEE_LV100,        '突合', '事業所従業者数, 1m以上・半壊がデータベースに登録されている事業所従業者数, 1m以上・半壊と一致しません。', ''],
    IPP_COM_EMPLOYEE_FULL:          [IPP_COM_EMPLOYEE_FULL,         '突合', '事業所従業者数, 全壊・流失がデータベースに登録されている事業所従業者数, 全壊・流失と一致しません。', ''],
    IPP_COM_INDUSTRY_CODE:          [IPP_COM_INDUSTRY_CODE,         '突合', '事業所の産業区分がデータベースに登録されている事業所の産業区分と一致しません。', '正しい事業所の産業区分を入力してください。'],
    IPP_COM_USAGE_CODE:             [IPP_COM_USAGE_CODE,            '突合', '地下空間の利用形態がデータベースに登録されている地下空間の利用形態と一致しません。', '正しい地下空間の利用形態を入力してください。'],
    IPP_COM_COMMENT:                [IPP_COM_COMMENT,               '突合', '備考がデータベースに登録されている備考と一致しません。', ''],
})

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### ※調査票の種類に応じてエラーメッセージが異なるため、共通化せずに、個々のviews.pyに記述する。
###############################################################################
def add_comment(ws, ws_result, row, column, fill, message_id, message):
    ws.cell(row=row, column=column).fill = fill
    ws_result.cell(row=row, column=column).fill = fill
    
    ### msg_str = message[message_id][3] + message[message_id][4]              ### 2024/11/12 COMMENT OUT
    msg_str = message[message_id][2] + message[message_id][3]                  ### 2024/11/12 ADD

    if (ws.cell(row=row, column=column).comment is None):
        ws.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws.cell(row=row, column=column).comment = Comment(str(ws.cell(row=row, column=column).comment.text) + msg_str, '')
        
    if (ws_result.cell(row=row, column=column).comment is None):
        ws_result.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws_result.cell(row=row, column=column).comment = Comment(str(ws_result.cell(row=row, column=column).comment.text) + msg_str, '')
        
    return True

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def custom_decorator(arg1):

    def outer_wrapper(view_func):
        
        def inner_wrapper(request, *args, **kwargs):
            try:
                reset_log()
                print_log('[DEBUG] P0110City.custom_decorator()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
                print_log('[DEBUG] P0110City.custom_decorator()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
                print_log('[DEBUG] P0110City.custom_decorator()関数 arg1={}'.format(arg1), 'DEBUG')
                PARAMS_SELECT_USER_PROXY = dict({
                    'USERNAME': str(request.user), 
                    'ROLE_CODE': _ROLE_CITY
                })
                SQL_SELECT_USER_PROXY = """
                    SELECT 
                        P1.ID, 
                        A1.USERNAME, 
                        P1.ROLE_CODE, 
                        P1.KEN_CODE, 
                        P1.CITY_CODE 
                    FROM USER_PROXY P1 
                    LEFT JOIN (
                        SELECT 
                            * 
                        FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                    WHERE 
                        A1.USERNAME=%(USERNAME)s AND 
                        P1.ROLE_CODE=%(ROLE_CODE)s"""
                SQL_SELECT_PROVISIONED_CONFIRMED = """
                    SELECT 
                        *
                    FROM PROVISIONED_CONFIRMED"""
                ### decoratorでビュー関数に変数を返す方法が不明のため、グローバル変数を使用した。
                global user_proxy_list
                global provisioned_confirmed_list
                user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
                provisioned_confirmed_list = PROVISIONED_CONFIRMED.objects.raw(SQL_SELECT_PROVISIONED_CONFIRMED)
        
                print_log('[DEBUG] P0110City.custom_decorator()関数 user_proxy_list={}'.format(user_proxy_list), 'DEBUG')
                print_log('[DEBUG] P0110City.custom_decorator()関数 len(user_proxy_list)={}'.format(len(user_proxy_list)), 'DEBUG')
                print_log('[DEBUG] P0110City.custom_decorator()関数 provisioned_confirmed_list={}'.format(provisioned_confirmed_list), 'DEBUG')
                print_log('[DEBUG] P0110City.custom_decorator()関数 len(provisioned_confirmed_list)={}'.format(len(provisioned_confirmed_list)), 'DEBUG')
                    
                ### デコレータの処理で警告が発生したら（user_proxy_listが正常に取得できなかったら）、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                if (user_proxy_list == False) or (
                    user_proxy_list == True and user_proxy_list[0].city_code == False):
                    print_log('[WARN] P0110City.custom_decorator()関数が警告終了しました。', 'WARN')
                    if (arg1 == 'bucket_view'):
                        template = loader.get_template('P0110City/bucket/bucket.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'browser_view'):
                        template = loader.get_template('P0110City/browser/browser.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'slide_ippan_header_id_view') or (
                          arg1 == 'apply_ippan_header_id_view') or (
                          arg1 == 'delete_ippan_header_id_view'):
                        data = {
                            'return_code': ["FALSE"], 
                        }
                        response = JsonResponse(data)
                        response['Access-Control-Allow-Origin'] = 'localhost:8000'
                        response['Access-Control-Allow-Credentials'] = 'true'
                        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
                        response['Access-Control-Allow-Methods'] = 'GET'
                        return response
                    elif (arg1 == 'download_ippan_chosa_excel_header_id_view') or (
                          arg1 == 'download_ippan_chosa_csv_header_id_view') or (
                          arg1 == 'download_ippan_summary_excel_header_id_view') or (
                          arg1 == 'download_ippan_summary_csv_header_id_view'):
                        return HttpResponseNotFound("")
                
                ### ここまで正常に処理できたら、ビュー関数を戻して、ビュー関数の処理に移行する。
                return view_func(request, *args, **kwargs)
            
            except:
                ### デコレータの処理で異常が発生したら、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                print_log('[ERROR] P0110City.custom_decorator()関数が異常終了しました。', 'ERROR')
                if (arg1 == 'bucket_view'):
                    template = loader.get_template('P0110City/bucket/bucket.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'browser_view'):
                    template = loader.get_template('P0110City/browser/browser.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'slide_ippan_header_id_view') or (
                      arg1 == 'apply_ippan_header_id_view') or (
                      arg1 == 'delete_ippan_header_id_view'):
                    data = {
                        'return_code': ["FALSE"], 
                    }
                    response = JsonResponse(data)
                    response['Access-Control-Allow-Origin'] = 'localhost:8000'
                    response['Access-Control-Allow-Credentials'] = 'true'
                    response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
                    response['Access-Control-Allow-Methods'] = 'GET'
                    return response
                elif (arg1 == 'download_ippan_chosa_excel_header_id_view') or (
                      arg1 == 'download_ippan_chosa_csv_header_id_view') or (
                      arg1 == 'download_ippan_summary_excel_header_id_view') or (
                      arg1 == 'download_ippan_summary_csv_header_id_view'):
                    return HttpResponseNotFound("")
        
        return inner_wrapper
            
    return outer_wrapper

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def browser_get(request):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 1/3.', 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'CITY_CODE': user_proxy_list[0].city_code,
                'IPPAN_CITY_UPLOAD': _PROVISIONED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _PROVISIONED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _PROVISIONED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _PROVISIONED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _PROVISIONED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _PROVISIONED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _PROVISIONED_IPPAN_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'CITY_CODE': user_proxy_list[0].city_code,
                'IPPAN_CITY_UPLOAD': _CONFIRMED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _CONFIRMED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _CONFIRMED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _CONFIRMED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _CONFIRMED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _CONFIRMED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _CONFIRMED_IPPAN_MANAGE_DISAPPROVE,
            })
        SQL_SELECT_CITY_BUCKET = """
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, -- ディスク使用量
                FILES -- ファイル格納数
            FROM CITY_BUCKET 
            WHERE 
                CITY_CODE=%(CITY_CODE)s"""
        SQL_SELECT_IPPAN_HEADER = """
            SELECT 
                I1.IPPAN_HEADER_ID, 
                I1.IPPAN_HEADER_NAME, 
                I1.KEN_CODE, 
                I1.CITY_CODE, 
                I1.KUIKI_ID,
                I1.WEATHER_ID,
                I1.UPLOAD_FILE_PATH, 
                I1.UPLOAD_FILE_NAME, 
                I1.UPLOAD_FILE_SIZE, 
                I1.SUMMARY_FILE_PATH, 
                I1.SUMMARY_FILE_NAME, 
                I1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', I1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', I1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                S1.IPPAN_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM IPPAN_HEADER I1
            LEFT JOIN (
                SELECT
                    IPPAN_HISTORY_ID,
                    IPPAN_HEADER_ID,
                    WORKFLOW_CODE
                FROM IPPAN_HISTORY
                WHERE
                    IPPAN_HISTORY_ID IN (
                        SELECT
                            MAX(IPPAN_HISTORY_ID)
                        FROM IPPAN_HISTORY
                        GROUP BY IPPAN_HEADER_ID
                    )
            ) S1 ON I1.IPPAN_HEADER_ID=S1.IPPAN_HEADER_ID
            WHERE 
                I1.CITY_CODE=%(CITY_CODE)s AND 
                I1.DELETED_AT IS NULL 
            ORDER BY I1.IPPAN_HEADER_ID"""
        
        ### HTMLタイトル部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw(SQL_SELECT_CITY_BUCKET, PARAMS)
        ### HTML一覧部分表示用
        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS)
        
        print_log('[DEBUG] P0110City.browser_get()関数 city_bucket_list={}'.format(city_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_get()関数 len(city_bucket_list)={}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_get()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_get()関数 len(ippan_header_list)={}'.format(len(ippan_header_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 2/3.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0110City.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        ### 一般資産調査員調査票ファイルの0件は正常であるため、チェックしない。

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0110City.browser_get()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'city_bucket_list': city_bucket_list, 
            'ippan_header_list': ippan_header_list, 
        }
        return True, HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0110City.browser_get()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.browser_get()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.browser_get()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数
###############################################################################
def browser_post_ippan(request):
    
    ###########################################################################
    ### 関数内関数：必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            nonlocal require_warn_list
            nonlocal require_warn_grid
            ###################################################################
            ### 関数内関数：必須チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 1/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[7:2]: 都道府県[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=7, column=2).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=2, fill=fill, message_id=IPP_REQ_KEN_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 7, 2, 
                                              IPP_REQ_MSG[IPP_REQ_KEN_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_KEN_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_KEN_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_KEN_CODE][3]])
                    
                ### セル[7:3]: 市区町村[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=7, column=3).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=3, fill=fill, message_id=IPP_REQ_CITY_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 7, 3, 
                                              IPP_REQ_MSG[IPP_REQ_CITY_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_CITY_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_CITY_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_CITY_CODE][3]])
                
                ### セル[7:4]: 水害発生月日[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=7, column=4).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=4, fill=fill, message_id=IPP_REQ_BEGIN_DATE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 7, 4, 
                                              IPP_REQ_MSG[IPP_REQ_BEGIN_DATE][0],  ### 'W0001'
                                              IPP_REQ_MSG[IPP_REQ_BEGIN_DATE][1],  ### '必須'
                                              IPP_REQ_MSG[IPP_REQ_BEGIN_DATE][2],  ### '都道府県が入力されていません。'
                                              IPP_REQ_MSG[IPP_REQ_BEGIN_DATE][3]]) ### '都道府県を入力してください。'
        
                ### セル[7:5]: 水害終了月日[任意]に値がセットされていることをチェックしない。
                
                ### セル[7:6]: 水害原因1[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=7, column=6).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_REQ_CAUSE_1_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 7, 6, 
                                              IPP_REQ_MSG[IPP_REQ_CAUSE_1_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_CAUSE_1_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_CAUSE_1_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_CAUSE_1_CODE][3]])
        
                ### セル[7:7]: 水害原因2[任意]に値がセットされていることをチェックしない。
                ### セル[7:8]: 水害原因3[任意]に値がセットされていることをチェックしない。
                
                ### セル[7:9]: 水害区域番号[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=7, column=9).value is None):                ### 2024/11/11 コメントアウトからチェックするように戻す。
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=9, fill=fill, message_id=IPP_REQ_KUIKI_ID, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 7, 9, 
                                              IPP_REQ_MSG[IPP_REQ_KUIKI_ID][0], 
                                              IPP_REQ_MSG[IPP_REQ_KUIKI_ID][1], 
                                              IPP_REQ_MSG[IPP_REQ_KUIKI_ID][2], 
                                              IPP_REQ_MSG[IPP_REQ_KUIKI_ID][3]])
        
            ###################################################################
            ### 関数内関数：必須チェック処理（0010）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 2/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=10, column=2).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=2, fill=fill, message_id=IPP_REQ_SUIKEI_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 10, 2, 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_CODE][3]])
                    
                ### セル[10:3]: 水系種別[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=10, column=3).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_REQ_SUIKEI_TYPE_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 10, 3, 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_TYPE_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_TYPE_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_TYPE_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_SUIKEI_TYPE_CODE][3]])
                    
                ### セル[10:4]: 河川・海岸名[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=10, column=4).value is None):               ### 2024/11/11 コメントアウトからチェックするように戻す。
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=4, fill=fill, message_id=IPP_REQ_KASEN_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 10, 4, 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_CODE][3]])
                    
                ### セル[10:5]: 河川種別[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=10, column=5).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_REQ_KASEN_TYPE_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 10, 5, 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_TYPE_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_TYPE_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_TYPE_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_KASEN_TYPE_CODE][3]])
                    
                ### セル[10:6]: 地盤勾配区分[必須]に値がセットされていることをチェックする。
                if (ws[ws_idx].cell(row=10, column=6).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=6, fill=fill, message_id=IPP_REQ_GRADIENT_CODE, message=IPP_REQ_MSG)
                    require_warn_list.append([ws[ws_idx].title, 10, 6, 
                                              IPP_REQ_MSG[IPP_REQ_GRADIENT_CODE][0], 
                                              IPP_REQ_MSG[IPP_REQ_GRADIENT_CODE][1], 
                                              IPP_REQ_MSG[IPP_REQ_GRADIENT_CODE][2], 
                                              IPP_REQ_MSG[IPP_REQ_GRADIENT_CODE][3]])
        
            ###################################################################
            ### 関数内関数：必須チェック処理（0020）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 3/4.', 'DEBUG')
            ### for i, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地[任意]に値がセットされていることをチェックしない。
                ### セル[14:3]: 水害区域面積の農地[任意]に値がセットされていることをチェックしない。
                ### セル[14:4]: 水害区域面積の地下[任意]に値がセットされていることをチェックしない。
                ### セル[14:6]: 工種[任意]に値がセットされていることをチェックしない。
                ### セル[14:8]: 農作物被害額[任意]に値がセットされていることをチェックしない。
                ### セル[14:10]: 異常気象コード[任意]に値がセットされていることをチェックしない。
        
            ###################################################################
            ### 関数内関数：必須チェック処理（0030）
            ### ※max_rowの20は入力部分の開始EXCEL行番号である。
            ### ※max_rowの20は町丁名・大字名、名称等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 4/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                if (max_row[ws_idx] >= 20):
                    for j in range(20, max_row[ws_idx] + 1):
                        ### セル[20:2]: 町丁名・大字名[必須]に値がセットされていることをチェックする。
                        if (ws[ws_idx].cell(row=j, column=2).value is None):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=2, fill=fill, message_id=IPP_REQ_IPPAN_NAME, message=IPP_REQ_MSG)
                            require_warn_grid.append([ws[ws_idx].title, j, 2, 
                                                      IPP_REQ_MSG[IPP_REQ_IPPAN_NAME][0], 
                                                      IPP_REQ_MSG[IPP_REQ_IPPAN_NAME][1], 
                                                      IPP_REQ_MSG[IPP_REQ_IPPAN_NAME][2], 
                                                      IPP_REQ_MSG[IPP_REQ_IPPAN_NAME][3]])
                            
                        ### セル[20:3]: 名称[必須]に値がセットされていることをチェックする。
                        if (ws[ws_idx].cell(row=j, column=3).value is None):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=3, fill=fill, message_id=IPP_REQ_BUILDING_CODE, message=IPP_REQ_MSG)
                            require_warn_grid.append([ws[ws_idx].title, j, 3, 
                                                      IPP_REQ_MSG[IPP_REQ_BUILDING_CODE][0], 
                                                      IPP_REQ_MSG[IPP_REQ_BUILDING_CODE][1], 
                                                      IPP_REQ_MSG[IPP_REQ_BUILDING_CODE][2], 
                                                      IPP_REQ_MSG[IPP_REQ_BUILDING_CODE][3]])
                            
                        ### セル[20:4]: 地上・地下被害の区分[必須]に値がセットされていることをチェックする。
                        if (ws[ws_idx].cell(row=j, column=4).value is None):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_REQ_UNDERGROUND_CODE, message=IPP_REQ_MSG)
                            require_warn_grid.append([ws[ws_idx].title, j, 4, 
                                                      IPP_REQ_MSG[IPP_REQ_UNDERGROUND_CODE][0], 
                                                      IPP_REQ_MSG[IPP_REQ_UNDERGROUND_CODE][1], 
                                                      IPP_REQ_MSG[IPP_REQ_UNDERGROUND_CODE][2], 
                                                      IPP_REQ_MSG[IPP_REQ_UNDERGROUND_CODE][3]])
                            
                        ### セル[20:5]: 浸水土砂被害の区分[必須]に値がセットされていることをチェックする。
                        if (ws[ws_idx].cell(row=j, column=5).value is None):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=5, fill=fill, message_id=IPP_REQ_FLOOD_SEDIMENT_CODE, message=IPP_REQ_MSG)
                            require_warn_grid.append([ws[ws_idx].title, j, 5, 
                                                      IPP_REQ_MSG[IPP_REQ_FLOOD_SEDIMENT_CODE][0], 
                                                      IPP_REQ_MSG[IPP_REQ_FLOOD_SEDIMENT_CODE][1], 
                                                      IPP_REQ_MSG[IPP_REQ_FLOOD_SEDIMENT_CODE][2], 
                                                      IPP_REQ_MSG[IPP_REQ_FLOOD_SEDIMENT_CODE][3]])
                            
                        ### セル[20:6]: 被害建物棟数、床下浸水[任意]に値がセットされていることをチェックしない。
                        ### セル[20:7]: 被害建物棟数、1cm〜49cm[任意]に値がセットされていることをチェックしない。
                        ### セル[20:8]: 被害建物棟数、50cm〜99cm[任意]に値がセットされていることをチェックしない。
                        ### セル[20:9]: 被害建物棟数、1m以上[任意]に値がセットされていることをチェックしない。
                        ### セル[20:10]: 被害建物棟数、半壊[任意]に値がセットされていることをチェックしない。
                        ### セル[20:11]: 被害建物棟数、全壊・流失[任意]に値がセットされていることをチェックしない。
                        ### セル[20:12]: 被害建物の延床面積[任意]に値がセットされていることをチェックしない。
                        ### セル[20:13]: 被災世帯数[任意]に値がセットされていることをチェックしない。
                        ### セル[20:14]: 被災事業所数[任意]に値がセットされていることをチェックしない。
                        ### セル[20:15]: 農家・漁家戸数、床下浸水[任意]に値がセットされていることをチェックしない。
                        ### セル[20:16]: 農家・漁家戸数、1cm〜49cm[任意]に値がセットされていることをチェックしない。
                        ### セル[20:17]: 農家・漁家戸数、50cm〜99cm[任意]に値がセットされていることをチェックしない。
                        ### セル[20:18]: 農家・漁家戸数、1m以上・半壊[任意]に値がセットされていることをチェックしない。
                        ### セル[20:19]: 農家・漁家戸数、全壊・流失[任意]に値がセットされていることをチェックしない。
                        ### セル[20:20]: 事業所従業者数、床下浸水[任意]に値がセットされていることをチェックしない。
                        ### セル[20:21]: 事業所従業者数、1cm〜49cm[任意]に値がセットされていることをチェックしない。
                        ### セル[20:22]: 事業所従業者数、50cm〜99cm[任意]に値がセットされていることをチェックしない。
                        ### セル[20:23]: 事業所従業者数、1m以上・半壊[任意]に値がセットされていることをチェックしない。
                        ### セル[20:24]: 事業所従業者数、全壊・流失[任意]に値がセットされていることをチェックしない。
                        ### セル[20:25]: 事業所の産業区分[任意]に値がセットされていることをチェックしない。
                        ### セル[20:26]: 地下空間の利用形態[任意]に値がセットされていることをチェックしない。
                        ### セル[20:27]: 備考[任意]に値がセットされていることをチェックしない。
            return True
        
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            nonlocal format_warn_list
            nonlocal format_warn_grid
            ###################################################################
            ### 関数内関数：形式チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 1/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[7:2]: 都道府県について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=7, column=2).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=2).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=2, fill=fill, message_id=IPP_FOR_KEN_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 7, 2, 
                                                 IPP_FOR_MSG[IPP_FOR_KEN_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_KEN_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_KEN_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_KEN_CODE][3]])
            
                ### セル[7:3]: 市区町村について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=7, column=3).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=3).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=3, fill=fill, message_id=IPP_FOR_CITY_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 7, 3, 
                                                 IPP_FOR_MSG[IPP_FOR_CITY_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_CITY_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_CITY_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_CITY_CODE][3]])
          
                ### セル[7:4]: 水害発生月日について形式が正しいことをチェックしない。
                ### if (ws[ws_idx].cell(row=7, column=4).value is None): ### COMMENT OUT 2023/11/22
                ###     pass
                ### else:
                ###     if (isdate(ws[ws_idx].cell(row=7, column=4).value) == False):
                ###         add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=4, fill=fill, message_id=IPP_FOR_BEGIN_DATE, message=IPP_FOR_MSG)
                ###         format_warn_list.append([ws[ws_idx].title, 7, 4, 
                ###                                  IPP_FOR_MSG[IPP_FOR_BEGIN_DATE][0], 
                ###                                  IPP_FOR_MSG[IPP_FOR_BEGIN_DATE][1], 
                ###                                  IPP_FOR_MSG[IPP_FOR_BEGIN_DATE][2], 
                ###                                  IPP_FOR_MSG[IPP_FOR_BEGIN_DATE][3]])
            
                ### セル[7:5]: 水害終了月日について形式が正しいことをチェックしない。
                ### if (ws[ws_idx].cell(row=7, column=5).value is None): ### COMMENT OUT 2023/11/22
                ###     pass
                ### else:
                ###     if (isdate(ws[ws_idx].cell(row=7, column=5).value) == False):
                ###         add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=5, fill=fill, message_id=IPP_FOR_END_DATE, message=IPP_FOR_MSG)
                ###         format_warn_list.append([ws[ws_idx].title, 7, 5, 
                ###                                  IPP_FOR_MSG[IPP_FOR_END_DATE][0], 
                ###                                  IPP_FOR_MSG[IPP_FOR_END_DATE][1], 
                ###                                  IPP_FOR_MSG[IPP_FOR_END_DATE][2], 
                ###                                  IPP_FOR_MSG[IPP_FOR_END_DATE][3]])
                    
                ### セル[7:6]: 水害原因1について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=7, column=6).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=6).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_FOR_CAUSE_1_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 7, 6, 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_1_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_1_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_1_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_1_CODE][3]])
                    
                ### セル[7:7]: 水害原因2について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=7, column=7).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=7).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=7, fill=fill, message_id=IPP_FOR_CAUSE_2_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 7, 7, 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_2_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_2_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_2_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_2_CODE][3]])
                    
                ### セル[7:8]: 水害原因3について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=7, column=8).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=8).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=8, fill=fill, message_id=IPP_FOR_CAUSE_3_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 7, 8, 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_3_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_3_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_3_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_CAUSE_3_CODE][3]])
                    
                ### セル[7:9]: 水害区域番号について形式が正しいことをチェックする。 ### 2024/11/11 コメントアウトからチェックするように戻す。
                ### if (ws[ws_idx].cell(row=7, column=9).value is None):            ### 2024/11/13 COMMENT OUT
                ###     pass
                ### else:
                ###     if (split_name_code(ws[ws_idx].cell(row=7, column=9).value)[-1].isdecimal() == False):
                ###         add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=9, fill=fill, message_id=IPP_FOR_KUIKI_ID, message=IPP_FOR_MSG)
                ###         format_warn_list.append([ws[ws_idx].title, 7, 9, 
                ###                                  IPP_FOR_MSG[IPP_FOR_KUIKI_ID][0], 
                ###                                  IPP_FOR_MSG[IPP_FOR_KUIKI_ID][1], 
                ###                                  IPP_FOR_MSG[IPP_FOR_KUIKI_ID][2], 
                ###                                  IPP_FOR_MSG[IPP_FOR_KUIKI_ID][3]])
                if (ws[ws_idx].cell(row=7, column=9).value is None):                ### 2024/11/13 ADD
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=7, column=9).value, int) == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=9, fill=fill, message_id=IPP_FOR_KUIKI_ID, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 7, 9, 
                                                 IPP_FOR_MSG[IPP_FOR_KUIKI_ID][0], 
                                                 IPP_FOR_MSG[IPP_FOR_KUIKI_ID][1], 
                                                 IPP_FOR_MSG[IPP_FOR_KUIKI_ID][2], 
                                                 IPP_FOR_MSG[IPP_FOR_KUIKI_ID][3]])
        
            ###################################################################
            ### 関数内関数：形式チェック処理（0010）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 2/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=10, column=2).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=10, column=2).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=2, fill=fill, message_id=IPP_FOR_SUIKEI_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 10, 2, 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_CODE][3]])
                    
                ### セル[10:3]: 水系種別について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=10, column=3).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_FOR_SUIKEI_TYPE_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_TYPE_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_TYPE_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_TYPE_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_SUIKEI_TYPE_CODE][3]])
                    
                ### セル[10:4]: 河川・海岸名について形式が正しいことをチェックする。
                ### if (ws[ws_idx].cell(row=10, column=4).value is None): ### COMMENT OUT 2023/11/22
                ###     pass
                ### else:
                ###     if (split_name_code(ws[ws_idx].cell(row=10, column=4).value)[-1].isdecimal() == False):
                ###         add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=4, fill=fill, message_id=IPP_FOR_KASEN_CODE, message=IPP_FOR_MSG)
                ###         format_warn_list.append([ws[ws_idx].title, 10, 4, 
                ###                                  IPP_FOR_MSG[IPP_FOR_KASEN_CODE][0], 
                ###                                  IPP_FOR_MSG[IPP_FOR_KASEN_CODE][1], 
                ###                                  IPP_FOR_MSG[IPP_FOR_KASEN_CODE][2], 
                ###                                  IPP_FOR_MSG[IPP_FOR_KASEN_CODE][3]])
                    
                ### セル[10:5]: 河川種別について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=10, column=5).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_FOR_KASEN_TYPE_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_TYPE_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_TYPE_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_TYPE_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_TYPE_CODE][3]])
                    
                ### セル[10:6]: 地盤勾配区分について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=10, column=6).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=10, column=6).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=6, fill=fill, message_id=IPP_FOR_GRADIENT_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 10, 6, 
                                                 IPP_FOR_MSG[IPP_FOR_GRADIENT_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_GRADIENT_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_GRADIENT_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_GRADIENT_CODE][3]])
        
            ###################################################################
            ### 関数内関数：形式チェック処理（0020）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 3/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=2).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=2).value, int) == False) and (
                        isinstance(ws[ws_idx].cell(row=14, column=2).value, float) == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=2, fill=fill, message_id=IPP_FOR_RESIDENTIAL_AREA, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 14, 2, 
                                                 IPP_FOR_MSG[IPP_FOR_RESIDENTIAL_AREA][0], 
                                                 IPP_FOR_MSG[IPP_FOR_RESIDENTIAL_AREA][1], 
                                                 IPP_FOR_MSG[IPP_FOR_RESIDENTIAL_AREA][2], 
                                                 IPP_FOR_MSG[IPP_FOR_RESIDENTIAL_AREA][3]])
        
                ### セル[14:3]: 水害区域面積の農地について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=3).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=3).value, int) == False) and (
                        isinstance(ws[ws_idx].cell(row=14, column=3).value, float) == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=3, fill=fill, message_id=IPP_FOR_AGRICULTURAL_AREA, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 14, 3, 
                                                 IPP_FOR_MSG[IPP_FOR_AGRICULTURAL_AREA][0], 
                                                 IPP_FOR_MSG[IPP_FOR_AGRICULTURAL_AREA][1], 
                                                 IPP_FOR_MSG[IPP_FOR_AGRICULTURAL_AREA][2], 
                                                 IPP_FOR_MSG[IPP_FOR_AGRICULTURAL_AREA][3]])
                    
                ### セル[14:4]: 水害区域面積の地下について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=4).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=4).value, int) == False) and (
                        isinstance(ws[ws_idx].cell(row=14, column=4).value, float) == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=4, fill=fill, message_id=IPP_FOR_UNDERGROUND_AREA, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 14, 4, 
                                                 IPP_FOR_MSG[IPP_FOR_UNDERGROUND_AREA][0], 
                                                 IPP_FOR_MSG[IPP_FOR_UNDERGROUND_AREA][1], 
                                                 IPP_FOR_MSG[IPP_FOR_UNDERGROUND_AREA][2], 
                                                 IPP_FOR_MSG[IPP_FOR_UNDERGROUND_AREA][3]])
                    
                ### セル[14:6]: 工種について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=6).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1].isdecimal() == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_FOR_KASEN_KAIGAN_CODE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_KAIGAN_CODE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_KAIGAN_CODE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_KAIGAN_CODE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_KASEN_KAIGAN_CODE][3]])
                    
                ### セル[14:8]: 農作物被害額について形式が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=8).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=8).value, int) == False) and (
                        isinstance(ws[ws_idx].cell(row=14, column=8).value, float) == False):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=8, fill=fill, message_id=IPP_FOR_CROP_DAMAGE, message=IPP_FOR_MSG)
                        format_warn_list.append([ws[ws_idx].title, 14, 8, 
                                                 IPP_FOR_MSG[IPP_FOR_CROP_DAMAGE][0], 
                                                 IPP_FOR_MSG[IPP_FOR_CROP_DAMAGE][1], 
                                                 IPP_FOR_MSG[IPP_FOR_CROP_DAMAGE][2], 
                                                 IPP_FOR_MSG[IPP_FOR_CROP_DAMAGE][3]])
                    
                ### セル[14:10]: 異常気象コードについて形式が正しいことをチェックしない。
                    
            ###################################################################
            ### 関数内関数：形式チェック処理（0030）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 4/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                if (max_row[ws_idx] >= 20):
                    for j in range(20, max_row[ws_idx] + 1):
                        ### セル[20:2]: 町丁名・大字名について形式が正しいことをチェックしない。
                        
                        ### セル[20:3]: 名称について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=3).value is None):
                            pass
                        else:
                            if (split_name_code(ws[ws_idx].cell(row=j, column=3).value)[-1].isdecimal() == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=3, fill=fill, message_id=IPP_FOR_BUILDING_CODE, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 3, 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_CODE][0], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_CODE][1], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_CODE][2], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_CODE][3]])
                            
                        ### セル[20:4]: 地上・地下被害の区分について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=4).value is None):
                            pass
                        else:
                            if (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1].isdecimal() == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_FOR_UNDERGROUND_CODE, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 4, 
                                                         IPP_FOR_MSG[IPP_FOR_UNDERGROUND_CODE][0], 
                                                         IPP_FOR_MSG[IPP_FOR_UNDERGROUND_CODE][1], 
                                                         IPP_FOR_MSG[IPP_FOR_UNDERGROUND_CODE][2], 
                                                         IPP_FOR_MSG[IPP_FOR_UNDERGROUND_CODE][3]])
                            
                        ### セル[20:5]: 浸水土砂被害の区分について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=5).value is None):
                            pass
                        else:
                            if (split_name_code(ws[ws_idx].cell(row=j, column=5).value)[-1].isdecimal() == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=5, fill=fill, message_id=IPP_FOR_FLOOD_SEDIMENT_CODE, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 5, 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOD_SEDIMENT_CODE][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOD_SEDIMENT_CODE][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOD_SEDIMENT_CODE][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOD_SEDIMENT_CODE][3]])
                            
                        ### セル[20:6]: 被害建物棟数, 床下浸水について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=6).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=6).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=6).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=6, fill=fill, message_id=IPP_FOR_BUILDING_LV00, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 6, 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV00][0], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV00][1], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV00][2], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV00][3]])
                            
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cmについて形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=7).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=7).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=7).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=7, fill=fill, message_id=IPP_FOR_BUILDING_LV01_49, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 7, 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV01_49][0], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV01_49][1], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV01_49][2], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV01_49][3]])
                            
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cmについて形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=8).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=8).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=8).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=8, fill=fill, message_id=IPP_FOR_BUILDING_LV50_99, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 8, 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV50_99][0], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV50_99][1], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV50_99][2], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV50_99][3]])
                            
                        ### セル[20:9]: 被害建物棟数, 1m以上について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=9).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=9).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=9).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=9, fill=fill, message_id=IPP_FOR_BUILDING_LV100, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 9, 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV100][0], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV100][1], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV100][2], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_LV100][3]])
                            
                        ### セル[20:10]: 被害建物棟数, 半壊について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=10).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=10).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=10).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=10, fill=fill, message_id=IPP_FOR_BUILDING_HALF, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 10, 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_HALF][0], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_HALF][1], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_HALF][2], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_HALF][3]])
                            
                        ### セル[20:11]: 被害建物棟数, 全壊・流失について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=11).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=11).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=11).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=11, fill=fill, message_id=IPP_FOR_BUILDING_FULL, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 11, 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_FULL][0], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_FULL][1], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_FULL][2], 
                                                         IPP_FOR_MSG[IPP_FOR_BUILDING_FULL][3]])
                            
                        ### セル[20:12]: 被害建物の延床面積について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=12).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=12).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=12).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=12, fill=fill, message_id=IPP_FOR_FLOOR_AREA, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 12, 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOR_AREA][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOR_AREA][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOR_AREA][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FLOOR_AREA][3]])
                            
                        ### セル[20:13]: 被災世帯数について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=13).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=13).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=13).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=13, fill=fill, message_id=IPP_FOR_FAMILY, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 13, 
                                                         IPP_FOR_MSG[IPP_FOR_FAMILY][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FAMILY][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FAMILY][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FAMILY][3]])
                            
                        ### セル[20:14]: 被災事業所数について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=14).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=14).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=14).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=14, fill=fill, message_id=IPP_FOR_OFFICE, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 14, 
                                                         IPP_FOR_MSG[IPP_FOR_OFFICE][0], 
                                                         IPP_FOR_MSG[IPP_FOR_OFFICE][1], 
                                                         IPP_FOR_MSG[IPP_FOR_OFFICE][2], 
                                                         IPP_FOR_MSG[IPP_FOR_OFFICE][3]])
                            
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=15).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=15).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=15).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=15, fill=fill, message_id=IPP_FOR_FARMER_FISHER_LV00, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 15, 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV00][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV00][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV00][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV00][3]])
                            
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmについて形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=16).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=16).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=16).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=16, fill=fill, message_id=IPP_FOR_FARMER_FISHER_LV01_49, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 16, 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV01_49][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV01_49][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV01_49][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV01_49][3]])
                            
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmについて形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=17).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=17).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=17).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=17, fill=fill, message_id=IPP_FOR_FARMER_FISHER_LV50_99, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 17, 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV50_99][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV50_99][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV50_99][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV50_99][3]])
                            
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=18).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=18).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=18).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=18, fill=fill, message_id=IPP_FOR_FARMER_FISHER_LV100, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 18, 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV100][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV100][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV100][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_LV100][3]])
                            
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=19).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=19).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=19).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=19, fill=fill, message_id=IPP_FOR_FARMER_FISHER_FULL, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 19, 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_FULL][0], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_FULL][1], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_FULL][2], 
                                                         IPP_FOR_MSG[IPP_FOR_FARMER_FISHER_FULL][3]])
                            
                        ### セル[20:20]: 事業所従業者数, 床下浸水について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=20).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=20).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=20).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=20, fill=fill, message_id=IPP_FOR_EMPLOYEE_LV00, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 20, 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV00][0], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV00][1], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV00][2], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV00][3]])
                            
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmについて形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=21).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=21).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=21).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=21, fill=fill, message_id=IPP_FOR_EMPLOYEE_LV01_49, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 21, 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV01_49][0], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV01_49][1], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV01_49][2], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV01_49][3]])
                            
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmについて形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=22).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=22).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=22).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=22, fill=fill, message_id=IPP_FOR_EMPLOYEE_LV50_99, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 22, 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV50_99][0], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV50_99][1], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV50_99][2], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV50_99][3]])
                            
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=23).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=23).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=23).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=23, fill=fill, message_id=IPP_FOR_EMPLOYEE_LV100, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 23, 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV100][0], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV100][1], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV100][2], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_LV100][3]])
                            
                        ### セル[20:24]: 事業所従業者数, 全壊・流失について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=24).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=24).value, int) == False) and (
                                isinstance(ws[ws_idx].cell(row=j, column=24).value, float) == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=24, fill=fill, message_id=IPP_FOR_EMPLOYEE_FULL, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 24, 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_FULL][0], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_FULL][1], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_FULL][2], 
                                                         IPP_FOR_MSG[IPP_FOR_EMPLOYEE_FULL][3]])
                            
                        ### セル[20:25]: 事業所の産業区分について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=25).value is None):
                            pass
                        else:
                            if (split_name_code(ws[ws_idx].cell(row=j, column=25).value)[-1].isdecimal() == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=25, fill=fill, message_id=IPP_FOR_INDUSTRY_CODE, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 25, 
                                                         IPP_FOR_MSG[IPP_FOR_INDUSTRY_CODE][0], 
                                                         IPP_FOR_MSG[IPP_FOR_INDUSTRY_CODE][1], 
                                                         IPP_FOR_MSG[IPP_FOR_INDUSTRY_CODE][2], 
                                                         IPP_FOR_MSG[IPP_FOR_INDUSTRY_CODE][3]])
                            
                        ### セル[20:26]: 地下空間の利用形態について形式が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=26).value is None):
                            pass
                        else:
                            if (split_name_code(ws[ws_idx].cell(row=j, column=26).value)[-1].isdecimal() == False):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=26, fill=fill, message_id=IPP_FOR_USAGE_CODE, message=IPP_FOR_MSG)
                                format_warn_grid.append([ws[ws_idx].title, j, 26, 
                                                         IPP_FOR_MSG[IPP_FOR_USAGE_CODE][0], 
                                                         IPP_FOR_MSG[IPP_FOR_USAGE_CODE][1], 
                                                         IPP_FOR_MSG[IPP_FOR_USAGE_CODE][2], 
                                                         IPP_FOR_MSG[IPP_FOR_USAGE_CODE][3]])
                            
                        ### セル[20:27]: 備考について形式が正しいことをチェックしない。
            return True
        
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            nonlocal range_warn_list
            nonlocal range_warn_grid
            ###################################################################
            ### 関数内関数：範囲チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 1/4.', 'DEBUG')
            ### for i, _ in enumerate(ws):
                ### セル[7:2]: 都道府県について範囲が正しいことをチェックしない。
                ### セル[7:3]: 市区町村について範囲が正しいことをチェックしない。
                ### セル[7:4]: 水害発生月日について範囲が正しいことをチェックしない。
                ### セル[7:5]: 水害終了月日について範囲が正しいことをチェックしない。
                ### セル[7:6]: 水害原因1について範囲が正しいことをチェックしない。
                ### セル[7:7]: 水害原因2について範囲が正しいことをチェックしない。
                ### セル[7:8]: 水害原因3について範囲が正しいことをチェックしない。
                ### セル[7:9]: 水害区域番号について範囲が正しいことをチェックしない。
    
            ###################################################################
            ### 関数内関数：範囲チェック処理（0010）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 2/4.', 'DEBUG')
            ### for i, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名について範囲が正しいことをチェックしない。
                ### セル[10:3]: 水系種別について範囲が正しいことをチェックしない。
                ### セル[10:4]: 河川・海岸名について範囲が正しいことをチェックしない。
                ### セル[10:5]: 河川種別について範囲が正しいことをチェックしない。
                ### セル[10:6]: 地盤勾配区分について範囲が正しいことをチェックしない。
    
            ###################################################################
            ### 関数内関数：範囲チェック処理（0020）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 3/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地について範囲が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=2).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=2).value, int) == True) or (
                        isinstance(ws[ws_idx].cell(row=14, column=2).value, float) == True):
                        if (float(ws[ws_idx].cell(row=14, column=2).value) < 0):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=2, fill=fill, message_id=IPP_RAN_RESIDENTIAL_AREA, message=IPP_RAN_MSG)
                            range_warn_list.append([ws[ws_idx].title, 14, 2, 
                                                    IPP_RAN_MSG[IPP_RAN_RESIDENTIAL_AREA][0], 
                                                    IPP_RAN_MSG[IPP_RAN_RESIDENTIAL_AREA][1], 
                                                    IPP_RAN_MSG[IPP_RAN_RESIDENTIAL_AREA][2], 
                                                    IPP_RAN_MSG[IPP_RAN_RESIDENTIAL_AREA][3]])
                    
                ### セル[14:3]: 水害区域面積の農地について範囲が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=3).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=3).value, int) == True) or (
                        isinstance(ws[ws_idx].cell(row=14, column=3).value, float) == True):
                        if (float(ws[ws_idx].cell(row=14, column=3).value) < 0):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=3, fill=fill, message_id=IPP_RAN_AGRICULTURAL_AREA, message=IPP_RAN_MSG)
                            range_warn_list.append([ws[ws_idx].title, 14, 3, 
                                                    IPP_RAN_MSG[IPP_RAN_AGRICULTURAL_AREA][0], 
                                                    IPP_RAN_MSG[IPP_RAN_AGRICULTURAL_AREA][1], 
                                                    IPP_RAN_MSG[IPP_RAN_AGRICULTURAL_AREA][2], 
                                                    IPP_RAN_MSG[IPP_RAN_AGRICULTURAL_AREA][3]])
        
                ### セル[14:4]: 水害区域面積の地下について範囲が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=4).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=4).value, int) == True) or (
                        isinstance(ws[ws_idx].cell(row=14, column=4).value, float) == True):
                        if (float(ws[ws_idx].cell(row=14, column=4).value) < 0):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=4, fill=fill, message_id=IPP_RAN_UNDERGROUND_AREA, message=IPP_RAN_MSG)
                            range_warn_list.append([ws[ws_idx].title, 14, 4, 
                                                    IPP_RAN_MSG[IPP_RAN_UNDERGROUND_AREA][0], 
                                                    IPP_RAN_MSG[IPP_RAN_UNDERGROUND_AREA][1], 
                                                    IPP_RAN_MSG[IPP_RAN_UNDERGROUND_AREA][2], 
                                                    IPP_RAN_MSG[IPP_RAN_UNDERGROUND_AREA][3]])
                    
                ### セル[14:6]: 工種について範囲が正しいことをチェックしない。
                ### セル[14:8]: 農作物被害額について範囲が正しいことをチェックする。
                if (ws[ws_idx].cell(row=14, column=8).value is None):
                    pass
                else:
                    if (isinstance(ws[ws_idx].cell(row=14, column=8).value, int) == True) or (
                        isinstance(ws[ws_idx].cell(row=14, column=8).value, float) == True):
                        if (float(ws[ws_idx].cell(row=14, column=8).value) < 0):
                            add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=8, fill=fill, message_id=IPP_RAN_CROP_DAMAGE, message=IPP_RAN_MSG)
                            range_warn_list.append([ws[ws_idx].title, 14, 8, 
                                                    IPP_RAN_MSG[IPP_RAN_CROP_DAMAGE][0], 
                                                    IPP_RAN_MSG[IPP_RAN_CROP_DAMAGE][1], 
                                                    IPP_RAN_MSG[IPP_RAN_CROP_DAMAGE][2], 
                                                    IPP_RAN_MSG[IPP_RAN_CROP_DAMAGE][3]])
        
                ### セル[14:10]: 異常気象コードについて範囲が正しいことをチェックしない。
    
            ###################################################################
            ### 関数内関数：範囲チェック処理（0030）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 4/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                if (max_row[ws_idx] >= 20):
                    for j in range(20, max_row[ws_idx] + 1):
                        ### セル[20:2]: 町丁名・大字名について範囲が正しいことをチェックしない。
                        ### セル[20:3]: 名称について範囲が正しいことをチェックしない。
                        ### セル[20:4]: 地上・地下被害の区分について範囲が正しいことをチェックしない。
                        ### セル[20:5]: 浸水土砂被害の区分について範囲が正しいことをチェックしない。
                        ### セル[20:6]: 被害建物棟数, 床下浸水について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=6).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=6).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=6).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=6).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=6, fill=fill, message_id=IPP_RAN_BUILDING_LV00, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 6, 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV00][0], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV00][1], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV00][2], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV00][3]])
        
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cmについて範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=7).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=7).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=7).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=7).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=7, fill=fill, message_id=IPP_RAN_BUILDING_LV01_49, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 7, 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV01_49][0], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV01_49][1], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV01_49][2], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV01_49][3]])
                        
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cmについて範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=8).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=8).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=8).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=8).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=8, fill=fill, message_id=IPP_RAN_BUILDING_LV50_99, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 8, 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV50_99][0], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV50_99][1], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV50_99][2], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV50_99][3]])
        
                        ### セル[20:9]: 被害建物棟数, 1m以上について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=9).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=9).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=9).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=9).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=9, fill=fill, message_id=IPP_RAN_BUILDING_LV100, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 9, 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV100][0], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV100][1], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV100][2], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_LV100][3]])
        
                        ### セル[20:10]: 被害建物棟数, 半壊について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=10).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=10).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=10).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=10).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=10, fill=fill, message_id=IPP_RAN_BUILDING_HALF, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 10, 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_HALF][0], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_HALF][1], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_HALF][2], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_HALF][3]])
        
                        ### セル[20:11]: 被害建物棟数, 全壊・流失について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=11).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=11).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=11).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=11).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=11, fill=fill, message_id=IPP_RAN_BUILDING_FULL, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 11, 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_FULL][0], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_FULL][1], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_FULL][2], 
                                                            IPP_RAN_MSG[IPP_RAN_BUILDING_FULL][3]])
        
                        ### セル[20:12]: 被害建物の延床面積について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=12).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=12).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=12).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=12).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=12, fill=fill, message_id=IPP_RAN_FLOOR_AREA, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 12, 
                                                            IPP_RAN_MSG[IPP_RAN_FLOOR_AREA][0], 
                                                            IPP_RAN_MSG[IPP_RAN_FLOOR_AREA][1], 
                                                            IPP_RAN_MSG[IPP_RAN_FLOOR_AREA][2], 
                                                            IPP_RAN_MSG[IPP_RAN_FLOOR_AREA][3]])
        
                        ### セル[20:13]: 被災世帯数について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=13).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=13).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=13).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=13).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=13, fill=fill, message_id=IPP_RAN_FAMILY, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 13, 
                                                            IPP_RAN_MSG[IPP_RAN_FAMILY][0], 
                                                            IPP_RAN_MSG[IPP_RAN_FAMILY][1], 
                                                            IPP_RAN_MSG[IPP_RAN_FAMILY][2], 
                                                            IPP_RAN_MSG[IPP_RAN_FAMILY][3]])
                        
                        ### セル[20:14]: 被災事業所数について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=14).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=14).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=14).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=14).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=14, fill=fill, message_id=IPP_RAN_OFFICE, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 14, 
                                                            IPP_RAN_MSG[IPP_RAN_OFFICE][0], 
                                                            IPP_RAN_MSG[IPP_RAN_OFFICE][1], 
                                                            IPP_RAN_MSG[IPP_RAN_OFFICE][2], 
                                                            IPP_RAN_MSG[IPP_RAN_OFFICE][3]])
        
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=15).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=15).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=15).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=15).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=15, fill=fill, message_id=IPP_RAN_FARMER_FISHER_LV00, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 15, 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV00][0], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV00][1], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV00][2], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV00][3]])
        
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmについて範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=16).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=16).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=16).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=16).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=16, fill=fill, message_id=IPP_RAN_FARMER_FISHER_LV01_49, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 16, 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV01_49][0], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV01_49][1], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV01_49][2], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV01_49][3]])
        
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmについて範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=17).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=17).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=17).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=17).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=17, fill=fill, message_id=IPP_RAN_FARMER_FISHER_LV50_99, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 17, 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV50_99][0], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV50_99][1], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV50_99][2], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV50_99][3]])
        
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=18).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=18).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=18).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=18).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=18, fill=fill, message_id=IPP_RAN_FARMER_FISHER_LV100, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 18, 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV100][0], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV100][1], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV100][2], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_LV100][3]])
        
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=19).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=19).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=19).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=19).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=19, fill=fill, message_id=IPP_RAN_FARMER_FISHER_FULL, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 19, 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_FULL][0], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_FULL][1], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_FULL][2], 
                                                            IPP_RAN_MSG[IPP_RAN_FARMER_FISHER_FULL][3]])
        
                        ### セル[20:20]: 事業所従業者数, 床下浸水について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=20).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=20).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=20).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=20).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=20, fill=fill, message_id=IPP_RAN_EMPLOYEE_LV00, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 20, 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV00][0], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV00][1], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV00][2], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV00][3]])
        
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmについて範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=21).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=21).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=21).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=21).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=21, fill=fill, message_id=IPP_RAN_EMPLOYEE_LV01_49, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 21, 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV01_49][0], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV01_49][1], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV01_49][2], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV01_49][3]])
        
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmについて範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=22).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=22).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=22).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=22).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=22, fill=fill, message_id=IPP_RAN_EMPLOYEE_LV50_99, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 22, 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV50_99][0], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV50_99][1], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV50_99][2], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV50_99][3]])
        
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=23).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=23).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=23).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=23).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=23, fill=fill, message_id=IPP_RAN_EMPLOYEE_LV100, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 23, 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV100][0], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV100][1], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV100][2], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_LV100][3]])
        
                        ### セル[20:24]: 事業所従業者数, 全壊・流失について範囲が正しいことをチェックする。
                        if (ws[ws_idx].cell(row=j, column=24).value is None):
                            pass
                        else:
                            if (isinstance(ws[ws_idx].cell(row=j, column=24).value, int) == True) or (
                                isinstance(ws[ws_idx].cell(row=j, column=24).value, float) == True):
                                if (float(ws[ws_idx].cell(row=j, column=24).value) < 0):
                                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=24, fill=fill, message_id=IPP_RAN_EMPLOYEE_FULL, message=IPP_RAN_MSG)
                                    range_warn_grid.append([ws[ws_idx].title, j, 24, 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_FULL][0], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_FULL][1], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_FULL][2], 
                                                            IPP_RAN_MSG[IPP_RAN_EMPLOYEE_FULL][3]])
        
                        ### セル[20:25]: 事業所の産業区分について範囲が正しいことをチェックしない。
                        ### セル[20:26]: 地下空間の利用形態について範囲が正しいことをチェックしない。
                        ### セル[20:27]: 備考について範囲が正しいことをチェックしない。
            return True
        
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            nonlocal correlate_warn_list
            nonlocal correlate_warn_grid
            ###################################################################
            ### 関数内関数：相関チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 1/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[7:2]: 都道府県が何かの値のときに、相関する市区町村名は正しく選択されているか。
                ### セル[7:3]: 市区町村が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[7:4]: 水害発生月日 vs セル[7:5]: 水害終了月日
                ### if (ws[ws_idx].cell(row=7, column=4).value is None) or ( ### COMMENT OUT 2023/11/22
                ###     ws[ws_idx].cell(row=7, column=5).value is None):
                ###     pass
                ### else:
                ###     if (isdate(ws[ws_idx].cell(row=7, column=4).value) == False) or (
                ###         isdate(ws[ws_idx].cell(row=7, column=5).value) == False):
                ###         pass
                ###     else:
                ###         ### 水害発生月日 > 水害終了月日である。
                ###         if (datetime.strptime(ws[ws_idx].cell(row=7, column=4).value, '%Y/%m/%d') > datetime.strptime(ws[ws_idx].cell(row=7, column=5).value, '%Y/%m/%d')): 
                ###             add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=4, fill=fill, message_id=IPP_COR_BEGIN_DATE_END_DATE, message=IPP_COR_MSG)
                ###             add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=5, fill=fill, message_id=IPP_COR_BEGIN_DATE_END_DATE, message=IPP_COR_MSG)
                ###             correlate_warn_list.append([ws[ws_idx].title, 7, 4, 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][0], 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][1], 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][2], 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][3]])
                ###             correlate_warn_list.append([ws[ws_idx].title, 7, 5, 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][0], 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][1], 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][2], 
                ###                                         IPP_COR_MSG[IPP_COR_BEGIN_DATE_END_DATE][3]])
        
                ### セル[7:5]: 水害終了月日が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[7:4]: 水害発生月日 vs セル[7:5]: 水害終了月日
                ### セル[7:6]: 水害原因1 vs セル[14:6]: 工種
                if (ws[ws_idx].cell(row=7, column=6).value is None) or (
                    ws[ws_idx].cell(row=14, column=6).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=6).value)[-1].isdecimal() == False) or (
                        split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1].isdecimal() == False):
                        pass
                    else:
                        ### 水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、相関する工種は、「1:河川」である。
                        if (split_name_code(ws[ws_idx].cell(row=7, column=6).value)[-1] in [10, 20, 30, 40]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_01][3]])
                                
                        ### 水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、相関する工種は、「3:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=6).value)[-1] in [50, 80, 90]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 3):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_02][3]])
                                
                        ### 水害原因が「93:波浪」の場合、相関する工種は、「2:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=6).value)[-1] in [93]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 2):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_03][3]])
                                
                        ### 水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、相関する工種は、「1:河川」「2:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=6).value)[-1] in [60, 91, 92]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1) or (
                                split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 2):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_04][3]])
                                
                        ### 水害原因が「70:土石流」の場合、相関する工種は、「1:河川」「3:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=6).value)[-1] in [70]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1) or (
                                split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 3):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_1_CODE_KASEN_KAIGAN_CODE_05][3]])
        
                ### セル[7:7]: 水害原因2 vs セル[14:6]: 工種
                if (ws[ws_idx].cell(row=7, column=7).value is None) or (
                    ws[ws_idx].cell(row=14, column=6).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=7).value)[-1].isdecimal() == False) or (
                        split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1].isdecimal() == False):
                        pass
                    else:
                        ### 水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、相関する工種は、「1:河川」である。
                        if (split_name_code(ws[ws_idx].cell(row=7, column=7).value)[-1] in [10, 20, 30, 40]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=7, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 7, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_01][3]])
                                
                        ### 水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、相関する工種は、「3:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=7).value)[-1] in [50, 80, 90]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 3):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=7, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 7, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_02][3]])
                                
                        ### 水害原因が「93:波浪」の場合、相関する工種は、「2:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=7).value)[-1] in [93]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 2):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=7, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 7, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_03][3]])
                                
                        ### 水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、相関する工種は、「1:河川」「2:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=7).value)[-1] in [60, 91, 92]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1) or (
                                split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 2):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=7, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 7, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_04][3]])
                                
                        ### 水害原因が「70:土石流」の場合、相関する工種は、「1:河川」「3:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=7).value)[-1] in [70]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1) or (
                                split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 3):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=7, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 7, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_2_CODE_KASEN_KAIGAN_CODE_05][3]])
        
                ### セル[7:8]: 水害原因3 vs セル[14:6]: 工種
                if (ws[ws_idx].cell(row=7, column=8).value is None) or (
                    ws[ws_idx].cell(row=14, column=6).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=7, column=8).value)[-1].isdecimal() == False) or (
                        split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1].isdecimal() == False):
                        pass
                    else:
                        ### 水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、相関する工種は、「1:河川」である。
                        if (split_name_code(ws[ws_idx].cell(row=7, column=8).value)[-1] in [10, 20, 30, 40]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=8, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 8, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_01][3]])
                                
                        ### 水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、相関する工種は、「3:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=8).value)[-1] in [50, 80, 90]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 3):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=8, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 8, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_02][3]])
                                
                        ### 水害原因が「93:波浪」の場合、相関する工種は、「2:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=8).value)[-1] in [93]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 2):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=8, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 8, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_03][3]])
                                
                        ### 水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、相関する工種は、「1:河川」「2:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=8).value)[-1] in [60, 91, 92]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1) or (
                                split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 2):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=8, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 8, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_04][3]])
                                
                        ### 水害原因が「70:土石流」の場合、相関する工種は、「1:河川」「3:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=7, column=8).value)[-1] in [70]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 1) or (
                                split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] == 3):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=8, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 7, 8, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_CAUSE_3_CODE_KASEN_KAIGAN_CODE_05][3]])
        
                ### セル[7:9]: 水害区域番号が何かの値のときに、相関する他項目は正しく選択されているか。
        
            ###################################################################
            ### 関数内関数：相関チェック処理（0010）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 2/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名が何かの値のときに、相関する水系種別は正しく選択されているか。
                ### if (ws[ws_idx].cell(row=10, column=2).value is None):
                ###     result_correlate_list.append([ws[ws_idx].title, 10, 2, constants.MESSAGE[][0], constants.MESSAGE[][1], constants.MESSAGE[][2], constants.MESSAGE[][3], constants.MESSAGE[][4]])
                ### セル[10:2]: 水系・沿岸名が何かの値のときに、相関する工種は正しく選択されているか。
                ### if (ws[ws_idx].cell(row=10, column=2).value is None) or (
                ###     ws[ws_idx].cell(row=14, column=6).value is None):
                ###     pass
                ### else:
                ###     if (split_name_code(ws[ws_idx].cell(row=10, column=2).value)[-1].isdecimal() == False) or (
                ###         split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1].isdecimal() == False):
                ###         pass
                ###     else:
                ###         ### 水系・沿岸名が「水系」のときに、相関する工種は、「1:河川」である。
                ###         if (split_name_code(ws[ws_idx].cell(row=10, column=2).value)[-1] == ):
                ###             if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] in [1]):
                ###                 pass
                ###             else:
                ###                 add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=)
                ###                 correlate_warn_list.append([ws[ws_idx].title, 14, 6, ])
                ###         ### 水系・沿岸名が「沿岸」のときに、相関する工種は、「2:海岸」である。
                ###         elif (split_name_code(ws[ws_idx].cell(row=10, column=2).value)[-1] == ):
                ###             if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] in [2]):
                ###                 pass
                ###             else:
                ###                 add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=)
                ###                 correlate_warn_list.append([ws[ws_idx].title, 14, 6, ])
                ###         ### 水系・沿岸名が「河川海岸以外」のときに、相関する工種は、「3:河川海岸以外」である。
                ###         elif (split_name_code(ws[ws_idx].cell(row=10, column=2).value)[-1] == ):
                ###             if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] in [3]):
                ###                 pass
                ###             else:
                ###                 add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=)
                ###                 correlate_warn_list.append([ws[ws_idx].title, 14, 6, ])
                ### セル[10:3]: 水系種別 vs セル[10:5]: 河川種別
                if (ws[ws_idx].cell(row=10, column=3).value is None) or (
                    ws[ws_idx].cell(row=10, column=5).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1].isdecimal() == False) or (
                        split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1].isdecimal() == False):
                        pass
                    else:
                        ### 水系種別が「1:一級」のときに、相関する河川種別は、「1:直轄」「2:指定」「4:準用」「5:普通」である。
                        if (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] == 1):
                            if (split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1] in [1, 2, 4, 5]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_01][3]])
    
                        ### 水系種別が「2:二級」のときに、相関する河川種別は、「3:二級」「4:準用」「5:普通」である。
                        elif (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] == 2):
                            if (split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1] in [3, 4, 5]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_02][3]])
    
                        ### 水系種別が「3:準用」のときに、相関する河川種別は、「4:準用」「5:普通」である。
                        elif (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] == 3):
                            if (split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1] in [4, 5]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_03][3]])
    
                        ### 水系種別が「4:普通」のときに、相関する河川種別は、「5:普通」である。
                        elif (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] == 4):
                            if (split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1] in [5]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_04][3]])
    
                        ### 水系種別が「5:沿岸」のときに、相関する河川種別は、「6:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] == 5):
                            if (split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1] in [6]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_05][3]])
    
                        ### 水系種別が「6:河川海岸以外」のときに、相関する河川種別は、「7:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] == 6):
                            if (split_name_code(ws[ws_idx].cell(row=10, column=5).value)[-1] in [7]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_TYPE_CODE_06][3]])
    
                ### セル[10:3]: 水系種別 vs セル[14:6]: 工種
                if (ws[ws_idx].cell(row=10, column=3).value is None) or (
                    ws[ws_idx].cell(row=14, column=6).value is None):
                    pass
                else:
                    if (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1].isdecimal() == False) or (
                        split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1].isdecimal() == False):
                        pass
                    else:
                        ### 水系種別が「1:一級」「2:二級」「3:準用」「4:普通」のときに、相関する工種は、「1:河川」である。
                        if (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] in [1, 2, 3, 4]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] in [1]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_01][3]])
                    
                        ### 水系種別が「5:沿岸」のときに、相関する工種は、「2:海岸」である。
                        elif (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] in [5]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] in [2]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_02][3]])
                                
                        ### 水系種別が「6:河川海岸以外」のときに、相関する工種は、「3:河川海岸以外」である。
                        elif (split_name_code(ws[ws_idx].cell(row=10, column=3).value)[-1] in [6]):
                            if (split_name_code(ws[ws_idx].cell(row=14, column=6).value)[-1] in [6]):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=6, fill=fill, message_id=IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][3]])
                                correlate_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][0], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][1], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][2], 
                                                            IPP_COR_MSG[IPP_COR_SUIKEI_TYPE_CODE_KASEN_KAIGAN_CODE_03][3]])
    
                ### セル[10:4]: 河川・海岸名が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[10:5]: 河川種別が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[10:6]: 地盤勾配区分が何かの値のときに、相関する他項目は正しく選択されているか。
        
            ###################################################################
            ### 関数内関数：相関チェック処理（0020）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 3/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[14:3]: 水害区域面積の農地 vs セル[14:8]: 農作物被害額
                ### セル[14:3]: 水害区域面積の農地がNoneのとき、農作物被害額はNoneが正しい。
                if (ws[ws_idx].cell(row=14, column=3).value is None):
                    if (ws[ws_idx].cell(row=14, column=8).value is None):
                        pass
                    else:
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=3, fill=fill, message_id=IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01, message=IPP_COR_MSG)
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=8, fill=fill, message_id=IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01, message=IPP_COR_MSG)
                        correlate_warn_list.append([ws[ws_idx].title, 14, 3, 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][0], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][1], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][2], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][3]])
                        correlate_warn_list.append([ws[ws_idx].title, 14, 8, 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][0], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][1], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][2], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_01][3]])
                else:
                    if (ws[ws_idx].cell(row=14, column=8).value is None):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=3, fill=fill, message_id=IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02, message=IPP_COR_MSG)
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=8, fill=fill, message_id=IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02, message=IPP_COR_MSG)
                        correlate_warn_list.append([ws[ws_idx].title, 14, 3, 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][0], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][1], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][2], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][3]])
                        correlate_warn_list.append([ws[ws_idx].title, 14, 8, 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][0], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][1], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][2], 
                                                    IPP_COR_MSG[IPP_COR_AGRICULTURAL_AREA_CROP_DAMAGE_02][3]])
    
                ### セル[14:2]: 水害区域面積の宅地が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:3]: 水害区域面積の農地が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:4]: 水害区域面積の地下が何かの値のときに、相関する他項目は正しく選択されているか。
                ### 水害区域面積の宅地、農地、地下のいずれかに入力されているか。
                if (ws[ws_idx].cell(row=14, column=2).value is None) and (
                    ws[ws_idx].cell(row=14, column=3).value is None) and (
                    ws[ws_idx].cell(row=14, column=4).value is None):
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=2, fill=fill, message_id=IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA, message=IPP_COR_MSG)
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=3, fill=fill, message_id=IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA, message=IPP_COR_MSG)
                    add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=4, fill=fill, message_id=IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA, message=IPP_COR_MSG)
                    correlate_warn_list.append([ws[ws_idx].title, 14, 2, 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][0], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][1], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][2], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][3]])
                    correlate_warn_list.append([ws[ws_idx].title, 14, 3, 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][0], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][1], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][2], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][3]])
                    correlate_warn_list.append([ws[ws_idx].title, 14, 4, 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][0], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][1], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][2], 
                                                IPP_COR_MSG[IPP_COR_RESIDENTIAL_AGRICULTURAL_UNDERGROUND_AREA][3]])
                
                ### セル[14:6]: 工種が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:8]: 農作物被害額が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:10]: 異常気象が何かの値のときに、相関する他項目は正しく選択されているか。
        
            ###################################################################
            ### 関数内関数：相関チェック処理（0030）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 4/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                if (max_row[ws_idx] >= 20):
                    for j in range(20, max_row[ws_idx] + 1):
                        ### セル[20:2]: 町丁名・大字名が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:3]: 名称が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:4]: 地上・地下被害の区分 vs セル[14:2]: 水害区域面積の宅地、またはセル[14:3]: 水害区域面積の農地
                        if (ws[ws_idx].cell(row=j, column=4).value is None):
                            pass
                        else:
                            if (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1].isdecimal() == False):
                                pass
                            else:
                                ### 地上・地下被害の区分が「地上のみ:1」のときに、相関する水害区域面積の宅地または水害区域面積の農地が入力されているか。
                                if (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1] in [1]):
                                    if (ws[ws_idx].cell(row=14, column=2).value is None) and (
                                        ws[ws_idx].cell(row=14, column=3).value is None):
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01, message=IPP_COR_MSG)
                                        correlate_warn_list.append([ws[ws_idx].title, j, 4, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_01][3]])
    
                                ### 地上・地下被害の区分が「地上部分:2」のときに、相関する水害区域面積の宅地または水害区域面積の農地が入力されているか。
                                elif (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1] in [2]):
                                    if (ws[ws_idx].cell(row=14, column=2).value is None) and (
                                        ws[ws_idx].cell(row=14, column=3).value is None):
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02, message=IPP_COR_MSG)
                                        correlate_warn_list.append([ws[ws_idx].title, j, 4, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_02][3]])
    
                                ### 地上・地下被害の区分が「地下部分:3」のときに、相関する水害区域面積の地下が入力されているか。
                                elif (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1] in [3]):
                                    if (ws[ws_idx].cell(row=14, column=4).value is None):
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03, message=IPP_COR_MSG)
                                        correlate_warn_list.append([ws[ws_idx].title, j, 4, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_03][3]])
    
                                ### 地上・地下被害の区分が「地下のみ:4」のときに、相関する水害区域面積の地下が入力されているか。
                                elif (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1] in [4]):
                                    if (ws[ws_idx].cell(row=14, column=4).value is None):
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04, message=IPP_COR_MSG)
                                        correlate_warn_list.append([ws[ws_idx].title, j, 4, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_RESIDENTIAL_AGRICULTURAL_AREA_04][3]])
    
                        ### セル[20:4]: 地上・地下被害の区分 vs セル[20:26]: 地下空間の利用形態
                        if (ws[ws_idx].cell(row=j, column=4).value is None):
                            pass
                        else:
                            if (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1].isdecimal() == False):
                                pass
                            else:
                                ### 地上・地下被害の区分が「1:」「2:」の場合、相関する地下空間の利用形態は、何らかの値が入力される。
                                if (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1] in [1, 2]):
                                    if (ws[ws_idx].cell(row=j, column=27).value is None):
                                        pass
                                    else:
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01, message=IPP_COR_MSG)
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=27, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01, message=IPP_COR_MSG)
                                        correlate_warn_list.append([ws[ws_idx].title, j, 4, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][3]])
                                        correlate_warn_list.append([ws[ws_idx].title, j, 27, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_01][3]])
    
                                elif (split_name_code(ws[ws_idx].cell(row=j, column=4).value)[-1] in [3, 4]):
                                    if (ws[ws_idx].cell(row=j, column=27).value is None):
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02, message=IPP_COR_MSG)
                                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=27, fill=fill, message_id=IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02, message=IPP_COR_MSG)
                                        correlate_warn_list.append([ws[ws_idx].title, j, 4, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][3]])
                                        correlate_warn_list.append([ws[ws_idx].title, j, 27, 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][0], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][1], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][2], 
                                                                    IPP_COR_MSG[IPP_COR_UNDERGROUND_CODE_USAGE_CODE_02][3]])
                            
                        ### セル[20:5]: 浸水土砂被害の区分が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:6]: 被害建物棟数, 床下浸水 vs セル[20:12]: 延床面積
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cm vs セル[20:12]: 延床面積
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cm vs セル[20:12]: 延床面積
                        ### セル[20:9]: 被害建物棟数, 1m以上 vs セル[20:12]: 延床面積
                        ### セル[20:10]: 被害建物棟数, 半壊 vs セル[20:12]: 延床面積
                        ### セル[20:11]: 被害建物棟数, 全壊・流失 vs セル[20:12]: 延床面積
                        if (ws[ws_idx].cell(row=j, column=6).value is None) and (
                            ws[ws_idx].cell(row=j, column=7).value is None) and (
                            ws[ws_idx].cell(row=j, column=8).value is None) and (
                            ws[ws_idx].cell(row=j, column=9).value is None) and (
                            ws[ws_idx].cell(row=j, column=10).value is None) and (
                            ws[ws_idx].cell(row=j, column=11).value is None):
                            if (ws[ws_idx].cell(row=j, column=12).value is None):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=6, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=7, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=8, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=9, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=10, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=11, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=12, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, j, 6, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 7, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 8, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 9, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 10, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 11, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 12, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_01][3]])
                        else:
                            if (ws[ws_idx].cell(row=j, column=12).value is None):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=6, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=7, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=8, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=9, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=10, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=11, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=12, fill=fill, message_id=IPP_COR_BUILDING_FLOOR_AREA_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, j, 6, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 7, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 8, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 9, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 10, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 11, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 12, 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][0], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][1], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][2], 
                                                            IPP_COR_MSG[IPP_COR_BUILDING_FLOOR_AREA_02][3]])
                            
                        ### セル[20:12]: 被害建物の延床面積が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:13]: 被災世帯数が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:14]: 被災事業所数 vs セル[20:25]: 事業所の産業区分
                        if (ws[ws_idx].cell(row=j, column=14).value is None):
                            if (ws[ws_idx].cell(row=j, column=25).value is None):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=14, fill=fill, message_id=IPP_COR_OFFICE_INDUSTRY_CODE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=25, fill=fill, message_id=IPP_COR_OFFICE_INDUSTRY_CODE_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, j, 14, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 25, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_01][3]])
                        else:
                            if (ws[ws_idx].cell(row=j, column=25).value is None):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=14, fill=fill, message_id=IPP_COR_OFFICE_INDUSTRY_CODE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=25, fill=fill, message_id=IPP_COR_OFFICE_INDUSTRY_CODE_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, j, 14, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 25, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_INDUSTRY_CODE_02][3]])
    
                        ### セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数, 床下浸水
                        ### セル[20:14]: 被災事業所数 vs セル[20:21]: 事業所従業者数, 1cm〜49cm
                        ### セル[20:14]: 被災事業所数 vs セル[20:22]: 事業所従業者数, 50cm〜99cm
                        ### セル[20:14]: 被災事業所数 vs セル[20:23]: 事業所従業者数, 1m以上・半壊
                        ### セル[20:14]: 被災事業所数 vs セル[20:24]: 事業所従業者数, 全壊・流失
                        if (ws[ws_idx].cell(row=j, column=14).value is None):
                            if (ws[ws_idx].cell(row=j, column=20).value is None) and (
                                ws[ws_idx].cell(row=j, column=21).value is None) and (
                                ws[ws_idx].cell(row=j, column=22).value is None) and (
                                ws[ws_idx].cell(row=j, column=23).value is None) and (
                                ws[ws_idx].cell(row=j, column=24).value is None):
                                pass
                            else:
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=14, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=20, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=21, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=22, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=23, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_01, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=24, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_01, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, j, 14, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 20, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 21, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 22, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 23, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 24, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_01][3]])
                        else:
                            if (ws[ws_idx].cell(row=j, column=20).value is None) and (
                                ws[ws_idx].cell(row=j, column=21).value is None) and (
                                ws[ws_idx].cell(row=j, column=22).value is None) and (
                                ws[ws_idx].cell(row=j, column=23).value is None) and (
                                ws[ws_idx].cell(row=j, column=24).value is None):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=14, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=20, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=21, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=22, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=23, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_02, message=IPP_COR_MSG)
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=24, fill=fill, message_id=IPP_COR_OFFICE_EMPLOYEE_02, message=IPP_COR_MSG)
                                correlate_warn_list.append([ws[ws_idx].title, j, 14, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 20, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 21, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 22, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 23, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][3]])
                                correlate_warn_list.append([ws[ws_idx].title, j, 24, 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][0], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][1], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][2], 
                                                            IPP_COR_MSG[IPP_COR_OFFICE_EMPLOYEE_02][3]])
                            
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmが何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmが何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:20]: 事業所従業者数, 床下浸水が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmが何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmが何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:24]: 事業所従業者数, 全壊・流失が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:25]: 事業所の産業区分が何かの値のときに、相関する他項目は正しく選択されているか。 参照  
                        ### セル[20:26]: 地下空間の利用形態が何かの値のときに、相関する他項目は正しく選択されているか。 参照 
                        ### セル[20:27]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            return True
        
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            nonlocal compare_warn_list
            nonlocal compare_warn_grid
            ###################################################################
            ### 関数内関数：突合チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 1/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[7:2]: 都道府県についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=7, column=2).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=7, column=2).value not in list(ken_code_list)) and (
                        ws[ws_idx].cell(row=7, column=2).value not in list(ken_name_list)) and (
                        ws[ws_idx].cell(row=7, column=2).value not in list(ken_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=2, fill=fill, message_id=IPP_COM_KEN_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 7, 2, 
                                                  IPP_COM_MSG[IPP_COM_KEN_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_KEN_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_KEN_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_KEN_CODE][3]])
                    
                ### セル[7:3]: 市区町村についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=7, column=3).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=7, column=3).value not in list(city_code_list)) and (
                        ws[ws_idx].cell(row=7, column=3).value not in list(city_name_list)) and (
                        ws[ws_idx].cell(row=7, column=3).value not in list(city_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=3, fill=fill, message_id=IPP_COM_CITY_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 7, 3, 
                                                  IPP_COM_MSG[IPP_COM_CITY_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_CITY_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_CITY_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_CITY_CODE][3]])
                    
                ### セル[7:4]: 水害発生月日についてデータベースに登録されている値と突合せチェックする。
                ### セル[7:5]: 水害終了月日についてデータベースに登録されている値と突合せチェックする。
                ### セル[7:6]: 水害原因1についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=7, column=6).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=7, column=6).value not in list(cause_code_list)) and (
                        ws[ws_idx].cell(row=7, column=6).value not in list(cause_name_list)) and (
                        ws[ws_idx].cell(row=7, column=6).value not in list(cause_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=6, fill=fill, message_id=IPP_COM_CAUSE_1_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 7, 6, 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_1_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_1_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_1_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_1_CODE][3]])
                    
                ### セル[7:7]: 水害原因2についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=7, column=7).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=7, column=7).value not in list(cause_code_list)) and (
                        ws[ws_idx].cell(row=7, column=7).value not in list(cause_name_list)) and (
                        ws[ws_idx].cell(row=7, column=7).value not in list(cause_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=7, fill=fill, message_id=IPP_COM_CAUSE_2_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 7, 7, 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_2_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_2_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_2_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_2_CODE][3]])
                    
                ### セル[7:8]: 水害原因3についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=7, column=8).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=7, column=8).value not in list(cause_code_list)) and (
                        ws[ws_idx].cell(row=7, column=8).value not in list(cause_name_list)) and (
                        ws[ws_idx].cell(row=7, column=8).value not in list(cause_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=7, column=8, fill=fill, message_id=IPP_COM_CAUSE_3_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 7, 8, 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_3_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_3_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_3_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_CAUSE_3_CODE][3]])
                    
                ### セル[7:9]: 水害区域番号についてデータベースに登録されている値と突合せチェックしない。
        
            ###################################################################
            ### 関数内関数：突合チェック処理（0010）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 2/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=10, column=2).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=10, column=2).value not in list(suikei_code_list)) and (
                        ws[ws_idx].cell(row=10, column=2).value not in list(suikei_name_list)) and (
                        ws[ws_idx].cell(row=10, column=2).value not in list(suikei_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=2, fill=fill, message_id=IPP_COM_SUIKEI_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 10, 2, 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_CODE][3]])
                    
                ### セル[10:3]: 水系種別についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=10, column=3).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=10, column=3).value not in list(suikei_type_code_list)) and (
                        ws[ws_idx].cell(row=10, column=3).value not in list(suikei_type_name_list)) and (
                        ws[ws_idx].cell(row=10, column=3).value not in list(suikei_type_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=3, fill=fill, message_id=IPP_COM_SUIKEI_TYPE_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 10, 3, 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_TYPE_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_TYPE_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_TYPE_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_SUIKEI_TYPE_CODE][3]])
                    
                ### セル[10:4]: 河川・海岸名についてデータベースに登録されている値と突合せチェックする。
                ### if (ws[ws_idx].cell(row=10, column=4).value is None): ### 2024/11/12 コメントアウトからチェックするように戻す。
                ###     pass
                ### else:
                ###     if (ws[ws_idx].cell(row=10, column=4).value not in list(kasen_code_list)) and (
                ###         ws[ws_idx].cell(row=10, column=4).value not in list(kasen_name_list)) and (
                ###         ws[ws_idx].cell(row=10, column=4).value not in list(kasen_name_code_list)):
                ###         add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=4, fill=fill, message_id=IPP_COM_KASEN_CODE, message=IPP_COM_MSG)
                ###         compare_warn_list.append([ws[ws_idx].title, 10, 4, 
                ###                                   IPP_COM_MSG[IPP_COM_KASEN_CODE][0], 
                ###                                   IPP_COM_MSG[IPP_COM_KASEN_CODE][1], 
                ###                                   IPP_COM_MSG[IPP_COM_KASEN_CODE][2], 
                ###                                   IPP_COM_MSG[IPP_COM_KASEN_CODE][3]])
                    
                ### セルE10[10:5]: 河川種別についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=10, column=5).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=10, column=5).value not in list(kasen_type_code_list)) and (
                        ws[ws_idx].cell(row=10, column=5).value not in list(kasen_type_name_list)) and (
                        ws[ws_idx].cell(row=10, column=5).value not in list(kasen_type_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=5, fill=fill, message_id=IPP_COM_KASEN_TYPE_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 10, 5, 
                                                  IPP_COM_MSG[IPP_COM_KASEN_TYPE_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_KASEN_TYPE_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_KASEN_TYPE_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_KASEN_TYPE_CODE][3]])
                    
                ### セル[10:6]: 地盤勾配区分についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=10, column=6).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=10, column=6).value not in list(gradient_code_list)) and (
                        ws[ws_idx].cell(row=10, column=6).value not in list(gradient_name_list)) and (
                        ws[ws_idx].cell(row=10, column=6).value not in list(gradient_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=10, column=6, fill=fill, message_id=IPP_COM_GRADIENT_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 10, 6, 
                                                  IPP_COM_MSG[IPP_COM_GRADIENT_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_GRADIENT_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_GRADIENT_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_GRADIENT_CODE][3]])
        
            ###################################################################
            ### 関数内関数：突合チェック処理（0020）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 3/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地についてデータベースに登録されている値と突合せチェックする。
                ### セル[14:3]: 水害区域面積の農地についてデータベースに登録されている値と突合せチェックする。
                ### セル[14:4]: 水害区域面積の地下についてデータベースに登録されている値と突合せチェックする。
                ### セル[14:6]: 工種についてデータベースに登録されている値と突合せチェックする。
                if (ws[ws_idx].cell(row=14, column=6).value is None):
                    pass
                else:
                    if (ws[ws_idx].cell(row=14, column=6).value not in list(kasen_kaigan_code_list)) and (
                        ws[ws_idx].cell(row=14, column=6).value not in list(kasen_kaigan_name_list)) and (
                        ws[ws_idx].cell(row=14, column=6).value not in list(kasen_kaigan_name_code_list)):
                        add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=14, column=2, fill=fill, message_id=IPP_COM_KASEN_KAIGAN_CODE, message=IPP_COM_MSG)
                        compare_warn_list.append([ws[ws_idx].title, 14, 6, 
                                                  IPP_COM_MSG[IPP_COM_KASEN_KAIGAN_CODE][0], 
                                                  IPP_COM_MSG[IPP_COM_KASEN_KAIGAN_CODE][1], 
                                                  IPP_COM_MSG[IPP_COM_KASEN_KAIGAN_CODE][2], 
                                                  IPP_COM_MSG[IPP_COM_KASEN_KAIGAN_CODE][3]])
                    
                ### セル[14:8]: 農作物被害額についてデータベースに登録されている値と突合せチェックしない。
                ### セル[14:10]: 異常気象コードについてデータベースに登録されている値と突合せチェックしない。
        
            ###################################################################
            ### 関数内関数：突合チェック処理（0030）
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 4/4.', 'DEBUG')
            for ws_idx, _ in enumerate(ws):
                if (max_row[ws_idx] >= 20):
                    for j in range(20, max_row[ws_idx] + 1):
                        ### セル[20:2]: 町丁名・大字名についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:3]: 名称についてデータベースに登録されている値と突合せチェックする。
                        if (ws[ws_idx].cell(row=j, column=4).value is None):
                            pass
                        else:
                            if (ws[ws_idx].cell(row=j, column=3).value not in list(building_code_list)) and (
                                ws[ws_idx].cell(row=j, column=3).value not in list(building_name_list)) and (
                                ws[ws_idx].cell(row=j, column=3).value not in list(building_name_code_list)):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=3, fill=fill, message_id=IPP_COM_BUILDING_CODE, message=IPP_COM_MSG)
                                compare_warn_grid.append([ws[ws_idx].title, j, 3, 
                                                          IPP_COM_MSG[IPP_COM_BUILDING_CODE][0], 
                                                          IPP_COM_MSG[IPP_COM_BUILDING_CODE][1], 
                                                          IPP_COM_MSG[IPP_COM_BUILDING_CODE][2], 
                                                          IPP_COM_MSG[IPP_COM_BUILDING_CODE][3]])
                            
                        ### セル[20:4]: 地上・地下被害の区分についてデータベースに登録されている値と突合せチェックする。
                        if (ws[ws_idx].cell(row=j, column=4).value is None):
                            pass
                        else:
                            if (ws[ws_idx].cell(row=j, column=4).value not in list(underground_code_list)) and (
                                ws[ws_idx].cell(row=j, column=4).value not in list(underground_name_list)) and (
                                ws[ws_idx].cell(row=j, column=4).value not in list(underground_name_code_list)):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=4, fill=fill, message_id=IPP_COM_UNDERGROUND_CODE, message=IPP_COM_MSG)
                                compare_warn_grid.append([ws[ws_idx].title, j, 4, 
                                                          IPP_COM_MSG[IPP_COM_UNDERGROUND_CODE][0], 
                                                          IPP_COM_MSG[IPP_COM_UNDERGROUND_CODE][1], 
                                                          IPP_COM_MSG[IPP_COM_UNDERGROUND_CODE][2], 
                                                          IPP_COM_MSG[IPP_COM_UNDERGROUND_CODE][3]])
                            
                        ### セル[20:5]: 浸水土砂被害の区分についてデータベースに登録されている値と突合せチェックする。
                        if (ws[ws_idx].cell(row=j, column=5).value is None):
                            pass
                        else:
                            if (ws[ws_idx].cell(row=j, column=5).value not in list(flood_sediment_code_list)) and (
                                ws[ws_idx].cell(row=j, column=5).value not in list(flood_sediment_name_list)) and (
                                ws[ws_idx].cell(row=j, column=5).value not in list(flood_sediment_name_code_list)):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=5, fill=fill, message_id=IPP_COM_FLOOD_SEDIMENT_CODE, message=IPP_COM_MSG)
                                compare_warn_grid.append([ws[ws_idx].title, j, 5, 
                                                          IPP_COM_MSG[IPP_COM_FLOOD_SEDIMENT_CODE][0], 
                                                          IPP_COM_MSG[IPP_COM_FLOOD_SEDIMENT_CODE][1], 
                                                          IPP_COM_MSG[IPP_COM_FLOOD_SEDIMENT_CODE][2], 
                                                          IPP_COM_MSG[IPP_COM_FLOOD_SEDIMENT_CODE][3]])
                            
                        ### セル[20:6]: 被害建物棟数, 床下浸水についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cmについてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cmについてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:9]: 被害建物棟数, 1m以上についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:10]: 被害建物棟数, 半壊についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:11]: 被害建物棟数, 全壊・流失についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:12]: 被害建物の延床面積についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:13]: 被災世帯数についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:14]: 被災事業所数についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmについてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmについてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:20]: 事業所従業者数, 床下浸水についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmについてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmについてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:24]: 事業所従業者数, 全壊・流失についてデータベースに登録されている値と突合せチェックしない。
                        ### セル[20:25]: 事業所の産業区分についてデータベースに登録されている値と突合せチェックする。
                        if (ws[ws_idx].cell(row=j, column=25).value is None):
                            pass
                        else:
                            if (ws[ws_idx].cell(row=j, column=25).value not in list(industry_code_list)) and (
                                ws[ws_idx].cell(row=j, column=25).value not in list(industry_name_list)) and (
                                ws[ws_idx].cell(row=j, column=25).value not in list(industry_name_code_list)):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=25, fill=fill, message_id=IPP_COM_INDUSTRY_CODE, message=IPP_COM_MSG)
                                compare_warn_grid.append([ws[ws_idx].title, j, 25, 
                                                          IPP_COM_MSG[IPP_COM_INDUSTRY_CODE][0], 
                                                          IPP_COM_MSG[IPP_COM_INDUSTRY_CODE][1], 
                                                          IPP_COM_MSG[IPP_COM_INDUSTRY_CODE][2], 
                                                          IPP_COM_MSG[IPP_COM_INDUSTRY_CODE][3]])
                            
                        ### セル[20:26]: 地下空間の利用形態についてデータベースに登録されている値と突合せチェックする。
                        if (ws[ws_idx].cell(row=j, column=26).value is None):
                            pass
                        else:
                            if (ws[ws_idx].cell(row=j, column=26).value not in list(usage_code_list)) and (
                                ws[ws_idx].cell(row=j, column=26).value not in list(usage_name_list)) and (
                                ws[ws_idx].cell(row=j, column=26).value not in list(usage_name_code_list)):
                                add_comment(ws=ws[ws_idx], ws_result=ws_result[ws_idx], row=j, column=26, fill=fill, message_id=IPP_COM_USAGE_CODE, message=IPP_COM_MSG)
                                compare_warn_grid.append([ws[ws_idx].title, j, 26, 
                                                          IPP_COM_MSG[IPP_COM_USAGE_CODE][0], 
                                                          IPP_COM_MSG[IPP_COM_USAGE_CODE][1], 
                                                          IPP_COM_MSG[IPP_COM_USAGE_CODE][2], 
                                                          IPP_COM_MSG[IPP_COM_USAGE_CODE][3]])
                            
                        ### セル[20:27]: 備考についてデータベースに登録されている値と突合せチェックしない。
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：シートがNONE（NULL）か否かの判別処理
    ### ※NONE（NULL）ではないセルを見つけたら、False：NONE（NULL）ではないをリターンする。
    ###########################################################################
    def is_sheet_none(ws):
        try:
            ### セル[7:2]: 都道府県がNONE（NULL）か否かを判別しない。
            ### セル[7:3]: 市区町村がNONE（NULL）か否かを判別しない。
            ### セル[7:4]: 水害発生月日がNONE（NULL）か否かを判別する。
            ### セル[7:5]: 水害終了月日がNONE（NULL）か否かを判別する。
            ### セル[7:6]: 水害原因1がNONE（NULL）か否かを判別する。
            ### セル[7:7]: 水害原因2がNONE（NULL）か否かを判別する。
            ### セル[7:8]: 水害原因3がNONE（NULL）か否かを判別する。
            ### セル[7:9]: 水害区域番号がNONE（NULL）か否かを判別する。
            ### セル[10:2]: 水系・沿岸名がNONE（NULL）か否かを判別する。
            ### セル[10:3]: 水系種別がNONE（NULL）か否かを判別する。
            ### セル[10:4]: 河川・海岸名がNONE（NULL）か否かを判別する。
            ### セル[10:5]: 河川種別がNONE（NULL）か否かを判別する。
            ### セル[10:6]: 地盤勾配区分がNONE（NULL）か否かを判別する。
            ### セル[14:2]: 水害区域面積の宅地がNONE（NULL）か否かを判別する。
            ### セル[14:3]: 水害区域面積の農地がNONE（NULL）か否かを判別する。
            ### セル[14:4]: 水害区域面積の地下がNONE（NULL）か否かを判別する。
            ### セル[14:6]: 工種がNONE（NULL）か否かを判別する。
            ### セル[14:8]: 農作物被害額がNONE（NULL）か否かを判別する。
            ### セル[14:10]: 異常気象コードがNONE（NULL）か否かを判別する。
            ### ※NONE（NULL）ではないセルを見つけたら、False：NONE（NULL）ではないをリターンする。
            if ws.cell(row=7, column=4).value is not None: return False
            if ws.cell(row=7, column=5).value is not None: return False
            if ws.cell(row=7, column=6).value is not None: return False
            if ws.cell(row=7, column=7).value is not None: return False
            if ws.cell(row=7, column=8).value is not None: return False
            if ws.cell(row=7, column=9).value is not None: return False

            if ws.cell(row=10, column=2).value is not None: return False
            if ws.cell(row=10, column=3).value is not None: return False
            if ws.cell(row=10, column=4).value is not None: return False
            if ws.cell(row=10, column=5).value is not None: return False
            if ws.cell(row=10, column=6).value is not None: return False

            if ws.cell(row=14, column=2).value is not None: return False
            if ws.cell(row=14, column=3).value is not None: return False
            if ws.cell(row=14, column=4).value is not None: return False
            if ws.cell(row=14, column=6).value is not None: return False
            if ws.cell(row=14, column=8).value is not None: return False
            if ws.cell(row=14, column=10).value is not None: return False

            ### セル[20:2] ws.max_rowから順番に20行までチェックする。
            max_row_temp = 19
            for i in range(ws.max_row + 1, 19, -1):
                if (ws.cell(row=i, column=2).value is not None) or (
                    ws.cell(row=i, column=3).value is not None) or (
                    ws.cell(row=i, column=4).value is not None) or (
                    ws.cell(row=i, column=5).value is not None) or (
                    ws.cell(row=i, column=6).value is not None) or (
                    ws.cell(row=i, column=7).value is not None) or (
                    ws.cell(row=i, column=8).value is not None) or (
                    ws.cell(row=i, column=9).value is not None) or (
                    ws.cell(row=i, column=10).value is not None) or (
                    ws.cell(row=i, column=11).value is not None) or (
                    ws.cell(row=i, column=12).value is not None) or (
                    ws.cell(row=i, column=13).value is not None) or (
                    ws.cell(row=i, column=14).value is not None) or (
                    ws.cell(row=i, column=15).value is not None) or (
                    ws.cell(row=i, column=16).value is not None) or (
                    ws.cell(row=i, column=17).value is not None) or (
                    ws.cell(row=i, column=18).value is not None) or (
                    ws.cell(row=i, column=19).value is not None) or (
                    ws.cell(row=i, column=20).value is not None) or (
                    ws.cell(row=i, column=21).value is not None) or (
                    ws.cell(row=i, column=22).value is not None) or (
                    ws.cell(row=i, column=23).value is not None) or (
                    ws.cell(row=i, column=24).value is not None) or (
                    ws.cell(row=i, column=25).value is not None) or (
                    ws.cell(row=i, column=26).value is not None) or (
                    ws.cell(row=i, column=27).value is not None):
                    max_row_temp = i
                    break
            if max_row_temp >= 20: return False
            
            return True                                                        ### True：NONE（NULL）をリターンする。
        
        except:
            return None                                                        ### NONE：エラーをリターンする。
    
    try:
        #######################################################################
        #######################################################################
        ### 局所変数セット処理(0010)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 1/18.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_warn_list = []
        require_warn_grid = []

        ### 形式チェック用の局所変数を初期化する。
        format_warn_list = []
        format_warn_grid = []

        ### 範囲チェック用の局所変数を初期化する。
        range_warn_list = []
        range_warn_grid = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_warn_list = []
        correlate_warn_grid = []

        ### 突合せチェック用の局所変数を初期化する。
        compare_warn_list = []
        compare_warn_grid = []
    
        #######################################################################
        ### フォーム検証処理(0020)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 2/18.', 'DEBUG')
        form = UploadIppanForm(request.POST, request.FILES)
        if form.is_valid() == False:
            print_log('[WARN] P0110City.browser_post_ippan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた一般資産調査員調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 3/18.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + user_proxy_list[0].city_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + user_proxy_list[0].city_code + '/' + output_file_name

        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
                
        upload_file_size = os.path.getsize(upload_file_path)/1024 ## KB
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_size={} KB'.format(upload_file_size), 'DEBUG')
                
        #######################################################################
        ### EXCEL入出力処理(0040)
        ### (1)アップロードされた一般資産調査員調査票ファイルのワークブックを読み込む。
        ### (2)IPPANワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 4/18.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        ### for ws_temp in wb.worksheets:                                      ### 2024/11/13 COMMENT OUT
        ###     if 'IPPAN' in ws_temp.title:
        ###         ws.append(ws_temp)
        ###         ws_result.append(wb.copy_worksheet(ws_temp))
        ###         ws_result[-1].title = 'RESULT' + ws_temp.title
        ###         ws_title.append(ws_temp.title)
        for ws_temp in wb.worksheets:                                          ### 2024/11/13 ADD
            if 'IPPAN' in ws_temp.title:
                ### シートがNON（NULL）でない場合、リストに追加する。
                if is_sheet_none(ws_temp) == False:
                    ws.append(ws_temp)
                    ws_result.append(wb.copy_worksheet(ws_temp))
                    ws_result[-1].title = 'RESULT' + ws_temp.title
                    ws_title.append(ws_temp.title)

        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)

        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(0050)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の19は、町丁名・大字名、名称等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 5/18.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 19
            ### セル[20:2] ws.max_rowから順番に20行までチェックする。
            for i in range(ws_temp.max_row + 1, 19, -1):
                if (ws_temp.cell(row=i, column=2).value is not None) or (
                    ws_temp.cell(row=i, column=3).value is not None) or (
                    ws_temp.cell(row=i, column=4).value is not None) or (
                    ws_temp.cell(row=i, column=5).value is not None) or (
                    ws_temp.cell(row=i, column=6).value is not None) or (
                    ws_temp.cell(row=i, column=7).value is not None) or (
                    ws_temp.cell(row=i, column=8).value is not None) or (
                    ws_temp.cell(row=i, column=9).value is not None) or (
                    ws_temp.cell(row=i, column=10).value is not None) or (
                    ws_temp.cell(row=i, column=11).value is not None) or (
                    ws_temp.cell(row=i, column=12).value is not None) or (
                    ws_temp.cell(row=i, column=13).value is not None) or (
                    ws_temp.cell(row=i, column=14).value is not None) or (
                    ws_temp.cell(row=i, column=15).value is not None) or (
                    ws_temp.cell(row=i, column=16).value is not None) or (
                    ws_temp.cell(row=i, column=17).value is not None) or (
                    ws_temp.cell(row=i, column=18).value is not None) or (
                    ws_temp.cell(row=i, column=19).value is not None) or (
                    ws_temp.cell(row=i, column=20).value is not None) or (
                    ws_temp.cell(row=i, column=21).value is not None) or (
                    ws_temp.cell(row=i, column=22).value is not None) or (
                    ws_temp.cell(row=i, column=23).value is not None) or (
                    ws_temp.cell(row=i, column=24).value is not None) or (
                    ws_temp.cell(row=i, column=25).value is not None) or (
                    ws_temp.cell(row=i, column=26).value is not None) or (
                    ws_temp.cell(row=i, column=27).value is not None):
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(0060)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 6/18.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(0070)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 7/18.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        cause_list = CAUSE.objects.raw("""SELECT * FROM CAUSE ORDER BY CAST(CAUSE_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        gradient_list = GRADIENT.objects.raw("""SELECT * FROM GRADIENT ORDER BY CAST(GRADIENT_CODE AS INTEGER)""")
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        building_list = BUILDING.objects.raw("""SELECT * FROM BUILDING ORDER BY CAST(BUILDING_CODE AS INTEGER)""")
        underground_list = UNDERGROUND.objects.raw("""SELECT * FROM UNDERGROUND ORDER BY CAST(UNDERGROUND_CODE AS INTEGER)""")
        flood_sediment_list = FLOOD_SEDIMENT.objects.raw("""SELECT * FROM FLOOD_SEDIMENT ORDER BY CAST(FLOOD_SEDIMENT_CODE AS INTEGER)""")
        industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
        usage_list = USAGE.objects.raw("""SELECT * FROM USAGE ORDER BY CAST(USAGE_CODE AS INTEGER)""")
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        cause_code_list = [cause.cause_code for cause in cause_list]
        cause_name_list = [cause.cause_name for cause in cause_list]
        cause_name_code_list = [str(cause.cause_name) + ":" + str(cause.cause_code) for cause in cause_list]
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        gradient_code_list = [gradient.gradient_code for gradient in gradient_list]
        gradient_name_list = [gradient.gradient_name for gradient in gradient_list]
        gradient_name_code_list = [str(gradient.gradient_name) + ":" + str(gradient.gradient_code) for gradient in gradient_list]
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        building_code_list = [building.building_code for building in building_list]
        building_name_list = [building.building_name for building in building_list]
        building_name_code_list = [str(building.building_name) + ":" + str(building.building_code) for building in building_list]
        underground_code_list = [underground.underground_code for underground in underground_list]
        underground_name_list = [underground.underground_name for underground in underground_list]
        underground_name_code_list = [str(underground.underground_name) + ":" + str(underground.underground_code) for underground in underground_list]
        flood_sediment_code_list = [flood_sediment.flood_sediment_code for flood_sediment in flood_sediment_list]
        flood_sediment_name_list = [flood_sediment.flood_sediment_name for flood_sediment in flood_sediment_list]
        flood_sediment_name_code_list = [str(flood_sediment.flood_sediment_name) + ":" + str(flood_sediment.flood_sediment_code) for flood_sediment in flood_sediment_list]
        industry_code_list = [industry.industry_code for industry in industry_list]
        industry_name_list = [industry.industry_name for industry in industry_list]
        industry_name_code_list = [str(industry.industry_name) + ":" + str(industry.industry_code) for industry in industry_list]
        usage_code_list = [usage.usage_code for usage in usage_list]
        usage_name_list = [usage.usage_name for usage in usage_list]
        usage_name_code_list = [str(usage.usage_name) + ":" + str(usage.usage_code) for usage in usage_list]

        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(0080)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 8/18.', 'DEBUG')
        bool_return_01 = check_require()
        bool_return_02 = check_format()
        bool_return_03 = check_range()
        bool_return_04 = check_correlate()
        bool_return_05 = check_compare()
        
        if (bool_return_01 == False) or (bool_return_02 == False) or (bool_return_03 == False) or (bool_return_04 == False) or (bool_return_05 == False):
            print_log('[ERROR] P0110City.browser_post_ippan()関数 check_()関数が異常終了しました。', 'WARN')
            raise Exception

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0090)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 9/18.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0100)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 10/18.', 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(require_warn_list)={}'.format(len(require_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(format_warn_list)={}'.format(len(format_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(range_warn_list)={}'.format(len(range_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(correlate_warn_list)={}'.format(len(correlate_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(compare_warn_list)={}'.format(len(compare_warn_list)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0110)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 11/18.', 'DEBUG')
        warn_str = ''
        ### 0: require_warn_list[i][0]: title: シート名
        ### 1: require_warn_list[i][1]: row: 行
        ### 2: require_warn_list[i][2]: column: 列
        ### 3: require_warn_list[i][3]: W0000, W0001, : エラーコード
        ### 4: require_warn_list[i][4]: 必須: チェック
        ### 5: require_warn_list[i][5]: エラーメッセージ
        for i in range(len(require_warn_list)):
            warn_str = warn_str + \
                str(require_warn_list[i][0]) + ',' + \
                str(require_warn_list[i][1]) + ',' + \
                str(require_warn_list[i][2]) + ',' + \
                str(require_warn_list[i][3]) + ',' + \
                str(require_warn_list[i][4]) + ',' + \
                str(require_warn_list[i][5]) + '\n'        
        
        for i in range(len(format_warn_list)):
            warn_str = warn_str + \
                str(format_warn_list[i][0]) + ',' + \
                str(format_warn_list[i][1]) + ',' + \
                str(format_warn_list[i][2]) + ',' + \
                str(format_warn_list[i][3]) + ',' + \
                str(format_warn_list[i][4]) + ',' + \
                str(format_warn_list[i][5]) + '\n'        

        for i in range(len(range_warn_list)):
            warn_str = warn_str + \
                str(range_warn_list[i][0]) + ',' + \
                str(range_warn_list[i][1]) + ',' + \
                str(range_warn_list[i][2]) + ',' + \
                str(range_warn_list[i][3]) + ',' + \
                str(range_warn_list[i][4]) + ',' + \
                str(range_warn_list[i][5]) + '\n'        

        for i in range(len(correlate_warn_list)):
            warn_str = warn_str + \
                str(correlate_warn_list[i][0]) + ',' + \
                str(correlate_warn_list[i][1]) + ',' + \
                str(correlate_warn_list[i][2]) + ',' + \
                str(correlate_warn_list[i][3]) + ',' + \
                str(correlate_warn_list[i][4]) + ',' + \
                str(correlate_warn_list[i][5]) + '\n'        

        for i in range(len(compare_warn_list)):
            warn_str = warn_str + \
                str(compare_warn_list[i][0]) + ',' + \
                str(compare_warn_list[i][1]) + ',' + \
                str(compare_warn_list[i][2]) + ',' + \
                str(compare_warn_list[i][3]) + ',' + \
                str(compare_warn_list[i][4]) + ',' + \
                str(compare_warn_list[i][5]) + '\n'        

        #######################################################################
        #######################################################################
        ### 【警告】条件分岐処理(1000)
        ### ※入力チェックでエラーが発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 12/18.', 'DEBUG')
        if len(require_warn_list) > 0 or len(require_warn_grid) > 0 or len(format_warn_list) > 0 or len(format_warn_grid) > 0 or \
            len(range_warn_list) > 0 or len(range_warn_grid) > 0 or len(correlate_warn_list) > 0 or len(correlate_warn_grid) > 0 or \
            len(compare_warn_list) > 0 or len(compare_warn_grid) > 0:
                
            ###################################################################
            ### 【警告】DBアクセス処理(1010)
            ### ※入力チェックで警告が発見された場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 13/18.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")

                PARAMS = dict({
                    'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
                })
                SQL_UPDATE_IPPAN_HEADER = """
                    UPDATE IPPAN_HEADER SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE IPPAN_HEADER_ID IN (
                    SELECT 
                        IPPAN_HEADER_ID 
                    FROM IPPAN_HEADER 
                    WHERE 
                        CITY_CODE=%(CITY_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_IPPAN = """
                    UPDATE IPPAN SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE IPPAN_ID IN (
                    SELECT 
                        IPPAN_ID 
                    FROM IPPAN_VIEW 
                    WHERE 
                        CITY_CODE=%(CITY_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_IPPAN_SUMMARY = """
                    UPDATE IPPAN_SUMMARY SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE IPPAN_ID IN (
                    SELECT 
                        IPPAN_ID 
                    FROM IPPAN_SUMMARY_VIEW 
                    WHERE 
                        CITY_CODE=%(CITY_CODE)s AND 
                        DELETED_AT IS NULL)"""
                
                connection_cursor.execute(SQL_UPDATE_IPPAN_HEADER,  PARAMS)
                connection_cursor.execute(SQL_UPDATE_IPPAN,         PARAMS)
                connection_cursor.execute(SQL_UPDATE_IPPAN_SUMMARY, PARAMS)

                ### _IPP_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
                ### _IPP_ACT_02等でも良い。
                ### 同じ市区町村コードのトリガーが削除済に更新される。
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': None, 
                    'city_code': split_name_code(ws[0].cell(row=7, column=3).value)[-1], 
                    'action_code': _IPP_ACT_01,
                })
                bool_return = delete_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[ERROR] P0110City.browser_post_ippan()関数 delete_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                    
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] P0110City.browser_post_ippan()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0110City.browser_post_ippan()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### 【警告】レスポンスセット処理(1020)
            ### ※入力チェックで警告が発見された場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 14/18.', 'DEBUG')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'browser_post_ippan_warn': 'browser_post_ippan_warn',
                'require_warn_grid': require_warn_grid, 
                'require_warn_list': require_warn_list, 
                'format_warn_grid': format_warn_grid,
                'format_warn_list': format_warn_list,
                'range_warn_grid': range_warn_grid,
                'range_warn_list': range_warn_list,
                'correlate_warn_grid': correlate_warn_grid,
                'correlate_warn_list': correlate_warn_list,
                'compare_warn_grid': compare_warn_grid,
                'compare_warn_list': compare_warn_list,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0110City.browser_post_ippan()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        #######################################################################
        ### 【正常】DBアクセス処理(2000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 15/18.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")

            ###################################################################
            ### 【正常】DBアクセス処理(2010) STEP1
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存データの削除日に値をセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 16/18.', 'DEBUG')
            PARAMS = dict({
                'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
            })
            SQL_UPDATE_IPPAN_HEADER = """
                UPDATE IPPAN_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE IPPAN_HEADER_ID IN (
                SELECT 
                    IPPAN_HEADER_ID 
                FROM IPPAN_HEADER 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_IPPAN = """
                UPDATE IPPAN SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE IPPAN_ID IN (
                SELECT 
                    IPPAN_ID 
                FROM IPPAN_VIEW 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_IPPAN_SUMMARY = """
                UPDATE IPPAN_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE IPPAN_ID IN (
                SELECT 
                    IPPAN_ID 
                FROM IPPAN_SUMMARY_VIEW 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL)"""
            
            connection_cursor.execute(SQL_UPDATE_IPPAN_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_IPPAN,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_IPPAN_SUMMARY, PARAMS)

            ### _IPP_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _IPP_ACT_02等でも良い。
            ### 同じ市区町村コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': None, 
                'city_code': split_name_code(ws[0].cell(row=7, column=3).value)[-1], 
                'action_code': _IPP_ACT_01,
            })
            bool_return = delete_message(PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0110City.browser_post_ippan()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception
            
            ###################################################################
            ### 【正常】DBアクセス処理(2020) STEP2
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※アップロードされたデータを登録する。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 17/18.', 'DEBUG')
            for i, _ in enumerate(ws):
                ippan_header_id = IPPAN_HEADER.objects.all().aggregate(Max('ippan_header_id'))['ippan_header_id__max']
                if ippan_header_id is None:
                    ippan_header_id = 1
                else:
                    ippan_header_id += 1

                if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
                    PARAMS = dict({
                        'IPPAN_HEADER_ID': ippan_header_id, 
                        'IPPAN_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=2).value)[-1]), 
                        'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=3).value)[-1]), 
                        'BEGIN_DATE': str(convert_empty_to_none(ws[i].cell(row=7, column=4).value)).replace('-','/').replace(' 00:00:00',''), 
                        'END_DATE': str(convert_empty_to_none(ws[i].cell(row=7, column=5).value)).replace('-','/').replace(' 00:00:00',''), 
                        'CAUSE_1_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=6).value)[-1]), 
                        'CAUSE_2_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=7).value)[-1]), 
                        'CAUSE_3_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=8).value)[-1]), 
                        ### 'KUIKI_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=9).value)[-1]), ### 2024/11/13 COMMENTOUT
                        'KUIKI_ID': convert_empty_to_none(ws[i].cell(row=7, column=9).value),                          ### 2024/11/13 ADD
                        'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=2).value)[-1]), 
                        'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=3).value)[-1]), ### 2024/11/15 ADD
                        'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=4).value)[-1]), 
                        'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=5).value)[-1]),  ### 2024/11/15 ADD
                        'GRADIENT_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=6).value)[-1]), 
                        'RESIDENTIAL_AREA': convert_empty_to_none(ws[i].cell(row=14, column=2).value), 
                        'AGRICULTURAL_AREA': convert_empty_to_none(ws[i].cell(row=14, column=3).value), 
                        'UNDERGROUND_AREA': convert_empty_to_none(ws[i].cell(row=14, column=4).value), 
                        'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=14, column=6).value)[-1]), 
                        'CROP_DAMAGE': convert_empty_to_none(ws[i].cell(row=14, column=8).value), 
                        ### 'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=14, column=10).value)[-1]), ### 2024/11/15 COMMENT OUT
                        'DELETED_AT': None, 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'UPLOAD_FILE_SIZE': upload_file_size,  ### ADD 2023/03/03
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None,
                        'IPPAN_CITY_UPLOAD': _PROVISIONED_IPPAN_CITY_UPLOAD,
                    })
                else:
                    PARAMS = dict({
                        'IPPAN_HEADER_ID': ippan_header_id, 
                        'IPPAN_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=2).value)[-1]), 
                        'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=3).value)[-1]), 
                        'BEGIN_DATE': str(convert_empty_to_none(ws[i].cell(row=7, column=4).value)).replace('-','/').replace(' 00:00:00',''), 
                        'END_DATE': str(convert_empty_to_none(ws[i].cell(row=7, column=5).value)).replace('-','/').replace(' 00:00:00',''), 
                        'CAUSE_1_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=6).value)[-1]), 
                        'CAUSE_2_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=7).value)[-1]), 
                        'CAUSE_3_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=8).value)[-1]), 
                        ### 'KUIKI_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=9).value)[-1]), ### 2024/11/13 COMMENT OUT
                        'KUIKI_ID': convert_empty_to_none(ws[i].cell(row=7, column=9).value),                          ### 2024/11/13 ADD
                        'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=2).value)[-1]), 
                        'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=3).value)[-1]), ### 2024/11/15 ADD
                        'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=4).value)[-1]), 
                        'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=5).value)[-1]),  ### 2024/11/15 ADD
                        'GRADIENT_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=6).value)[-1]), 
                        'RESIDENTIAL_AREA': convert_empty_to_none(ws[i].cell(row=14, column=2).value), 
                        'AGRICULTURAL_AREA': convert_empty_to_none(ws[i].cell(row=14, column=3).value), 
                        'UNDERGROUND_AREA': convert_empty_to_none(ws[i].cell(row=14, column=4).value), 
                        'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=14, column=6).value)[-1]), 
                        'CROP_DAMAGE': convert_empty_to_none(ws[i].cell(row=14, column=8).value), 
                        ### 'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=14, column=10).value)[-1]), ### 2024/11/15 COMMENT OUT
                        'DELETED_AT': None, 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'UPLOAD_FILE_SIZE': upload_file_size,  ### ADD 2023/03/03
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None,
                        'IPPAN_CITY_UPLOAD': _CONFIRMED_IPPAN_CITY_UPLOAD,
                    })
                ### SQL_INSERT_IPPAN_HEADER_01 = """                           ### 2024/11/15 COMMENT OUT
                ###     INSERT INTO IPPAN_HEADER (
                ###         IPPAN_HEADER_ID, IPPAN_HEADER_NAME, KEN_CODE, CITY_CODE, BEGIN_DATE, END_DATE, 
                ###         CAUSE_1_CODE, CAUSE_2_CODE, CAUSE_3_CODE, KUIKI_ID, SUIKEI_CODE, 
                ###         KASEN_CODE, GRADIENT_CODE, RESIDENTIAL_AREA, AGRICULTURAL_AREA, UNDERGROUND_AREA, 
                ###         KASEN_KAIGAN_CODE, CROP_DAMAGE, WEATHER_ID, COMMITTED_AT, DELETED_AT, UPLOAD_FILE_PATH, 
                ###         UPLOAD_FILE_NAME, UPLOAD_FILE_SIZE, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME 
                ###     ) VALUES (
                ###         %(IPPAN_HEADER_ID)s, 
                ###         %(IPPAN_HEADER_NAME)s, 
                ###         %(KEN_CODE)s, 
                ###         %(CITY_CODE)s, 
                ###         TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                ###         TO_DATE(%(END_DATE)s, 'YYYY/MM/DD'),
                ###         %(CAUSE_1_CODE)s, 
                ###         %(CAUSE_2_CODE)s, 
                ###         %(CAUSE_3_CODE)s, 
                ###         %(KUIKI_ID)s, 
                ###         %(SUIKEI_CODE)s, 
                ###         %(KASEN_CODE)s, 
                ###         %(GRADIENT_CODE)s, 
                ###         %(RESIDENTIAL_AREA)s, 
                ###         %(AGRICULTURAL_AREA)s, 
                ###         %(UNDERGROUND_AREA)s, 
                ###         %(KASEN_KAIGAN_CODE)s, 
                ###         %(CROP_DAMAGE)s, 
                ###         %(WEATHER_ID)s, 
                ###         CURRENT_TIMESTAMP,  -- COMMITTED_AT 
                ###         %(DELETED_AT)s, 
                ###         %(UPLOAD_FILE_PATH)s, 
                ###         %(UPLOAD_FILE_NAME)s, 
                ###         %(UPLOAD_FILE_SIZE)s, 
                ###         %(SUMMARY_FILE_PATH)s, 
                ###         %(SUMMARY_FILE_NAME)s)"""
                SQL_INSERT_IPPAN_HEADER_01 = """
                    INSERT INTO IPPAN_HEADER (
                        IPPAN_HEADER_ID, IPPAN_HEADER_NAME, KEN_CODE, CITY_CODE, BEGIN_DATE, END_DATE, 
                        CAUSE_1_CODE, CAUSE_2_CODE, CAUSE_3_CODE, KUIKI_ID, SUIKEI_CODE, SUIKEI_TYPE_CODE,
                        KASEN_CODE, KASEN_TYPE_CODE, GRADIENT_CODE, RESIDENTIAL_AREA, AGRICULTURAL_AREA, UNDERGROUND_AREA, 
                        KASEN_KAIGAN_CODE, CROP_DAMAGE, COMMITTED_AT, DELETED_AT, UPLOAD_FILE_PATH, 
                        UPLOAD_FILE_NAME, UPLOAD_FILE_SIZE, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME 
                    ) VALUES (
                        %(IPPAN_HEADER_ID)s, 
                        %(IPPAN_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(CITY_CODE)s, 
                        TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                        TO_DATE(%(END_DATE)s, 'YYYY/MM/DD'),
                        %(CAUSE_1_CODE)s, 
                        %(CAUSE_2_CODE)s, 
                        %(CAUSE_3_CODE)s, 
                        %(KUIKI_ID)s, 
                        %(SUIKEI_CODE)s, 
                        %(SUIKEI_TYPE_CODE)s, -- 2024/11/15 ADD
                        %(KASEN_CODE)s, 
                        %(KASEN_TYPE_CODE)s,  -- 2024/11/15 ADD
                        %(GRADIENT_CODE)s, 
                        %(RESIDENTIAL_AREA)s, 
                        %(AGRICULTURAL_AREA)s, 
                        %(UNDERGROUND_AREA)s, 
                        %(KASEN_KAIGAN_CODE)s, 
                        %(CROP_DAMAGE)s, 
                        -- WEATHER_ID,  -- 2024/11/15 COMMENT OUT
                        CURRENT_TIMESTAMP,  -- COMMITTED_AT 
                        %(DELETED_AT)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(UPLOAD_FILE_SIZE)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s)"""
                ### SQL_INSERT_IPPAN_HEADER_02 = """                           ### 2024/11/15 COMMENT OUT
                ###     INSERT INTO IPPAN_HEADER (
                ###         IPPAN_HEADER_ID, IPPAN_HEADER_NAME, KEN_CODE, CITY_CODE, BEGIN_DATE, END_DATE, 
                ###         CAUSE_1_CODE, CAUSE_2_CODE, CAUSE_3_CODE, KUIKI_ID, SUIKEI_CODE, 
                ###         KASEN_CODE, GRADIENT_CODE, RESIDENTIAL_AREA, AGRICULTURAL_AREA, UNDERGROUND_AREA, 
                ###         KASEN_KAIGAN_CODE, CROP_DAMAGE, WEATHER_ID, COMMITTED_AT, DELETED_AT, UPLOAD_FILE_PATH, 
                ###         UPLOAD_FILE_NAME, UPLOAD_FILE_SIZE, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME 
                ###     ) VALUES (
                ###         %(IPPAN_HEADER_ID)s, 
                ###         %(IPPAN_HEADER_NAME)s, 
                ###         %(KEN_CODE)s, 
                ###         %(CITY_CODE)s, 
                ###         TO_DATE('2023/01/01', 'YYYY/MM/DD'), 
                ###         NULL, -- ADD 2023/11/22
                ###         %(CAUSE_1_CODE)s, 
                ###         %(CAUSE_2_CODE)s, 
                ###         %(CAUSE_3_CODE)s, 
                ###         %(KUIKI_ID)s, 
                ###         %(SUIKEI_CODE)s, 
                ###         %(KASEN_CODE)s, 
                ###         %(GRADIENT_CODE)s, 
                ###         %(RESIDENTIAL_AREA)s, 
                ###         %(AGRICULTURAL_AREA)s, 
                ###         %(UNDERGROUND_AREA)s, 
                ###         %(KASEN_KAIGAN_CODE)s, 
                ###         %(CROP_DAMAGE)s, 
                ###         %(WEATHER_ID)s, 
                ###         CURRENT_TIMESTAMP,  -- COMMITTED_AT 
                ###         %(DELETED_AT)s, 
                ###         %(UPLOAD_FILE_PATH)s, 
                ###         %(UPLOAD_FILE_NAME)s, 
                ###         %(UPLOAD_FILE_SIZE)s, 
                ###         %(SUMMARY_FILE_PATH)s, 
                ###         %(SUMMARY_FILE_NAME)s)"""
                SQL_INSERT_IPPAN_HEADER_02 = """
                    INSERT INTO IPPAN_HEADER (
                        IPPAN_HEADER_ID, IPPAN_HEADER_NAME, KEN_CODE, CITY_CODE, BEGIN_DATE, END_DATE, 
                        CAUSE_1_CODE, CAUSE_2_CODE, CAUSE_3_CODE, KUIKI_ID, SUIKEI_CODE, SUIKEI_TYPE_CODE, 
                        KASEN_CODE, KASEN_TYPE_CODE, GRADIENT_CODE, RESIDENTIAL_AREA, AGRICULTURAL_AREA, UNDERGROUND_AREA, 
                        KASEN_KAIGAN_CODE, CROP_DAMAGE, COMMITTED_AT, DELETED_AT, UPLOAD_FILE_PATH, 
                        UPLOAD_FILE_NAME, UPLOAD_FILE_SIZE, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME 
                    ) VALUES (
                        %(IPPAN_HEADER_ID)s, 
                        %(IPPAN_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(CITY_CODE)s, 
                        TO_DATE('2023/01/01', 'YYYY/MM/DD'), 
                        NULL, -- ADD 2023/11/22
                        %(CAUSE_1_CODE)s, 
                        %(CAUSE_2_CODE)s, 
                        %(CAUSE_3_CODE)s, 
                        %(KUIKI_ID)s, 
                        %(SUIKEI_CODE)s, 
                        %(SUIKEI_TYPE_CODE)s, -- 2024/11/15 ADD
                        %(KASEN_CODE)s, 
                        %(KASEN_TYPE_CODE)s,  -- 2024/11/15 ADD
                        %(GRADIENT_CODE)s, 
                        %(RESIDENTIAL_AREA)s, 
                        %(AGRICULTURAL_AREA)s, 
                        %(UNDERGROUND_AREA)s, 
                        %(KASEN_KAIGAN_CODE)s, 
                        %(CROP_DAMAGE)s, 
                        -- WEATHER_ID,  -- 2024/11/15 COMMENT OUT
                        CURRENT_TIMESTAMP,  -- COMMITTED_AT 
                        %(DELETED_AT)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(UPLOAD_FILE_SIZE)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s)"""
                ### SQL_INSERT_IPPAN_HEADER_03 = """                           ### 2024/11/15 COMMENT OUT
                ###     INSERT INTO IPPAN_HEADER (
                ###         IPPAN_HEADER_ID, IPPAN_HEADER_NAME, KEN_CODE, CITY_CODE, BEGIN_DATE, END_DATE, 
                ###         CAUSE_1_CODE, CAUSE_2_CODE, CAUSE_3_CODE, KUIKI_ID, SUIKEI_CODE, 
                ###         KASEN_CODE, GRADIENT_CODE, RESIDENTIAL_AREA, AGRICULTURAL_AREA, UNDERGROUND_AREA, 
                ###         KASEN_KAIGAN_CODE, CROP_DAMAGE, WEATHER_ID, COMMITTED_AT, DELETED_AT, UPLOAD_FILE_PATH, 
                ###         UPLOAD_FILE_NAME, UPLOAD_FILE_SIZE, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME 
                ###     ) VALUES (
                ###         %(IPPAN_HEADER_ID)s,
                ###         %(IPPAN_HEADER_NAME)s,
                ###         %(KEN_CODE)s,
                ###         %(CITY_CODE)s,
                ###         TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'),
                ###         NULL, -- ADD 2023/11/22
                ###         %(CAUSE_1_CODE)s,
                ###         %(CAUSE_2_CODE)s,
                ###         %(CAUSE_3_CODE)s,
                ###         %(KUIKI_ID)s,
                ###         %(SUIKEI_CODE)s,
                ###         %(KASEN_CODE)s,
                ###         %(GRADIENT_CODE)s,
                ###         %(RESIDENTIAL_AREA)s,
                ###         %(AGRICULTURAL_AREA)s,
                ###         %(UNDERGROUND_AREA)s,
                ###         %(KASEN_KAIGAN_CODE)s,
                ###         %(CROP_DAMAGE)s,
                ###         %(WEATHER_ID)s,
                ###         CURRENT_TIMESTAMP,  -- COMMITTED_AT
                ###         %(DELETED_AT)s,
                ###         %(UPLOAD_FILE_PATH)s,
                ###         %(UPLOAD_FILE_NAME)s,
                ###         %(UPLOAD_FILE_SIZE)s,
                ###         %(SUMMARY_FILE_PATH)s,
                ###         %(SUMMARY_FILE_NAME)s)"""
                SQL_INSERT_IPPAN_HEADER_03 = """
                    INSERT INTO IPPAN_HEADER (
                        IPPAN_HEADER_ID, IPPAN_HEADER_NAME, KEN_CODE, CITY_CODE, BEGIN_DATE, END_DATE, 
                        CAUSE_1_CODE, CAUSE_2_CODE, CAUSE_3_CODE, KUIKI_ID, SUIKEI_CODE, SUIKEI_TYPE_CODE,
                        KASEN_CODE, KASEN_TYPE_CODE, GRADIENT_CODE, RESIDENTIAL_AREA, AGRICULTURAL_AREA, UNDERGROUND_AREA, 
                        KASEN_KAIGAN_CODE, CROP_DAMAGE, COMMITTED_AT, DELETED_AT, UPLOAD_FILE_PATH, 
                        UPLOAD_FILE_NAME, UPLOAD_FILE_SIZE, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME 
                    ) VALUES (
                        %(IPPAN_HEADER_ID)s,
                        %(IPPAN_HEADER_NAME)s,
                        %(KEN_CODE)s,
                        %(CITY_CODE)s,
                        TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'),
                        NULL, -- ADD 2023/11/22
                        %(CAUSE_1_CODE)s,
                        %(CAUSE_2_CODE)s,
                        %(CAUSE_3_CODE)s,
                        %(KUIKI_ID)s,
                        %(SUIKEI_TYPE_CODE)s, -- 2024/11/15 ADD
                        %(SUIKEI_CODE)s,
                        %(KASEN_CODE)s,
                        %(KASEN_TYPE_CODE)s,  -- 2024/11/15 ADD
                        %(GRADIENT_CODE)s,
                        %(RESIDENTIAL_AREA)s,
                        %(AGRICULTURAL_AREA)s,
                        %(UNDERGROUND_AREA)s,
                        %(KASEN_KAIGAN_CODE)s,
                        %(CROP_DAMAGE)s,
                        -- WEATHER_ID,  -- 2024/11/15 COMMENT OUT
                        CURRENT_TIMESTAMP,  -- COMMITTED_AT
                        %(DELETED_AT)s,
                        %(UPLOAD_FILE_PATH)s,
                        %(UPLOAD_FILE_NAME)s,
                        %(UPLOAD_FILE_SIZE)s,
                        %(SUMMARY_FILE_PATH)s,
                        %(SUMMARY_FILE_NAME)s)"""
                SQL_INSERT_IPPAN_HISTORY = """
                    INSERT INTO IPPAN_HISTORY (
                        IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
                    ) VALUES (
                        %(IPPAN_HEADER_ID)s,
                        %(IPPAN_CITY_UPLOAD)s,
                        CURRENT_TIMESTAMP)"""    
                            
                if len(str(convert_empty_to_none(ws[i].cell(row=7, column=5).value)).replace('-','/').replace(' 00:00:00','')) >= 8:
                    connection_cursor.execute(SQL_INSERT_IPPAN_HEADER_01, PARAMS)
                else:
                    ### BEGIN_DATE 44927 1/1 etc.
                    if len(str(convert_empty_to_none(ws[i].cell(row=7, column=4).value)).replace('-','/').replace(' 00:00:00','')) == 5:
                        connection_cursor.execute(SQL_INSERT_IPPAN_HEADER_02, PARAMS)
                    ### BEGIN_DATE 
                    else:
                        connection_cursor.execute(SQL_INSERT_IPPAN_HEADER_03, PARAMS)
                        
                connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)
                    
                ###############################################################
                ### 【正常】DBアクセス処理(2030) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※アップロードされたデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 17_1/18.', 'DEBUG')
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if (max_row[i] >= 20):
                    for j in range(20, max_row[i] + 1):
                        print_log('[DEBUG] P0110City.browser_post_ippan()関数 j={}'.format(j), 'DEBUG')
                        PARAMS_INSERT_IPPAN = dict({
                            'IPPAN_NAME': convert_empty_to_none(ws[i].cell(row=j, column=2).value), 
                            'IPPAN_HEADER_ID': ippan_header_id, 
                            'BUILDING_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=3).value)[-1]), 
                            'UNDERGROUND_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'FLOOD_SEDIMENT_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=5).value)[-1]), 
                            'BUILDING_LV00': convert_empty_to_none(ws[i].cell(row=j, column=6).value), 
                            'BUILDING_LV01_49': convert_empty_to_none(ws[i].cell(row=j, column=7).value), 
                            'BUILDING_LV50_99': convert_empty_to_none(ws[i].cell(row=j, column=8).value), 
                            'BUILDING_LV100': convert_empty_to_none(ws[i].cell(row=j, column=9).value), 
                            'BUILDING_HALF': convert_empty_to_none(ws[i].cell(row=j, column=10).value), 
                            'BUILDING_FULL': convert_empty_to_none(ws[i].cell(row=j, column=11).value), 
                            'FLOOR_AREA': convert_empty_to_none(ws[i].cell(row=j, column=12).value), 
                            'FAMILY': convert_empty_to_none(ws[i].cell(row=j, column=13).value), 
                            'OFFICE': convert_empty_to_none(ws[i].cell(row=j, column=14).value), 
                            'FARMER_FISHER_LV00': convert_empty_to_none(ws[i].cell(row=j, column=15).value), 
                            'FARMER_FISHER_LV01_49': convert_empty_to_none(ws[i].cell(row=j, column=16).value), 
                            'FARMER_FISHER_LV50_99': convert_empty_to_none(ws[i].cell(row=j, column=17).value), 
                            'FARMER_FISHER_LV100': convert_empty_to_none(ws[i].cell(row=j, column=18).value), 
                            'FARMER_FISHER_FULL': convert_empty_to_none(ws[i].cell(row=j, column=19).value), 
                            'EMPLOYEE_LV00': convert_empty_to_none(ws[i].cell(row=j, column=20).value), 
                            'EMPLOYEE_LV01_49': convert_empty_to_none(ws[i].cell(row=j, column=21).value), 
                            'EMPLOYEE_LV50_99': convert_empty_to_none(ws[i].cell(row=j, column=22).value), 
                            'EMPLOYEE_LV100': convert_empty_to_none(ws[i].cell(row=j, column=23).value), 
                            'EMPLOYEE_FULL': convert_empty_to_none(ws[i].cell(row=j, column=24).value), 
                            'INDUSTRY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=25).value)[-1]), 
                            'USAGE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=26).value)[-1]), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=27).value), 
                            'DELETED_AT': None
                        })
                        SQL_INSERT_IPPAN = """ 
                            INSERT INTO IPPAN (
                                IPPAN_ID, IPPAN_NAME, IPPAN_HEADER_ID, 
                                BUILDING_CODE, UNDERGROUND_CODE, FLOOD_SEDIMENT_CODE, 
                                BUILDING_LV00, BUILDING_LV01_49, BUILDING_LV50_99, BUILDING_LV100, BUILDING_HALF, BUILDING_FULL, 
                                FLOOR_AREA, FAMILY, OFFICE, 
                                FARMER_FISHER_LV00, FARMER_FISHER_LV01_49, FARMER_FISHER_LV50_99, FARMER_FISHER_LV100, FARMER_FISHER_FULL, 
                                EMPLOYEE_LV00, EMPLOYEE_LV01_49, EMPLOYEE_LV50_99, EMPLOYEE_LV100, EMPLOYEE_FULL, 
                                INDUSTRY_CODE, USAGE_CODE, COMMENT, 
                                COMMITTED_AT, DELETED_AT 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(IPPAN_ID+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(IPPAN_ID+1) AS INTEGER) END AS IPPAN_ID FROM IPPAN), -- IPPAN_ID 
                                %(IPPAN_NAME)s, 
                                %(IPPAN_HEADER_ID)s, 
                                %(BUILDING_CODE)s, 
                                %(UNDERGROUND_CODE)s, 
                                %(FLOOD_SEDIMENT_CODE)s, 
                                %(BUILDING_LV00)s, 
                                %(BUILDING_LV01_49)s, 
                                %(BUILDING_LV50_99)s, 
                                %(BUILDING_LV100)s, 
                                %(BUILDING_HALF)s, 
                                %(BUILDING_FULL)s, 
                                %(FLOOR_AREA)s, 
                                %(FAMILY)s, 
                                %(OFFICE)s, 
                                %(FARMER_FISHER_LV00)s, 
                                %(FARMER_FISHER_LV01_49)s, 
                                %(FARMER_FISHER_LV50_99)s, 
                                %(FARMER_FISHER_LV100)s, 
                                %(FARMER_FISHER_FULL)s, 
                                %(EMPLOYEE_LV00)s, 
                                %(EMPLOYEE_LV01_49)s, 
                                %(EMPLOYEE_LV50_99)s, 
                                %(EMPLOYEE_LV100)s, 
                                %(EMPLOYEE_FULL)s, 
                                %(INDUSTRY_CODE)s, 
                                %(USAGE_CODE)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- COMMITTED_AT 
                                %(DELETED_AT)s) """

                        connection_cursor.execute(SQL_INSERT_IPPAN, PARAMS_INSERT_IPPAN)

                ###############################################################
                ### 【正常】DBアクセス処理(2040) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにIPP_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 17_2/18.', 'DEBUG')
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': ippan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=2).value)[-1]), 
                    'city_code': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=3).value)[-1]), 
                    'action_code': _IPP_ACT_01, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[ERROR] P0110City.browser_post_ippan()関数 publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0110City.browser_post_ippan()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0110City.browser_post_ippan()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0110City.browser_post_ippan()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        finally:
            connection_cursor.close()
        
        #######################################################################
        ### 【正常】レスポンスセット処理(2050)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 18/18.', 'DEBUG')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'browser_post_ippan_info': 'browser_post_ippan_info',
        }
        print_log('[INFO] P0110City.browser_post_ippan()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0110City.browser_post_ippan()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.browser_post_ippan()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.browser_post_ippan()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### /P0110City/ => /P0110City/bucket/ リダイレクト用
### urlpattern：path('', views.index_view, name='index_view')
### ※リダイレクトのみのため、custom_decoratorはセットしない。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    return redirect('bucket/')

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 市区町村バケット
### urlpattern：path('bucket/', views.bucket_view, name='bucket_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='bucket_view')
def bucket_view(request):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### CITY_BUCKET: バケットデータ_市区町村
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 1/3.', 'DEBUG')
        PARAMS = dict({
            'CITY_CODE': user_proxy_list[0].city_code 
        })
        SQL_SELECT_CITY_BUCKET = """
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, 
                FILES 
            FROM CITY_BUCKET 
            WHERE 
                CITY_CODE=%(CITY_CODE)s"""
        city_bucket_list = CITY_BUCKET.objects.raw(SQL_SELECT_CITY_BUCKET, PARAMS)

        print_log('[DEBUG] P0110City.bucket_view()関数 city_bucket_list={}'.format(city_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0110City.bucket_view()関数 len(city_bucket_list)={}'.format(len(city_bucket_list)), 'DEBUG')
            
        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 2/3.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0110City.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
        
        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0110City.bucket_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0110City/bucket/bucket.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed, 
            'city_bucket_list': city_bucket_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0110City.bucket_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.bucket_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.bucket_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0110City/bucket/bucket.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 市区町村ブラウザ
### urlpattern：path('browser/', views.browser_view, name='browser_view')
### (1)GETの場合、ファイル管理画面を表示する。
### (2)POSTの場合、アップロードされた一般資産調査員調査票をチェックして、正常ケースの場合、DBに登録する。
### ※複数EXCELシート対応版
### ※DELEGATE処理のため、関数からの戻り値のbool_returnを処理しない。
### ※except、異常処理は関数からの戻り値のresponseに含めること。
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='browser_view')
def browser_view(request):
    if request.method == 'GET':
        bool_return, response = browser_get(request)
        return response
    
    if request.method == 'POST':
        if 'upload_ippan_button' in request.POST:
            bool_return, response = browser_post_ippan(request)
            return response
        
        return redirect('/P0110City/browser/')
    
    return redirect('/P0110City/browser/')

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 右スライドメニュー表示
### urlpattern：path('slide/ippan/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_ippan_header_id_view')
def slide_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### IPPAN_HEADER: アップロードデータ_一般資産調査員調査票_ヘッダ部分
        ### IPPAN_HISTORY: 
        ### ※IPPAN_HEADER_IDを指定して他市区町村の参照ができないように、ユーザ情報から取得した市区町村コードも検索条件に含める。
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 city_code={}'.format(user_proxy_list[0].city_code), 'DEBUG')

        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:        
            PARAMS = dict({
                'CITY_CODE': user_proxy_list[0].city_code, 
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_UPLOAD': _PROVISIONED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _PROVISIONED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _PROVISIONED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _PROVISIONED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _PROVISIONED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _PROVISIONED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _PROVISIONED_IPPAN_MANAGE_DISAPPROVE,
                'IPP_ACT_01': _IPP_ACT_01,
                'IPP_ACT_02': _IPP_ACT_02,
                'IPP_ACT_03': _IPP_ACT_03,
            })
        else:
            PARAMS = dict({
                'CITY_CODE': user_proxy_list[0].city_code, 
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_UPLOAD': _CONFIRMED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _CONFIRMED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _CONFIRMED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _CONFIRMED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _CONFIRMED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _CONFIRMED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _CONFIRMED_IPPAN_MANAGE_DISAPPROVE,
                'IPP_ACT_01': _IPP_ACT_01,
                'IPP_ACT_02': _IPP_ACT_02,
                'IPP_ACT_03': _IPP_ACT_03,
            })
        SQL_SELECT_IPPAN_HEADER = """
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                KUIKI_ID, -- ADD 2024/10/02
                WEATHER_ID, -- ADD 2024/10/02
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s"""
        SQL_SELECT_IPPAN_HISTORY = """
            SELECT
                IPPAN_HISTORY_ID,
                IPPAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM IPPAN_HISTORY
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s
            ORDER BY IPPAN_HISTORY_ID"""
        SQL_SELECT_IPPAN_HISTORY_LATEST = """
            SELECT
                IPPAN_HISTORY_ID,
                IPPAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM IPPAN_HISTORY
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s
            ORDER BY IPPAN_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_IPPAN_TRIGGER = """
            SELECT
                IPPAN_TRIGGER_ID,
                IPPAN_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM IPPAN_TRIGGER
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND
                ACTION_CODE IN (%(IPP_ACT_01)s, %(IPP_ACT_02)s, %(IPP_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY IPPAN_TRIGGER_ID"""

        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS)
        ippan_history_list = IPPAN_HISTORY.objects.raw(SQL_SELECT_IPPAN_HISTORY, PARAMS)
        ippan_history_latest_list = IPPAN_HISTORY.objects.raw(SQL_SELECT_IPPAN_HISTORY_LATEST, PARAMS)
        ippan_trigger_list = IPPAN_TRIGGER.objects.raw(SQL_SELECT_IPPAN_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 len(ippan_header_list)={}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 ippan_history_list={}'.format(ippan_history_list), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 len(ippan_history_list)={}'.format(len(ippan_history_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 ippan_history_latest_list={}'.format(ippan_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 len(ippan_history_latest_list)={}'.format(len(ippan_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 ippan_trigger_list={}'.format(ippan_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 len(ippan_trigger_list)={}'.format(len(ippan_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if ippan_header_list == False:
            print_log('[WARN] P0110City.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'return_code': ["TRUE"], 
            'ippan_header_id': ippan_header_list[0].ippan_header_id, 
            'ippan_header_name': ippan_header_list[0].ippan_header_name, 
            'ken_code': ippan_header_list[0].ken_code, 
            'city_code': ippan_header_list[0].city_code, 
            'kuiki_id': ippan_header_list[0].kuiki_id,
            'weather_id': ippan_header_list[0].weather_id,
            'upload_file_path': ippan_header_list[0].upload_file_path, 
            'upload_file_name': ippan_header_list[0].upload_file_name, 
            'upload_file_size': ippan_header_list[0].upload_file_size, 
            'summary_file_path': ippan_header_list[0].summary_file_path, 
            'summary_file_name': ippan_header_list[0].summary_file_name, 
            'summary_file_size': ippan_header_list[0].summary_file_size, 
            'committed_at': ippan_header_list[0].committed_at, 
            'deleted_at': ippan_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if ippan_history_latest_list:
            latest = {
                'latest_workflow_code': ippan_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if ippan_history_list:
            for ippan_history in ippan_history_list:
                history_list.append({'workflow_code': ippan_history.workflow_code, 'committed_at': ippan_history.committed_at})

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if ippan_trigger_list:
            for ippan_trigger in ippan_trigger_list:
                trigger_list.append({'action_code': ippan_trigger.action_code, 'status_code': ippan_trigger.status_code, 'consumed_at': ippan_trigger.consumed_at})
        
        print_log('[INFO] P0110City.slide_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0110City.slide_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.slide_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.slide_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 申請
### urlpattern：path('apply/ippan/header/<slug:header_id>/', views.apply_ippan_header_id_view, name='apply_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='apply_ippan_header_id_view')
def apply_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0110City.apply_ippan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0110City.apply_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.apply_ippan_header_id_view()関数 _PROVISIONED_IPPAN_CITY_APPLY={}'.format(_PROVISIONED_IPPAN_CITY_APPLY), 'DEBUG')
        print_log('[DEBUG] P0110City.apply_ippan_header_id_view()関数 _CONFIRMED_IPPAN_CITY_APPLY={}'.format(_CONFIRMED_IPPAN_CITY_APPLY), 'DEBUG')

        connection_cursor = connection.cursor()

        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_CITY_APPLY': _PROVISIONED_IPPAN_CITY_APPLY,
            })
        else:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_CITY_APPLY': _CONFIRMED_IPPAN_CITY_APPLY,
            })
        SQL_INSERT_IPPAN_HISTORY = """
            INSERT INTO IPPAN_HISTORY (
                IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(IPPAN_HEADER_ID)s,
                %(IPPAN_CITY_APPLY)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.apply_ippan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0110City.apply_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0110City.apply_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.apply_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.apply_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 削除
### urlpattern：path('delete/ippan/header/<slug:header_id>/', views.delete_ippan_header_id_view, name='delete_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='delete_ippan_header_id_view')
def delete_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### IPPAN_HEADER: アップロードデータ_一般資産調査員調査票_ヘッダ部分
        ### IPPAN: アップロードデータ_一般資産調査員調査票_一覧表部分
        ### IPPAN_SUMMARY: 集計データ_一般資産調査員調査票_一覧表部分
        ### IPPAN_TRIGGER: キューデータ_一般資産調査員調査票_トリガーメッセージ
        #######################################################################
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 city_code={}'.format(user_proxy_list[0].city_code), 'DEBUG')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 _PROVISIONED_IPPAN_CITY_DELETE={}'.format(_PROVISIONED_IPPAN_CITY_DELETE), 'DEBUG')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 _CONFIRMED_IPPAN_CITY_DELETE={}'.format(_CONFIRMED_IPPAN_CITY_DELETE), 'DEBUG')

        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'CITY_CODE': user_proxy_list[0].city_code, 
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_DELETE': _PROVISIONED_IPPAN_CITY_DELETE,
            })
        else:
            PARAMS = dict({
                'CITY_CODE': user_proxy_list[0].city_code, 
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_DELETE': _CONFIRMED_IPPAN_CITY_DELETE,
            })
        ### SQL_UPDATE_IPPAN_HEADER = """                                      ### 2024/11/14 COMMENT OUT
        ###     UPDATE IPPAN_HEADER SET 
        ###         DELETED_AT=CURRENT_TIMESTAMP 
        ###     WHERE IPPAN_HEADER_ID IN (
        ###     SELECT 
        ###         IPPAN_HEADER_ID 
        ###     FROM IPPAN_HEADER 
        ###     WHERE 
        ###         CITY_CODE=%(CITY_CODE)s AND 
        ###         DELETED_AT IS NULL)"""
        ### SQL_UPDATE_IPPAN = """                                             ### 2024/11/14 COMMENT OUT
        ###     UPDATE IPPAN SET 
        ###         DELETED_AT=CURRENT_TIMESTAMP 
        ###     WHERE IPPAN_ID IN (
        ###     SELECT 
        ###         IPPAN_ID 
        ###     FROM IPPAN_VIEW 
        ###     WHERE 
        ###         CITY_CODE=%(CITY_CODE)s AND 
        ###         DELETED_AT IS NULL)"""
        ### SQL_UPDATE_IPPAN_SUMMARY = """                                     ### 2024/11/14 COMMENT OUT
        ###     UPDATE IPPAN_SUMMARY SET 
        ###         DELETED_AT=CURRENT_TIMESTAMP 
        ###     WHERE IPPAN_ID IN (
        ###     SELECT 
        ###         IPPAN_ID 
        ###     FROM IPPAN_SUMMARY_VIEW 
        ###     WHERE 
        ###         CITY_CODE=%(CITY_CODE)s AND 
        ###         DELETED_AT IS NULL)"""
        ### SQL_INSERT_IPPAN_HISTORY = """                                     ### 2024/11/14 COMMENT OUT
        ###     INSERT INTO IPPAN_HISTORY (
        ###         IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
        ###     ) VALUES (
        ###         %(IPPAN_HEADER_ID)s,
        ###         %(IPPAN_CITY_DELETE)s,
        ###         CURRENT_TIMESTAMP)"""

        SQL_UPDATE_IPPAN_HEADER = """
            UPDATE IPPAN_HEADER SET 
                DELETED_AT=CURRENT_TIMESTAMP 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                DELETED_AT IS NULL"""
        SQL_UPDATE_IPPAN = """
            UPDATE IPPAN SET 
                DELETED_AT=CURRENT_TIMESTAMP 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND
                DELETED_AT IS NULL"""
        SQL_UPDATE_IPPAN_SUMMARY = """
            UPDATE IPPAN_SUMMARY SET 
                DELETED_AT=CURRENT_TIMESTAMP 
            WHERE IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND
                DELETED_AT IS NULL"""
        SQL_INSERT_IPPAN_HISTORY = """
            INSERT INTO IPPAN_HISTORY (
                IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(IPPAN_HEADER_ID)s,
                %(IPPAN_CITY_DELETE)s,
                CURRENT_TIMESTAMP)"""
        
        connection_cursor = connection.cursor()

        try:
            connection_cursor.execute("""BEGIN""")

            connection_cursor.execute(SQL_UPDATE_IPPAN_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_IPPAN,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_IPPAN_SUMMARY, PARAMS)
            connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)

            ### _IPP_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _IPP_ACT_02等でも良い。
            ### 同じ市区町村コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': None, 
                'city_code': user_proxy_list[0].city_code, 
                'action_code': _IPP_ACT_01
            })
            bool_return = delete_message(PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0110City.delete_ippan_header_id_view()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0110City.delete_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0110City.delete_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.delete_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.delete_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 EXCELダウンロード
### urlpattern：path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_chosa_excel_header_id_view')
def download_ippan_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_chosa_excel_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_chosa_excel_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_chosa_excel_header_id_view()関数 _IPP_CHO_EXC={}'.format(_IPP_CHO_EXC), 'DEBUG')
        
        PARAMS_IPPAN_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'FILE_TYPE': _IPP_CHO_EXC
        })
        bool_return, file_path = get_ippan_chosa_csv_excel(request, PARAMS_IPPAN_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_chosa_excel_header_id_view()関数 STEP 2/2.', 'DEBUG')
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    
    except:
        print_log('[ERROR] P0110City.download_ippan_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")
    
###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 CSVダウンロード
### urlpattern：path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_chosa_csv_header_id_view')
def download_ippan_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_chosa_csv_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_chosa_csv_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_chosa_csv_header_id_view()関数 _IPP_CHO_CSV={}'.format(_IPP_CHO_CSV), 'DEBUG')

        PARAMS_IPPAN_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'FILE_TYPE': _IPP_CHO_CSV
        })
        bool_return, file_path = get_ippan_chosa_csv_excel(request, PARAMS_IPPAN_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_chosa_csv_header_id_view()関数 STEP 2/2.', 'DEBUG')
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0110City.download_ippan_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産集計結果 EXCELダウンロード
### urlpattern：path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_summary_excel_header_id_view')
def download_ippan_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_summary_excel_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_summary_excel_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_summary_excel_header_id_view()関数 _IPP_SUM_EXC={}'.format(_IPP_SUM_EXC), 'DEBUG')
        
        PARAMS_IPPAN_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'FILE_TYPE': _IPP_SUM_EXC
        })
        bool_return, file_path = get_ippan_summary_csv_excel(request, PARAMS_IPPAN_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_summary_excel_header_id_view()関数 STEP 2/2.', 'DEBUG')
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0110City.download_ippan_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")
    
###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産集計結果 CSVダウンロード
### urlpattern：path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_summary_csv_header_id_view')
def download_ippan_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_summary_csv_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_summary_csv_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.download_ippan_summary_csv_header_id_view()関数 _IPP_SUM_CSV={}'.format(_IPP_SUM_CSV), 'DEBUG')
        
        PARAMS_IPPAN_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'FILE_TYPE': _IPP_SUM_CSV
        })
        bool_return, file_path = get_ippan_summary_csv_excel(request, PARAMS_IPPAN_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0110City.download_ippan_summary_csv_header_id_view()関数 STEP 2/2.', 'DEBUG')
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0110City.download_ippan_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.download_ippan_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")
