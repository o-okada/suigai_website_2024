###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### ファイル名：P0700EStat/hyo25_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO25:
    def __init__(self, city_code, city_name, breach_damage, with_dike_damage, without_dike_damage, inland_damage, pit_damage, scouring_damage, debris_damage, landslide_damage, steepslope_damage, surge_damage, tsunami_damage, waves_damage, other_damage, sum_total_damage):
        self.city_code = city_code
        self.city_name = city_name
        self.breach_damage = breach_damage
        self.with_dike_damage = with_dike_damage
        self.without_dike_damage = without_dike_damage
        self.inland_damage = inland_damage
        self.pit_damage = pit_damage
        self.scouring_damage = scouring_damage
        self.debris_damage = debris_damage
        self.landslide_damage = landslide_damage
        self.steepslope_damage = steepslope_damage
        self.surge_damage = surge_damage
        self.tsunami_damage = tsunami_damage
        self.waves_damage = waves_damage
        self.other_damage = other_damage
        self.sum_total_damage = sum_total_damage

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo25(cause_code, ken_code)
### 1 市区町村別_水害原因別_被害額_合計 
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo25(cause_code, ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo25()関数 cause_code={}'.format(cause_code), 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo25()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if cause_code in constants.cause_values:
            pass
        else:
            return False, []
        
        if ken_code in constants.ken_values:
            pass
        else:
            return False, []
        
        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        cause_keys = ['CAUSE_CODE']
        cause_values = [cause_code]
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(cause_keys + ken_keys, cause_values + ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25()関数 STEP 2/3.', 'DEBUG')
        hyo25_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CITY1.city_code, 
                CITY1.city_name, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 市区町村
            (SELECT SUB1.city_code, CITY0.city_name 
            FROM 
                (SELECT SUB0.city_code  
                FROM 
                    (SELECT city_code 
                    FROM IPPAN_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM KOEKI_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    ) SUB0 
                GROUP BY SUB0.city_code 
                ) SUB1 
            LEFT JOIN CITY CITY0 ON SUB1.city_code=CITY0.city_code 
            ORDER BY SUB1.city_code 
            ) CITY1
            
            -- 一般資産被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN01 
            ON CITY1.city_code=IPPAN01.city_code 
            
            -- 公益事業被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) KOEKI01 
            ON CITY1.city_code=KOEKI01.city_code 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25()関数 STEP 3/3.', 'DEBUG')
        return True, hyo25_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo25_zenken(cause_code, ken_code)
### 2_1 全県_水害原因別_被害額_合計 中間下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo25_zenken(cause_code, ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_zenken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo25_zenken()関数 cause_code={}'.format(cause_code), 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo25_zenken()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if cause_code in constants.cause_values:
            pass
        else:
            return False, []

        if ken_code in constants.ken_values:
            pass
        else:
            return False, []
        
        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        cause_keys = ['CAUSE_CODE']
        cause_values = [cause_code]
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(cause_keys + ken_keys, cause_values + ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_zenken()関数 STEP 2/3.', 'DEBUG')
        hyo25_zenken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 
            
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s AND ken_code=%(KEN_CODE)s 
            ) IPPAN01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s AND ken_code=%(KEN_CODE)s 
            ) KOEKI01 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_zenken()関数 STEP 3/3.', 'DEBUG')
        return True, hyo25_zenken_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo25_zenkoku(cause_code)
### 2_2 全国_水害原因別_被害額_合計 最下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo25_zenkoku(cause_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_zenkoku()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo25_zenkoku()関数 cause_code={}'.format(cause_code), 'DEBUG')
        if cause_code in constants.cause_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        cause_keys = ['CAUSE_CODE']
        cause_values = [cause_code]
        params = dict(zip(cause_keys, cause_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo25_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 
            
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s 
            ) IPPAN01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s 
            ) KOEKI01 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_zenkoku()関数 STEP 3/3.', 'DEBUG')
        return True, hyo25_zenkoku_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo25_sum_total(ken_code)
### 3 市区町村別_全水害原因別_被害額_合計 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo25_sum_total(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total()関数 ken_code={}'.format(ken_code), 'DEBUG')

        if ken_code in constants.ken_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total()関数 STEP 2/3.', 'DEBUG')
        hyo25_sum_total_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                CITY1.city_code, 
                CITY1.city_name, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 市区町村
            (SELECT SUB1.city_code, CITY0.city_name 
            FROM 
                (SELECT SUB0.city_code  
                FROM 
                    (SELECT city_code 
                    FROM IPPAN_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM KOEKI_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    ) SUB0 
                GROUP BY SUB0.city_code 
                ) SUB1 
            LEFT JOIN CITY CITY0 ON SUB1.city_code=CITY0.city_code 
            ORDER BY SUB1.city_code 
            ) CITY1

            -- 一般資産被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN01 
            ON CITY1.city_code=IPPAN01.city_code 
            
            -- 公益事業被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) KOEKI01 
            ON CITY1.city_code=KOEKI01.city_code 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total()関数 STEP 3/3.', 'DEBUG')
        return True, hyo25_sum_total_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo25_sum_total_zenken(ken_code)
### 4_1 全県_全水害原因別_被害額_合計 中間下端 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo25_sum_total_zenken(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total_zenken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total_zenken()関数 ken_code={}'.format(ken_code), 'DEBUG')

        if ken_code in constants.ken_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total_zenken()関数 STEP 2/3.', 'DEBUG')
        hyo25_sum_total_zenken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) KOEKI01 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total_zenken()関数 STEP 3/3.', 'DEBUG')
        return True, hyo25_sum_total_zenken_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo25_sum_total_zenkoku()
### 4_2 全国_全水害原因別_被害額_合計 最下端 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo25_sum_total_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total_zenkoku()関数 STEP 1/3.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo25_sum_total_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI01 
            
            """, [])

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo25_sum_total_zenkoku()関数 STEP 3/3.', 'DEBUG')
        return True, hyo25_sum_total_zenkoku_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：hyo25_view(request, cat_code)
### urlpattern：path('hyo25/', hyo25_views.hyo25_view, name='hyo25_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo25_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo25_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo25_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo25_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo25_view()関数 STEP 2/4.', 'DEBUG')
        params = dict(zip(constants.cause_keys, constants.cause_values))

        ### 1 市区町村別_水害原因別_被害額_合計
        breach_list = []
        with_dike_list = []
        without_dike_list = []
        inland_list = []
        pit_list = []
        scouring_list = []
        debris_list = []
        landslide_list = []
        steepslope_list = []
        surge_list = []
        tsunami_list = []
        waves_list = []
        other_list = []
        
        for ken_code in constants.ken_values:
            bool_return, temp_breach_list = get_hyo25(params['BREACH'], ken_code)
            if bool_return == False:
                raise Exception
        
            bool_return, temp_with_dike_list = get_hyo25(params['WITH_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_without_dike_list = get_hyo25(params['WITHOUT_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_inland_list = get_hyo25(params['INLAND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_pit_list = get_hyo25(params['PIT'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_scouring_list = get_hyo25(params['SCOURING'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_debris_list = get_hyo25(params['DEBRIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_landslide_list = get_hyo25(params['LANDSLIDE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_steepslope_list = get_hyo25(params['STEEPSLOPE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_surge_list = get_hyo25(params['SURGE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_tsunami_list = get_hyo25(params['TSUNAMI'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_waves_list = get_hyo25(params['WAVES'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_list = get_hyo25(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception

            breach_list.append(temp_breach_list)
            with_dike_list.append(temp_with_dike_list)
            without_dike_list.append(temp_without_dike_list)
            inland_list.append(temp_inland_list)
            pit_list.append(temp_pit_list)
            scouring_list.append(temp_scouring_list)
            debris_list.append(temp_debris_list)
            landslide_list.append(temp_landslide_list)
            steepslope_list.append(temp_steepslope_list)
            surge_list.append(temp_surge_list)
            tsunami_list.append(temp_tsunami_list)
            waves_list.append(temp_waves_list)
            other_list.append(temp_other_list)

        ### 2_1 全県_水害原因別_被害額_合計 中間下端
        breach_zenken_list = []
        with_dike_zenken_list = []
        without_dike_zenken_list = []
        inland_zenken_list = []
        pit_zenken_list = []
        scouring_zenken_list = []
        debris_zenken_list = []
        landslide_zenken_list = []
        steepslope_zenken_list = []
        surge_zenken_list = []
        tsunami_zenken_list = []
        waves_zenken_list = []
        other_zenken_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_breach_zenken_list = get_hyo25_zenken(params['BREACH'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_with_dike_zenken_list = get_hyo25_zenken(params['WITH_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_without_dike_zenken_list = get_hyo25_zenken(params['WITHOUT_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_inland_zenken_list = get_hyo25_zenken(params['INLAND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_pit_zenken_list = get_hyo25_zenken(params['PIT'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_scouring_zenken_list = get_hyo25_zenken(params['SCOURING'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_debris_zenken_list = get_hyo25_zenken(params['DEBRIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_landslide_zenken_list = get_hyo25_zenken(params['LANDSLIDE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_steepslope_zenken_list = get_hyo25_zenken(params['STEEPSLOPE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_surge_zenken_list = get_hyo25_zenken(params['SURGE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_tsunami_zenken_list = get_hyo25_zenken(params['TSUNAMI'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_waves_zenken_list = get_hyo25_zenken(params['WAVES'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_zenken_list = get_hyo25_zenken(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception

            breach_zenken_list.append(temp_breach_zenken_list)
            with_dike_zenken_list.append(temp_with_dike_zenken_list)
            without_dike_zenken_list.append(temp_without_dike_zenken_list)
            inland_zenken_list.append(temp_inland_zenken_list)
            pit_zenken_list.append(temp_pit_zenken_list)
            scouring_zenken_list.append(temp_scouring_zenken_list)
            debris_zenken_list.append(temp_debris_zenken_list)
            landslide_zenken_list.append(temp_landslide_zenken_list)
            steepslope_zenken_list.append(temp_steepslope_zenken_list)
            surge_zenken_list.append(temp_surge_zenken_list)
            tsunami_zenken_list.append(temp_tsunami_zenken_list)
            waves_zenken_list.append(temp_waves_zenken_list)
            other_zenken_list.append(temp_other_zenken_list)

        ### 2_2 全国_水害原因別_被害額_合計 最下端
        bool_return, breach_zenkoku_list = get_hyo25_zenkoku(params['BREACH'])
        if bool_return == False:
            raise Exception
        
        bool_return, with_dike_zenkoku_list = get_hyo25_zenkoku(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception
        
        bool_return, without_dike_zenkoku_list = get_hyo25_zenkoku(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception
        
        bool_return, inland_zenkoku_list = get_hyo25_zenkoku(params['INLAND'])
        if bool_return == False:
            raise Exception
        
        bool_return, pit_zenkoku_list = get_hyo25_zenkoku(params['PIT'])
        if bool_return == False:
            raise Exception
        
        bool_return, scouring_zenkoku_list = get_hyo25_zenkoku(params['SCOURING'])
        if bool_return == False:
            raise Exception
        
        bool_return, debris_zenkoku_list = get_hyo25_zenkoku(params['DEBRIS'])
        if bool_return == False:
            raise Exception
        
        bool_return, landslide_zenkoku_list = get_hyo25_zenkoku(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception
        
        bool_return, steepslope_zenkoku_list = get_hyo25_zenkoku(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception
        
        bool_return, surge_zenkoku_list = get_hyo25_zenkoku(params['SURGE'])
        if bool_return == False:
            raise Exception
        
        bool_return, tsunami_zenkoku_list = get_hyo25_zenkoku(params['TSUNAMI'])
        if bool_return == False:
            raise Exception
        
        bool_return, waves_zenkoku_list = get_hyo25_zenkoku(params['WAVES'])
        if bool_return == False:
            raise Exception
        
        bool_return, other_zenkoku_list = get_hyo25_zenkoku(params['OTHER'])
        if bool_return == False:
            raise Exception
        
        ### 3 市区町村別_全水害原因別_被害額_合計 右端
        sum_total_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_list = get_hyo25_sum_total(ken_code)
            if bool_return == False:
                raise Exception
            
            sum_total_list.append(temp_sum_total_list)

        ### 4_1 全県_全水害原因別_被害額_合計 中間下端 右端
        sum_total_zenken_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_zenken_list = get_hyo25_sum_total_zenken(ken_code)
            if bool_return == False:
                raise Exception
                
            sum_total_zenken_list.append(temp_sum_total_zenken_list)
        
        ### 4_2 全国_全水害原因別_被害額_合計 最下端 右端
        bool_return, sum_total_zenkoku_list = get_hyo25_sum_total_zenkoku()
        if bool_return == False:
            raise Exception
        
        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo25_view()関数 STEP 3/4.', 'DEBUG')
        ### 1 市区町村別_水害原因別_被害額_合計
        ### 3 市区町村別_全水害原因別_被害額_合計 右端
        zencity_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for breach, with_dike, without_dike, inland, pit, scouring, debris, landslide, steepslope, surge, tsunami, waves, other, sum_total in zip(
                breach_list[i], with_dike_list[i], without_dike_list[i], inland_list[i], pit_list[i], 
                scouring_list[i], debris_list[i], landslide_list[i], steepslope_list[i], surge_list[i], 
                tsunami_list[i], waves_list[i], other_list[i], sum_total_list[i]):
                print('breach.city_code={}'.format(breach.city_code), flush=True)
                print('breach.city_name={}'.format(breach.city_name), flush=True)
                print('breach.damage={}'.format(breach.damage), flush=True)
                print('with_dike.damage={}'.format(with_dike.damage), flush=True)
                print('without_dike.damage={}'.format(without_dike.damage), flush=True)
                print('inland.damage={}'.format(inland.damage), flush=True)
                print('pit.damage={}'.format(pit.damage), flush=True)
                print('scouring.damage={}'.format(scouring.damage), flush=True)
                print('debris.damage={}'.format(debris.damage), flush=True)
                print('landslide.damage={}'.format(landslide.damage), flush=True)
                print('steepslope.damage={}'.format(steepslope.damage), flush=True)
                print('surge.damage={}'.format(surge.damage), flush=True)
                print('tsunami.damage={}'.format(tsunami.damage), flush=True)
                print('waves.damage={}'.format(waves.damage), flush=True)
                print('other.damage={}'.format(other.damage), flush=True)
                print('sum_total.damage={}'.format(sum_total.damage), flush=True)
                hyo25 = HYO25(
                    breach.city_code, breach.city_name, 
                    breach.damage, with_dike.damage, without_dike.damage, inland.damage, pit.damage, 
                    scouring.damage, debris.damage, landslide.damage, steepslope.damage, surge.damage, 
                    tsunami.damage, waves.damage, other.damage, sum_total.damage)
                temp_list.append(hyo25)
                
            zencity_list.append(temp_list)

        ### 2_1 全県_水害原因別_被害額_合計 中間下端
        ### 4_1 全県_全水害原因別_被害額_合計 中間下端 右端
        zenken_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for breach_zenken, with_dike_zenken, without_dike_zenken, inland_zenken, pit_zenken, scouring_zenken, debris_zenken, landslide_zenken, steepslope_zenken, surge_zenken, tsunami_zenken, waves_zenken, other_zenken, sum_total_zenken in zip(
                breach_zenken_list[i], with_dike_zenken_list[i], without_dike_zenken_list[i], inland_zenken_list[i], pit_zenken_list[i], 
                scouring_zenken_list[i], debris_zenken_list[i], landslide_zenken_list[i], steepslope_zenken_list[i], surge_zenken_list[i], 
                tsunami_zenken_list[i], waves_zenken_list[i], other_zenken_list[i], sum_total_zenken_list[i]):
                print('breach_zenken.damage={}'.format(breach_zenken.damage), flush=True)
                print('with_dike_zenken.damage={}'.format(with_dike_zenken.damage), flush=True)
                print('without_dike_zenken.damage={}'.format(without_dike_zenken.damage), flush=True)
                print('inland_zenken.damage={}'.format(inland_zenken.damage), flush=True)
                print('pit_zenken.damage={}'.format(pit_zenken.damage), flush=True)
                print('scouring_zenken.damage={}'.format(scouring_zenken.damage), flush=True)
                print('debris_zenken.damage={}'.format(debris_zenken.damage), flush=True)
                print('landslide_zenken.damage={}'.format(landslide_zenken.damage), flush=True)
                print('steepslope_zenken.damage={}'.format(steepslope_zenken.damage), flush=True)
                print('surge_zenken.damage={}'.format(surge_zenken.damage), flush=True)
                print('tsunami_zenken.damage={}'.format(tsunami_zenken.damage), flush=True)
                print('waves_zenken.damage={}'.format(waves_zenken.damage), flush=True)
                print('other_zenken.damage={}'.format(other_zenken.damage), flush=True)
                print('sum_total_zenken.damage={}'.format(sum_total_zenken.damage), flush=True)
                hyo25 = HYO25(
                    '', '', 
                    breach_zenken.damage, with_dike_zenken.damage, without_dike_zenken.damage, inland_zenken.damage, pit_zenken.damage, 
                    scouring_zenken.damage, debris_zenken.damage, landslide_zenken.damage, steepslope_zenken.damage, surge_zenken.damage, 
                    tsunami_zenken.damage, waves_zenken.damage, other_zenken.damage, sum_total_zenken.damage)
                temp_list.append(hyo25)

            zenken_list.append(temp_list)
        
        ### 2_2 全国_水害原因別_被害額_合計 最下端
        ### 4_2 全国_全水害原因別_被害額_合計 最下端 右端
        zenkoku_list = []
        for breach_zenkoku, with_dike_zenkoku, without_dike_zenkoku, inland_zenkoku, pit_zenkoku, scouring_zenkoku, debris_zenkoku, landslide_zenkoku, steepslope_zenkoku, surge_zenkoku, tsunami_zenkoku, waves_zenkoku, other_zenkoku, sum_total_zenkoku in zip(
            breach_zenkoku_list, with_dike_zenkoku_list, without_dike_zenkoku_list, inland_zenkoku_list, pit_zenkoku_list, 
            scouring_zenkoku_list, debris_zenkoku_list, landslide_zenkoku_list, steepslope_zenkoku_list, surge_zenkoku_list, 
            tsunami_zenkoku_list, waves_zenkoku_list, other_zenkoku_list, sum_total_zenkoku_list):
            print('breach_zenkoku.damage={}'.format(breach_zenkoku.damage), flush=True)
            print('with_dike_zenkoku.damage={}'.format(with_dike_zenkoku.damage), flush=True)
            print('without_dike_zenkoku.damage={}'.format(without_dike_zenkoku.damage), flush=True)
            print('inland_zenkoku.damage={}'.format(inland_zenkoku.damage), flush=True)
            print('pit_zenkoku.damage={}'.format(pit_zenkoku.damage), flush=True)
            print('scouring_zenkoku.damage={}'.format(scouring_zenkoku.damage), flush=True)
            print('debris_zenkoku.damage={}'.format(debris_zenkoku.damage), flush=True)
            print('landslide_zenkoku.damage={}'.format(landslide_zenkoku.damage), flush=True)
            print('steepslope_zenkoku.damage={}'.format(steepslope_zenkoku.damage), flush=True)
            print('surge_zenkoku.damage={}'.format(surge_zenkoku.damage), flush=True)
            print('tsunami_zenkoku.damage={}'.format(tsunami_zenkoku.damage), flush=True)
            print('waves_zenkoku.damage={}'.format(waves_zenkoku.damage), flush=True)
            print('other_zenkoku.damage={}'.format(other_zenkoku.damage), flush=True)
            print('sum_total_zenkoku.damage={}'.format(sum_total_zenkoku.damage), flush=True)
            hyo25 = HYO25(
                '', '', 
                breach_zenkoku.damage, with_dike_zenkoku.damage, without_dike_zenkoku.damage, inland_zenkoku.damage, pit_zenkoku.damage, 
                scouring_zenkoku.damage, debris_zenkoku.damage, landslide_zenkoku.damage, steepslope_zenkoku.damage, surge_zenkoku.damage, 
                tsunami_zenkoku.damage, waves_zenkoku.damage, other_zenkoku.damage, sum_total_zenkoku.damage)
            zenkoku_list.append(hyo25)

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo25_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo25', 
            'zencity_list': zencity_list, 
            'zenken_list': zenken_list, 
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo25_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo25_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo25_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo25_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_25水害原因別市町村別一般資産等被害額.xlsx
### 関数名：hyo25_download_view(request)
### urlpattern：path('download/hyo25/', hyo25_views.hyo25_download_view, name='hyo25_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo25_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo25_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo25_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo25_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo25_download_view()関数 STEP 2/5.', 'DEBUG')
        params = dict(zip(constants.cause_keys, constants.cause_values))

        ### 1 市区町村別_水害原因別_被害額_合計
        breach_list = []
        with_dike_list = []
        without_dike_list = []
        inland_list = []
        pit_list = []
        scouring_list = []
        debris_list = []
        landslide_list = []
        steepslope_list = []
        surge_list = []
        tsunami_list = []
        waves_list = []
        other_list = []
        
        for ken_code in constants.ken_values:
            bool_return, temp_breach_list = get_hyo25(params['BREACH'], ken_code)
            if bool_return == False:
                raise Exception
        
            bool_return, temp_with_dike_list = get_hyo25(params['WITH_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_without_dike_list = get_hyo25(params['WITHOUT_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_inland_list = get_hyo25(params['INLAND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_pit_list = get_hyo25(params['PIT'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_scouring_list = get_hyo25(params['SCOURING'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_debris_list = get_hyo25(params['DEBRIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_landslide_list = get_hyo25(params['LANDSLIDE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_steepslope_list = get_hyo25(params['STEEPSLOPE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_surge_list = get_hyo25(params['SURGE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_tsunami_list = get_hyo25(params['TSUNAMI'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_waves_list = get_hyo25(params['WAVES'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_list = get_hyo25(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception

            breach_list.append(temp_breach_list)
            with_dike_list.append(temp_with_dike_list)
            without_dike_list.append(temp_without_dike_list)
            inland_list.append(temp_inland_list)
            pit_list.append(temp_pit_list)
            scouring_list.append(temp_scouring_list)
            debris_list.append(temp_debris_list)
            landslide_list.append(temp_landslide_list)
            steepslope_list.append(temp_steepslope_list)
            surge_list.append(temp_surge_list)
            tsunami_list.append(temp_tsunami_list)
            waves_list.append(temp_waves_list)
            other_list.append(temp_other_list)

        ### 2_1 全県_水害原因別_被害額_合計 中間下端
        breach_zenken_list = []
        with_dike_zenken_list = []
        without_dike_zenken_list = []
        inland_zenken_list = []
        pit_zenken_list = []
        scouring_zenken_list = []
        debris_zenken_list = []
        landslide_zenken_list = []
        steepslope_zenken_list = []
        surge_zenken_list = []
        tsunami_zenken_list = []
        waves_zenken_list = []
        other_zenken_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_breach_zenken_list = get_hyo25_zenken(params['BREACH'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_with_dike_zenken_list = get_hyo25_zenken(params['WITH_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_without_dike_zenken_list = get_hyo25_zenken(params['WITHOUT_DIKE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_inland_zenken_list = get_hyo25_zenken(params['INLAND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_pit_zenken_list = get_hyo25_zenken(params['PIT'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_scouring_zenken_list = get_hyo25_zenken(params['SCOURING'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_debris_zenken_list = get_hyo25_zenken(params['DEBRIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_landslide_zenken_list = get_hyo25_zenken(params['LANDSLIDE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_steepslope_zenken_list = get_hyo25_zenken(params['STEEPSLOPE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_surge_zenken_list = get_hyo25_zenken(params['SURGE'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_tsunami_zenken_list = get_hyo25_zenken(params['TSUNAMI'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_waves_zenken_list = get_hyo25_zenken(params['WAVES'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_zenken_list = get_hyo25_zenken(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception

            breach_zenken_list.append(temp_breach_zenken_list)
            with_dike_zenken_list.append(temp_with_dike_zenken_list)
            without_dike_zenken_list.append(temp_without_dike_zenken_list)
            inland_zenken_list.append(temp_inland_zenken_list)
            pit_zenken_list.append(temp_pit_zenken_list)
            scouring_zenken_list.append(temp_scouring_zenken_list)
            debris_zenken_list.append(temp_debris_zenken_list)
            landslide_zenken_list.append(temp_landslide_zenken_list)
            steepslope_zenken_list.append(temp_steepslope_zenken_list)
            surge_zenken_list.append(temp_surge_zenken_list)
            tsunami_zenken_list.append(temp_tsunami_zenken_list)
            waves_zenken_list.append(temp_waves_zenken_list)
            other_zenken_list.append(temp_other_zenken_list)

        ### 2_2 全国_水害原因別_被害額_合計 最下端
        bool_return, breach_zenkoku_list = get_hyo25_zenkoku(params['BREACH'])
        if bool_return == False:
            raise Exception
        
        bool_return, with_dike_zenkoku_list = get_hyo25_zenkoku(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception
        
        bool_return, without_dike_zenkoku_list = get_hyo25_zenkoku(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception
        
        bool_return, inland_zenkoku_list = get_hyo25_zenkoku(params['INLAND'])
        if bool_return == False:
            raise Exception
        
        bool_return, pit_zenkoku_list = get_hyo25_zenkoku(params['PIT'])
        if bool_return == False:
            raise Exception
        
        bool_return, scouring_zenkoku_list = get_hyo25_zenkoku(params['SCOURING'])
        if bool_return == False:
            raise Exception
        
        bool_return, debris_zenkoku_list = get_hyo25_zenkoku(params['DEBRIS'])
        if bool_return == False:
            raise Exception
        
        bool_return, landslide_zenkoku_list = get_hyo25_zenkoku(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception
        
        bool_return, steepslope_zenkoku_list = get_hyo25_zenkoku(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception
        
        bool_return, surge_zenkoku_list = get_hyo25_zenkoku(params['SURGE'])
        if bool_return == False:
            raise Exception
        
        bool_return, tsunami_zenkoku_list = get_hyo25_zenkoku(params['TSUNAMI'])
        if bool_return == False:
            raise Exception
        
        bool_return, waves_zenkoku_list = get_hyo25_zenkoku(params['WAVES'])
        if bool_return == False:
            raise Exception
        
        bool_return, other_zenkoku_list = get_hyo25_zenkoku(params['OTHER'])
        if bool_return == False:
            raise Exception
        
        ### 3 市区町村別_全水害原因別_被害額_合計 右端
        sum_total_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_list = get_hyo25_sum_total(ken_code)
            if bool_return == False:
                raise Exception
            
            sum_total_list.append(temp_sum_total_list)

        ### 4_1 全県_全水害原因別_被害額_合計 中間下端 右端
        sum_total_zenken_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_zenken_list = get_hyo25_sum_total_zenken(ken_code)
            if bool_return == False:
                raise Exception
                
            sum_total_zenken_list.append(temp_sum_total_zenken_list)
        
        ### 4_2 全国_全水害原因別_被害額_合計 最下端 右端
        bool_return, sum_total_zenkoku_list = get_hyo25_sum_total_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo25_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 市区町村別_水害原因別_被害額_合計
        ### 3 市区町村別_全水害原因別_被害額_合計 右端
        zencity_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for breach, with_dike, without_dike, inland, pit, scouring, debris, landslide, steepslope, surge, tsunami, waves, other, sum_total in zip(
                breach_list[i], with_dike_list[i], without_dike_list[i], inland_list[i], pit_list[i], 
                scouring_list[i], debris_list[i], landslide_list[i], steepslope_list[i], surge_list[i], 
                tsunami_list[i], waves_list[i], other_list[i], sum_total_list[i]):
                print('breach.city_code={}'.format(breach.city_code), flush=True)
                print('breach.city_name={}'.format(breach.city_name), flush=True)
                print('breach.damage={}'.format(breach.damage), flush=True)
                print('with_dike.damage={}'.format(with_dike.damage), flush=True)
                print('without_dike.damage={}'.format(without_dike.damage), flush=True)
                print('inland.damage={}'.format(inland.damage), flush=True)
                print('pit.damage={}'.format(pit.damage), flush=True)
                print('scouring.damage={}'.format(scouring.damage), flush=True)
                print('debris.damage={}'.format(debris.damage), flush=True)
                print('landslide.damage={}'.format(landslide.damage), flush=True)
                print('steepslope.damage={}'.format(steepslope.damage), flush=True)
                print('surge.damage={}'.format(surge.damage), flush=True)
                print('tsunami.damage={}'.format(tsunami.damage), flush=True)
                print('waves.damage={}'.format(waves.damage), flush=True)
                print('other.damage={}'.format(other.damage), flush=True)
                print('sum_total.damage={}'.format(sum_total.damage), flush=True)
                hyo25 = HYO25(
                    breach.city_code, breach.city_name, 
                    breach.damage, with_dike.damage, without_dike.damage, inland.damage, pit.damage, 
                    scouring.damage, debris.damage, landslide.damage, steepslope.damage, surge.damage, 
                    tsunami.damage, waves.damage, other.damage, sum_total.damage)
                temp_list.append(hyo25)
                
            zencity_list.append(temp_list)

        ### 2_1 全県_水害原因別_被害額_合計 中間下端
        ### 4_1 全県_全水害原因別_被害額_合計 中間下端 右端
        zenken_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for breach_zenken, with_dike_zenken, without_dike_zenken, inland_zenken, pit_zenken, scouring_zenken, debris_zenken, landslide_zenken, steepslope_zenken, surge_zenken, tsunami_zenken, waves_zenken, other_zenken, sum_total_zenken in zip(
                breach_zenken_list[i], with_dike_zenken_list[i], without_dike_zenken_list[i], inland_zenken_list[i], pit_zenken_list[i], 
                scouring_zenken_list[i], debris_zenken_list[i], landslide_zenken_list[i], steepslope_zenken_list[i], surge_zenken_list[i], 
                tsunami_zenken_list[i], waves_zenken_list[i], other_zenken_list[i], sum_total_zenken_list[i]):
                print('breach_zenken.damage={}'.format(breach_zenken.damage), flush=True)
                print('with_dike_zenken.damage={}'.format(with_dike_zenken.damage), flush=True)
                print('without_dike_zenken.damage={}'.format(without_dike_zenken.damage), flush=True)
                print('inland_zenken.damage={}'.format(inland_zenken.damage), flush=True)
                print('pit_zenken.damage={}'.format(pit_zenken.damage), flush=True)
                print('scouring_zenken.damage={}'.format(scouring_zenken.damage), flush=True)
                print('debris_zenken.damage={}'.format(debris_zenken.damage), flush=True)
                print('landslide_zenken.damage={}'.format(landslide_zenken.damage), flush=True)
                print('steepslope_zenken.damage={}'.format(steepslope_zenken.damage), flush=True)
                print('surge_zenken.damage={}'.format(surge_zenken.damage), flush=True)
                print('tsunami_zenken.damage={}'.format(tsunami_zenken.damage), flush=True)
                print('waves_zenken.damage={}'.format(waves_zenken.damage), flush=True)
                print('other_zenken.damage={}'.format(other_zenken.damage), flush=True)
                print('sum_total_zenken.damage={}'.format(sum_total_zenken.damage), flush=True)
                hyo25 = HYO25(
                    '', '', 
                    breach_zenken.damage, with_dike_zenken.damage, without_dike_zenken.damage, inland_zenken.damage, pit_zenken.damage, 
                    scouring_zenken.damage, debris_zenken.damage, landslide_zenken.damage, steepslope_zenken.damage, surge_zenken.damage, 
                    tsunami_zenken.damage, waves_zenken.damage, other_zenken.damage, sum_total_zenken.damage)
                temp_list.append(hyo25)

            zenken_list.append(temp_list)
        
        ### 2_2 全国_水害原因別_被害額_合計 最下端
        ### 4_2 全国_全水害原因別_被害額_合計 最下端 右端
        zenkoku_list = []
        for breach_zenkoku, with_dike_zenkoku, without_dike_zenkoku, inland_zenkoku, pit_zenkoku, scouring_zenkoku, debris_zenkoku, landslide_zenkoku, steepslope_zenkoku, surge_zenkoku, tsunami_zenkoku, waves_zenkoku, other_zenkoku, sum_total_zenkoku in zip(
            breach_zenkoku_list, with_dike_zenkoku_list, without_dike_zenkoku_list, inland_zenkoku_list, pit_zenkoku_list, 
            scouring_zenkoku_list, debris_zenkoku_list, landslide_zenkoku_list, steepslope_zenkoku_list, surge_zenkoku_list, 
            tsunami_zenkoku_list, waves_zenkoku_list, other_zenkoku_list, sum_total_zenkoku_list):
            print('breach_zenkoku.damage={}'.format(breach_zenkoku.damage), flush=True)
            print('with_dike_zenkoku.damage={}'.format(with_dike_zenkoku.damage), flush=True)
            print('without_dike_zenkoku.damage={}'.format(without_dike_zenkoku.damage), flush=True)
            print('inland_zenkoku.damage={}'.format(inland_zenkoku.damage), flush=True)
            print('pit_zenkoku.damage={}'.format(pit_zenkoku.damage), flush=True)
            print('scouring_zenkoku.damage={}'.format(scouring_zenkoku.damage), flush=True)
            print('debris_zenkoku.damage={}'.format(debris_zenkoku.damage), flush=True)
            print('landslide_zenkoku.damage={}'.format(landslide_zenkoku.damage), flush=True)
            print('steepslope_zenkoku.damage={}'.format(steepslope_zenkoku.damage), flush=True)
            print('surge_zenkoku.damage={}'.format(surge_zenkoku.damage), flush=True)
            print('tsunami_zenkoku.damage={}'.format(tsunami_zenkoku.damage), flush=True)
            print('waves_zenkoku.damage={}'.format(waves_zenkoku.damage), flush=True)
            print('other_zenkoku.damage={}'.format(other_zenkoku.damage), flush=True)
            print('sum_total_zenkoku.damage={}'.format(sum_total_zenkoku.damage), flush=True)
            hyo25 = HYO25(
                '', '', 
                breach_zenkoku.damage, with_dike_zenkoku.damage, without_dike_zenkoku.damage, inland_zenkoku.damage, pit_zenkoku.damage, 
                scouring_zenkoku.damage, debris_zenkoku.damage, landslide_zenkoku.damage, steepslope_zenkoku.damage, surge_zenkoku.damage, 
                tsunami_zenkoku.damage, waves_zenkoku.damage, other_zenkoku.damage, sum_total_zenkoku.damage)
            zenkoku_list.append(hyo25)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo25_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo25.xlsx'
        ### download_file_path = 'static/download_hyo25.xlsx'
        template_file_path = 'static/template/template_hyo25.xlsx'
        download_file_path = 'static/tmp/download_hyo25.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo25'
        
        ws.cell(row=1, column=1).value = '表－２５　水害原因別市区町村別一般資産等被害額'
        ws.cell(row=2, column=16).value = '（単位：千円）'
        ws.cell(row=3, column=1).value = '都道府県名'
        ws.cell(row=3, column=2).value = '市区町村名'
        ws.cell(row=3, column=3).value = '破　堤'
        ws.cell(row=3, column=4).value = '有堤部溢水'
        ws.cell(row=3, column=5).value = '無堤部溢水'
        ws.cell(row=3, column=6).value = '内　水'
        ws.cell(row=3, column=7).value = '窪地内水'
        ws.cell(row=3, column=8).value = '洗掘･流出'
        ws.cell(row=3, column=9).value = '土石流'
        ws.cell(row=3, column=10).value = '地すべり'
        ws.cell(row=3, column=11).value = '急傾斜崩壊'
        ws.cell(row=3, column=12).value = '高　潮'
        ws.cell(row=3, column=13).value = '津　波'
        ws.cell(row=3, column=14).value = '波　浪'
        ws.cell(row=3, column=15).value = 'その他'
        ws.cell(row=3, column=16).value = '合　計'
        
        row_index = 3
        for i, ken_code in enumerate(constants.ken_values):
            for j, zencity in enumerate(zencity_list[i]):
                for k, city in enumerate(zencity):
                    row_index += 1
                    if k == 0 and i == 0:
                        ws.cell(row=row_index, column=1).value = '北海道'
                    elif k == 0 and i == 1:
                        ws.cell(row=row_index, column=1).value = '青森'
                    elif k == 0 and i == 2:
                        ws.cell(row=row_index, column=1).value = '岩手'
                    elif k == 0 and i == 3:
                        ws.cell(row=row_index, column=1).value = '宮城'
                    elif k == 0 and i == 4:
                        ws.cell(row=row_index, column=1).value = '秋田'
                    elif k == 0 and i == 5:
                        ws.cell(row=row_index, column=1).value = '山形'
                    elif k == 0 and i == 6:
                        ws.cell(row=row_index, column=1).value = '福島'
                    elif k == 0 and i == 7:
                        ws.cell(row=row_index, column=1).value = '茨城'
                    elif k == 0 and i == 8:
                        ws.cell(row=row_index, column=1).value = '栃木'
                    elif k == 0 and i == 9:
                        ws.cell(row=row_index, column=1).value = '群馬'
                    elif k == 0 and i == 10:
                        ws.cell(row=row_index, column=1).value = '埼玉'
                    elif k == 0 and i == 11:
                        ws.cell(row=row_index, column=1).value = '千葉'
                    elif k == 0 and i == 12:
                        ws.cell(row=row_index, column=1).value = '東京'
                    elif k == 0 and i == 13:
                        ws.cell(row=row_index, column=1).value = '神奈川'
                    elif k == 0 and i == 14:
                        ws.cell(row=row_index, column=1).value = '新潟'
                    elif k == 0 and i == 15:
                        ws.cell(row=row_index, column=1).value = '富山'
                    elif k == 0 and i == 16:
                        ws.cell(row=row_index, column=1).value = '石川'
                    elif k == 0 and i == 17:
                        ws.cell(row=row_index, column=1).value = '福井'
                    elif k == 0 and i == 18:
                        ws.cell(row=row_index, column=1).value = '山梨'
                    elif k == 0 and i == 19:
                        ws.cell(row=row_index, column=1).value = '長野'
                    elif k == 0 and i == 20:
                        ws.cell(row=row_index, column=1).value = '岐阜'
                    elif k == 0 and i == 21:
                        ws.cell(row=row_index, column=1).value = '静岡'
                    elif k == 0 and i == 22:
                        ws.cell(row=row_index, column=1).value = '愛知'
                    elif k == 0 and i == 23:
                        ws.cell(row=row_index, column=1).value = '三重'
                    elif k == 0 and i == 24:
                        ws.cell(row=row_index, column=1).value = '滋賀'
                    elif k == 0 and i == 25:
                        ws.cell(row=row_index, column=1).value = '京都'
                    elif k == 0 and i == 26:
                        ws.cell(row=row_index, column=1).value = '大阪'
                    elif k == 0 and i == 27:
                        ws.cell(row=row_index, column=1).value = '兵庫'
                    elif k == 0 and i == 28:
                        ws.cell(row=row_index, column=1).value = '奈良'
                    elif k == 0 and i == 29:
                        ws.cell(row=row_index, column=1).value = '和歌山'
                    elif k == 0 and i == 30:
                        ws.cell(row=row_index, column=1).value = '鳥取'
                    elif k == 0 and i == 31:
                        ws.cell(row=row_index, column=1).value = '島根'
                    elif k == 0 and i == 32:
                        ws.cell(row=row_index, column=1).value = '岡山'
                    elif k == 0 and i == 33:
                        ws.cell(row=row_index, column=1).value = '広島'
                    elif k == 0 and i == 34:
                        ws.cell(row=row_index, column=1).value = '山口'
                    elif k == 0 and i == 35:
                        ws.cell(row=row_index, column=1).value = '徳島'
                    elif k == 0 and i == 36:
                        ws.cell(row=row_index, column=1).value = '香川'
                    elif k == 0 and i == 37:
                        ws.cell(row=row_index, column=1).value = '愛媛'
                    elif k == 0 and i == 38:
                        ws.cell(row=row_index, column=1).value = '高知'
                    elif k == 0 and i == 39:
                        ws.cell(row=row_index, column=1).value = '福岡'
                    elif k == 0 and i == 40:
                        ws.cell(row=row_index, column=1).value = '佐賀'
                    elif k == 0 and i == 41:
                        ws.cell(row=row_index, column=1).value = '長崎'
                    elif k == 0 and i == 42:
                        ws.cell(row=row_index, column=1).value = '熊本'
                    elif k == 0 and i == 43:
                        ws.cell(row=row_index, column=1).value = '大分'
                    elif k == 0 and i == 44:
                        ws.cell(row=row_index, column=1).value = '宮崎'
                    elif k == 0 and i == 45:
                        ws.cell(row=row_index, column=1).value = '鹿児島'
                    elif k == 0 and i == 46:
                        ws.cell(row=row_index, column=1).value = '沖縄'
                        
                    ws.cell(row=row_index, column=2).value = city.breach_ken_name
                    ws.cell(row=row_index, column=3).value = city.breach_damage
                    ws.cell(row=row_index, column=4).value = city.with_dike_damage
                    ws.cell(row=row_index, column=5).value = city.without_dike_damage
                    ws.cell(row=row_index, column=6).value = city.inland_damage
                    ws.cell(row=row_index, column=7).value = city.pit_damage
                    ws.cell(row=row_index, column=8).value = city.scouring_damage
                    ws.cell(row=row_index, column=9).value = city.debris_damage
                    ws.cell(row=row_index, column=10).value = city.landslide_damage
                    ws.cell(row=row_index, column=11).value = city.steepslope_damage
                    ws.cell(row=row_index, column=12).value = city.surge_damage
                    ws.cell(row=row_index, column=13).value = city.tsunami_damage
                    ws.cell(row=row_index, column=14).value = city.waves_damage
                    ws.cell(row=row_index, column=15).value = city.other_damage
                    ws.cell(row=row_index, column=16).value = city.sum_total_damage
    
            for j, zenken in enumerate(zenken_list[i]):
                row_index += 1
                if len(zencity_list[i]) == 0 and i == 0:
                    ws.cell(row=row_index, column=1).value = '北海道'
                elif len(zencity_list[i]) == 0 and i == 1:
                    ws.cell(row=row_index, column=1).value = '青森'
                elif len(zencity_list[i]) == 0 and i == 2:
                    ws.cell(row=row_index, column=1).value = '岩手'
                elif len(zencity_list[i]) == 0 and i == 3:
                    ws.cell(row=row_index, column=1).value = '宮城'
                elif len(zencity_list[i]) == 0 and i == 4:
                    ws.cell(row=row_index, column=1).value = '秋田'
                elif len(zencity_list[i]) == 0 and i == 5:
                    ws.cell(row=row_index, column=1).value = '山形'
                elif len(zencity_list[i]) == 0 and i == 6:
                    ws.cell(row=row_index, column=1).value = '福島'
                elif len(zencity_list[i]) == 0 and i == 7:
                    ws.cell(row=row_index, column=1).value = '茨城'
                elif len(zencity_list[i]) == 0 and i == 8:
                    ws.cell(row=row_index, column=1).value = '栃木'
                elif len(zencity_list[i]) == 0 and i == 9:
                    ws.cell(row=row_idx, column=1).value = '群馬'
                elif len(zencity_list[i]) == 0 and i == 10:
                    ws.cell(row=row_index, column=1).value = '埼玉'
                elif len(zencity_list[i]) == 0 and i == 11:
                    ws.cell(row=row_index, column=1).value = '千葉'
                elif len(zencity_list[i]) == 0 and i == 12:
                    ws.cell(row=row_index, column=1).value = '東京'
                elif len(zencity_list[i]) == 0 and i == 13:
                    ws.cell(row=row_index, column=1).value = '神奈川'
                elif len(zencity_list[i]) == 0 and i == 14:
                    ws.cell(row=row_index, column=1).value = '新潟'
                elif len(zencity_list[i]) == 0 and i == 15:
                    ws.cell(row=row_index, column=1).value = '富山'
                elif len(zencity_list[i]) == 0 and i == 16:
                    ws.cell(row=row_index, column=1).value = '石川'
                elif len(zencity_list[i]) == 0 and i == 17:
                    ws.cell(row=row_index, column=1).value = '福井'
                elif len(zencity_list[i]) == 0 and i == 18:
                    ws.cell(row=row_index, column=1).value = '山梨'
                elif len(zencity_list[i]) == 0 and i == 19:
                    ws.cell(row=row_index, column=1).value = '長野'
                elif len(zencity_list[i]) == 0 and i == 20:
                    ws.cell(row=row_index, column=1).value = '岐阜'
                elif len(zencity_list[i]) == 0 and i == 21:
                    ws.cell(row=row_index, column=1).value = '静岡'
                elif len(zencity_list[i]) == 0 and i == 22:
                    ws.cell(row=row_index, column=1).value = '愛知'
                elif len(zencity_list[i]) == 0 and i == 23:
                    ws.cell(row=row_index, column=1).value = '三重'
                elif len(zencity_list[i]) == 0 and i == 24:
                    ws.cell(row=row_index, column=1).value = '滋賀'
                elif len(zencity_list[i]) == 0 and i == 25:
                    ws.cell(row=row_index, column=1).value = '京都'
                elif len(zencity_list[i]) == 0 and i == 26:
                    ws.cell(row=row_index, column=1).value = '大阪'
                elif len(zencity_list[i]) == 0 and i == 27:
                    ws.cell(row=row_index, column=1).value = '兵庫'
                elif len(zencity_list[i]) == 0 and i == 28:
                    ws.cell(row=row_index, column=1).value = '奈良'
                elif len(zencity_list[i]) == 0 and i == 29:
                    ws.cell(row=row_index, column=1).value = '和歌山'
                elif len(zencity_list[i]) == 0 and i == 30:
                    ws.cell(row=row_index, column=1).value = '鳥取'
                elif len(zencity_list[i]) == 0 and i == 31:
                    ws.cell(row=row_index, column=1).value = '島根'
                elif len(zencity_list[i]) == 0 and i == 32:
                    ws.cell(row=row_index, column=1).value = '岡山'
                elif len(zencity_list[i]) == 0 and i == 33:
                    ws.cell(row=row_index, column=1).value = '広島'
                elif len(zencity_list[i]) == 0 and i == 34:
                    ws.cell(row=row_index, column=1).value = '山口'
                elif len(zencity_list[i]) == 0 and i == 35:
                    ws.cell(row=row_index, column=1).value = '徳島'
                elif len(zencity_list[i]) == 0 and i == 36:
                    ws.cell(row=row_index, column=1).value = '香川'
                elif len(zencity_list[i]) == 0 and i == 37:
                    ws.cell(row=row_index, column=1).value = '愛媛'
                elif len(zencity_list[i]) == 0 and i == 38:
                    ws.cell(row=row_index, column=1).value = '高知'
                elif len(zencity_list[i]) == 0 and i == 39:
                    ws.cell(row=row_index, column=1).value = '福岡'
                elif len(zencity_list[i]) == 0 and i == 40:
                    ws.cell(row=row_index, column=1).value = '佐賀'
                elif len(zencity_list[i]) == 0 and i == 41:
                    ws.cell(row=row_index, column=1).value = '長崎'
                elif len(zencity_list[i]) == 0 and i == 42:
                    ws.cell(row=row_index, column=1).value = '熊本'
                elif len(zencity_list[i]) == 0 and i == 43:
                    ws.cell(row=row_index, column=1).value = '大分'
                elif len(zencity_list[i]) == 0 and i == 44:
                    ws.cell(row=row_index, column=1).value = '宮崎'
                elif len(zencity_list[i]) == 0 and i == 45:
                    ws.cell(row=row_index, column=1).value = '鹿児島'
                elif len(zencity_list[i]) == 0 and i == 46:
                    ws.cell(row=row_index, column=1).value = '沖縄'
                    
                ws.cell(row=row_index, column=2).value = '計'
                ws.cell(row=row_index, column=3).value = zenken.breach_damage
                ws.cell(row=row_index, column=4).value = zenken.with_dike_damage
                ws.cell(row=row_index, column=5).value = zenken.without_dike_damage
                ws.cell(row=row_index, column=6).value = zenken.inland_damage
                ws.cell(row=row_index, column=7).value = zenken.pit_damage
                ws.cell(row=row_index, column=8).value = zenken.scouring_damage
                ws.cell(row=row_index, column=9).value = zenken.debris_damage
                ws.cell(row=row_index, column=10).value = zenken.landslide_damage
                ws.cell(row=row_index, column=11).value = zenken.steepslope_damage
                ws.cell(row=row_index, column=12).value = zenken.surge_damage
                ws.cell(row=row_index, column=13).value = zenken.tsunami_damage
                ws.cell(row=row_index, column=14).value = zenken.waves_damage
                ws.cell(row=row_index, column=15).value = zenken.other_damage
                ws.cell(row=row_index, column=16).value = zenken.sum_total_damage
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo25_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo25_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo25.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo25_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo25_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo25_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
