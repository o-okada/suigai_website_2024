###############################################################################
### 帳票名：hyo_06資産等別一般資産等被害額.xlsx
### ファイル名：P0700EStat/hyo06_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO06:
    def __init__(self, ):
        pass

###############################################################################
### 帳票名：hyo_06資産等別一般資産等被害額.xlsx
### 関数名：get_hyo06_ken(ken_code)
### 1 都道府県別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo06_ken(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo06_ken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo06_ken()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if ken_code in constants.ken_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo06_ken()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo06_ken()関数 STEP 2/3.', 'DEBUG')
        hyo06_ken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (IPPAN01.house_damage) IS NULL THEN 0.00 ELSE IPPAN01.house_damage END, 
                CASE WHEN (IPPAN02.household_damage) IS NULL THEN 0.00 ELSE IPPAN02.household_damage END, 
                CASE WHEN (IPPAN03.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN03.farmer_fisher_damage END, 
                CASE WHEN (IPPAN04.office_damage) IS NULL THEN 0.00 ELSE IPPAN04.office_damage END, 
                CASE WHEN (IPPAN05.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN05.house_alt_clean_damage END, 
                CASE WHEN (IPPAN06.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN06.office_alt_damage END, 

                CASE WHEN (IPPAN01.house_damage) IS NULL THEN 0.00 ELSE IPPAN01.house_damage END+ 
                CASE WHEN (IPPAN02.household_damage) IS NULL THEN 0.00 ELSE IPPAN02.household_damage END+ 
                CASE WHEN (IPPAN03.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN03.farmer_fisher_damage END+ 
                CASE WHEN (IPPAN04.office_damage) IS NULL THEN 0.00 ELSE IPPAN04.office_damage END+ 
                CASE WHEN (IPPAN05.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN05.house_alt_clean_damage END+ 
                CASE WHEN (IPPAN06.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN06.office_alt_damage END 
                AS asset_damage, 
                
                CASE WHEN (IPPAN07.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN07.office_sales_damage END, 
                CASE WHEN (IPPAN08.crop_damage) IS NULL THEN 0.00 ELSE IPPAN08.crop_damage END, 
                
                CASE WHEN (IPPAN01.house_damage) IS NULL THEN 0.00 ELSE IPPAN01.house_damage END+ 
                CASE WHEN (IPPAN02.household_damage) IS NULL THEN 0.00 ELSE IPPAN02.household_damage END+ 
                CASE WHEN (IPPAN03.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN03.farmer_fisher_damage END+ 
                CASE WHEN (IPPAN04.office_damage) IS NULL THEN 0.00 ELSE IPPAN04.office_damage END+ 
                CASE WHEN (IPPAN05.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN05.house_alt_clean_damage END+ 
                CASE WHEN (IPPAN06.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN06.office_alt_damage END+ 
                CASE WHEN (IPPAN07.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN07.office_sales_damage END+ 
                CASE WHEN (IPPAN08.crop_damage) IS NULL THEN 0.00 ELSE IPPAN08.crop_damage END
                AS asset_sales_damage 
                
            FROM 

            -- 都道府県
            (SELECT 
                ken_code, ken_name 
            FROM KEN 
            WHERE ken_code=%(KEN_CODE)s 
            ) KEN1, 
                
            -- 家屋被害額
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END 
                ) AS house_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s
            ) IPPAN01, 
                
            -- 家庭用品被害額
            (SELECT 
                SUM(
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END 
                ) AS household_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN02, 
                
            -- 農漁家資産被害額
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END
                ) AS farmer_fisher_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN03, 
                
            -- 事業所資産被害額
            (SELECT 
                SUM(
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END
                ) AS office_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN04, 
                
            -- 家庭応急対策費
            (SELECT 
                SUM(
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END
                ) AS house_alt_clean_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN05, 
                
            -- 事業所応急対策費
            (SELECT 
                SUM(
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END
                ) AS office_alt_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN06, 
                
            -- 営業停止損失額
            (SELECT 
                SUM(
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END
                ) AS office_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN07, 
                
            -- 農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END
                ) AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN08 
                
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo06_ken()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo06_ken()関数が正常終了しました。', 'INFO')
        return True, hyo06_ken_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo06_ken()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo06_ken()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo06_ken()関数が異常終了しました。', 'ERROR')
        return False, []
    
###############################################################################
### 帳票名：hyo_06資産等別一般資産等被害額.xlsx
### 関数名：get_hyo06_zenkoku()
### 2 全国_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo06_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo06_zenkoku()関数 STEP 1/3.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo06_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo06_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.house_damage) IS NULL THEN 0.00 ELSE IPPAN01.house_damage END, 
                CASE WHEN (IPPAN02.household_damage) IS NULL THEN 0.00 ELSE IPPAN02.household_damage END, 
                CASE WHEN (IPPAN03.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN03.farmer_fisher_damage END, 
                CASE WHEN (IPPAN04.office_damage) IS NULL THEN 0.00 ELSE IPPAN04.office_damage END, 
                CASE WHEN (IPPAN05.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN05.house_alt_clean_damage END, 
                CASE WHEN (IPPAN06.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN06.office_alt_damage END, 

                CASE WHEN (IPPAN01.house_damage) IS NULL THEN 0.00 ELSE IPPAN01.house_damage END+ 
                CASE WHEN (IPPAN02.household_damage) IS NULL THEN 0.00 ELSE IPPAN02.household_damage END+ 
                CASE WHEN (IPPAN03.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN03.farmer_fisher_damage END+ 
                CASE WHEN (IPPAN04.office_damage) IS NULL THEN 0.00 ELSE IPPAN04.office_damage END+ 
                CASE WHEN (IPPAN05.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN05.house_alt_clean_damage END+ 
                CASE WHEN (IPPAN06.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN06.office_alt_damage END 
                AS asset_damage, 
                
                CASE WHEN (IPPAN07.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN07.office_sales_damage END, 
                CASE WHEN (IPPAN08.crop_damage) IS NULL THEN 0.00 ELSE IPPAN08.crop_damage END, 
                
                CASE WHEN (IPPAN01.house_damage) IS NULL THEN 0.00 ELSE IPPAN01.house_damage END+ 
                CASE WHEN (IPPAN02.household_damage) IS NULL THEN 0.00 ELSE IPPAN02.household_damage END+ 
                CASE WHEN (IPPAN03.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN03.farmer_fisher_damage END+ 
                CASE WHEN (IPPAN04.office_damage) IS NULL THEN 0.00 ELSE IPPAN04.office_damage END+ 
                CASE WHEN (IPPAN05.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN05.house_alt_clean_damage END+ 
                CASE WHEN (IPPAN06.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN06.office_alt_damage END+ 
                CASE WHEN (IPPAN07.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN07.office_sales_damage END+ 
                CASE WHEN (IPPAN08.crop_damage) IS NULL THEN 0.00 ELSE IPPAN08.crop_damage END
                AS asset_sales_damage 
                
            FROM 
                
            -- 家屋被害額
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END 
                ) AS house_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN01, 
                
            -- 家庭用品被害額
            (SELECT 
                SUM(
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END 
                ) AS household_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN02, 
                
            -- 農漁家資産被害額
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END
                ) AS farmer_fisher_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN03, 
                
            -- 事業所資産被害額
            (SELECT 
                SUM(
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END
                ) AS office_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN04, 
                
            -- 家庭応急対策費
            (SELECT 
                SUM(
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END
                ) AS house_alt_clean_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN05, 
                
            -- 事業所応急対策費
            (SELECT 
                SUM(
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END
                ) AS office_alt_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN06, 
                
            -- 営業停止損失額
            (SELECT 
                SUM(
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END
                ) AS office_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN07, 
                
            -- 農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END
                ) AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW
            WHERE deleted_at IS NULL 
            ) IPPAN08 
                
            """, [])
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo06_zenkoku()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo06_zenkoku()関数が正常終了しました。', 'INFO')
        return True, hyo06_zenkoku_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo06_zenkoku()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo06_zenkoku()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo06_zenkoku()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_06資産等別一般資産等被害額.xlsx
### 関数名：hyo06_view(request)
### urlpattern：path('hyo06/', hyo06_views.hyo06_view, name='hyo06_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo06_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo06_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 2/4.', 'DEBUG')
        ### 1 都道府県別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 2_1/4.', 'DEBUG')
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo06_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)

        ### 2 全国_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 2_2/4.', 'DEBUG')
        bool_return, zenkoku_list = get_hyo06_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 3/4.', 'DEBUG')
        ### 1 都道府県別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 3_1/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.house_damage={}'.format(i, j, ken.house_damage), flush=True)

        ### 2 全国_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 3_2/4.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.house_damage={}'.format(i, zenkoku.house_damage), flush=True)

        #######################################################################
        ### レスポンスセット処理(0040)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo06_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo06', 
            'ken_list': ken_list, 
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo06_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo06_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo06_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo06_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_06資産等別一般資産等被害額.xlsx
### 関数名：hyo06_download_view(request)
### urlpattern：path('download/hyo06/', hyo06_views.hyo06_download_view, name='hyo06_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo06_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo06_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 1 都道府県別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 2_1/5.', 'DEBUG')
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo06_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)

        ### 2 全国_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 2_2/5.', 'DEBUG')
        bool_return, zenkoku_list = get_hyo06_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 都道府県別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 3_1/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.house_damage={}'.format(i, j, ken.house_damage), flush=True)

        ### 2 全国_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 3_2/5.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.house_damage={}'.format(i, zenkoku.house_damage), flush=True)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo06.xlsx'
        ### download_file_path = 'static/download_hyo06.xlsx'
        template_file_path = 'static/template/template_hyo06.xlsx'
        download_file_path = 'static/tmp/download_hyo06.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo06'
        
        ws.cell(row=1, column=1).value = '３．資産別等被害'
        ws.cell(row=4, column=1).value = '　表－６　資産等別一般資産等被害額'
        ws.cell(row=6, column=11).value = '（単位：百万円）'
        ws.cell(row=7, column=1).value = '都　道'
        ws.cell(row=7, column=2).value = '家　屋'
        ws.cell(row=7, column=3).value = '家庭用品'
        ws.cell(row=7, column=4).value = '農漁家'
        ws.cell(row=7, column=5).value = '事業所'
        ws.cell(row=7, column=6).value = '家庭応急'
        ws.cell(row=7, column=7).value = '事業所応急'
        ws.cell(row=7, column=8).value = '計'
        ws.cell(row=7, column=9).value = '営業停止'
        ws.cell(row=7, column=10).value = '農作物'
        ws.cell(row=7, column=11).value = '合　計'
        ws.cell(row=8, column=1).value = '府県名'
        ws.cell(row=8, column=4).value = '資　産'
        ws.cell(row=8, column=5).value = '資　産'
        ws.cell(row=8, column=6).value = '対策費'
        ws.cell(row=8, column=7).value = '対策費'
        ws.cell(row=8, column=9).value = '損失額'
        ws.cell(row=8, column=10).value = '被害額'
        
        row_index = 8
        
        ### 1 都道府県別_被害額_合計
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                row_index += 1
                
                ws.cell(row=row_index, column=1).value = ken.ken_name
                ws.cell(row=row_index, column=2).value = ken.house_damage
                ws.cell(row=row_index, column=3).value = ken.household_damage
                ws.cell(row=row_index, column=4).value = ken.farmer_fisher_damage
                ws.cell(row=row_index, column=5).value = ken.office_damage
                ws.cell(row=row_index, column=6).value = ken.house_alt_clean_damage
                ws.cell(row=row_index, column=7).value = ken.office_alt_damage
                ws.cell(row=row_index, column=8).value = ken.asset_damage
                ws.cell(row=row_index, column=9).value = ken.office_sales_damage
                ws.cell(row=row_index, column=10).value = ken.crop_damage
                ws.cell(row=row_index, column=11).value = ken.asset_sales_damage

        ### 2 全国_被害額_合計
        for i, zenkoku in enumerate(zenkoku_list):
            row_index += 1
            
            ws.cell(row=row_index, column=1).value = '合　計'
            ws.cell(row=row_index, column=2).value = zenkoku.house_damage
            ws.cell(row=row_index, column=3).value = zenkoku.household_damage
            ws.cell(row=row_index, column=4).value = zenkoku.farmer_fisher_damage
            ws.cell(row=row_index, column=5).value = zenkoku.office_damage
            ws.cell(row=row_index, column=6).value = zenkoku.house_alt_clean_damage
            ws.cell(row=row_index, column=7).value = zenkoku.office_alt_damage
            ws.cell(row=row_index, column=8).value = zenkoku.asset_damage
            ws.cell(row=row_index, column=9).value = zenkoku.office_sales_damage
            ws.cell(row=row_index, column=10).value = zenkoku.crop_damage
            ws.cell(row=row_index, column=11).value = zenkoku.asset_sales_damage
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo06_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo06_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo06.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo06_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo06_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo06_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
