###############################################################################
### 帳票名：hyo_24水害原因別都道府県別公益事業等被害額.xlsx
### ファイル名：P0700EStat/hyo24_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO24:
    def __init__(self, ken_code, ken_name, breach_damage, with_dike_damage, without_dike_damage, inland_damage, pit_damage, scouring_damage, debris_damage, landslide_damage, steepslope_damage, surge_damage, tsunami_damage, waves_damage, other_damage, sum_total_damage):
        self.ken_code = ken_code
        self.ken_name = ken_name
        self.breach_damage = breach_damage
        self.with_dike_damage = with_dike_damage
        self.without_dike_damage = without_dike_damage
        self.inland_damage = inland_damage
        self.pit_damage = pit_damage
        self.scouring_damage = scouring_damage
        self.debris_damage = debris_damage
        self.landslide_damage = landslide_damage
        self.steepslope_damage = steepslope_damage
        self.surge_damage = surge_damage
        self.tsunami_damage = tsunami_damage
        self.waves_damage = waves_damage
        self.other_damage = other_damage
        self.sum_total_damage = sum_total_damage

###############################################################################
### 帳票名：hyo_24水害原因別都道府県別公益事業等被害額.xlsx
### 関数名：get_hyo24(cause_code)
### 1 県別_水害原因別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo24(cause_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo24()関数 cause_code={}'.format(cause_code), 'DEBUG')
        if cause_code in constants.cause_values:
            pass
        else:
            return False, []
        
        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        cause_keys = ['CAUSE_CODE']
        cause_values = [cause_code]
        params = dict(zip(cause_keys, cause_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24()関数 STEP 2/3.', 'DEBUG')
        hyo24_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 都道府県
            (SELECT 
                ken_code, 
                ken_name 
            FROM KEN 
            ORDER BY ken_code 
            ) KEN1 
            
            -- 公益事業被害額
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s 
            GROUP BY ken_code 
            ) KOEKI01 
            ON KEN1.ken_code=KOEKI01.ken_code 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24()関数 STEP 3/3.', 'DEBUG')
        return True, hyo24_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_24水害原因別都道府県別公益事業等被害額.xlsx
### 関数名：get_hyo24_zenkoku(cause_code)
### 2 全国_水害原因別_被害額_合計 下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo24_zenkoku(cause_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_zenkoku()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo24_zenkoku()関数 cause_code={}'.format(cause_code), 'DEBUG')
        if cause_code in constants.cause_values:
            pass
        else:
            return False, []
        
        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        cause_keys = ['CAUSE_CODE']
        cause_values = [cause_code]
        params = dict(zip(cause_keys, cause_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo24_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s
            ) KOEKI01 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_zenkoku()関数 STEP 3/3.', 'DEBUG')
        return True, hyo24_zenkoku_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_24水害原因別都道府県別公益事業等被害額.xlsx
### 関数名：get_hyo24_sum_total()
### 3 県別_全水害原因別_被害額_合計 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo24_sum_total():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_sum_total()関数 STEP 1/3.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_sum_total()関数 STEP 2/3.', 'DEBUG')
        hyo24_sum_total_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 都道府県
            (SELECT 
                ken_code, 
                ken_name 
            FROM KEN 
            ORDER BY ken_code 
            ) KEN1 
            
            -- 公益事業被害額
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY ken_code 
            ) KOEKI01 
            ON KEN1.ken_code=KOEKI01.ken_code 
            
            """, [])

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_sum_total()関数 STEP 3/3.', 'DEBUG')
        return True, hyo24_sum_total_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_24水害原因別都道府県別公益事業等被害額.xlsx
### 関数名：get_hyo24_sum_total_zenkoku()
### 4 全国_全水害原因別_被害額_合計 下端 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo24_sum_total_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_sum_total_zenkoku()関数 STEP 1/3.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_sum_total_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo24_sum_total_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI01 
            
            """, [])

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo24_sum_total_zenkoku()関数 STEP 3/3.', 'DEBUG')
        return True, hyo24_sum_total_zenkoku_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_24水害原因別都道府県別公益事業等被害額.xlsx
### 関数名：hyo24_view(request)
### urlpattern：path('hyo24/', hyo24_views.hyo24_view, name='hyo24_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo24_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo24_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo24_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo24_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo24_view()関数 STEP 2/4.', 'DEBUG')
        params = dict(zip(constants.cause_keys, constants.cause_values))

        ### 1 県別_水害原因別_被害額_合計
        bool_return, breach_list = get_hyo24(params['BREACH'])
        if bool_return == False:
            raise Exception
            
        bool_return, with_dike_list = get_hyo24(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception
            
        bool_return, without_dike_list = get_hyo24(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception
            
        bool_return, inland_list = get_hyo24(params['INLAND'])
        if bool_return == False:
            raise Exception
            
        bool_return, pit_list = get_hyo24(params['PIT'])
        if bool_return == False:
            raise Exception
            
        bool_return, scouring_list = get_hyo24(params['SCOURING'])
        if bool_return == False:
            raise Exception
            
        bool_return, debris_list = get_hyo24(params['DEBRIS'])
        if bool_return == False:
            raise Exception
            
        bool_return, landslide_list = get_hyo24(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception
            
        bool_return, steepslope_list = get_hyo24(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception
            
        bool_return, surge_list = get_hyo24(params['SURGE'])
        if bool_return == False:
            raise Exception
            
        bool_return, tsunami_list = get_hyo24(params['TSUNAMI'])
        if bool_return == False:
            raise Exception
            
        bool_return, waves_list = get_hyo24(params['WAVES'])
        if bool_return == False:
            raise Exception
            
        bool_return, other_list = get_hyo24(params['OTHER'])
        if bool_return == False:
            raise Exception
        
        ### 2 全国_水害原因別_被害額_合計 下端
        bool_return, breach_zenkoku_list = get_hyo24_zenkoku(params['BREACH'])
        if bool_return == False:
            raise Exception

        bool_return, with_dike_zenkoku_list = get_hyo24_zenkoku(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, without_dike_zenkoku_list = get_hyo24_zenkoku(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, inland_zenkoku_list = get_hyo24_zenkoku(params['INLAND'])
        if bool_return == False:
            raise Exception

        bool_return, pit_zenkoku_list = get_hyo24_zenkoku(params['PIT'])
        if bool_return == False:
            raise Exception

        bool_return, scouring_zenkoku_list = get_hyo24_zenkoku(params['SCOURING'])
        if bool_return == False:
            raise Exception

        bool_return, debris_zenkoku_list = get_hyo24_zenkoku(params['DEBRIS'])
        if bool_return == False:
            raise Exception

        bool_return, landslide_zenkoku_list = get_hyo24_zenkoku(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception

        bool_return, steepslope_zenkoku_list = get_hyo24_zenkoku(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception

        bool_return, surge_zenkoku_list = get_hyo24_zenkoku(params['SURGE'])
        if bool_return == False:
            raise Exception

        bool_return, tsunami_zenkoku_list = get_hyo24_zenkoku(params['TSUNAMI'])
        if bool_return == False:
            raise Exception

        bool_return, waves_zenkoku_list = get_hyo24_zenkoku(params['WAVES'])
        if bool_return == False:
            raise Exception

        bool_return, other_zenkoku_list = get_hyo24_zenkoku(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 3 県別_全水害原因別_被害額_合計 右端
        bool_return, sum_total_list = get_hyo24_sum_total()
        if bool_return == False:
            raise Exception
        
        ### 4 全国_全水害原因別_被害額_合計 下端 右端
        bool_return, sum_total_zenkoku_list = get_hyo24_sum_total_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo24_view()関数 STEP 3/4.', 'DEBUG')
        ### 1 県別_水害原因別_被害額_合計
        ### 3 県別_全水害原因別_被害額_合計 右端
        temp_list = []
        for breach, with_dike, without_dike, inland, pit, scouring, debris, landslide, steepslope, surge, tsunami, waves, other, sum_total in zip(
            breach_list, with_dike_list, without_dike_list, inland_list, pit_list, 
            scouring_list, debris_list, landslide_list, steepslope_list, surge_list, 
            tsunami_list, waves_list, other_list, sum_total_list):
            hyo24 = HYO24(
                breach.ken_code, breach.ken_name, 
                breach.damage, with_dike.damage, without_dike.damage, inland.damage, pit.damage, 
                scouring.damage, debris.damage, landslide.damage, steepslope.damage, surge.damage, 
                tsunami.damage, waves.damage, other.damage, sum_total.damage)
            temp_list.append(hyo24)
            
        ### 2 全国_水害原因別_被害額_合計 下端
        ### 4 全国_全水害原因別_被害額_合計 下端 右端
        zenkoku_list = []
        for breach_zenkoku, with_dike_zenkoku, without_dike_zenkoku, inland_zenkoku, pit_zenkoku, scouring_zenkoku, debris_zenkoku, landslide_zenkoku, steepslope_zenkoku, surge_zenkoku, tsunami_zenkoku, waves_zenkoku, other_zenkoku, sum_total_zenkoku in zip(
            breach_zenkoku_list, with_dike_zenkoku_list, without_dike_zenkoku_list, inland_zenkoku_list, pit_zenkoku_list, 
            scouring_zenkoku_list, debris_zenkoku_list, landslide_zenkoku_list, steepslope_zenkoku_list, surge_zenkoku_list, 
            tsunami_zenkoku_list, waves_zenkoku_list, other_zenkoku_list, sum_total_zenkoku_list):
            hyo24 = HYO24(
                '', '', 
                breach_zenkoku.damage, with_dike_zenkoku.damage, without_dike_zenkoku.damage, inland_zenkoku.damage, pit_zenkoku.damage, 
                scouring_zenkoku.damage, debris_zenkoku.damage, landslide_zenkoku.damage, steepslope_zenkoku.damage, surge_zenkoku.damage, 
                tsunami_zenkoku.damage, waves_zenkoku.damage, other_zenkoku.damage, sum_total_zenkoku.damage)
            zenkoku_list.append(hyo24)
        
        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo24_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo24', 
            'temp_list': temp_list, 
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo24_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo24_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo24_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo24_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_24水害原因別都道府県別公益事業等被害額.xlsx
### 関数名：hyo24_download_view(request)
### urlpattern：path('download/hyo24/', hyo24_views.hyo24_download_view, name='hyo24_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo24_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo24_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo24_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo24_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo24_download_view()関数 STEP 2/5.', 'DEBUG')
        params = dict(zip(constants.cause_keys, constants.cause_values))

        ### 1 県別_水害原因別_被害額_合計
        bool_return, breach_list = get_hyo24(params['BREACH'])
        if bool_return == False:
            raise Exception
            
        bool_return, with_dike_list = get_hyo24(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception
            
        bool_return, without_dike_list = get_hyo24(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception
            
        bool_return, inland_list = get_hyo24(params['INLAND'])
        if bool_return == False:
            raise Exception
            
        bool_return, pit_list = get_hyo24(params['PIT'])
        if bool_return == False:
            raise Exception
            
        bool_return, scouring_list = get_hyo24(params['SCOURING'])
        if bool_return == False:
            raise Exception
            
        bool_return, debris_list = get_hyo24(params['DEBRIS'])
        if bool_return == False:
            raise Exception
            
        bool_return, landslide_list = get_hyo24(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception
            
        bool_return, steepslope_list = get_hyo24(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception
            
        bool_return, surge_list = get_hyo24(params['SURGE'])
        if bool_return == False:
            raise Exception
            
        bool_return, tsunami_list = get_hyo24(params['TSUNAMI'])
        if bool_return == False:
            raise Exception
            
        bool_return, waves_list = get_hyo24(params['WAVES'])
        if bool_return == False:
            raise Exception
            
        bool_return, other_list = get_hyo24(params['OTHER'])
        if bool_return == False:
            raise Exception
        
        ### 2 全国_水害原因別_被害額_合計 下端
        bool_return, breach_zenkoku_list = get_hyo24_zenkoku(params['BREACH'])
        if bool_return == False:
            raise Exception

        bool_return, with_dike_zenkoku_list = get_hyo24_zenkoku(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, without_dike_zenkoku_list = get_hyo24_zenkoku(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, inland_zenkoku_list = get_hyo24_zenkoku(params['INLAND'])
        if bool_return == False:
            raise Exception

        bool_return, pit_zenkoku_list = get_hyo24_zenkoku(params['PIT'])
        if bool_return == False:
            raise Exception

        bool_return, scouring_zenkoku_list = get_hyo24_zenkoku(params['SCOURING'])
        if bool_return == False:
            raise Exception

        bool_return, debris_zenkoku_list = get_hyo24_zenkoku(params['DEBRIS'])
        if bool_return == False:
            raise Exception

        bool_return, landslide_zenkoku_list = get_hyo24_zenkoku(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception

        bool_return, steepslope_zenkoku_list = get_hyo24_zenkoku(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception

        bool_return, surge_zenkoku_list = get_hyo24_zenkoku(params['SURGE'])
        if bool_return == False:
            raise Exception

        bool_return, tsunami_zenkoku_list = get_hyo24_zenkoku(params['TSUNAMI'])
        if bool_return == False:
            raise Exception

        bool_return, waves_zenkoku_list = get_hyo24_zenkoku(params['WAVES'])
        if bool_return == False:
            raise Exception

        bool_return, other_zenkoku_list = get_hyo24_zenkoku(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 3 県別_全水害原因別_被害額_合計 右端
        bool_return, sum_total_list = get_hyo24_sum_total()
        if bool_return == False:
            raise Exception
        
        ### 4 全国_全水害原因別_被害額_合計 下端 右端
        bool_return, sum_total_zenkoku_list = get_hyo24_sum_total_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo24_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 県別_水害原因別_被害額_合計
        ### 3 県別_全水害原因別_被害額_合計 右端
        temp_list = []
        for breach, with_dike, without_dike, inland, pit, scouring, debris, landslide, steepslope, surge, tsunami, waves, other, sum_total in zip(
            breach_list, with_dike_list, without_dike_list, inland_list, pit_list, 
            scouring_list, debris_list, landslide_list, steepslope_list, surge_list, 
            tsunami_list, waves_list, other_list, sum_total_list):
            hyo24 = HYO24(
                breach.ken_code, breach.ken_name, 
                breach.damage, with_dike.damage, without_dike.damage, inland.damage, pit.damage, 
                scouring.damage, debris.damage, landslide.damage, steepslope.damage, surge.damage, 
                tsunami.damage, waves.damage, other.damage, sum_total.damage)
            temp_list.append(hyo24)
            
        ### 2 全国_水害原因別_被害額_合計 下端
        ### 4 全国_全水害原因別_被害額_合計 下端 右端
        zenkoku_list = []
        for breach_zenkoku, with_dike_zenkoku, without_dike_zenkoku, inland_zenkoku, pit_zenkoku, scouring_zenkoku, debris_zenkoku, landslide_zenkoku, steepslope_zenkoku, surge_zenkoku, tsunami_zenkoku, waves_zenkoku, other_zenkoku, sum_total_zenkoku in zip(
            breach_zenkoku_list, with_dike_zenkoku_list, without_dike_zenkoku_list, inland_zenkoku_list, pit_zenkoku_list, 
            scouring_zenkoku_list, debris_zenkoku_list, landslide_zenkoku_list, steepslope_zenkoku_list, surge_zenkoku_list, 
            tsunami_zenkoku_list, waves_zenkoku_list, other_zenkoku_list, sum_total_zenkoku_list):
            hyo24 = HYO24(
                '', '', 
                breach_zenkoku.damage, with_dike_zenkoku.damage, without_dike_zenkoku.damage, inland_zenkoku.damage, pit_zenkoku.damage, 
                scouring_zenkoku.damage, debris_zenkoku.damage, landslide_zenkoku.damage, steepslope_zenkoku.damage, surge_zenkoku.damage, 
                tsunami_zenkoku.damage, waves_zenkoku.damage, other_zenkoku.damage, sum_total_zenkoku.damage)
            zenkoku_list.append(hyo24)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo24_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo24.xlsx'
        ### download_file_path = 'static/download_hyo24.xlsx'
        template_file_path = 'static/template/template_hyo24.xlsx'
        download_file_path = 'static/tmp/download_hyo24.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo24'
        
        print_log('[DEBUG] P0700EStat.hyo24_download_view()関数 STEP 4_1/5.', 'DEBUG')
        ws.cell(row=1, column=1).value = '表－２４　水害原因別都道府県別公益事業等被害額'
        ws.cell(row=2, column=15).value = '(単位：千円)'
        ws.cell(row=3, column=1).value = '都道府県名'
        ws.cell(row=3, column=2).value = '破　堤'
        ws.cell(row=3, column=3).value = '有堤部溢水'
        ws.cell(row=3, column=4).value = '無堤部溢水'
        ws.cell(row=3, column=5).value = '内　水'
        ws.cell(row=3, column=6).value = '窪地内水'
        ws.cell(row=3, column=7).value = '洗掘・流失'
        ws.cell(row=3, column=8).value = '土石流'
        ws.cell(row=3, column=9).value = '地すべり'
        ws.cell(row=3, column=10).value = '急傾斜地崩壊'
        ws.cell(row=3, column=11).value = '高　潮'
        ws.cell(row=3, column=12).value = '津　波'
        ws.cell(row=3, column=13).value = '波　浪'
        ws.cell(row=3, column=14).value = 'その他'
        ws.cell(row=3, column=15).value = '合　計'
        
        row_index = 3
        for i, temp in enumerate(temp_list):
            row_index += 1
            print('temp.ken_code={}'.format(temp.ken_code), flush=True)
            print('temp.ken_name={}'.format(temp.ken_name), flush=True)
            print('temp.breach_damage={}'.format(temp.breach_damage), flush=True)
            print('temp.with_dike_damage={}'.format(temp.with_dike_damage), flush=True)
            print('temp.without_dike_damage={}'.format(temp.without_dike_damage), flush=True)
            print('temp.inland_damage={}'.format(temp.inland_damage), flush=True)
            print('temp.pit_damage={}'.format(temp.pit_damage), flush=True)
            print('temp.scouring_damage={}'.format(temp.scouring_damage), flush=True)
            print('temp.debris_damage={}'.format(temp.debris_damage), flush=True)
            print('temp.landslide_damage={}'.format(temp.landslide_damage), flush=True)
            print('temp.steepslope_damage={}'.format(temp.steepslope_damage), flush=True)
            print('temp.surge_damage={}'.format(temp.surge_damage), flush=True)
            print('temp.tsunami_damage={}'.format(temp.tsunami_damage), flush=True)
            print('temp.waves_damage={}'.format(temp.waves_damage), flush=True)
            print('temp.other_damage={}'.format(temp.other_damage), flush=True)
            print('temp.sum_total_damage={}'.format(temp.sum_total_damage), flush=True)
            ws.cell(row=row_index, column=1).value = temp.ken_name
            ws.cell(row=row_index, column=2).value = temp.breach_damage
            ws.cell(row=row_index, column=3).value = temp.with_dike_damage
            ws.cell(row=row_index, column=4).value = temp.without_dike_damage
            ws.cell(row=row_index, column=5).value = temp.inland_damage
            ws.cell(row=row_index, column=6).value = temp.pit_damage
            ws.cell(row=row_index, column=7).value = temp.scouring_damage
            ws.cell(row=row_index, column=8).value = temp.debris_damage
            ws.cell(row=row_index, column=9).value = temp.landslide_damage
            ws.cell(row=row_index, column=10).value = temp.steepslope_damage
            ws.cell(row=row_index, column=11).value = temp.surge_damage
            ws.cell(row=row_index, column=12).value = temp.tsunami_damage
            ws.cell(row=row_index, column=13).value = temp.waves_damage
            ws.cell(row=row_index, column=14).value = temp.other_damage
            ws.cell(row=row_index, column=15).value = temp.sum_total_damage
            
        for i, zenkoku in enumerate(zenkoku_list):
            row_index += 1
            print('zenkoku.ken_code={}'.format(zenkoku.ken_code), flush=True)
            print('zenkoku.ken_name={}'.format(zenkoku.ken_name), flush=True)
            print('zenkoku.breach_damage={}'.format(zenkoku.breach_damage), flush=True)
            print('zenkoku.with_dike_damage={}'.format(zenkoku.with_dike_damage), flush=True)
            print('zenkoku.without_dike_damage={}'.format(zenkoku.without_dike_damage), flush=True)
            print('zenkoku.inland_damage={}'.format(zenkoku.inland_damage), flush=True)
            print('zenkoku.pit_damage={}'.format(zenkoku.pit_damage), flush=True)
            print('zenkoku.scouring_damage={}'.format(zenkoku.scouring_damage), flush=True)
            print('zenkoku.debris_damage={}'.format(zenkoku.debris_damage), flush=True)
            print('zenkoku.landslide_damage={}'.format(zenkoku.landslide_damage), flush=True)
            print('zenkoku.steepslope_damage={}'.format(zenkoku.steepslope_damage), flush=True)
            print('zenkoku.surge_damage={}'.format(zenkoku.surge_damage), flush=True)
            print('zenkoku.tsunami_damage={}'.format(zenkoku.tsunami_damage), flush=True)
            print('zenkoku.waves_damage={}'.format(zenkoku.waves_damage), flush=True)
            print('zenkoku.other_damage={}'.format(zenkoku.other_damage), flush=True)
            print('zenkoku.sum_total_damage={}'.format(zenkoku.sum_total_damage), flush=True)
            ws.cell(row=row_index, column=1).value = '全　国'
            ws.cell(row=row_index, column=2).value = zenkoku.breach_damage
            ws.cell(row=row_index, column=3).value = zenkoku.with_dike_damage
            ws.cell(row=row_index, column=4).value = zenkoku.without_dike_damage
            ws.cell(row=row_index, column=5).value = zenkoku.inland_damage
            ws.cell(row=row_index, column=6).value = zenkoku.pit_damage
            ws.cell(row=row_index, column=7).value = zenkoku.scouring_damage
            ws.cell(row=row_index, column=8).value = zenkoku.debris_damage
            ws.cell(row=row_index, column=9).value = zenkoku.landslide_damage
            ws.cell(row=row_index, column=10).value = zenkoku.steepslope_damage
            ws.cell(row=row_index, column=11).value = zenkoku.surge_damage
            ws.cell(row=row_index, column=12).value = zenkoku.tsunami_damage
            ws.cell(row=row_index, column=13).value = zenkoku.waves_damage
            ws.cell(row=row_index, column=14).value = zenkoku.other_damage
            ws.cell(row=row_index, column=15).value = zenkoku.sum_total_damage
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo24_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo24_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo24.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo24_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo24_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo24_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
