###############################################################################
### 帳票名：hyo_09_2事業別公益事業等被害状況.xlsx
### ファイル名：P0700EStat/hyo09_2_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO09_2:
    def __init__(self, ):
        pass

###############################################################################
### 帳票名：hyo_09_2事業別公益事業等被害状況.xlsx
### 関数名：get_hyo09_ken(ken_code)
### 1 都道府県別_被害額
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo09_ken(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo09_ken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo09_ken()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if ken_code in constants.ken_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo09_ken()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(constants.business_keys + ken_keys, constants.business_values + ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo09_ken()関数 STEP 2/3.', 'DEBUG')
        hyo09_ken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (KOEKI01.transport_suspended_days) IS NULL THEN 0.00 ELSE KOEKI01.transport_suspended_days END, 
                CASE WHEN (KOEKI02.passenger_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI02.passenger_suspended_amounts END, 
                CASE WHEN (KOEKI03.cargo_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI03.cargo_suspended_amounts END, 
                CASE WHEN (KOEKI04.communicate_suspended_days) IS NULL THEN 0.00 ELSE KOEKI04.communicate_suspended_days END, 
                CASE WHEN (KOEKI05.communicate_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI05.communicate_suspended_amounts END, 
                CASE WHEN (KOEKI06.electric_suspended_days) IS NULL THEN 0.00 ELSE KOEKI06.electric_suspended_days END, 
                CASE WHEN (KOEKI07.electric_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI07.electric_suspended_amounts END, 
                CASE WHEN (KOEKI08.gas_suspended_days) IS NULL THEN 0.00 ELSE KOEKI08.gas_suspended_days END, 
                CASE WHEN (KOEKI09.gas_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI09.gas_suspended_amounts END, 
                CASE WHEN (KOEKI10.water_suspended_days) IS NULL THEN 0.00 ELSE KOEKI10.water_suspended_days END, 
                CASE WHEN (KOEKI11.water_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI11.water_suspended_amounts END 
                
            FROM 

            -- 都道府県
            (SELECT 
                ken_code, ken_name 
            FROM KEN 
            WHERE ken_code=%(KEN_CODE)s 
            ) KEN1, 
            
            -- 公益事業_運輸_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS transport_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(RAIL_CARGO)s,%(ROAD_PASSENGER)s,%(ROAD_CARGO)s,%(SEA_PASSENGER)s,%(SEA_CARGO)s,%(AIR_PASSENGER)s,%(AIR_CARGO)s)
            AND ken_code=%(KEN_CODE)s
            ) KOEKI01, 
            
            -- 公益事業_運輸_旅客（人）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS passenger_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(ROAD_PASSENGER)s,%(SEA_PASSENGER)s,%(AIR_PASSENGER)s) 
            AND ken_code=%(KEN_CODE)s
            ) KOEKI02, 
            
            -- 公益事業_運輸_貨物（ｔ）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS cargo_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_CARGO)s,%(ROAD_CARGO)s,%(SEA_CARGO)s,%(AIR_CARGO)s) 
            AND ken_code=%(KEN_CODE)s
            ) KOEKI03, 
            
            -- 公益事業_通信_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS communicate_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(COMMUNICATE)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI04, 
            
            -- 公益事業_通信_停止数量（回線）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS communicate_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(COMMUNICATE)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI05, 
            
            -- 公益事業_電力_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS electric_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(ELECTRIC)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI06, 
            
            -- 公益事業_電力_停止数量（世帯）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS electric_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(ELECTRIC)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI07, 
            
            -- 公益事業_ガス_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS gas_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(GAS)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI08, 
            
            -- 公益事業_ガス_停止数量（世帯）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS gas_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(GAS)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI09, 
            
            -- 公益事業_水道_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS water_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(WATER)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI10, 
            
            -- 公益事業_水道_停止数量（世帯）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS water_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(WATER)s) AND ken_code=%(KEN_CODE)s
            ) KOEKI11 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo09_ken()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo09_ken()関数が正常終了しました。', 'INFO')
        return True, hyo09_ken_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo09_ken()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo09_ken()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo09_ken()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_09_2事業別公益事業等被害状況.xlsx
### 関数名：get_hyo09_zenkoku()
### 2 全国_被害額_
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo09_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo09_zenkoku()関数 STEP 1/3.', 'DEBUG')
        params = dict(zip(constants.business_keys, constants.business_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo09_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo09_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (KOEKI01.transport_suspended_days) IS NULL THEN 0.00 ELSE KOEKI01.transport_suspended_days END, 
                CASE WHEN (KOEKI02.passenger_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI02.passenger_suspended_amounts END, 
                CASE WHEN (KOEKI03.cargo_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI03.cargo_suspended_amounts END, 
                CASE WHEN (KOEKI04.communicate_suspended_days) IS NULL THEN 0.00 ELSE KOEKI04.communicate_suspended_days END, 
                CASE WHEN (KOEKI05.communicate_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI05.communicate_suspended_amounts END, 
                CASE WHEN (KOEKI06.electric_suspended_days) IS NULL THEN 0.00 ELSE KOEKI06.electric_suspended_days END, 
                CASE WHEN (KOEKI07.electric_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI07.electric_suspended_amounts END, 
                CASE WHEN (KOEKI08.gas_suspended_days) IS NULL THEN 0.00 ELSE KOEKI08.gas_suspended_days END, 
                CASE WHEN (KOEKI09.gas_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI09.gas_suspended_amounts END, 
                CASE WHEN (KOEKI10.water_suspended_days) IS NULL THEN 0.00 ELSE KOEKI10.water_suspended_days END, 
                CASE WHEN (KOEKI11.water_suspended_amounts) IS NULL THEN 0.00 ELSE KOEKI11.water_suspended_amounts END 
                
            FROM 
            
            -- 公益事業_運輸_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS transport_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(RAIL_CARGO)s,%(ROAD_PASSENGER)s,%(ROAD_CARGO)s,%(SEA_PASSENGER)s,%(SEA_CARGO)s,%(AIR_PASSENGER)s,%(AIR_CARGO)s)
            ) KOEKI01, 
            
            -- 公益事業_運輸_旅客（人）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS passenger_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(ROAD_PASSENGER)s,%(SEA_PASSENGER)s,%(AIR_PASSENGER)s) 
            ) KOEKI02, 
            
            -- 公益事業_運輸_貨物（ｔ）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS cargo_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_CARGO)s,%(ROAD_CARGO)s,%(SEA_CARGO)s,%(AIR_CARGO)s) 
            ) KOEKI03, 
            
            -- 公益事業_通信_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS communicate_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(COMMUNICATE)s)
            ) KOEKI04, 
            
            -- 公益事業_通信_停止数量（回線）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS communicate_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(COMMUNICATE)s) 
            ) KOEKI05, 
            
            -- 公益事業_電力_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS electric_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(ELECTRIC)s)
            ) KOEKI06, 
            
            -- 公益事業_電力_停止数量（世帯）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS electric_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(ELECTRIC)s) 
            ) KOEKI07, 
            
            -- 公益事業_ガス_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS gas_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(GAS)s) 
            ) KOEKI08, 
            
            -- 公益事業_ガス_停止数量（世帯）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS gas_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(GAS)s) 
            ) KOEKI09, 
            
            -- 公益事業_水道_停止期間（日）
            (SELECT 
                SUM(
                CASE WHEN (suspended_days) IS NULL THEN 0.00 ELSE suspended_days END 
                ) AS water_suspended_days 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(WATER)s) 
            ) KOEKI10, 
            
            -- 公益事業_水道_停止数量（世帯）
            (SELECT 
                SUM(
                CASE WHEN (suspended_amounts) IS NULL THEN 0.00 ELSE suspended_amounts END 
                ) AS water_suspended_amounts 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(WATER)s) 
            ) KOEKI11 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo09_zenkoku()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo09_zenkoku()関数が正常終了しました。', 'INFO')
        return True, hyo09_zenkoku_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo09_zenkoku()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo09_zenkoku()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo09_zenkoku()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_09_2事業別公益事業等被害状況.xlsx
### 関数名：hyo09_2_view(request)
### urlpattern：path('hyo09_2/', hyo09_2views.hyo09_2_view, name='hyo09_2_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo09_2_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo09_2_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 2/4.', 'DEBUG')
        ### 1 都道府県別_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 2_1/4.', 'DEBUG')
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo09_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)

        ### 2 全国_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 2_1/4.', 'DEBUG')
        bool_return, zenkoku_list = get_hyo09_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 3/4.', 'DEBUG')
        ### 1 都道府県別_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 3_1/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.transport_suspended_days={}'.format(i, j, ken.transport_suspended_days), flush=True)

        ### 2 全国_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 3_2/4.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.transport_suspended_days={}'.format(i, zenkoku.transport_suspended_days), flush=True)

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo09_2', 
            'ken_list': ken_list, 
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo09_2_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo09_2_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo09_2_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo09_2_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_09_2事業別公益事業等被害状況.xlsx
### 関数名：hyo09_2_download_view(request)
### urlpattern：path('download/hyo09_2/', hyo09_2_views.hyo09_2_view, name='hyo09_2_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo09_2_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo09_2_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo09_2_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo09_2_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo09_2_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 1 都道府県別_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 2_1/5.', 'DEBUG')
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo09_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)

        ### 2 全国_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 2_1/5.', 'DEBUG')
        bool_return, zenkoku_list = get_hyo09_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 都道府県別_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 3_1/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.transport_suspended_days={}'.format(i, j, ken.transport_suspended_days), flush=True)

        ### 2 全国_被害額
        print_log('[DEBUG] P0700EStat.hyo09_2_view()関数 STEP 3_2/5.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.transport_suspended_days={}'.format(i, zenkoku.transport_suspended_days), flush=True)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo09_2_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo09_2.xlsx'
        ### download_file_path = 'static/download_hyo09_2.xlsx'
        template_file_path = 'static/template/template_hyo09_2.xlsx'
        download_file_path = 'static/tmp/download_hyo09_2.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo09_2'
        
        ws.cell(row=1, column=1).value = '表－９－②　事業別公益事業等被害状況'
        ws.cell(row=3, column=1).value = '都　道　　　府県名'
        ws.cell(row=3, column=2).value = '運輸'
        ws.cell(row=3, column=5).value = '通信'
        ws.cell(row=3, column=7).value = '電力'
        ws.cell(row=3, column=9).value = 'ガス'
        ws.cell(row=3, column=11).value = '水道'
        ws.cell(row=4, column=2).value = '停止期間'
        ws.cell(row=4, column=3).value = '旅客'
        ws.cell(row=4, column=4).value = '貨物'
        ws.cell(row=4, column=5).value = '停止期間'
        ws.cell(row=4, column=6).value = '停止数量'
        ws.cell(row=4, column=7).value = '停止期間'
        ws.cell(row=4, column=8).value = '停止数量'
        ws.cell(row=4, column=9).value = '停止期間'
        ws.cell(row=4, column=10).value = '停止数量'
        ws.cell(row=4, column=11).value = '停止期間'
        ws.cell(row=4, column=12).value = '停止数量'
        ws.cell(row=5, column=2).value = '（日）'
        ws.cell(row=5, column=3).value = '（人）'
        ws.cell(row=5, column=4).value = '（ｔ）'
        ws.cell(row=5, column=5).value = '（日）'
        ws.cell(row=5, column=6).value = '（回線）'
        ws.cell(row=5, column=7).value = '（日）'
        ws.cell(row=5, column=8).value = '（世帯）'
        ws.cell(row=5, column=9).value = '（日）'
        ws.cell(row=5, column=10).value = '（世帯）'
        ws.cell(row=5, column=11).value = '（日）'
        ws.cell(row=5, column=12).value = '（世帯）'
        
        row_index = 5

        ### 1 都道府県別_被害額
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                row_index += 1
                
                ws.cell(row=row_index, column=1).value = ken.ken_name
                ws.cell(row=row_index, column=2).value = ken.transport_suspended_days
                ws.cell(row=row_index, column=3).value = ken.passenger_suspended_amounts
                ws.cell(row=row_index, column=4).value = ken.cargo_suspended_amounts
                ws.cell(row=row_index, column=5).value = ken.communicate_suspended_days
                ws.cell(row=row_index, column=6).value = ken.communicate_suspended_amounts
                ws.cell(row=row_index, column=7).value = ken.electric_suspended_days
                ws.cell(row=row_index, column=8).value = ken.electric_suspended_amounts
                ws.cell(row=row_index, column=9).value = ken.gas_suspended_days
                ws.cell(row=row_index, column=10).value = ken.gas_suspended_amounts
                ws.cell(row=row_index, column=11).value = ken.water_suspended_days
                ws.cell(row=row_index, column=12).value = ken.water_suspended_amounts

        ### 2 全国_被害額
        for i, zenkoku in enumerate(zenkoku_list):
            row_index += 1

            ws.cell(row=row_index, column=1).value = '全　国'
            ws.cell(row=row_index, column=2).value = zenkoku.transport_suspended_days
            ws.cell(row=row_index, column=3).value = zenkoku.passenger_suspended_amounts
            ws.cell(row=row_index, column=4).value = zenkoku.cargo_suspended_amounts
            ws.cell(row=row_index, column=5).value = zenkoku.communicate_suspended_days
            ws.cell(row=row_index, column=6).value = zenkoku.communicate_suspended_amounts
            ws.cell(row=row_index, column=7).value = zenkoku.electric_suspended_days
            ws.cell(row=row_index, column=8).value = zenkoku.electric_suspended_amounts
            ws.cell(row=row_index, column=9).value = zenkoku.gas_suspended_days
            ws.cell(row=row_index, column=10).value = zenkoku.gas_suspended_amounts
            ws.cell(row=row_index, column=11).value = zenkoku.water_suspended_days
            ws.cell(row=row_index, column=12).value = zenkoku.water_suspended_amounts
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo09_2_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo09_2_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo09_2.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo09_2_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo09_2_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo09_2_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
