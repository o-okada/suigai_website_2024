###############################################################################
### 帳票名：hyo_02都道府県別水害被害.xlsx
### ファイル名：P0700EStat/hyo02_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO02:
    def __init__(self, ):
        self.ken_code = ken_code
        self.ken_name = ken_name
        
        self.death_num = death_num
        self.missing_num = missing_num
        self.wounded_num = wounded_num
        self.death_missing_wounded_num = death_missing_wounded_num
        
        self.ippan_suikei_num = ippan_suikei_num
        self.kokyo_suikei_num = kokyo_suikei_num
        self.koeki_suikei_num = koeki_suikei_num
        self.ippan_kasen_num = ippan_kasen_num
        self.kokyo_kasen_num = kokyo_kasen_num
        self.koeki_kasen_num = koeki_kasen_num
        self.ippan_city_num = ippan_city_num
        self.kokyo_city_num = kokyo_city_num
        self.koeki_city_num = koeki_city_num
        
        self.ippan_asset_damage = ippan_asset_damage
        self.office_sales_damage = office_sales_damage
        self.crop_damage = crop_damage
        self.ippan_damage = ippan_damage
        
        self.kasen_damage = kasen_damage
        self.kaigan_damage = kaigan_damage
        self.sabou_damage = sabou_damage
        self.landslide_damage = landslide_damage
        self.steepslope_damage = steepslope_damage
        self.road_damage = road_damage
        self.bridge_damage = bridge_damage
        self.sewer_damage = sewer_damage
        self.park_damage = park_damage
        self.kokyo_damage = kokyo_damage
        
        self.physical_damage = physical_damage
        self.sales_damage = sales_damage
        self.koeki_damage = koeki_damage
        
        self.ippan_chitan_hojo_koeki_damage = ippan_chitan_hojo_koeki_damage

###############################################################################
### 帳票名：hyo_02都道府県別水害被害.xlsx
### 関数名：get_hyo02(tisei_code)
### 1 都道府県別_被害額
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo02(tisei_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo02()関数 tisei_code={}'.format(tisei_code), 'DEBUG')
        if tisei_code in constants.tisei_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo02()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN1','KEN2','KEN3','KEN4','KEN5','KEN6','KEN7','KEN8','KEN9','KEN10']
        if tisei_code == "81":              ### 北海道1 北海道
            ken_values = ['01','','','','','','','','','']
        elif tisei_code == "82":            ### 東北6 青森 岩手 宮城 秋田 山形 福島
            ken_values = ['02','03','04','05','06','07','','','','']
        elif tisei_code == "83":            ### 関東7 茨城 栃木 群馬 埼玉 千葉 東京 神奈川
            ken_values = ['08','09','10','11','12','13','14','','','']
        elif tisei_code == "84":            ### 北陸4 新潟 富山 石川 福井
            ken_values = ['15','16','17','18','','','','','','']
        elif tisei_code == "85":            ### 中部6 山梨 長野 岐阜 静岡 愛知 三重
            ken_values = ['19','20','21','22','23','24','','','','']
        elif tisei_code == "86":            ### 近畿6 滋賀 京都 大阪 兵庫 奈良 和歌山
            ken_values = ['25','26','27','28','29','30','','','','']
        elif tisei_code == "87":            ### 中国5 鳥取 島根 岡山 広島 山口
            ken_values = ['31','32','33','34','35','','','','','']
        elif tisei_code == "88":            ### 四国4 徳島 香川 愛媛 高知
            ken_values = ['36','37','38','39','','','','','','']
        elif tisei_code == "89":            ### 九州7 福岡 佐賀 長崎 熊本 大分 宮崎 鹿児島
            ken_values = ['40','41','42','43','44','45','46','','','']
        elif tisei_code == "90":            ### 沖縄1 沖縄
            ken_values = ['47','','','','','','','','','']

        params = dict(zip(constants.setubi_keys + ken_keys, constants.setubi_values + ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02()関数 STEP 2/3.', 'DEBUG')
        hyo02_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END, 
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END, 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END, 
                
                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END+ 
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END+ 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END 
                AS death_missing_wounded_num, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                
                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END, 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 
                
                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END+ 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END+ 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END 
                AS ippan_damage, 

                CASE WHEN (CHITAN04.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.kasen_estimated_cost END+ 
                CASE WHEN (HOJO04.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.kasen_determined_cost END 
                AS kasen_damage, 
                
                CASE WHEN (CHITAN05.kaigan_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.kaigan_estimated_cost END+ 
                CASE WHEN (HOJO05.kaigan_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.kaigan_determined_cost END 
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN06.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.sabou_estimated_cost END+ 
                CASE WHEN (HOJO06.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.sabou_determined_cost END 
                AS sabou_damage, 
                
                CASE WHEN (CHITAN07.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.landslide_estimated_cost END+ 
                CASE WHEN (HOJO07.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.landslide_determined_cost END 
                AS landslide_damage, 
                
                CASE WHEN (CHITAN08.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.steepslope_estimated_cost END+ 
                CASE WHEN (HOJO08.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.steepslope_determined_cost END 
                AS steepslope_damage, 
                
                CASE WHEN (CHITAN09.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.road_estimated_cost END+ 
                CASE WHEN (HOJO09.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.road_determined_cost END 
                AS road_damage, 
                
                CASE WHEN (CHITAN10.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN10.bridge_estimated_cost END+ 
                CASE WHEN (HOJO10.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO10.bridge_determined_cost END 
                AS bridge_damage, 
                
                CASE WHEN (CHITAN11.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN11.sewer_estimated_cost END+ 
                CASE WHEN (HOJO11.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO11.sewer_determined_cost END 
                AS sewer_damage, 
                
                CASE WHEN (CHITAN12.park_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN12.park_estimated_cost END+ 
                CASE WHEN (HOJO12.park_determined_cost) IS NULL THEN 0.00 ELSE HOJO12.park_determined_cost END 
                AS park_damage, 
                
                CASE WHEN (CHITAN13.estimated_cost) IS NULL THEN 0.00 ELSE CHITAN13.estimated_cost END+ 
                CASE WHEN (HOJO13.determined_cost) IS NULL THEN 0.00 ELSE HOJO13.determined_cost END 
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI05.sales_damage) IS NULL THEN 0.00 ELSE KOEKI05.sales_damage END, 
                CASE WHEN (KOEKI06.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI06.koeki_damage END, 

                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END+ 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END+ 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END+ 
                CASE WHEN (CHITAN13.estimated_cost) IS NULL THEN 0.00 ELSE CHITAN13.estimated_cost END+ 
                CASE WHEN (HOJO13.determined_cost) IS NULL THEN 0.00 ELSE HOJO13.determined_cost END + 
                CASE WHEN (KOEKI06.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI06.koeki_damage END 
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 

            -- 都道府県
            (SELECT 
                ken_code, 
                ken_name 
            FROM KEN 
            WHERE ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ORDER BY ken_code 
            ) KEN1 

            -- 死傷者数 TODO TO_DO TO-DO
            LEFT JOIN 
            (SELECT 
                '01' AS ken_code, 
                11 AS death_num, 
                22 AS missing_num, 
                33 AS wounded_num, 
                11 + 22 + 33 AS death_missing_wounded_num 
            ) SUB01 
            ON KEN1.ken_code=SUB01.ken_code 

            -- 一般資産等_水系・沿岸数
            LEFT JOIN 
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                ken_code, weather_id, suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code, weather_id, suikei_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) IPPAN01 
            ON KEN1.ken_code=IPPAN01.ken_code 

            -- 公共土木施設_水系・沿岸数
            LEFT JOIN 
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (SELECT 
                ken_code, weather_id, suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            UNION 
            SELECT 
                ken_code, weather_id, suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s)
            GROUP BY ken_code, weather_id, suikei_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) KOKYO01 
            ON KEN1.ken_code=KOKYO01.ken_code 

            -- 公益事業等_水系・沿岸数
            LEFT JOIN 
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                ken_code, weather_id, suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code, weather_id, suikei_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) KOEKI01 
            ON KEN1.ken_code=KOEKI01.ken_code 

            -- 一般資産等_河川・海岸数
            LEFT JOIN
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                ken_code, weather_id, kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s)
            GROUP BY ken_code, weather_id, kasen_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) IPPAN02 
            ON KEN1.ken_code=IPPAN02.ken_code 

            -- 公共土木施設_河川・海岸数
            LEFT JOIN
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (SELECT 
                ken_code, weather_id, kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s)
            UNION 
            SELECT 
                ken_code, weather_id, kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            GROUP BY ken_code, weather_id, kasen_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) KOKYO02 
            ON KEN1.ken_code=KOKYO02.ken_code 

            -- 公益事業等_河川・海岸数
            LEFT JOIN
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                ken_code, weather_id, kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s)
            GROUP BY ken_code, weather_id, kasen_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) KOEKI02 
            ON KEN1.ken_code=KOEKI02.ken_code 

            -- 一般資産等_市区町村数
            LEFT JOIN 
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                ken_code, weather_id, city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code, weather_id, city_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) IPPAN03 
            ON KEN1.ken_code=IPPAN03.ken_code 

            -- 公共土木施設_市区町村数
            LEFT JOIN 
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (SELECT 
                ken_code, weather_id, city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            UNION 
            SELECT 
                ken_code, weather_id, city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code, weather_id, city_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) KOKYO03 
            ON KEN1.ken_code=KOKYO03.ken_code 

            -- 公益事業等_市区町村数
            LEFT JOIN 
            (SELECT 
                SUB00.ken_code, 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                ken_code, weather_id, city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code, weather_id, city_code 
            ) SUB00 
            GROUP BY SUB00.ken_code 
            ) KOEKI03 
            ON KEN1.ken_code=KOEKI03.ken_code 

            -- 一般資産被害額
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) IPPAN04 
            ON KEN1.ken_code=IPPAN04.ken_code 
            
            -- 一般資産_営業停止被害額
            LEFT JOIN 
            (SELECT 
                ken_code AS ken_code, 
                SUM(
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END) 
                AS office_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) IPPAN05 
            ON KEN1.ken_code=IPPAN05.ken_code 
            
            -- 一般資産_農作物被害額
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) IPPAN06 
            ON KEN1.ken_code=IPPAN06.ken_code 

            -- 地方単独事業被害額_河川
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kasen_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN04 
            ON KEN1.ken_code=CHITAN04.ken_code 

            -- 地方単独事業被害額_海岸・港湾
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kaigan_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN05 
            ON KEN1.ken_code=CHITAN05.ken_code 

            -- 地方単独事業被害額_砂防設備
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sabou_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN06 
            ON KEN1.ken_code=CHITAN06.ken_code 

            -- 地方単独事業被害額_地すべり
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS landslide_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN07 
            ON KEN1.ken_code=CHITAN07.ken_code 

            -- 地方単独事業被害額_急傾斜地
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS steepslope_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN08 
            ON KEN1.ken_code=CHITAN08.ken_code 

            -- 地方単独事業被害額_道路
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS road_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN09 
            ON KEN1.ken_code=CHITAN09.ken_code 

            -- 地方単独事業被害額_橋梁
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS bridge_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN10 
            ON KEN1.ken_code=CHITAN10.ken_code 

            -- 地方単独事業被害額_下水道
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sewer_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN11 
            ON KEN1.ken_code=CHITAN11.ken_code 

            -- 地方単独事業被害額_公園・都市施設
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS park_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN12 
            ON KEN1.ken_code=CHITAN12.ken_code 

            -- 地方単独事業被害額_合計
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) CHITAN13 
            ON KEN1.ken_code=CHITAN13.ken_code 

            -- 補助事業被害額_河川
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kasen_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO04 
            ON KEN1.ken_code=HOJO04.ken_code 

            -- 補助事業被害額_海岸・港湾
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kaigan_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO05 
            ON KEN1.ken_code=HOJO05.ken_code 

            -- 補助事業被害額_砂防設備
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sabou_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO06 
            ON KEN1.ken_code=HOJO06.ken_code 

            -- 補助事業被害額_地すべり
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS landslide_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO07 
            ON KEN1.ken_code=HOJO07.ken_code 

            -- 補助事業被害額_急傾斜地
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS steepslope_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO08 
            ON KEN1.ken_code=HOJO08.ken_code 

            -- 補助事業被害額_道路
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS road_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO09 
            ON KEN1.ken_code=HOJO09.ken_code 

            -- 補助事業被害額_橋梁
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS bridge_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO10 
            ON KEN1.ken_code=HOJO10.ken_code 

            -- 補助事業被害額_下水道
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sewer_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO11 
            ON KEN1.ken_code=HOJO11.ken_code 

            -- 補助事業被害額_公園・都市施設
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS park_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO12 
            ON KEN1.ken_code=HOJO12.ken_code 

            -- 補助事業被害額_合計
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) HOJO13 
            ON KEN1.ken_code=HOJO13.ken_code 

            -- 公益事業等被害額_物的被害額
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code 
            ) KOEKI04 
            ON KEN1.ken_code=KOEKI04.ken_code 

            -- 公益事業等被害額_営業停止損失額
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s)
            GROUP BY ken_code
            ) KOEKI05 
            ON KEN1.ken_code=KOEKI05.ken_code 

            -- 公益事業等被害額_合計
            LEFT JOIN 
            (SELECT 
                ken_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY ken_code
            ) KOEKI06 
            ON KEN1.ken_code=KOEKI06.ken_code 
            
            """, params)
                
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo02()関数が正常終了しました。', 'INFO')
        return True, hyo02_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo02()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo02()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo02()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_02都道府県別水害被害.xlsx
### 関数名：get_hyo02_tisei(tisei_code)
### 2 地方別_被害額 中間下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo02_tisei(tisei_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02_tisei()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo02_tisei()関数 tisei_code={}'.format(tisei_code), 'DEBUG')
        if tisei_code in constants.tisei_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo02_tisei()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN1','KEN2','KEN3','KEN4','KEN5','KEN6','KEN7','KEN8','KEN9','KEN10']
        if tisei_code == "81":              ### 北海道1 北海道
            ken_values = ['01','','','','','','','','','']
        elif tisei_code == "82":            ### 東北6 青森 岩手 宮城 秋田 山形 福島
            ken_values = ['02','03','04','05','06','07','','','','']
        elif tisei_code == "83":            ### 関東7 茨城 栃木 群馬 埼玉 千葉 東京 神奈川
            ken_values = ['08','09','10','11','12','13','14','','','']
        elif tisei_code == "84":            ### 北陸4 新潟 富山 石川 福井
            ken_values = ['15','16','17','18','','','','','','']
        elif tisei_code == "85":            ### 中部6 山梨 長野 岐阜 静岡 愛知 三重
            ken_values = ['19','20','21','22','23','24','','','','']
        elif tisei_code == "86":            ### 近畿6 滋賀 京都 大阪 兵庫 奈良 和歌山
            ken_values = ['25','26','27','28','29','30','','','','']
        elif tisei_code == "87":            ### 中国5 鳥取 島根 岡山 広島 山口
            ken_values = ['31','32','33','34','35','','','','','']
        elif tisei_code == "88":            ### 四国4 徳島 香川 愛媛 高知
            ken_values = ['36','37','38','39','','','','','','']
        elif tisei_code == "89":            ### 九州7 福岡 佐賀 長崎 熊本 大分 宮崎 鹿児島
            ken_values = ['40','41','42','43','44','45','46','','','']
        elif tisei_code == "90":            ### 沖縄1 沖縄
            ken_values = ['47','','','','','','','','','']

        params = dict(zip(constants.setubi_keys + ken_keys, constants.setubi_values + ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02_tisei()関数 STEP 2/3.', 'DEBUG')
        hyo02_tisei_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END, 
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END, 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END, 
                
                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END+ 
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END+ 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END 
                AS death_missing_wounded_num, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                
                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END, 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 

                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END+ 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END+ 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END 
                AS ippan_damage, 
                
                CASE WHEN (CHITAN04.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.kasen_estimated_cost END+ 
                CASE WHEN (HOJO04.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.kasen_determined_cost END 
                AS kasen_damage, 
                
                CASE WHEN (CHITAN05.kaigan_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.kaigan_estimated_cost END+ 
                CASE WHEN (HOJO05.kaigan_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.kaigan_determined_cost END 
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN06.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.sabou_estimated_cost END+ 
                CASE WHEN (HOJO06.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.sabou_determined_cost END 
                AS sabou_damage, 
                
                CASE WHEN (CHITAN07.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.landslide_estimated_cost END+ 
                CASE WHEN (HOJO07.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.landslide_determined_cost END 
                AS landslide_damage, 
                
                CASE WHEN (CHITAN08.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.steepslope_estimated_cost END+ 
                CASE WHEN (HOJO08.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.steepslope_determined_cost END 
                AS steepslope_damage, 
                
                CASE WHEN (CHITAN09.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.road_estimated_cost END+ 
                CASE WHEN (HOJO09.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.road_determined_cost END 
                AS road_damage, 
                
                CASE WHEN (CHITAN10.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN10.bridge_estimated_cost END+ 
                CASE WHEN (HOJO10.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO10.bridge_determined_cost END 
                AS bridge_damage, 
                
                CASE WHEN (CHITAN11.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN11.sewer_estimated_cost END+ 
                CASE WHEN (HOJO11.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO11.sewer_determined_cost END 
                AS sewer_damage, 
                
                CASE WHEN (CHITAN12.park_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN12.park_estimated_cost END+ 
                CASE WHEN (HOJO12.park_determined_cost) IS NULL THEN 0.00 ELSE HOJO12.park_determined_cost END 
                AS park_damage, 
                
                CASE WHEN (CHITAN13.estimated_cost) IS NULL THEN 0.00 ELSE CHITAN13.estimated_cost END+ 
                CASE WHEN (HOJO13.determined_cost) IS NULL THEN 0.00 ELSE HOJO13.determined_cost END 
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI05.sales_damage) IS NULL THEN 0.00 ELSE KOEKI05.sales_damage END, 
                CASE WHEN (KOEKI06.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI06.koeki_damage END, 

                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END+ 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END+ 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END+ 
                CASE WHEN (CHITAN13.estimated_cost) IS NULL THEN 0.00 ELSE CHITAN13.estimated_cost END+ 
                CASE WHEN (HOJO13.determined_cost) IS NULL THEN 0.00 ELSE HOJO13.determined_cost END + 
                CASE WHEN (KOEKI06.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI06.koeki_damage END 
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 死傷者数
            (SELECT 
                11 AS death_num, 
                22 AS missing_num, 
                33 AS wounded_num, 
                11 + 22 + 33 AS death_missing_wounded_num 
            ) SUB01, 
            
            -- 一般資産等_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) IPPAN01, 

            -- 公共土木施設_水系・沿岸数
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, suikei_code 
            UNION 
            SELECT 
                weather_id, suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公益事業等_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) KOEKI01, 
            
            -- 一般資産等_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) IPPAN02, 

            -- 公共土木施設_河川・海岸数
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, kasen_code 
            UNION 
            SELECT 
                weather_id, kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公益事業等_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) KOEKI02, 
            
            -- 一般資産等_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) IPPAN03, 

            -- 公共土木施設_市区町村数
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, city_code 
            UNION 
            SELECT 
                weather_id, city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 公益事業等_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) KOEKI03, 
            
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) IPPAN04, 
            
            -- 一般資産_営業停止被害額
            (SELECT 
                SUM(
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END) 
                AS office_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) IPPAN05, 
            
            -- 一般資産_農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s)
            ) IPPAN06, 

            -- 地方単独事業被害額_河川
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kasen_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN04, 

            -- 地方単独事業被害額_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kaigan_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN05, 

            -- 地方単独事業被害額_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sabou_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN06, 

            -- 地方単独事業被害額_地すべり
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS landslide_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN07, 

            -- 地方単独事業被害額_急傾斜地
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS steepslope_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN08, 

            -- 地方単独事業被害額_道路
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS road_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN09, 
            
            -- 地方単独事業被害額_橋梁
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS bridge_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN10, 

            -- 地方単独事業被害額_下水道
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sewer_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN11, 

            -- 地方単独事業被害額_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS park_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN12, 

            -- 地方単独事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) CHITAN13, 

            -- 補助事業被害額_河川
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kasen_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO04, 

            -- 補助事業被害額_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kaigan_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO05, 

            -- 補助事業被害額_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sabou_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO06, 

            -- 補助事業被害額_地すべり
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS landslide_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO07, 

            -- 補助事業被害額_急傾斜地
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS steepslope_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO08, 

            -- 補助事業被害額_道路
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS road_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO09, 

            -- 補助事業被害額_橋梁
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS bridge_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO10, 

            -- 補助事業被害額_下水道
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sewer_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO11, 

            -- 補助事業被害額_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS park_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO12, 

            -- 補助事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) HOJO13, 

            -- 公益事業等被害額_物的被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) KOEKI04, 

            -- 公益事業等被害額_営業停止損失額
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) KOEKI05, 

            -- 公益事業等被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code IN (%(KEN1)s,%(KEN2)s,%(KEN3)s,%(KEN4)s,%(KEN5)s,%(KEN6)s,%(KEN7)s,%(KEN8)s,%(KEN9)s,%(KEN10)s) 
            ) KOEKI06 
                
            """, params)
                
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02_tisei()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo02_tisei()関数が正常終了しました。', 'INFO')
        return True, hyo02_tisei_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo02_tisei()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo02_tisei()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo02_tisei()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_02都道府県別水害被害.xlsx
### 関数名：get_hyo02_zenkoku()
### 3 全国_被害額 最下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo02_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02_zenkoku()関数 STEP 1/3.', 'DEBUG')
        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        params = dict(zip(constants.setubi_keys, constants.setubi_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo02_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END, 
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END, 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END, 

                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END+ 
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END+ 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END 
                AS death_missing_wounded_num, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 

                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 

                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                
                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END, 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 
                
                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END+ 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END+ 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END 
                AS ippan_damage, 

                CASE WHEN (CHITAN04.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.kasen_estimated_cost END+ 
                CASE WHEN (HOJO04.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.kasen_determined_cost END 
                AS kasen_damage, 
                
                CASE WHEN (CHITAN05.kaigan_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.kaigan_estimated_cost END+ 
                CASE WHEN (HOJO05.kaigan_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.kaigan_determined_cost END 
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN06.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.sabou_estimated_cost END+ 
                CASE WHEN (HOJO06.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.sabou_determined_cost END 
                AS sabou_damage, 
                
                CASE WHEN (CHITAN07.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.landslide_estimated_cost END+ 
                CASE WHEN (HOJO07.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.landslide_determined_cost END 
                AS landslide_damage, 
                
                CASE WHEN (CHITAN08.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.steepslope_estimated_cost END+ 
                CASE WHEN (HOJO08.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.steepslope_determined_cost END 
                AS steepslope_damage, 
                
                CASE WHEN (CHITAN09.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.road_estimated_cost END+ 
                CASE WHEN (HOJO09.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.road_determined_cost END 
                AS road_damage, 
                
                CASE WHEN (CHITAN10.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN10.bridge_estimated_cost END+ 
                CASE WHEN (HOJO10.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO10.bridge_determined_cost END 
                AS bridge_damage, 
                
                CASE WHEN (CHITAN11.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN11.sewer_estimated_cost END+ 
                CASE WHEN (HOJO11.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO11.sewer_determined_cost END 
                AS sewer_damage, 
                
                CASE WHEN (CHITAN12.park_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN12.park_estimated_cost END+ 
                CASE WHEN (HOJO12.park_determined_cost) IS NULL THEN 0.00 ELSE HOJO12.park_determined_cost END 
                AS park_damage, 
                
                CASE WHEN (CHITAN13.estimated_cost) IS NULL THEN 0.00 ELSE CHITAN13.estimated_cost END+ 
                CASE WHEN (HOJO13.determined_cost) IS NULL THEN 0.00 ELSE HOJO13.determined_cost END 
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI05.sales_damage) IS NULL THEN 0.00 ELSE KOEKI05.sales_damage END, 
                CASE WHEN (KOEKI06.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI06.koeki_damage END, 

                CASE WHEN (IPPAN04.ippan_asset_damage) IS NULL THEN 0.00 ELSE IPPAN04.ippan_asset_damage END+ 
                CASE WHEN (IPPAN05.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN05.office_sales_damage END+ 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END+ 
                CASE WHEN (CHITAN13.estimated_cost) IS NULL THEN 0.00 ELSE CHITAN13.estimated_cost END+ 
                CASE WHEN (HOJO13.determined_cost) IS NULL THEN 0.00 ELSE HOJO13.determined_cost END+ 
                CASE WHEN (KOEKI06.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI06.koeki_damage END 
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 死傷者数
            (SELECT 
                11 AS death_num, 
                22 AS missing_num, 
                33 AS wounded_num, 
                11 + 22 + 33 AS death_missing_wounded_num 
            ) SUB01, 
            
            -- 一般資産等_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) IPPAN01, 

            -- 公共土木施設_水系・沿岸数
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            UNION 
            SELECT 
                weather_id, suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公益事業等_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) KOEKI01, 
            
            -- 一般資産等_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) IPPAN02, 

            -- 公共土木施設_河川・海岸数
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            UNION 
            SELECT 
                weather_id, kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公益事業等_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) KOEKI02, 
            
            -- 一般資産等_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) IPPAN03, 

            -- 公共土木施設_市区町村数
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            UNION 
            SELECT 
                weather_id, city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 公益事業等_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) KOEKI03, 
            
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN04, 
            
            -- 一般資産_営業停止被害額
            (SELECT 
                SUM(
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END) 
                AS office_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN05, 
            
            -- 一般資産_農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL
            ) IPPAN06, 

            -- 地方単独事業被害額_河川
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kasen_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) CHITAN04, 

            -- 地方単独事業被害額_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kaigan_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) CHITAN05, 

            -- 地方単独事業被害額_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sabou_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) CHITAN06, 

            -- 地方単独事業被害額_地すべり
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS landslide_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) CHITAN07, 

            -- 地方単独事業被害額_急傾斜地
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS steepslope_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) CHITAN08, 

            -- 地方単独事業被害額_道路
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS road_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) CHITAN09, 
            
            -- 地方単独事業被害額_橋梁
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS bridge_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) CHITAN10, 

            -- 地方単独事業被害額_下水道
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sewer_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) CHITAN11, 

            -- 地方単独事業被害額_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS park_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) CHITAN12, 

            -- 地方単独事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            ) CHITAN13, 

            -- 補助事業被害額_河川
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kasen_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) HOJO04, 

            -- 補助事業被害額_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kaigan_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) HOJO05, 

            -- 補助事業被害額_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sabou_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) HOJO06, 

            -- 補助事業被害額_地すべり
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS landslide_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) HOJO07, 

            -- 補助事業被害額_急傾斜地
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS steepslope_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) HOJO08, 

            -- 補助事業被害額_道路
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS road_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) HOJO09, 

            -- 補助事業被害額_橋梁
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS bridge_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) HOJO10, 

            -- 補助事業被害額_下水道
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sewer_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) HOJO11, 

            -- 補助事業被害額_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS park_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) HOJO12, 

            -- 補助事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            ) HOJO13, 

            -- 公益事業等被害額_物的被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI04, 

            -- 公益事業等被害額_営業停止損失額
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI05, 

            -- 公益事業等被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI06 
            
            """, params)
                
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo02_zenkoku()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo02_zenkoku()関数が正常終了しました。', 'INFO')
        return True, hyo02_zenkoku_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo02_zenkoku()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo02_zenkoku()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo02_zenkoku()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_02都道府県別水害被害.xlsx
### 関数名：hyo02_view(request)
### urlpattern：path('hyo02/', hyo02_views.hyo02_view, name='hyo02_view'),
###############################################################################
### @login_required(None, login_url='/P0100Login/')
### def hyo02_view(request):
###     try:
###         #######################################################################
###         ### 引数チェック処理(0000)
###         ### ブラウザからのリクエストと引数をチェックする。
###         #######################################################################
###         reset_log()
###         print_log('[INFO] P0700EStat.hyo02_view()関数が開始しました。', 'INFO')
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 request={}'.format(request.method), 'DEBUG')
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 1/4.', 'DEBUG')

###         #######################################################################
###         ### DBアクセス処理(0010)
###         ### DBにアクセスして、データを取得する。
###         #######################################################################
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 2/4.', 'DEBUG')
###         ### 1 都道府県別_被害額
###         bool_return, ken_81_list = get_hyo02('81')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_82_list = get_hyo02('82')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_83_list = get_hyo02('83')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_84_list = get_hyo02('84')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_85_list = get_hyo02('85')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_86_list = get_hyo02('86')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_87_list = get_hyo02('87')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_88_list = get_hyo02('88')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_89_list = get_hyo02('89')
###         if bool_return == False:
###             raise Exception

###         bool_return, ken_90_list = get_hyo02('90')
###         if bool_return == False:
###             raise Exception

###         ### 2 地方別_被害額 中間下端
###         bool_return, tisei_81_list = get_hyo02_tisei('81')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_82_list = get_hyo02_tisei('82')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_83_list = get_hyo02_tisei('83')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_84_list = get_hyo02_tisei('84')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_85_list = get_hyo02_tisei('85')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_86_list = get_hyo02_tisei('86')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_87_list = get_hyo02_tisei('87')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_88_list = get_hyo02_tisei('88')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_89_list = get_hyo02_tisei('89')
###         if bool_return == False:
###             raise Exception

###         bool_return, tisei_90_list = get_hyo02_tisei('90')
###         if bool_return == False:
###             raise Exception

###         ### 3 全国_被害額 最下端
###         bool_return, zenkoku_list = get_hyo02_zenkoku()
###         if bool_return == False:
###             raise Exception
        
###         #######################################################################
###         ### 計算処理(0020)
###         ### 計算して局所変数に値をセットする。
###         ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
###         #######################################################################
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 3/4.', 'DEBUG')
###         ### 1 都道府県別_被害額
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 3_1/4.', 'DEBUG')
###         for i, ken in enumerate(ken_81_list):
###             print('ken.ken_code={}'.format(ken.ken_code), flush=True)
###             print('ken.ken_name={}'.format(ken.ken_name), flush=True)
        
###         ### 2 地方別_被害額 中間下端
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 3_2/4.', 'DEBUG')
###         for i, tisei in enumerate(tisei_81_list):
###             pass
###             print('tisei.death_num={}'.format(tisei.death_num), flush=True)
###             print('tisei.missing_num={}'.format(tisei.missing_num), flush=True)
###             print('tisei.wounded_num={}'.format(tisei.wounded_num), flush=True)
###             print('tisei.death_missing_wounded_num={}'.format(tisei.death_missing_wounded_num), flush=True)
        
###         ### 3 全国_被害額 最下端
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 3_3/4.', 'DEBUG')
###         for i, zenkoku in enumerate(zenkoku_list):
###             print('zenkoku.death_num={}'.format(zenkoku.death_num), flush=True)
###             print('zenkoku.missing_num={}'.format(zenkoku.missing_num), flush=True)
###             print('zenkoku.wounded_num={}'.format(zenkoku.wounded_num), flush=True)
###             print('zenkoku.death_missing_wounded_num={}'.format(zenkoku.death_missing_wounded_num), flush=True)
        
###         tisei_list = []
###         tisei_list.append(tisei_81_list)
###         tisei_list.append(tisei_82_list)
###         tisei_list.append(tisei_83_list)
###         tisei_list.append(tisei_84_list)
###         tisei_list.append(tisei_85_list)
###         tisei_list.append(tisei_86_list)
###         tisei_list.append(tisei_87_list)
###         tisei_list.append(tisei_88_list)
###         tisei_list.append(tisei_89_list)
###         tisei_list.append(tisei_90_list)
###         ### ※北海道と沖縄は県リストに値をセットしない。
###         ### ※北海道と沖縄は地方リストに値をセットする。
###         ken_list = []
###         ken_list.append([])
###         ken_list.append(ken_82_list)
###         ken_list.append(ken_83_list)
###         ken_list.append(ken_84_list)
###         ken_list.append(ken_85_list)
###         ken_list.append(ken_86_list)
###         ken_list.append(ken_87_list)
###         ken_list.append(ken_88_list)
###         ken_list.append(ken_89_list)
###         ken_list.append([])
        
###         #######################################################################
###         ### レスポンスセット処理(0030)
###         ### コンテキストを設定して、レスポンスをブラウザに戻す。
###         #######################################################################
###         print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 4/4.', 'DEBUG')
###         template = loader.get_template('P0700EStat/index.html')
###         context = {
###             'cat_code': 'hyo02', 
###             'values': [0,1,2,3,4,5,6,7,8,9],
###             'ken_list': ken_list, 
###             'tisei_list': tisei_list, 
###             'zenkoku_list': zenkoku_list, 
###         }
###         print_log('[INFO] P0700EStat.hyo02_view()関数が正常終了しました。', 'INFO')
###         return HttpResponse(template.render(context, request))
        
###     except:
###         print_log('[ERROR] P0700EStat.hyo02_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
###         print_log('[ERROR] P0700EStat.hyo02_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
###         print_log('[ERROR] P0700EStat.hyo02_view()関数が異常終了しました。', 'ERROR')
###         template = loader.get_template('P0700EStat/index.html')
###         context = {
###             'alert_log': get_alert_log(), 
###         }
###         return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_02都道府県別水害被害.xlsx
### 関数名：hyo02_download_view(request)
### urlpattern：path('download/hyo02/', hyo02_views.hyo02_download_view, name='hyo02_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo02_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo02_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 1 都道府県別_被害額
        bool_return, ken_81_list = get_hyo02('81')
        if bool_return == False:
            raise Exception

        bool_return, ken_82_list = get_hyo02('82')
        if bool_return == False:
            raise Exception

        bool_return, ken_83_list = get_hyo02('83')
        if bool_return == False:
            raise Exception

        bool_return, ken_84_list = get_hyo02('84')
        if bool_return == False:
            raise Exception

        bool_return, ken_85_list = get_hyo02('85')
        if bool_return == False:
            raise Exception

        bool_return, ken_86_list = get_hyo02('86')
        if bool_return == False:
            raise Exception

        bool_return, ken_87_list = get_hyo02('87')
        if bool_return == False:
            raise Exception

        bool_return, ken_88_list = get_hyo02('88')
        if bool_return == False:
            raise Exception

        bool_return, ken_89_list = get_hyo02('89')
        if bool_return == False:
            raise Exception

        bool_return, ken_90_list = get_hyo02('90')
        if bool_return == False:
            raise Exception

        ### 2 地方別_被害額計 中間
        bool_return, tisei_81_list = get_hyo02_tisei('81')
        if bool_return == False:
            raise Exception

        bool_return, tisei_82_list = get_hyo02_tisei('82')
        if bool_return == False:
            raise Exception

        bool_return, tisei_83_list = get_hyo02_tisei('83')
        if bool_return == False:
            raise Exception

        bool_return, tisei_84_list = get_hyo02_tisei('84')
        if bool_return == False:
            raise Exception

        bool_return, tisei_85_list = get_hyo02_tisei('85')
        if bool_return == False:
            raise Exception

        bool_return, tisei_86_list = get_hyo02_tisei('86')
        if bool_return == False:
            raise Exception

        bool_return, tisei_87_list = get_hyo02_tisei('87')
        if bool_return == False:
            raise Exception

        bool_return, tisei_88_list = get_hyo02_tisei('88')
        if bool_return == False:
            raise Exception

        bool_return, tisei_89_list = get_hyo02_tisei('89')
        if bool_return == False:
            raise Exception

        bool_return, tisei_90_list = get_hyo02_tisei('90')
        if bool_return == False:
            raise Exception

        ### 3 全国_被害額_合計 最下端
        bool_return, zenkoku_list = get_hyo02_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 3/5.', 'DEBUG')
        for i, ken in enumerate(ken_81_list):
            print('ken.ken_code={}'.format(ken.ken_code), flush=True)
            print('ken.ken_name={}'.format(ken.ken_name), flush=True)

        for i, tisei in enumerate(tisei_81_list):
            pass
            print('tisei.death_num={}'.format(tisei.death_num), flush=True)
            print('tisei.missing_num={}'.format(tisei.missing_num), flush=True)
            print('tisei.wounded_num={}'.format(tisei.wounded_num), flush=True)
            print('tisei.death_missing_wounded_num={}'.format(tisei.death_missing_wounded_num), flush=True)

        for i, zenkoku in enumerate(zenkoku_list):
            print('zenkoku.death_num={}'.format(zenkoku.death_num), flush=True)
            print('zenkoku.missing_num={}'.format(zenkoku.missing_num), flush=True)
            print('zenkoku.wounded_num={}'.format(zenkoku.wounded_num), flush=True)
            print('zenkoku.death_missing_wounded_num={}'.format(zenkoku.death_missing_wounded_num), flush=True)
        
        tisei_list = []
        tisei_list.append(tisei_81_list)
        tisei_list.append(tisei_82_list)
        tisei_list.append(tisei_83_list)
        tisei_list.append(tisei_84_list)
        tisei_list.append(tisei_85_list)
        tisei_list.append(tisei_86_list)
        tisei_list.append(tisei_87_list)
        tisei_list.append(tisei_88_list)
        tisei_list.append(tisei_89_list)
        tisei_list.append(tisei_90_list)
        
        ### ※北海道と沖縄は県リストに値をセットしない。
        ### ※北海道と沖縄は地方リストに値をセットする。
        ken_list = []
        ken_list.append([])
        ken_list.append(ken_82_list)
        ken_list.append(ken_83_list)
        ken_list.append(ken_84_list)
        ken_list.append(ken_85_list)
        ken_list.append(ken_86_list)
        ken_list.append(ken_87_list)
        ken_list.append(ken_88_list)
        ken_list.append(ken_89_list)
        ken_list.append([])
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo02.xlsx'
        ### download_file_path = 'static/download_hyo02.xlsx'
        template_file_path = 'static/template/template_hyo02.xlsx'
        download_file_path = 'static/tmp/download_hyo02.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo02'
        
        ws.cell(row=1, column=18).value = '表－２　都道府県'
        ws.cell(row=2, column=31).value = '（被害額単位：百万円）'
        ws.cell(row=3, column=1).value = ''
        ws.cell(row=3, column=2).value = '死傷者数'
        ws.cell(row=3, column=6).value = '水系・沿岸数'
        ws.cell(row=3, column=9).value = '河川・海岸数'
        ws.cell(row=3, column=12).value = '市区町村数'
        ws.cell(row=3, column=15).value = '一般資産等被害額'
        ws.cell(row=3, column=19).value = '公　　共　　土　　木　　施　　設　　被　　害　　額'
        ws.cell(row=3, column=29).value = '公益事業等被害額'
        ws.cell(row=3, column=32).value = ''
        ws.cell(row=3, column=33).value = ''
        ws.cell(row=4, column=1).value = '都　道'
        ws.cell(row=4, column=2).value = '（人）'
        ws.cell(row=4, column=6).value = '（延べ数）'
        ws.cell(row=4, column=9).value = '（延べ数）'
        ws.cell(row=4, column=12).value = '（延べ数）'
        ws.cell(row=4, column=32).value = '被害額'
        ws.cell(row=4, column=33).value = '都　道'
        ws.cell(row=5, column=1).value = '府県名'
        ws.cell(row=5, column=2).value = '死者'
        ws.cell(row=5, column=3).value = '行方'
        ws.cell(row=5, column=4).value = '負傷者'
        ws.cell(row=5, column=5).value = '計'
        ws.cell(row=5, column=6).value = '一般'
        ws.cell(row=5, column=7).value = '公共土'
        ws.cell(row=5, column=8).value = '公益'
        ws.cell(row=5, column=9).value = '一般'
        ws.cell(row=5, column=10).value = '公共土'
        ws.cell(row=5, column=11).value = '公益'
        ws.cell(row=5, column=12).value = '一般'
        ws.cell(row=5, column=13).value = '公共土'
        ws.cell(row=5, column=14).value = '公益'
        ws.cell(row=5, column=15).value = '一般資産'
        ws.cell(row=5, column=16).value = '営業停止'
        ws.cell(row=5, column=17).value = '農作物'
        ws.cell(row=5, column=18).value = '計'
        ws.cell(row=5, column=19).value = '河川'
        ws.cell(row=5, column=20).value = '海岸・港湾'
        ws.cell(row=5, column=21).value = '砂防設備'
        ws.cell(row=5, column=22).value = '地す'
        ws.cell(row=5, column=23).value = '急傾'
        ws.cell(row=5, column=24).value = '道路'
        ws.cell(row=5, column=25).value = '橋梁'
        ws.cell(row=5, column=26).value = '下水道'
        ws.cell(row=5, column=27).value = '公園・都市施設'
        ws.cell(row=5, column=28).value = '計'
        ws.cell(row=5, column=29).value = '物的'
        ws.cell(row=5, column=30).value = '営業停止'
        ws.cell(row=5, column=31).value = '計'
        ws.cell(row=5, column=32).value = '合計'
        ws.cell(row=5, column=33).value = '府県名'
        ws.cell(row=6, column=1).value = ''
        ws.cell(row=6, column=3).value = '不明'
        ws.cell(row=6, column=6).value = '資産等'
        ws.cell(row=6, column=7).value = '木施設'
        ws.cell(row=6, column=8).value = '事業等'
        ws.cell(row=6, column=9).value = '資産等'
        ws.cell(row=6, column=10).value = '木施設'
        ws.cell(row=6, column=11).value = '事業等'
        ws.cell(row=6, column=12).value = '資産等'
        ws.cell(row=6, column=13).value = '木施設'
        ws.cell(row=6, column=14).value = '事業等'
        ws.cell(row=6, column=22).value = 'べり'
        ws.cell(row=6, column=23).value = '斜地'
        ws.cell(row=6, column=29).value = '被害額'
        ws.cell(row=6, column=30).value = '損失額'
        ws.cell(row=6, column=32).value = ''
        ws.cell(row=6, column=33).value = ''
        
        row_index = 6
        
        for i in range(0, 10):
            ### 1 県別_被害額_合計
            print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 4_1/5.', 'DEBUG')
            for j, ken in enumerate(ken_list[i]):
                row_index += 1

                ws.cell(row=row_index, column=1).value = ken.ken_name
                ws.cell(row=row_index, column=2).value = ken.death_num
                ws.cell(row=row_index, column=3).value = ken.missing_num
                ws.cell(row=row_index, column=4).value = ken.wounded_num
                ws.cell(row=row_index, column=5).value = ken.death_missing_wounded_num
                ws.cell(row=row_index, column=6).value = ken.ippan_suikei_num
                ws.cell(row=row_index, column=7).value = ken.kokyo_suikei_num
                ws.cell(row=row_index, column=8).value = ken.koeki_suikei_num
                ws.cell(row=row_index, column=9).value = ken.ippan_kasen_num
                ws.cell(row=row_index, column=10).value = ken.kokyo_kasen_num
                ws.cell(row=row_index, column=11).value = ken.koeki_kasen_num
                ws.cell(row=row_index, column=12).value = ken.ippan_city_num
                ws.cell(row=row_index, column=13).value = ken.kokyo_city_num
                ws.cell(row=row_index, column=14).value = ken.koeki_city_num
                ws.cell(row=row_index, column=15).value = ken.ippan_asset_damage
                ws.cell(row=row_index, column=16).value = ken.office_sales_damage
                ws.cell(row=row_index, column=17).value = ken.crop_damage
                ws.cell(row=row_index, column=18).value = ken.ippan_damage
                ws.cell(row=row_index, column=19).value = ken.kasen_damage
                ws.cell(row=row_index, column=20).value = ken.kaigan_damage
                ws.cell(row=row_index, column=21).value = ken.sabou_damage
                ws.cell(row=row_index, column=22).value = ken.landslide_damage
                ws.cell(row=row_index, column=23).value = ken.steepslope_damage
                ws.cell(row=row_index, column=24).value = ken.road_damage
                ws.cell(row=row_index, column=25).value = ken.bridge_damage
                ws.cell(row=row_index, column=26).value = ken.sewer_damage
                ws.cell(row=row_index, column=27).value = ken.park_damage
                ws.cell(row=row_index, column=28).value = ken.kokyo_damage
                ws.cell(row=row_index, column=29).value = ken.physical_damage
                ws.cell(row=row_index, column=30).value = ken.sales_damage
                ws.cell(row=row_index, column=31).value = ken.koeki_damage
                ws.cell(row=row_index, column=32).value = ken.ippan_chitan_hojo_koeki_damage
                ws.cell(row=row_index, column=33).value = ken.ken_name
            
            ### 2 地方別_被害額_合計 中間下端
            print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 4_2/5.', 'DEBUG')
            for j, tisei in enumerate(tisei_list[i]):
                row_index += 1
    
                if i == 0:
                    ws.cell(row=row_index, column=1).value = '北海道'
                elif i == 1:
                    ws.cell(row=row_index, column=1).value = '東北'
                elif i == 2:
                    ws.cell(row=row_index, column=1).value = '関東'
                elif i == 3:
                    ws.cell(row=row_index, column=1).value = '北陸'
                elif i == 4:
                    ws.cell(row=row_index, column=1).value = '中部'
                elif i == 5:
                    ws.cell(row=row_index, column=1).value = '近畿'
                elif i == 6:
                    ws.cell(row=row_index, column=1).value = '中国'
                elif i == 7:
                    ws.cell(row=row_index, column=1).value = '四国'
                elif i == 8:
                    ws.cell(row=row_index, column=1).value = '九州'
                elif i == 9:
                    ws.cell(row=row_index, column=1).value = '沖　縄'
                    
                ws.cell(row=row_index, column=2).value = tisei.death_num
                ws.cell(row=row_index, column=3).value = tisei.missing_num
                ws.cell(row=row_index, column=4).value = tisei.wounded_num
                ws.cell(row=row_index, column=5).value = tisei.death_missing_wounded_num
                ws.cell(row=row_index, column=6).value = tisei.ippan_suikei_num
                ws.cell(row=row_index, column=7).value = tisei.kokyo_suikei_num
                ws.cell(row=row_index, column=8).value = tisei.koeki_suikei_num
                ws.cell(row=row_index, column=9).value = tisei.ippan_kasen_num
                ws.cell(row=row_index, column=10).value = tisei.kokyo_kasen_num
                ws.cell(row=row_index, column=11).value = tisei.koeki_kasen_num
                ws.cell(row=row_index, column=12).value = tisei.ippan_city_num
                ws.cell(row=row_index, column=13).value = tisei.kokyo_city_num
                ws.cell(row=row_index, column=14).value = tisei.koeki_city_num
                ws.cell(row=row_index, column=15).value = tisei.ippan_asset_damage
                ws.cell(row=row_index, column=16).value = tisei.office_sales_damage
                ws.cell(row=row_index, column=17).value = tisei.crop_damage
                ws.cell(row=row_index, column=18).value = tisei.ippan_damage
                ws.cell(row=row_index, column=19).value = tisei.kasen_damage
                ws.cell(row=row_index, column=20).value = tisei.kaigan_damage
                ws.cell(row=row_index, column=21).value = tisei.sabou_damage
                ws.cell(row=row_index, column=22).value = tisei.landslide_damage
                ws.cell(row=row_index, column=23).value = tisei.steepslope_damage
                ws.cell(row=row_index, column=24).value = tisei.road_damage
                ws.cell(row=row_index, column=25).value = tisei.bridge_damage
                ws.cell(row=row_index, column=26).value = tisei.sewer_damage
                ws.cell(row=row_index, column=27).value = tisei.park_damage
                ws.cell(row=row_index, column=28).value = tisei.kokyo_damage
                ws.cell(row=row_index, column=29).value = tisei.physical_damage
                ws.cell(row=row_index, column=30).value = tisei.sales_damage
                ws.cell(row=row_index, column=31).value = tisei.koeki_damage
                ws.cell(row=row_index, column=32).value = tisei.ippan_chitan_hojo_koeki_damage
    
                if i == 0:
                    ws.cell(row=row_index, column=33).value = '北海道'
                elif i == 1:
                    ws.cell(row=row_index, column=33).value = '東北'
                elif i == 2:
                    ws.cell(row=row_index, column=33).value = '関東'
                elif i == 3:
                    ws.cell(row=row_index, column=33).value = '北陸'
                elif i == 4:
                    ws.cell(row=row_index, column=33).value = '中部'
                elif i == 5:
                    ws.cell(row=row_index, column=33).value = '近畿'
                elif i == 6:
                    ws.cell(row=row_index, column=33).value = '中国'
                elif i == 7:
                    ws.cell(row=row_index, column=33).value = '四国'
                elif i == 8:
                    ws.cell(row=row_index, column=33).value = '九州'
                elif i == 9:
                    ws.cell(row=row_index, column=33).value = '沖　縄'

        ### 3 全国_被害額_合計 最下端
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 4_3/5.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            row_index += 1

            ws.cell(row=row_index, column=1).value = '全国'
            ws.cell(row=row_index, column=2).value = zenkoku.death_num
            ws.cell(row=row_index, column=3).value = zenkoku.missing_num
            ws.cell(row=row_index, column=4).value = zenkoku.wounded_num
            ws.cell(row=row_index, column=5).value = zenkoku.death_missing_wounded_num
            ws.cell(row=row_index, column=6).value = zenkoku.ippan_suikei_num
            ws.cell(row=row_index, column=7).value = zenkoku.kokyo_suikei_num
            ws.cell(row=row_index, column=8).value = zenkoku.koeki_suikei_num
            ws.cell(row=row_index, column=9).value = zenkoku.ippan_kasen_num
            ws.cell(row=row_index, column=10).value = zenkoku.kokyo_kasen_num
            ws.cell(row=row_index, column=11).value = zenkoku.koeki_kasen_num
            ws.cell(row=row_index, column=12).value = zenkoku.ippan_city_num
            ws.cell(row=row_index, column=13).value = zenkoku.kokyo_city_num
            ws.cell(row=row_index, column=14).value = zenkoku.koeki_city_num
            ws.cell(row=row_index, column=15).value = zenkoku.ippan_asset_damage
            ws.cell(row=row_index, column=16).value = zenkoku.office_sales_damage
            ws.cell(row=row_index, column=17).value = zenkoku.crop_damage
            ws.cell(row=row_index, column=18).value = zenkoku.ippan_damage
            ws.cell(row=row_index, column=19).value = zenkoku.kasen_damage
            ws.cell(row=row_index, column=20).value = zenkoku.kaigan_damage
            ws.cell(row=row_index, column=21).value = zenkoku.sabou_damage
            ws.cell(row=row_index, column=22).value = zenkoku.landslide_damage
            ws.cell(row=row_index, column=23).value = zenkoku.steepslope_damage
            ws.cell(row=row_index, column=24).value = zenkoku.road_damage
            ws.cell(row=row_index, column=25).value = zenkoku.bridge_damage
            ws.cell(row=row_index, column=26).value = zenkoku.sewer_damage
            ws.cell(row=row_index, column=27).value = zenkoku.park_damage
            ws.cell(row=row_index, column=28).value = zenkoku.kokyo_damage
            ws.cell(row=row_index, column=29).value = zenkoku.physical_damage
            ws.cell(row=row_index, column=30).value = zenkoku.sales_damage
            ws.cell(row=row_index, column=31).value = zenkoku.koeki_damage
            ws.cell(row=row_index, column=32).value = zenkoku.ippan_chitan_hojo_koeki_damage
            ws.cell(row=row_index, column=33).value = '全国'
        
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 4_4/5.', 'DEBUG')
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0030)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo02_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo02_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo02.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo02_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo02_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo02_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
