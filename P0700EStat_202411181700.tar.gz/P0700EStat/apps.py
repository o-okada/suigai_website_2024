from django.apps import AppConfig

class P0700EStatConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'P0700EStat'
