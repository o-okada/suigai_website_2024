tisei_values = ['81','82','83','84','85','86','87','88','89','90']

ken_values = ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20',
              '21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40',
              '41','42','43','44','45','46','47']

### R2要領（都道府県）.pdf P14 (6)工種区分
setubi_keys = ['KASEN','KAIGAN','SABOU','LANDSLIDE','STEEPSLOPE','ROAD','BRIDGE','PORT','SEWER','PARK','FACILITY']
setubi_values = ['01','02','03','04','05','06','07','08','09','10','11']

### R2要領（都道府県）.pdf P27 事業所の産業分類コード
industry_keys = ['MINING','CONSTRUCT','MANUFACT','POWER','COMMUNICATE','TRANSPORT','WHOLESALE','RESTAURANT','MEDICAL','SERVICE']
industry_values = ['1','2','3','4','5','6','7','8','9','10']

### R2要領（都道府県）.pdf P25 公益事業の事業コード
business_keys = ['RAIL_PASSENGER','RAIL_CARGO','ROAD_PASSENGER','ROAD_CARGO','COMMUNICATE','ELECTRIC','GAS','WATER','SEA_PASSENGER','SEA_CARGO','AIR_PASSENGER','AIR_CARGO']
business_values = ['1','2','3','4','5','6','7','8','9','10','11','12']

kasen_type_keys = ['DIRECT','SPECIFIED','SECOND','MUTANDIS','ORDINARY','KAIGAN','OTHER']
kasen_type_values = ['1','2','3','4','5','6','7']

### R2要領（都道府県）.pdf P29 水害原因コード
cause_keys = ['BREACH','WITH_DIKE','WITHOUT_DIKE','INLAND','PIT','SCOURING','DEBRIS','LANDSLIDE','STEEPSLOPE','SURGE','TSUNAMI','WAVES','OTHER']
cause_values = ['10','20','30','40','50','60','70','80','90','91','92','93','99']