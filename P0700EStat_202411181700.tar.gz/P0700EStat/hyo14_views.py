###############################################################################
### 帳票名：hyo_14河川等種類別水害被害額.xlsx
### ファイル名：P0700EStat/hyo14_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO14:
    def __init__(self, kasen_type_code, kasen_type_name, ippan_damage, kokyo_damage, koeki_damage, sum_total_damage, ippan_ratio, kokyo_ratio, koeki_ratio, sum_total_ratio):
        self.kasen_type_code = kasen_type_code
        self.kasen_type_name = kasen_type_name
        self.ippan_damage = ippan_damage
        self.kokyo_damage = kokyo_damage
        self.koeki_damage = koeki_damage
        self.sum_total_damage = sum_total_damage
        self.ippan_ratio = ippan_ratio
        self.kokyo_ratio = kokyo_ratio
        self.koeki_ratio = koeki_ratio
        self.sum_total_ratio = sum_total_ratio

###############################################################################
### 帳票名：hyo_14河川等種類別水害被害額.xlsx
### 関数名：get_hyo14(kasen_type_code)
### 1 河川種類別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo14(kasen_type_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo14()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo14()関数 kasen_type_code={}'.format(kasen_type_code), 'DEBUG')
        if kasen_type_code in constants.kasen_type_values: 
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        kasen_type_keys = ['KASEN_TYPE_CODE']
        kasen_type_values = [kasen_type_code]
        params = dict(zip(kasen_type_keys, kasen_type_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo14()関数 STEP 2/3.', 'DEBUG')
        hyo14_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                %(KASEN_TYPE_CODE)s AS kasen_type_code, 

                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END, 
                
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS sum_total_damage 
                
            FROM 
            
            -- 一般資産等被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            ) IPPAN01, 
            
            -- 地方単独事業被害額
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            ) CHITAN01, 
            
            -- 補助事業被害額
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            ) HOJO01, 
            
            -- 公益事業等被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            ) KOEKI01 
            
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo14()関数 STEP 3/3.', 'DEBUG')
        return True, hyo14_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_14河川等種類別水害被害額.xlsx
### 関数名：get_hyo14_zentype()
### 2 全河川種類_被害額_合計 下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo14_zentype():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo14_zentype()関数 STEP 1/3.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo14_zentype()関数 STEP 2/3.', 'DEBUG')
        hyo14_zentype_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END, 
                
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END, 

                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS sum_total_damage 
                
            FROM 
            
            -- 一般資産等被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN01, 
            
            -- 地方単独事業被害額
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) CHITAN01, 
            
            -- 補助事業被害額
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) HOJO01, 
            
            -- 公益事業等被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI01 
            
            """, [])
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo14_zentype()関数 STEP 3/3.', 'DEBUG')
        return True, hyo14_zentype_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_14河川等種類別水害被害額.xlsx
### 関数名：hyo14_view(request)
### urlpattern：path('hyo14/', hyo14_views.hyo14_view, name='hyo14_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo14_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo14_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo14_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo14_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo14_view()関数 STEP 2/4.', 'DEBUG')
        params = dict(zip(constants.kasen_type_keys, constants.kasen_type_values))
        ### 1 河川種類別_被害額_合計
        bool_return, direct = get_hyo14(params['DIRECT'])
        if bool_return == False:
            raise Exception

        bool_return, specified = get_hyo14(params['SPECIFIED'])
        if bool_return == False:
            raise Exception

        bool_return, second = get_hyo14(params['SECOND'])
        if bool_return == False:
            raise Exception

        bool_return, mutandis = get_hyo14(params['MUTANDIS'])
        if bool_return == False:
            raise Exception

        bool_return, ordinary = get_hyo14(params['ORDINARY'])
        if bool_return == False:
            raise Exception

        bool_return, kaigan = get_hyo14(params['KAIGAN'])
        if bool_return == False:
            raise Exception

        bool_return, other = get_hyo14(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 2 全河川種類_被害額_合計 下端
        bool_return, zentype = get_hyo14_zentype()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo14_view()関数 STEP 3/4.', 'DEBUG')
        temp_list = []
        hyo14 = HYO14(
            constants.kasen_type_values[0], '一級河川（直轄区間）', 
            direct[0].ippan_damage, direct[0].kokyo_damage, direct[0].koeki_damage, direct[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)
        
        hyo14 = HYO14(
            constants.kasen_type_values[1], '一級河川（指定区間）', 
            specified[0].ippan_damage, specified[0].kokyo_damage, specified[0].koeki_damage, specified[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[2], '二級河川', 
            second[0].ippan_damage, second[0].kokyo_damage, second[0].koeki_damage, second[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)
        
        hyo14 = HYO14(
            constants.kasen_type_values[3], '準用河川', 
            mutandis[0].ippan_damage, mutandis[0].kokyo_damage, mutandis[0].koeki_damage, mutandis[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[4], '普通河川', 
            ordinary[0].ippan_damage, ordinary[0].kokyo_damage, ordinary[0].koeki_damage, ordinary[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[5], '海岸', 
            kaigan[0].ippan_damage, kaigan[0].kokyo_damage, kaigan[0].koeki_damage, kaigan[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[6], 'その他', 
            other[0].ippan_damage, other[0].kokyo_damage, other[0].koeki_damage, other[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)
        
        zentype_list = []
        hyo14 = HYO14(
            '', '計', 
            zentype[0].ippan_damage, zentype[0].kokyo_damage, zentype[0].koeki_damage, zentype[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        zentype_list.append(hyo14)
        
        for i, temp in enumerate(temp_list):
            if zentype_list[0].ippan_damage == 0:
                temp.ippan_ratio = 0.0
            else:
                temp.ippan_ratio = temp.ippan_damage / zentype_list[0].ippan_damage

            if zentype_list[0].kokyo_damage == 0:
                temp.kokyo_ratio = 0.0
            else:
                temp.kokyo_ratio = temp.kokyo_damage / zentype_list[0].kokyo_damage

            if zentype_list[0].koeki_damage == 0:
                temp.koeki_ratio = 0.0
            else:
                temp.koeki_ratio = temp.koeki_damage / zentype_list[0].koeki_damage

            if zentype_list[0].sum_total_damage == 0:
                temp.sum_total_ratio = 0.0
            else:
                temp.sum_total_ratio = temp.sum_total_damage / zentype_list[0].sum_total_damage

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo14_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo14', 
            'temp_list': temp_list, 
            'zentype_list': zentype_list, 
        }
        print_log('[INFO] P0700EStat.hyo14_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo14_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo14_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo14_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_14河川等種類別水害被害額.xlsx
### 関数名：hyo14_download_view(request)
### urlpattern：path('download/hyo14/', hyo14_views.hyo14_download_view, name='hyo14_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo14_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo14_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo14_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo14_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo14_download_view()関数 STEP 2/5.', 'DEBUG')
        params = dict(zip(constants.kasen_type_keys, constants.kasen_type_values))
        ### 1 河川種類別_被害額_合計
        bool_return, direct = get_hyo14(params['DIRECT'])
        if bool_return == False:
            raise Exception

        bool_return, specified = get_hyo14(params['SPECIFIED'])
        if bool_return == False:
            raise Exception

        bool_return, second = get_hyo14(params['SECOND'])
        if bool_return == False:
            raise Exception

        bool_return, mutandis = get_hyo14(params['MUTANDIS'])
        if bool_return == False:
            raise Exception

        bool_return, ordinary = get_hyo14(params['ORDINARY'])
        if bool_return == False:
            raise Exception

        bool_return, kaigan = get_hyo14(params['KAIGAN'])
        if bool_return == False:
            raise Exception

        bool_return, other = get_hyo14(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 2 全河川種類_被害額_合計 下端
        bool_return, zentype = get_hyo14_zentype()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo14_download_view()関数 STEP 3/5.', 'DEBUG')
        temp_list = []
        hyo14 = HYO14(
            constants.kasen_type_values[0], '一級河川（直轄区間）', 
            direct[0].ippan_damage, direct[0].kokyo_damage, direct[0].koeki_damage, direct[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)
        
        hyo14 = HYO14(
            constants.kasen_type_values[1], '一級河川（指定区間）', 
            specified[0].ippan_damage, specified[0].kokyo_damage, specified[0].koeki_damage, specified[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[2], '二級河川', 
            second[0].ippan_damage, second[0].kokyo_damage, second[0].koeki_damage, second[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)
        
        hyo14 = HYO14(
            constants.kasen_type_values[3], '準用河川', 
            mutandis[0].ippan_damage, mutandis[0].kokyo_damage, mutandis[0].koeki_damage, mutandis[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[4], '普通河川', 
            ordinary[0].ippan_damage, ordinary[0].kokyo_damage, ordinary[0].koeki_damage, ordinary[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[5], '海岸', 
            kaigan[0].ippan_damage, kaigan[0].kokyo_damage, kaigan[0].koeki_damage, kaigan[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)

        hyo14 = HYO14(
            constants.kasen_type_values[6], 'その他', 
            other[0].ippan_damage, other[0].kokyo_damage, other[0].koeki_damage, other[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo14)
        
        zentype_list = []
        hyo14 = HYO14(
            '', '計', 
            zentype[0].ippan_damage, zentype[0].kokyo_damage, zentype[0].koeki_damage, zentype[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0)
        zentype_list.append(hyo14)
        
        for i, temp in enumerate(temp_list):
            if zentype_list[0].ippan_damage == 0:
                temp.ippan_ratio = 0.0
            else:
                temp.ippan_ratio = temp.ippan_damage / zentype_list[0].ippan_damage

            if zentype_list[0].kokyo_damage == 0:
                temp.kokyo_ratio = 0.0
            else:
                temp.kokyo_ratio = temp.kokyo_damage / zentype_list[0].kokyo_damage

            if zentype_list[0].koeki_damage == 0:
                temp.koeki_ratio = 0.0
            else:
                temp.koeki_ratio = temp.koeki_damage / zentype_list[0].koeki_damage

            if zentype_list[0].sum_total_damage == 0:
                temp.sum_total_ratio = 0.0
            else:
                temp.sum_total_ratio = temp.sum_total_damage / zentype_list[0].sum_total_damage
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo14_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo14.xlsx'
        ### download_file_path = 'static/download_hyo14.xlsx'
        template_file_path = 'static/template/template_hyo14.xlsx'
        download_file_path = 'static/tmp/download_hyo14.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo14'
        
        ws.cell(row=1, column=1).value = '６．河川等種類別被害'
        ws.cell(row=6, column=1).value = '表－１４　河川等種類別水害被害額'
        ws.cell(row=8, column=8).value = '（単位：百万円，％）'
        ws.cell(row=9, column=1).value = '種別'
        ws.cell(row=9, column=2).value = '一般資産等'
        ws.cell(row=9, column=4).value = '公共土木施設'
        ws.cell(row=9, column=6).value = '公益事業等'
        ws.cell(row=9, column=8).value = '合  計'
        ws.cell(row=10, column=2).value = '被害額'
        ws.cell(row=10, column=3).value = '構成比'
        ws.cell(row=10, column=4).value = '被害額'
        ws.cell(row=10, column=5).value = '構成比'
        ws.cell(row=10, column=6).value = '被害額'
        ws.cell(row=10, column=7).value = '構成比'
        ws.cell(row=10, column=8).value = '被害額'
        ws.cell(row=10, column=9).value = '構成比'
        
        row_index = 10
        for i, temp in enumerate(temp_list):
            row_index += 1
            print('temp.kasen_type_code={}'.format(temp.kasen_type_code), flush=True)
            print('temp.kasen_type_name={}'.format(temp.kasen_type_name), flush=True)
            print('temp.ippan_damage={}'.format(temp.ippan_damage), flush=True)
            print('temp.kokyo_damage={}'.format(temp.kokyo_damage), flush=True)
            print('temp.koeki_damage={}'.format(temp.koeki_damage), flush=True)
            print('temp.sum_total_damage={}'.format(temp.sum_total_damage), flush=True)
            print('temp.ippan_ratio={}'.format(temp.ippan_ratio), flush=True)
            print('temp.kokyo_ratio={}'.format(temp.kokyo_ratio), flush=True)
            print('temp.koeki_ratio={}'.format(temp.koeki_ratio), flush=True)
            print('temp.sum_total_ratio={}'.format(temp.sum_total_ratio), flush=True)
            ws.cell(row=row_index, column=1).value = temp.kasen_type_name
            ws.cell(row=row_index, column=2).value = temp.ippan_damage
            ws.cell(row=row_index, column=3).value = temp.ippan_ratio
            ws.cell(row=row_index, column=4).value = temp.kokyo_damage
            ws.cell(row=row_index, column=5).value = temp.kokyo_ratio
            ws.cell(row=row_index, column=6).value = temp.koeki_damage
            ws.cell(row=row_index, column=7).value = temp.koeki_ratio
            ws.cell(row=row_index, column=8).value = temp.sum_total_damage
            ws.cell(row=row_index, column=9).value = temp.sum_total_ratio
            
        for i, zentype in enumerate(zentype_list):
            row_index += 1
            print('zentype.kasen_type_code={}'.format(zentype.kasen_type_code), flush=True)
            print('zentype.kasen_type_name={}'.format(zentype.kasen_type_name), flush=True)
            print('zentype.ippan_damage={}'.format(zentype.ippan_damage), flush=True)
            print('zentype.kokyo_damage={}'.format(zentype.kokyo_damage), flush=True)
            print('zentype.koeki_damage={}'.format(zentype.koeki_damage), flush=True)
            print('zentype.sum_total_damage={}'.format(zentype.sum_total_damage), flush=True)
            print('zentype.ippan_ratio={}'.format(zentype.ippan_ratio), flush=True)
            print('zentype.kokyo_ratio={}'.format(zentype.kokyo_ratio), flush=True)
            print('zentype.koeki_ratio={}'.format(zentype.koeki_ratio), flush=True)
            print('zentype.sum_total_ratio={}'.format(zentype.sum_total_ratio), flush=True)
            ws.cell(row=row_index, column=1).value = zentype.kasen_type_name
            ws.cell(row=row_index, column=2).value = zentype.ippan_damage
            ws.cell(row=row_index, column=3).value = zentype.ippan_ratio
            ws.cell(row=row_index, column=4).value = zentype.kokyo_damage
            ws.cell(row=row_index, column=5).value = zentype.kokyo_ratio
            ws.cell(row=row_index, column=6).value = zentype.koeki_damage
            ws.cell(row=row_index, column=7).value = zentype.koeki_ratio
            ws.cell(row=row_index, column=8).value = zentype.sum_total_damage
            ws.cell(row=row_index, column=9).value = zentype.sum_total_ratio
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo14_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo14_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo14.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo14_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo14_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo14_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
