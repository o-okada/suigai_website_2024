###############################################################################
### 帳票名：hyo_10異常気象別水害被害.xlsx
### ファイル名：P0700EStat/hyo10_views.py
### ※表10は横方向に異常気象の繰り返しがありその他の表とは行列の配置が異なる。
### ※SQLも、プログラム的にも行方向にレコードが繰り返す（ループする）のが望ましい。
### ※したがって、表10は帳票の行列を転置したものを考えてDBからデータを取得して、zip関数を用いて転置する。
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO10:
    def __init__(self, ):
        pass

###############################################################################
### 帳票名：hyo_10異常気象別水害被害.xlsx
### 関数名：get_hyo10_weather_ids()
### 0 異常気象一覧
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo10_weather_ids():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_weather_ids()関数 STEP 1/4.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_weather_ids()関数 STEP 2/4.', 'DEBUG')
        hyo10_weather_ids = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                weather_id 
            FROM weather 
            ORDER BY weather_id 
            LIMIT 3 
            """, [])
        
        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_weather_ids()関数 STEP 3/4.', 'DEBUG')
        weather_1_id = None
        weather_2_id = None
        weather_3_id = None
        for i, weather in enumerate(hyo10_weather_ids):
            if i == 0:
                weather_1_id = weather.weather_id
            if i == 1:
                weather_2_id = weather.weather_id
            if i == 2:
                weather_3_id = weather.weather_id

        #######################################################################
        ### 戻り値セット処理(0030)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_weather_ids()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo10_weather_ids()関数が正常終了しました。', 'INFO')
        return True, weather_1_id, weather_2_id, weather_3_id 
    except:
        print_log('[ERROR] P0700EStat.get_hyo10_weather_ids()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_weather_ids()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_weather_ids()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_10異常気象別水害被害.xlsx
### 関数名：get_hyo10_weather(weather_id)
### 1 異常気象別_被害額
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo10_weather(weather_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_weather()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo10_weather()関数 weather_id={}'.format(weather_id), 'DEBUG')
        ### if ken_code in constants.ken_values:
        ###     pass
        ### else:
        ###     print_log('[WARN] P0700EStat.get_hyo10_weather()関数が警告終了しました。', 'INFO')
        ###     return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        weather_keys = ['WEATHER_ID']
        weather_values = [weather_id]
        params = dict(zip(constants.setubi_keys + weather_keys, constants.setubi_values + weather_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_weather()関数 STEP 2/3.', 'DEBUG')
        hyo10_weather_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN05.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN05.residential_underground_area END, 
                CASE WHEN (IPPAN05.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.agricultural_area END, 
                CASE WHEN (IPPAN05.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.residential_underground_agricultural_area END, 
                CASE WHEN (IPPAN06.asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END, 
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                
                CASE WHEN (CHITAN01.kasen_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_damage END+
                CASE WHEN (HOJO01.kasen_determined_damage) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_damage END
                AS kasen_damage, 
                
                CASE WHEN (CHITAN02.kaigan_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_estimated_damage END+
                CASE WHEN (HOJO02.kaigan_determined_damage) IS NULL THEN 0.00 ELSE HOJO02.kaigan_determined_damage END 
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN03.sabou_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_damage END+
                CASE WHEN (HOJO03.sabou_determined_damage) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_damage END 
                AS sabou_damage, 
                
                CASE WHEN (CHITAN04.landslide_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_damage END+
                CASE WHEN (HOJO04.landslide_determined_damage) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_damage END 
                AS landslide_damage, 

                CASE WHEN (CHITAN05.steepslope_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_damage END+
                CASE WHEN (HOJO05.steepslope_determined_damage) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_damage END 
                AS steepslope_damage, 

                CASE WHEN (CHITAN06.road_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_damage END+
                CASE WHEN (HOJO06.road_determined_damage) IS NULL THEN 0.00 ELSE HOJO06.road_determined_damage END 
                AS road_damage, 

                CASE WHEN (CHITAN07.bridge_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_damage END+
                CASE WHEN (HOJO07.bridge_determined_damage) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_damage END 
                AS bridge_damage, 

                CASE WHEN (CHITAN08.sewer_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_damage END+
                CASE WHEN (HOJO08.sewer_determined_damage) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_damage END 
                AS sewer_damage, 

                CASE WHEN (CHITAN09.park_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN09.park_estimated_damage END+
                CASE WHEN (HOJO09.park_determined_damage) IS NULL THEN 0.00 ELSE HOJO09.park_determined_damage END 
                AS park_damage, 

                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END 
                AS damage, 
                
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI04.sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.sales_alt_other_damage END, 
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END, 
                
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END+
                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END+
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END 
                AS ippan_chitan_hojo_koeki_damage 

            FROM 

            -- 一般資産等被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) IPPAN01, 

            -- 一般資産等被害_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY KASEN_CODE 
            ) SUB00 
            ) IPPAN02, 

            -- 一般資産等被害_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY CITY_CODE 
            ) SUB00 
            ) IPPAN03, 

            -- 一般資産等被害_家屋被害
            (SELECT 
                -- 全壊・流失
                SUM(
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END 
                ) AS building_full, 
                -- 半壊
                SUM(
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END 
                ) AS building_half, 
                -- 床上浸水
                SUM(
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END 
                ) AS building_lv01_50_100, 
                -- 床下浸水
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END
                ) AS building_lv00, 
                -- 計
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END 
                ) AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) IPPAN04, 

            -- 一般資産等被害_水害区域面積
            (SELECT 
                -- 宅地・その他
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END 
                ) AS residential_underground_area, 
                -- 農地
                SUM(
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END 
                ) AS agricultural_area, 
                -- 計
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END 
                ) AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) IPPAN05, 

            -- 一般資産等被害_被害額
            (SELECT 
                -- 一般資産・営業停止損失額
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END
                ) AS asset_sales_damage, 
                -- 農作物
                SUM(
                    crop_damage
                ) AS crop_damage, 
                -- 計
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END+ 
                    CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END 
                ) AS asset_sales_crop_damage 
            FROM IPPAN_SUMMARY_VIEW
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) IPPAN06, 

            -- 公共土木施設被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (
            SELECT 
                suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            UNION 
            SELECT 
                suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公共土木施設被害_河川・海岸数
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (
            SELECT 
                kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY kasen_code 
            UNION 
            SELECT 
                kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公共土木施設被害_市区町村数
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (
            SELECT 
                city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY city_code 
            UNION 
            SELECT 
                city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 地方単独事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kasen_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(KASEN)s 
            ) CHITAN01, 

            -- 地方単独事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kaigan_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) CHITAN02, 

            -- 地方単独事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sabou_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SABOU)s 
            ) CHITAN03, 

            -- 地方単独事業被害_被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS landslide_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(LANDSLIDE)s 
            ) CHITAN04, 

            -- 地方単独事業被害_被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS steepslope_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) CHITAN05, 

            -- 地方単独事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS road_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(ROAD)s 
            ) CHITAN06, 

            -- 地方単独事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS bridge_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(BRIDGE)s 
            ) CHITAN07, 

            -- 地方単独事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sewer_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SEWER)s 
            ) CHITAN08, 

            -- 地方単独事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS park_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) CHITAN09, 

            -- 地方単独事業被害_被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) CHITAN10, 

            -- 補助事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kasen_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(KASEN)s 
            ) HOJO01, 

            -- 補助事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kaigan_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) HOJO02, 

            -- 補助事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sabou_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SABOU)s 
            ) HOJO03, 

            -- 補助事業被害_被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS landslide_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(LANDSLIDE)s 
            ) HOJO04, 

            -- 補助事業被害_被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS steepslope_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) HOJO05, 

            -- 補助事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS road_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(ROAD)s 
            ) HOJO06, 

            -- 補助事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS bridge_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(BRIDGE)s 
            ) HOJO07, 

            -- 補助事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sewer_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SEWER)s 
            ) HOJO08, 

            -- 補助事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS park_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) HOJO09, 

            -- 補助事業被害_被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) HOJO10, 

            -- 公益事業等_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOEKI01, 

            -- 公益事業等_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOEKI02, 

            -- 公益事業等_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOEKI03, 

            -- 公益事業等_被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END 
                ) AS physical_damage, 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END 
                ) AS sales_alt_other_damage, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END 
                ) AS physical_sales_alt_other_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) KOEKI04 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_weather()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo10_weather()関数が正常終了しました。', 'INFO')
        return True, hyo10_weather_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo10_weather()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_weather()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_weather()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_10異常気象別水害被害.xlsx
### 関数名：get_hyo10_other(weather_id_1, weather_id_2, weather_id_3)
### 2 その他異常気象_被害額
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo10_other(weather_id_1, weather_id_2, weather_id_3):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_other()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo10_other()関数 weather_id_1={}'.format(weather_id_1), 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo10_other()関数 weather_id_2={}'.format(weather_id_2), 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo10_other()関数 weather_id_3={}'.format(weather_id_3), 'DEBUG')
        ### if ken_code in constants.ken_values:
        ###     pass
        ### else:
        ###     print_log('[WARN] P0700EStat.get_hyo10_other()関数が警告終了しました。', 'INFO')
        ###     return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ### ※検索結果が異なるため、WEATHER_ID_1、WEATHER_ID_2、WEATHER_ID_3のNULLに注意すること。
        weather_keys = ['WEATHER_ID_1','WEATHER_ID_2','WEATHER_ID_3']
        weather_values = [weather_id_1,weather_id_2,weather_id_3]
        params = dict(zip(constants.setubi_keys + weather_keys, constants.setubi_values + weather_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_other()関数 STEP 2/3.', 'DEBUG')
        hyo10_other_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN05.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN05.residential_underground_area END, 
                CASE WHEN (IPPAN05.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.agricultural_area END, 
                CASE WHEN (IPPAN05.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.residential_underground_agricultural_area END, 
                CASE WHEN (IPPAN06.asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END, 
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                
                CASE WHEN (CHITAN01.kasen_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_damage END+
                CASE WHEN (HOJO01.kasen_determined_damage) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_damage END
                AS kasen_damage, 
                
                CASE WHEN (CHITAN02.kaigan_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_estimated_damage END+
                CASE WHEN (HOJO02.kaigan_determined_damage) IS NULL THEN 0.00 ELSE HOJO02.kaigan_determined_damage END 
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN03.sabou_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_damage END+
                CASE WHEN (HOJO03.sabou_determined_damage) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_damage END 
                AS sabou_damage, 
                
                CASE WHEN (CHITAN04.landslide_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_damage END+
                CASE WHEN (HOJO04.landslide_determined_damage) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_damage END 
                AS landslide_damage, 

                CASE WHEN (CHITAN05.steepslope_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_damage END+
                CASE WHEN (HOJO05.steepslope_determined_damage) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_damage END 
                AS steepslope_damage, 

                CASE WHEN (CHITAN06.road_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_damage END+
                CASE WHEN (HOJO06.road_determined_damage) IS NULL THEN 0.00 ELSE HOJO06.road_determined_damage END 
                AS road_damage, 

                CASE WHEN (CHITAN07.bridge_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_damage END+
                CASE WHEN (HOJO07.bridge_determined_damage) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_damage END 
                AS bridge_damage, 

                CASE WHEN (CHITAN08.sewer_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_damage END+
                CASE WHEN (HOJO08.sewer_determined_damage) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_damage END 
                AS sewer_damage, 

                CASE WHEN (CHITAN09.park_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN09.park_estimated_damage END+
                CASE WHEN (HOJO09.park_determined_damage) IS NULL THEN 0.00 ELSE HOJO09.park_determined_damage END 
                AS park_damage, 

                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END 
                AS damage, 
                
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI04.sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.sales_alt_other_damage END, 
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END, 
                
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END+
                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END+
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END 
                AS ippan_chitan_hojo_koeki_damage 

            FROM 

            -- 一般資産等被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) IPPAN01, 

            -- 一般資産等被害_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY KASEN_CODE 
            ) SUB00 
            ) IPPAN02, 

            -- 一般資産等被害_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY CITY_CODE 
            ) SUB00 
            ) IPPAN03, 

            -- 一般資産等被害_家屋被害
            (SELECT 
                -- 全壊・流失
                SUM(
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END 
                ) AS building_full, 
                -- 半壊
                SUM(
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END 
                ) AS building_half, 
                -- 床上浸水
                SUM(
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END 
                ) AS building_lv01_50_100, 
                -- 床下浸水
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END
                ) AS building_lv00, 
                -- 計
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END 
                ) AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) IPPAN04, 

            -- 一般資産等被害_水害区域面積
            (SELECT 
                -- 宅地・その他
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END 
                ) AS residential_underground_area, 
                -- 農地
                SUM(
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END 
                ) AS agricultural_area, 
                -- 計
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END 
                ) AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) IPPAN05, 

            -- 一般資産等被害_被害額
            (SELECT 
                -- 一般資産・営業停止損失額
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END
                ) AS asset_sales_damage, 
                -- 農作物
                SUM(
                    crop_damage
                ) AS crop_damage, 
                -- 計
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END+ 
                    CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END 
                ) AS asset_sales_crop_damage 
            FROM IPPAN_SUMMARY_VIEW
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) IPPAN06, 

            -- 公共土木施設被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (
            SELECT 
                suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY suikei_code 
            UNION 
            SELECT 
                suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公共土木施設被害_河川・海岸数
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (
            SELECT 
                kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY kasen_code 
            UNION 
            SELECT 
                kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公共土木施設被害_市区町村数
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (
            SELECT 
                city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY city_code 
            UNION 
            SELECT 
                city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 地方単独事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kasen_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN01, 

            -- 地方単独事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kaigan_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN02, 

            -- 地方単独事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sabou_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN03, 

            -- 地方単独事業被害_被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS landslide_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN04, 

            -- 地方単独事業被害_被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS steepslope_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN05, 

            -- 地方単独事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS road_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN06, 

            -- 地方単独事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS bridge_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN07, 

            -- 地方単独事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sewer_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN08, 

            -- 地方単独事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS park_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN09, 

            -- 地方単独事業被害_被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) CHITAN10, 

            -- 補助事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kasen_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO01, 

            -- 補助事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kaigan_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO02, 

            -- 補助事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sabou_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO03, 

            -- 補助事業被害_被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS landslide_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO04, 

            -- 補助事業被害_被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS steepslope_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO05, 

            -- 補助事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS road_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO06, 

            -- 補助事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS bridge_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO07, 

            -- 補助事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sewer_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO08, 

            -- 補助事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS park_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO09, 

            -- 補助事業被害_被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) HOJO10, 

            -- 公益事業等_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOEKI01, 

            -- 公益事業等_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOEKI02, 

            -- 公益事業等_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOEKI03, 

            -- 公益事業等_被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END 
                ) AS physical_damage, 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END 
                ) AS sales_alt_other_damage, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END 
                ) AS physical_sales_alt_other_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id <> %(WEATHER_ID_1)s AND weather_id <> %(WEATHER_ID_2)s AND weather_id <> %(WEATHER_ID_3)s 
            ) KOEKI04 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_other()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo10_other()関数が正常終了しました。', 'INFO')
        return True, hyo10_other_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo10_other()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_other()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_other()関数が異常終了しました。', 'ERROR')
        return False, []
    
###############################################################################
### 帳票名：hyo_10異常気象別水害被害.xlsx
### 関数名：get_hyo10_zenweather()
### 3 全異常気象_被害額
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo10_zenweather():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_zenweather()関数 STEP 1/3.', 'DEBUG')

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        params = dict(zip(constants.setubi_keys, constants.setubi_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_zenweather()関数 STEP 2/3.', 'DEBUG')
        hyo10_zenweather_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN05.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN05.residential_underground_area END, 
                CASE WHEN (IPPAN05.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.agricultural_area END, 
                CASE WHEN (IPPAN05.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.residential_underground_agricultural_area END, 
                CASE WHEN (IPPAN06.asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END, 
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                
                CASE WHEN (CHITAN01.kasen_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_damage END+
                CASE WHEN (HOJO01.kasen_determined_damage) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_damage END
                AS kasen_damage, 
                
                CASE WHEN (CHITAN02.kaigan_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_estimated_damage END+
                CASE WHEN (HOJO02.kaigan_determined_damage) IS NULL THEN 0.00 ELSE HOJO02.kaigan_determined_damage END 
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN03.sabou_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_damage END+
                CASE WHEN (HOJO03.sabou_determined_damage) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_damage END 
                AS sabou_damage, 
                
                CASE WHEN (CHITAN04.landslide_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_damage END+
                CASE WHEN (HOJO04.landslide_determined_damage) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_damage END 
                AS landslide_damage, 

                CASE WHEN (CHITAN05.steepslope_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_damage END+
                CASE WHEN (HOJO05.steepslope_determined_damage) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_damage END 
                AS steepslope_damage, 

                CASE WHEN (CHITAN06.road_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_damage END+
                CASE WHEN (HOJO06.road_determined_damage) IS NULL THEN 0.00 ELSE HOJO06.road_determined_damage END 
                AS road_damage, 

                CASE WHEN (CHITAN07.bridge_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_damage END+
                CASE WHEN (HOJO07.bridge_determined_damage) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_damage END 
                AS bridge_damage, 

                CASE WHEN (CHITAN08.sewer_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_damage END+
                CASE WHEN (HOJO08.sewer_determined_damage) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_damage END 
                AS sewer_damage, 

                CASE WHEN (CHITAN09.park_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN09.park_estimated_damage END+
                CASE WHEN (HOJO09.park_determined_damage) IS NULL THEN 0.00 ELSE HOJO09.park_determined_damage END 
                AS park_damage, 

                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END 
                AS damage, 
                
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI04.sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.sales_alt_other_damage END, 
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END, 
                
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END+
                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END+
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END 
                AS ippan_chitan_hojo_koeki_damage 

            FROM 

            -- 一般資産等被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY suikei_code 
            ) SUB00 
            ) IPPAN01, 

            -- 一般資産等被害_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY KASEN_CODE 
            ) SUB00 
            ) IPPAN02, 

            -- 一般資産等被害_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY CITY_CODE 
            ) SUB00 
            ) IPPAN03, 

            -- 一般資産等被害_家屋被害
            (SELECT 
                -- 全壊・流失
                SUM(
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END 
                ) AS building_full, 
                -- 半壊
                SUM(
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END 
                ) AS building_half, 
                -- 床上浸水
                SUM(
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END 
                ) AS building_lv01_50_100, 
                -- 床下浸水
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END
                ) AS building_lv00, 
                -- 計
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END 
                ) AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN04, 

            -- 一般資産等被害_水害区域面積
            (SELECT 
                -- 宅地・その他
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END 
                ) AS residential_underground_area, 
                -- 農地
                SUM(
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END 
                ) AS agricultural_area, 
                -- 計
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END 
                ) AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN05, 

            -- 一般資産等被害_被害額
            (SELECT 
                -- 一般資産・営業停止損失額
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END
                ) AS asset_sales_damage, 
                -- 農作物
                SUM(
                    crop_damage
                ) AS crop_damage, 
                -- 計
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END+ 
                    CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END 
                ) AS asset_sales_crop_damage 
            FROM IPPAN_SUMMARY_VIEW
            WHERE deleted_at IS NULL 
            ) IPPAN06, 

            -- 公共土木施設被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (
            SELECT 
                suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY suikei_code 
            UNION 
            SELECT 
                suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公共土木施設被害_河川・海岸数
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (
            SELECT 
                kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY kasen_code 
            UNION 
            SELECT 
                kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公共土木施設被害_市区町村数
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (
            SELECT 
                city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY city_code 
            UNION 
            SELECT 
                city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 地方単独事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kasen_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) CHITAN01, 

            -- 地方単独事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kaigan_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) CHITAN02, 

            -- 地方単独事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sabou_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) CHITAN03, 

            -- 地方単独事業被害_被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS landslide_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) CHITAN04, 

            -- 地方単独事業被害_被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS steepslope_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) CHITAN05, 

            -- 地方単独事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS road_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) CHITAN06, 

            -- 地方単独事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS bridge_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) CHITAN07, 

            -- 地方単独事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sewer_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) CHITAN08, 

            -- 地方単独事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS park_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) CHITAN09, 

            -- 地方単独事業被害_被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) CHITAN10, 

            -- 補助事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kasen_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) HOJO01, 

            -- 補助事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kaigan_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) HOJO02, 

            -- 補助事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sabou_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) HOJO03, 

            -- 補助事業被害_被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS landslide_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) HOJO04, 

            -- 補助事業被害_被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS steepslope_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) HOJO05, 

            -- 補助事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS road_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) HOJO06, 

            -- 補助事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS bridge_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) HOJO07, 

            -- 補助事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sewer_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) HOJO08, 

            -- 補助事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS park_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) HOJO09, 

            -- 補助事業被害_被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) HOJO10, 

            -- 公益事業等_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOEKI01, 

            -- 公益事業等_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOEKI02, 

            -- 公益事業等_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY city_code 
            ) SUB00 
            ) KOEKI03, 

            -- 公益事業等_被害額
            (SELECT 
                -- 物的被害額
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END 
                ) AS physical_damage, 
                -- 営業停止損失額
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END 
                ) AS sales_alt_other_damage, 
                -- 計
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END 
                ) AS physical_sales_alt_other_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI04 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo10_zenweather()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo10_zenweather()関数が正常終了しました。', 'INFO')
        return True, hyo10_zenweather_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo10_zenweather()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_zenweather()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo10_zenweather()関数が異常終了しました。', 'ERROR')
        return False, []
    
###############################################################################
### 帳票名：hyo_10異常気象別水害被害.xlsx
### 関数名：hyo10_view(request)
### urlpattern：path('hyo10/', hyo10_views.hyo10_view, name='hyo10_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo10_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo10_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo10_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo10_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo10_view()関数 STEP 2/4.', 'DEBUG')

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo10_view()関数 STEP 3/4.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo10_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo10', 
            'weather_list': weather_list, 
            'other_list': other_list, 
            'zenweather_list': zenweather_list, 
        }
        print_log('[INFO] P0700EStat.hyo10_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo10_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo10_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo10_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_10異常気象別水害被害.xlsx
### 関数名：hyo10_download_view(request)
### urlpattern：path('download/hyo10/', hyo10_views.hyo10_download_view, name='hyo10_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo10_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo10_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 主要異常気象を3件取得する。
        bool_return, weather_1_id, weather_2_id, weather_3_id = get_hyo10_weather_ids()
        if bool_return == False:
            raise Exception
            
        if weather_1_id == None:
            weather_1_id = '0'
            
        if weather_2_id == None:
            weather_2_id = '0'
            
        if weather_3_id == None:
            weather_3_id = '0'
        
        ### 1 異常気象別_被害額
        bool_return, weather_1_list = get_hyo10_weather(weather_1_id)
        if bool_return == False:
            raise Exception

        bool_return, weather_2_list = get_hyo10_weather(weather_2_id)
        if bool_return == False:
            raise Exception

        bool_return, weather_3_list = get_hyo10_weather(weather_3_id)
        if bool_return == False:
            raise Exception

        ### 2 その他異常気象_被害額
        bool_return, other_list = get_hyo10_other(weather_1_id, weather_2_id, weather_3_id)
        if bool_return == False:
            raise Exception
        
        ### 3 全異常気象_被害額
        bool_return, zenweather_list = get_hyo10_zenweather()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 異常気象別_被害額
        for i, weather in enumerate(weather_1_list):
            print('weather.ippan_suikei_num={}'.format(weather.ippan_suikei_num), flush=True)

        for i, weather in enumerate(weather_2_list):
            print('weather.ippan_suikei_num={}'.format(weather.ippan_suikei_num), flush=True)

        for i, weather in enumerate(weather_3_list):
            print('weather.ippan_suikei_num={}'.format(weather.ippan_suikei_num), flush=True)

        ### 2 その他異常気象_被害額
        for i, other in enumerate(other_list):
            print('other.ippan_suikei_num={}'.format(other.ippan_suikei_num), flush=True)

        ### 3 全異常気象_被害額
        for i, zenweather in enumerate(zenweather_list):
            print('zenweather.ippan_suikei_num={}'.format(zenweather.ippan_suikei_num), flush=True)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo10.xlsx'
        ### download_file_path = 'static/download_hyo10.xlsx'
        template_file_path = 'static/template/template_hyo10.xlsx'
        download_file_path = 'static/tmp/download_hyo10.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo10'
        
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4_1/5.', 'DEBUG')
        ws.cell(row=1, column=1).value = '表－１０　異常気象別水害被害'
        ws.cell(row=3, column=1).value = '異常気象名'
        ws.cell(row=3, column=5).value = '①豪雨及び台風１４号'
        ws.cell(row=3, column=6).value = '②梅雨前線豪雨'
        ws.cell(row=3, column=7).value = '③豪雨'
        ws.cell(row=3, column=8).value = 'その他の異常気象'
        ws.cell(row=3, column=9).value = '全異常気象'
        ws.cell(row=5, column=1).value = '事　項'
        ws.cell(row=5, column=4).value = '単位'
        ws.cell(row=5, column=5).value = '(9.3～9.8)'
        ws.cell(row=5, column=6).value = '(6.27～7.7)'
        ws.cell(row=5, column=7).value = '(8.9～8.17)'
        ws.cell(row=6, column=1).value = '一般資産等被害'
        ws.cell(row=20, column=1).value = '公共土木施設被害'
        ws.cell(row=32, column=1).value = ''
        ws.cell(row=33, column=1).value = '公益事業等'
        ws.cell(row=39, column=1).value = '合計'
        ws.cell(row=6, column=2).value = '水系・沿岸数'
        ws.cell(row=7, column=2).value = '河川・海岸数'
        ws.cell(row=8, column=2).value = '市区町村数'
        ws.cell(row=9, column=2).value = '家屋被害'
        ws.cell(row=14, column=2).value = '水害区域面積'
        ws.cell(row=17, column=2).value = '被害額'
        ws.cell(row=20, column=2).value = '水系・沿岸数'
        ws.cell(row=21, column=2).value = '河川・海岸数'
        ws.cell(row=22, column=2).value = '市区町村数'
        ws.cell(row=23, column=2).value = '被害額'
        ws.cell(row=33, column=2).value = '水系・沿岸数'
        ws.cell(row=34, column=2).value = '河川・海岸数'
        ws.cell(row=35, column=2).value = '市区町村数'
        ws.cell(row=36, column=2).value = '被害額'
        ws.cell(row=39, column=2).value = '一般資産等被害額'
        ws.cell(row=40, column=2).value = '公共土木施設被害額'
        ws.cell(row=41, column=2).value = '公益事業等被害額'
        ws.cell(row=42, column=2).value = '計'
        ws.cell(row=6, column=3).value = ''
        ws.cell(row=7, column=3).value = ''
        ws.cell(row=8, column=3).value = ''
        ws.cell(row=9, column=3).value = '全壊・流失'
        ws.cell(row=10, column=3).value = '半壊'
        ws.cell(row=11, column=3).value = '床上浸水'
        ws.cell(row=12, column=3).value = '床下浸水'
        ws.cell(row=13, column=3).value = '計'
        ws.cell(row=14, column=3).value = '宅地・その他'
        ws.cell(row=15, column=3).value = '農地'
        ws.cell(row=16, column=3).value = '計'
        ws.cell(row=17, column=3).value = '一般資産・営業停止損失額'
        ws.cell(row=18, column=3).value = '農作物'
        ws.cell(row=19, column=3).value = '計'
        ws.cell(row=20, column=3).value = ''
        ws.cell(row=21, column=3).value = ''
        ws.cell(row=22, column=3).value = ''
        ws.cell(row=23, column=3).value = '河川'
        ws.cell(row=24, column=3).value = '海岸・港湾'
        ws.cell(row=25, column=3).value = '砂防設備'
        ws.cell(row=26, column=3).value = '地すべり防止施設'
        ws.cell(row=27, column=3).value = '急傾斜地崩壊防止施設'
        ws.cell(row=28, column=3).value = '道路'
        ws.cell(row=29, column=3).value = '橋梁'
        ws.cell(row=30, column=3).value = '下水道'
        ws.cell(row=31, column=3).value = '都市施設・公園'
        ws.cell(row=32, column=3).value = '計'
        ws.cell(row=33, column=3).value = ''
        ws.cell(row=34, column=3).value = ''
        ws.cell(row=35, column=3).value = ''
        ws.cell(row=36, column=3).value = '物的被害額'
        ws.cell(row=37, column=3).value = '営業停止損失額'
        ws.cell(row=38, column=3).value = '計'
        ws.cell(row=39, column=3).value = ''
        ws.cell(row=40, column=3).value = ''
        ws.cell(row=41, column=3).value = ''
        ws.cell(row=42, column=3).value = ''
        ws.cell(row=6, column=4).value = ''
        ws.cell(row=7, column=4).value = ''
        ws.cell(row=8, column=4).value = ''
        ws.cell(row=9, column=4).value = '棟'
        ws.cell(row=10, column=4).value = '〃'
        ws.cell(row=11, column=4).value = '〃'
        ws.cell(row=12, column=4).value = '〃'
        ws.cell(row=13, column=4).value = '〃'
        ws.cell(row=14, column=4).value = 'ha'
        ws.cell(row=15, column=4).value = '〃'
        ws.cell(row=16, column=4).value = '〃'
        ws.cell(row=17, column=4).value = '百万円'
        ws.cell(row=18, column=4).value = '〃'
        ws.cell(row=19, column=4).value = '〃'
        ws.cell(row=20, column=4).value = ''
        ws.cell(row=21, column=4).value = ''
        ws.cell(row=22, column=4).value = ''
        ws.cell(row=23, column=4).value = '百万円'
        ws.cell(row=24, column=4).value = '〃'
        ws.cell(row=25, column=4).value = '〃'
        ws.cell(row=26, column=4).value = '〃'
        ws.cell(row=27, column=4).value = '〃'
        ws.cell(row=28, column=4).value = '〃'
        ws.cell(row=29, column=4).value = '〃'
        ws.cell(row=30, column=4).value = '〃'
        ws.cell(row=31, column=4).value = '〃'
        ws.cell(row=32, column=4).value = '〃'
        ws.cell(row=33, column=4).value = ''
        ws.cell(row=34, column=4).value = ''
        ws.cell(row=35, column=4).value = ''
        ws.cell(row=36, column=4).value = '百万円'
        ws.cell(row=37, column=4).value = '〃'
        ws.cell(row=38, column=4).value = '〃'
        ws.cell(row=39, column=4).value = '百万円'
        ws.cell(row=40, column=4).value = '〃'
        ws.cell(row=41, column=4).value = '〃'
        ws.cell(row=42, column=4).value = '〃'
        
        ### 1 異常気象別_被害額
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4_2/5.', 'DEBUG')
        for i, weather in enumerate(weather_1_list):
            ws.cell(row=3, column=5).value = ''
            ws.cell(row=5, column=5).value = ''
            ws.cell(row=6, column=5).value = weather.ippan_suikei_num
            ws.cell(row=7, column=5).value = weather.ippan_kasen_num
            ws.cell(row=8, column=5).value = weather.ippan_city_num
            ws.cell(row=9, column=5).value = weather.building_full
            ws.cell(row=10, column=5).value = weather.building_half
            ws.cell(row=11, column=5).value = weather.building_lv01_50_100
            ws.cell(row=12, column=5).value = weather.building_lv00
            ws.cell(row=13, column=5).value = weather.building_lv00_01_50_100_half_full
            ws.cell(row=14, column=5).value = weather.residential_underground_area
            ws.cell(row=15, column=5).value = weather.agricultural_area
            ws.cell(row=16, column=5).value = weather.residential_underground_agricultural_area
            ws.cell(row=17, column=5).value = weather.asset_sales_damage
            ws.cell(row=18, column=5).value = weather.crop_damage
            ws.cell(row=19, column=5).value = weather.asset_sales_crop_damage
            ws.cell(row=20, column=5).value = weather.kokyo_suikei_num
            ws.cell(row=21, column=5).value = weather.kokyo_kasen_num
            ws.cell(row=22, column=5).value = weather.kokyo_city_num
            ws.cell(row=23, column=5).value = weather.kasen_damage
            ws.cell(row=24, column=5).value = weather.kaigan_damage
            ws.cell(row=25, column=5).value = weather.sabou_damage
            ws.cell(row=26, column=5).value = weather.landslide_damage
            ws.cell(row=27, column=5).value = weather.steepslope_damage
            ws.cell(row=28, column=5).value = weather.road_damage
            ws.cell(row=29, column=5).value = weather.bridge_damage
            ws.cell(row=30, column=5).value = weather.sewer_damage
            ws.cell(row=31, column=5).value = weather.park_damage
            ws.cell(row=32, column=5).value = weather.damage
            ws.cell(row=33, column=5).value = weather.koeki_suikei_num
            ws.cell(row=34, column=5).value = weather.koeki_kasen_num
            ws.cell(row=35, column=5).value = weather.koeki_city_num
            ws.cell(row=36, column=5).value = weather.physical_damage
            ws.cell(row=37, column=5).value = weather.sales_alt_other_damage
            ws.cell(row=38, column=5).value = weather.physical_sales_alt_other_damage
            ws.cell(row=39, column=5).value = weather.asset_sales_crop_damage
            ws.cell(row=40, column=5).value = weather.damage
            ws.cell(row=41, column=5).value = weather.physical_sales_alt_other_damage
            ws.cell(row=42, column=5).value = weather.ippan_chitan_hojo_koeki_damage

        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4_3/5.', 'DEBUG')
        for i, weather in enumerate(weather_2_list):
            ws.cell(row=3, column=6).value = ''
            ws.cell(row=5, column=6).value = ''
            ws.cell(row=6, column=6).value = weather.ippan_suikei_num
            ws.cell(row=7, column=6).value = weather.ippan_kasen_num
            ws.cell(row=8, column=6).value = weather.ippan_city_num
            ws.cell(row=9, column=6).value = weather.building_full
            ws.cell(row=10, column=6).value = weather.building_half
            ws.cell(row=11, column=6).value = weather.building_lv01_50_100
            ws.cell(row=12, column=6).value = weather.building_lv00
            ws.cell(row=13, column=6).value = weather.building_lv00_01_50_100_half_full
            ws.cell(row=14, column=6).value = weather.residential_underground_area
            ws.cell(row=15, column=6).value = weather.agricultural_area
            ws.cell(row=16, column=6).value = weather.residential_underground_agricultural_area
            ws.cell(row=17, column=6).value = weather.asset_sales_damage
            ws.cell(row=18, column=6).value = weather.crop_damage
            ws.cell(row=19, column=6).value = weather.asset_sales_crop_damage
            ws.cell(row=20, column=6).value = weather.kokyo_suikei_num
            ws.cell(row=21, column=6).value = weather.kokyo_kasen_num
            ws.cell(row=22, column=6).value = weather.kokyo_city_num
            ws.cell(row=23, column=6).value = weather.kasen_damage
            ws.cell(row=24, column=6).value = weather.kaigan_damage
            ws.cell(row=25, column=6).value = weather.sabou_damage
            ws.cell(row=26, column=6).value = weather.landslide_damage
            ws.cell(row=27, column=6).value = weather.steepslope_damage
            ws.cell(row=28, column=6).value = weather.road_damage
            ws.cell(row=29, column=6).value = weather.bridge_damage
            ws.cell(row=30, column=6).value = weather.sewer_damage
            ws.cell(row=31, column=6).value = weather.park_damage
            ws.cell(row=32, column=6).value = weather.damage
            ws.cell(row=33, column=6).value = weather.koeki_suikei_num
            ws.cell(row=34, column=6).value = weather.koeki_kasen_num
            ws.cell(row=35, column=6).value = weather.koeki_city_num
            ws.cell(row=36, column=6).value = weather.physical_damage
            ws.cell(row=37, column=6).value = weather.sales_alt_other_damage
            ws.cell(row=38, column=6).value = weather.physical_sales_alt_other_damage
            ws.cell(row=39, column=6).value = weather.asset_sales_crop_damage
            ws.cell(row=40, column=6).value = weather.damage
            ws.cell(row=41, column=6).value = weather.physical_sales_alt_other_damage
            ws.cell(row=42, column=6).value = weather.ippan_chitan_hojo_koeki_damage

        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4_4/5.', 'DEBUG')
        for i, weather in enumerate(weather_3_list):
            ws.cell(row=3, column=7).value = ''
            ws.cell(row=5, column=7).value = ''
            ws.cell(row=6, column=7).value = weather.ippan_suikei_num
            ws.cell(row=7, column=7).value = weather.ippan_kasen_num
            ws.cell(row=8, column=7).value = weather.ippan_city_num
            ws.cell(row=9, column=7).value = weather.building_full
            ws.cell(row=10, column=7).value = weather.building_half
            ws.cell(row=11, column=7).value = weather.building_lv01_50_100
            ws.cell(row=12, column=7).value = weather.building_lv00
            ws.cell(row=13, column=7).value = weather.building_lv00_01_50_100_half_full
            ws.cell(row=14, column=7).value = weather.residential_underground_area
            ws.cell(row=15, column=7).value = weather.agricultural_area
            ws.cell(row=16, column=7).value = weather.residential_underground_agricultural_area
            ws.cell(row=17, column=7).value = weather.asset_sales_damage
            ws.cell(row=18, column=7).value = weather.crop_damage
            ws.cell(row=19, column=7).value = weather.asset_sales_crop_damage
            ws.cell(row=20, column=7).value = weather.kokyo_suikei_num
            ws.cell(row=21, column=7).value = weather.kokyo_kasen_num
            ws.cell(row=22, column=7).value = weather.kokyo_city_num
            ws.cell(row=23, column=7).value = weather.kasen_damage
            ws.cell(row=24, column=7).value = weather.kaigan_damage
            ws.cell(row=25, column=7).value = weather.sabou_damage
            ws.cell(row=26, column=7).value = weather.landslide_damage
            ws.cell(row=27, column=7).value = weather.steepslope_damage
            ws.cell(row=28, column=7).value = weather.road_damage
            ws.cell(row=29, column=7).value = weather.bridge_damage
            ws.cell(row=30, column=7).value = weather.sewer_damage
            ws.cell(row=31, column=7).value = weather.park_damage
            ws.cell(row=32, column=7).value = weather.damage
            ws.cell(row=33, column=7).value = weather.koeki_suikei_num
            ws.cell(row=34, column=7).value = weather.koeki_kasen_num
            ws.cell(row=35, column=7).value = weather.koeki_city_num
            ws.cell(row=36, column=7).value = weather.physical_damage
            ws.cell(row=37, column=7).value = weather.sales_alt_other_damage
            ws.cell(row=38, column=7).value = weather.physical_sales_alt_other_damage
            ws.cell(row=39, column=7).value = weather.asset_sales_crop_damage
            ws.cell(row=40, column=7).value = weather.damage
            ws.cell(row=41, column=7).value = weather.physical_sales_alt_other_damage
            ws.cell(row=42, column=7).value = weather.ippan_chitan_hojo_koeki_damage
        
        ### 2 その他異常気象_被害額
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4_5/5.', 'DEBUG')
        for i, other in enumerate(other_list):
            ws.cell(row=3, column=8).value = ''
            ### ws.cell(row=5, column=8).value = ''
            ws.cell(row=6, column=8).value = other.ippan_suikei_num
            ws.cell(row=7, column=8).value = other.ippan_kasen_num
            ws.cell(row=8, column=8).value = other.ippan_city_num
            ws.cell(row=9, column=8).value = other.building_full
            ws.cell(row=10, column=8).value = other.building_half
            ws.cell(row=11, column=8).value = other.building_lv01_50_100
            ws.cell(row=12, column=8).value = other.building_lv00
            ws.cell(row=13, column=8).value = other.building_lv00_01_50_100_half_full
            ws.cell(row=14, column=8).value = other.residential_underground_area
            ws.cell(row=15, column=8).value = other.agricultural_area
            ws.cell(row=16, column=8).value = other.residential_underground_agricultural_area
            ws.cell(row=17, column=8).value = other.asset_sales_damage
            ws.cell(row=18, column=8).value = other.crop_damage
            ws.cell(row=19, column=8).value = other.asset_sales_crop_damage
            ws.cell(row=20, column=8).value = other.kokyo_suikei_num
            ws.cell(row=21, column=8).value = other.kokyo_kasen_num
            ws.cell(row=22, column=8).value = other.kokyo_city_num
            ws.cell(row=23, column=8).value = other.kasen_damage
            ws.cell(row=24, column=8).value = other.kaigan_damage
            ws.cell(row=25, column=8).value = other.sabou_damage
            ws.cell(row=26, column=8).value = other.landslide_damage
            ws.cell(row=27, column=8).value = other.steepslope_damage
            ws.cell(row=28, column=8).value = other.road_damage
            ws.cell(row=29, column=8).value = other.bridge_damage
            ws.cell(row=30, column=8).value = other.sewer_damage
            ws.cell(row=31, column=8).value = other.park_damage
            ws.cell(row=32, column=8).value = other.damage
            ws.cell(row=33, column=8).value = other.koeki_suikei_num
            ws.cell(row=34, column=8).value = other.koeki_kasen_num
            ws.cell(row=35, column=8).value = other.koeki_city_num
            ws.cell(row=36, column=8).value = other.physical_damage
            ws.cell(row=37, column=8).value = other.sales_alt_other_damage
            ws.cell(row=38, column=8).value = other.physical_sales_alt_other_damage
            ws.cell(row=39, column=8).value = other.asset_sales_crop_damage
            ws.cell(row=40, column=8).value = other.damage
            ws.cell(row=41, column=8).value = other.physical_sales_alt_other_damage
            ws.cell(row=42, column=8).value = other.ippan_chitan_hojo_koeki_damage

        ### 3 全異常気象_被害額
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4_6/5.', 'DEBUG')
        for i, zenweather in enumerate(zenweather_list):
            ws.cell(row=3, column=9).value = ''
            ### ws.cell(row=5, column=9).value = ''
            ws.cell(row=6, column=9).value = zenweather.ippan_suikei_num
            ws.cell(row=7, column=9).value = zenweather.ippan_kasen_num
            ws.cell(row=8, column=9).value = zenweather.ippan_city_num
            ws.cell(row=9, column=9).value = zenweather.building_full
            ws.cell(row=10, column=9).value = zenweather.building_half
            ws.cell(row=11, column=9).value = zenweather.building_lv01_50_100
            ws.cell(row=12, column=9).value = zenweather.building_lv00
            ws.cell(row=13, column=9).value = zenweather.building_lv00_01_50_100_half_full
            ws.cell(row=14, column=9).value = zenweather.residential_underground_area
            ws.cell(row=15, column=9).value = zenweather.agricultural_area
            ws.cell(row=16, column=9).value = zenweather.residential_underground_agricultural_area
            ws.cell(row=17, column=9).value = zenweather.asset_sales_damage
            ws.cell(row=18, column=9).value = zenweather.crop_damage
            ws.cell(row=19, column=9).value = zenweather.asset_sales_crop_damage
            ws.cell(row=20, column=9).value = zenweather.kokyo_suikei_num
            ws.cell(row=21, column=9).value = zenweather.kokyo_kasen_num
            ws.cell(row=22, column=9).value = zenweather.kokyo_city_num
            ws.cell(row=23, column=9).value = zenweather.kasen_damage
            ws.cell(row=24, column=9).value = zenweather.kaigan_damage
            ws.cell(row=25, column=9).value = zenweather.sabou_damage
            ws.cell(row=26, column=9).value = zenweather.landslide_damage
            ws.cell(row=27, column=9).value = zenweather.steepslope_damage
            ws.cell(row=28, column=9).value = zenweather.road_damage
            ws.cell(row=29, column=9).value = zenweather.bridge_damage
            ws.cell(row=30, column=9).value = zenweather.sewer_damage
            ws.cell(row=31, column=9).value = zenweather.park_damage
            ws.cell(row=32, column=9).value = zenweather.damage
            ws.cell(row=33, column=9).value = zenweather.koeki_suikei_num
            ws.cell(row=34, column=9).value = zenweather.koeki_kasen_num
            ws.cell(row=35, column=9).value = zenweather.koeki_city_num
            ws.cell(row=36, column=9).value = zenweather.physical_damage
            ws.cell(row=37, column=9).value = zenweather.sales_alt_other_damage
            ws.cell(row=38, column=9).value = zenweather.physical_sales_alt_other_damage
            ws.cell(row=39, column=9).value = zenweather.asset_sales_crop_damage
            ws.cell(row=40, column=9).value = zenweather.damage
            ws.cell(row=41, column=9).value = zenweather.physical_sales_alt_other_damage
            ws.cell(row=42, column=9).value = zenweather.ippan_chitan_hojo_koeki_damage
        
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 4_7/5.', 'DEBUG')
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo10_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo10_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo10.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo10_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo10_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo10_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
