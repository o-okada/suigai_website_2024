###############################################################################
### 帳票名：hyo_01水害被害一覧.xlsx
### ファイル名：P0700EStat/hyo01_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO01:
    def __init__(self, ):
        self.death_num = death_num
        self.missing_num = missing_num
        self.wounded_num = wounded_num
        self.death_missing_wounded_num
        
        self.ippan_suikei_num = ippan_suikei_num
        self.ippan_kasen_num = ippan_kasen_num
        self.ippan_city_num = ippan_city_num
        
        self.residential_underground_area = residential_underground_area
        self.agricultural_area = agricultural_area
        self.residential_underground_agricultural_area = residential_underground_agricultural_area
        
        self.building_full_num = building_full_num
        self.building_half_num = building_half_num
        self.building_above_num = building_above_num
        self.building_under_num = building_under_num
        self.building_full_half_above_under_num = building_full_half_above_under_num
        
        self.family_full_num = family_full_num
        self.family_above_num = family_above_num
        self.family_under_num = family_under_num
        self.farmer_fisher_num = farmer_fisher_num
        self.office_num = office_num
        self.employee_num = employee_num
        
        self.house_damage = house_damage
        self.household_car_damage = household_car_damage
        self.farmer_fisher_damage = farmer_fisher_damage
        self.office_dep_inv_damage = office_dep_inv_damage
        self.house_alt_clean_damage = house_alt_clean_damage
        self.office_alt_damage = office_alt_damage
        self.ippan_asset_damage = ippan_asset_damage

        self.office_sales_damage = office_sales_damage
        self.crop_damage = crop_damage
        self.ippan_damage = ippan_damage
        
        self.kokyo_suikei_num = kokyo_suikei_num
        self.kokyo_kasen_num = kokyo_kasen_num
        self.kokyo_city_num = kokyo_city_num
        
        self.kasen_damage = kasen_damage
        self.kaigan_damage = kaigan_damage
        self.sabou_damage = sabou_damage
        self.landslide_damage = landslide_damage
        self.steepslope_damage = steepslope_damage
        self.road_damage = road_damage
        self.bridge_damage = bridge_damage
        self.sewer_damage = sewer_damage
        self.park_damage = park_damage
        self.kokyo_damage = kokyo_damage
        
        self.koeki_suikei_num = koeki_suikei_num
        self.koeki_kasen_num = koeki_kasen_num
        self.koeki_city_num = koeki_city_num
        
        self.transport_physical_damage = transport_physical_damage
        self.transport_sales_damage = transport_sales_damage
        self.transport_damage = transport_damage
        self.communicate_physical_damage = communicate_physical_damage
        self.communicate_sales_damage = communicate_sales_damage
        self.communicate_damage = communicate_damage
        self.electric_physical_damage = electric_physical_damage
        self.electric_sales_damage = electric_sales_damage
        self.electric_damage = electric_damage
        self.gas_physical_damage = gas_physical_damage
        self.gas_sales_damage = gas_sales_damage
        self.gas_damage = gas_damage
        self.water_physical_damage = water_physical_damage
        self.water_sales_damage = water_sales_damage
        self.water_damage = water_damage
        self.physical_damage = physical_damage
        self.sales_damage = sales_damage
        self.koeki_damage = koeki_damage
        
        self.ippan_chitan_hojo_koeki_damage

###############################################################################
### 帳票名：hyo_01水害被害一覧.xlsx
### 関数名：get_hyo01()
### hyo_01水害被害一覧.xlsx
###############################################################################
def get_hyo01():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo01()関数 STEP 1/3.', 'DEBUG')
        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        params = dict(zip(constants.setubi_keys + constants.business_keys, constants.setubi_values + constants.business_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo01()関数 STEP 2/3.', 'DEBUG')
        hyo01_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END, 
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END, 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END, 
                
                CASE WHEN (SUB01.death_num) IS NULL THEN 0.00 ELSE SUB01.death_num END+
                CASE WHEN (SUB01.missing_num) IS NULL THEN 0.00 ELSE SUB01.missing_num END+ 
                CASE WHEN (SUB01.wounded_num) IS NULL THEN 0.00 ELSE SUB01.wounded_num END 
                AS death_missing_wounded_num, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                
                CASE WHEN (IPPAN04.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN04.residential_underground_area END, 
                CASE WHEN (IPPAN05.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.agricultural_area END, 

                CASE WHEN (IPPAN04.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN04.residential_underground_area END+ 
                CASE WHEN (IPPAN05.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN05.agricultural_area END 
                AS residential_underground_agricultural_area, 
                
                CASE WHEN (IPPAN07.building_full_num) IS NULL THEN 0.00 ELSE IPPAN07.building_full_num END, 
                CASE WHEN (IPPAN08.building_half_num) IS NULL THEN 0.00 ELSE IPPAN08.building_half_num END, 
                CASE WHEN (IPPAN09.building_above_num) IS NULL THEN 0.00 ELSE IPPAN09.building_above_num END, 
                CASE WHEN (IPPAN10.building_under_num) IS NULL THEN 0.00 ELSE IPPAN10.building_under_num END, 

                CASE WHEN (IPPAN07.building_full_num) IS NULL THEN 0.00 ELSE IPPAN07.building_full_num END+ 
                CASE WHEN (IPPAN08.building_half_num) IS NULL THEN 0.00 ELSE IPPAN08.building_half_num END+ 
                CASE WHEN (IPPAN09.building_above_num) IS NULL THEN 0.00 ELSE IPPAN09.building_above_num END+ 
                CASE WHEN (IPPAN10.building_under_num) IS NULL THEN 0.00 ELSE IPPAN10.building_under_num END 
                AS building_full_half_above_under_num, 
                
                CASE WHEN (IPPAN12.family_full_num) IS NULL THEN 0.00 ELSE IPPAN12.family_full_num END, 
                CASE WHEN (IPPAN13.family_above_num) IS NULL THEN 0.00 ELSE IPPAN13.family_above_num END, 
                CASE WHEN (IPPAN14.family_under_num) IS NULL THEN 0.00 ELSE IPPAN14.family_under_num END, 
                CASE WHEN (IPPAN15.farmer_fisher_num) IS NULL THEN 0.00 ELSE IPPAN15.farmer_fisher_num END, 
                CASE WHEN (IPPAN16.office_num) IS NULL THEN 0.00 ELSE IPPAN16.office_num END, 
                CASE WHEN (IPPAN17.employee_num) IS NULL THEN 0.00 ELSE IPPAN17.employee_num END, 
                
                CASE WHEN (IPPAN18.house_damage) IS NULL THEN 0.00 ELSE IPPAN18.house_damage END, 
                CASE WHEN (IPPAN19.household_car_damage) IS NULL THEN 0.00 ELSE IPPAN19.household_car_damage END, 
                CASE WHEN (IPPAN20.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN20.farmer_fisher_damage END, 
                CASE WHEN (IPPAN21.office_dep_inv_damage) IS NULL THEN 0.00 ELSE IPPAN21.office_dep_inv_damage END, 
                CASE WHEN (IPPAN22.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN22.house_alt_clean_damage END, 
                CASE WHEN (IPPAN23.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN23.office_alt_damage END, 

                CASE WHEN (IPPAN18.house_damage) IS NULL THEN 0.00 ELSE IPPAN18.house_damage END+ 
                CASE WHEN (IPPAN19.household_car_damage) IS NULL THEN 0.00 ELSE IPPAN19.household_car_damage END+ 
                CASE WHEN (IPPAN20.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN20.farmer_fisher_damage END+ 
                CASE WHEN (IPPAN21.office_dep_inv_damage) IS NULL THEN 0.00 ELSE IPPAN21.office_dep_inv_damage END+ 
                CASE WHEN (IPPAN22.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN22.house_alt_clean_damage END+ 
                CASE WHEN (IPPAN23.office_alt_damage) IS NULL THEN 0.00 ELSE IPPAN23.office_alt_damage END 
                AS ippan_asset_damage, 

                CASE WHEN (IPPAN25.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN25.office_sales_damage END, 
                CASE WHEN (IPPAN26.crop_damage) IS NULL THEN 0.00 ELSE IPPAN26.crop_damage END, 

                CASE WHEN (IPPAN18.house_damage) IS NULL THEN 0.00 ELSE IPPAN18.house_damage END+ 
                CASE WHEN (IPPAN19.household_car_damage) IS NULL THEN 0.00 ELSE IPPAN19.household_car_damage END+ 
                CASE WHEN (IPPAN20.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN20.farmer_fisher_damage END+ 
                CASE WHEN (IPPAN21.office_dep_inv_damage) IS NULL THEN 0.00 ELSE IPPAN21.office_dep_inv_damage END+ 
                CASE WHEN (IPPAN22.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN22.house_alt_clean_damage END+ 
                CASE WHEN (IPPAN25.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN25.office_sales_damage END+ 
                CASE WHEN (IPPAN26.crop_damage) IS NULL THEN 0.00 ELSE IPPAN26.crop_damage END 
                AS ippan_damage, 
                
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                
                CASE WHEN (CHITAN01.kasen_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_damage END+ 
                CASE WHEN (HOJO01.kasen_determined_damage) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_damage END 
                AS kasen_damage, 
                
                CASE WHEN (CHITAN02.kaigan_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_estimated_damage END+ 
                CASE WHEN (HOJO02.kaigan_determined_damage) IS NULL THEN 0.00 ELSE HOJO02.kaigan_determined_damage END 
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN03.sabou_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_damage END+ 
                CASE WHEN (HOJO03.sabou_determined_damage) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_damage END 
                AS sabou_damage, 
                
                CASE WHEN (CHITAN04.landslide_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_damage END+ 
                CASE WHEN (HOJO04.landslide_determined_damage) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_damage END 
                AS landslide_damage, 
                
                CASE WHEN (CHITAN05.steepslope_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_damage END+ 
                CASE WHEN (HOJO05.steepslope_determined_damage) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_damage END 
                AS steepslope_damage, 
                
                CASE WHEN (CHITAN06.road_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_damage END+ 
                CASE WHEN (HOJO06.road_determined_damage) IS NULL THEN 0.00 ELSE HOJO06.road_determined_damage END 
                AS road_damage, 
                
                CASE WHEN (CHITAN07.bridge_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_damage END+ 
                CASE WHEN (HOJO07.bridge_determined_damage) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_damage END 
                AS bridge_damage, 
                
                CASE WHEN (CHITAN08.sewer_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_damage END+ 
                CASE WHEN (HOJO08.sewer_determined_damage) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_damage END 
                AS sewer_damage, 
                
                CASE WHEN (CHITAN09.park_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN09.park_estimated_damage END+ 
                CASE WHEN (HOJO09.park_determined_damage) IS NULL THEN 0.00 ELSE HOJO09.park_determined_damage END 
                AS park_damage, 
                
                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+ 
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END 
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                
                CASE WHEN (KOEKI04.transport_physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.transport_physical_damage END, 
                CASE WHEN (KOEKI05.transport_sales_damage) IS NULL THEN 0.00 ELSE KOEKI05.transport_sales_damage END, 
                CASE WHEN (KOEKI06.transport_damage) IS NULL THEN 0.00 ELSE KOEKI06.transport_damage END, 
                
                CASE WHEN (KOEKI07.communicate_physical_damage) IS NULL THEN 0.00 ELSE KOEKI07.communicate_physical_damage END, 
                CASE WHEN (KOEKI08.communicate_sales_damage) IS NULL THEN 0.00 ELSE KOEKI08.communicate_sales_damage END, 
                CASE WHEN (KOEKI09.communicate_damage) IS NULL THEN 0.00 ELSE KOEKI09.communicate_damage END, 
                
                CASE WHEN (KOEKI10.electric_physical_damage) IS NULL THEN 0.00 ELSE KOEKI10.electric_physical_damage END, 
                CASE WHEN (KOEKI11.electric_sales_damage) IS NULL THEN 0.00 ELSE KOEKI11.electric_sales_damage END, 
                CASE WHEN (KOEKI12.electric_damage) IS NULL THEN 0.00 ELSE KOEKI12.electric_damage END, 
                
                CASE WHEN (KOEKI13.gas_physical_damage) IS NULL THEN 0.00 ELSE KOEKI13.gas_physical_damage END, 
                CASE WHEN (KOEKI14.gas_sales_damage) IS NULL THEN 0.00 ELSE KOEKI14.gas_sales_damage END, 
                CASE WHEN (KOEKI15.gas_damage) IS NULL THEN 0.00 ELSE KOEKI15.gas_damage END, 
                
                CASE WHEN (KOEKI16.water_physical_damage) IS NULL THEN 0.00 ELSE KOEKI16.water_physical_damage END, 
                CASE WHEN (KOEKI17.water_sales_damage) IS NULL THEN 0.00 ELSE KOEKI17.water_sales_damage END, 
                CASE WHEN (KOEKI18.water_damage) IS NULL THEN 0.00 ELSE KOEKI18.water_damage END, 
                
                CASE WHEN (KOEKI19.physical_damage) IS NULL THEN 0.00 ELSE KOEKI19.physical_damage END, 
                CASE WHEN (KOEKI20.sales_damage) IS NULL THEN 0.00 ELSE KOEKI20.sales_damage END, 

                CASE WHEN (KOEKI19.physical_damage) IS NULL THEN 0.00 ELSE KOEKI19.physical_damage END+ 
                CASE WHEN (KOEKI20.sales_damage) IS NULL THEN 0.00 ELSE KOEKI20.sales_damage END 
                AS koeki_damage,  

                CASE WHEN (IPPAN18.house_damage) IS NULL THEN 0.00 ELSE IPPAN18.house_damage END+ 
                CASE WHEN (IPPAN19.household_car_damage) IS NULL THEN 0.00 ELSE IPPAN19.household_car_damage END+ 
                CASE WHEN (IPPAN20.farmer_fisher_damage) IS NULL THEN 0.00 ELSE IPPAN20.farmer_fisher_damage END+ 
                CASE WHEN (IPPAN21.office_dep_inv_damage) IS NULL THEN 0.00 ELSE IPPAN21.office_dep_inv_damage END+ 
                CASE WHEN (IPPAN22.house_alt_clean_damage) IS NULL THEN 0.00 ELSE IPPAN22.house_alt_clean_damage END+ 
                CASE WHEN (IPPAN25.office_sales_damage) IS NULL THEN 0.00 ELSE IPPAN25.office_sales_damage END+ 
                CASE WHEN (IPPAN26.crop_damage) IS NULL THEN 0.00 ELSE IPPAN26.crop_damage END+ 
                CASE WHEN (CHITAN10.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.estimated_damage END+ 
                CASE WHEN (HOJO10.determined_damage) IS NULL THEN 0.00 ELSE HOJO10.determined_damage END+ 
                CASE WHEN (KOEKI19.physical_damage) IS NULL THEN 0.00 ELSE KOEKI19.physical_damage END+ 
                CASE WHEN (KOEKI20.sales_damage) IS NULL THEN 0.00 ELSE KOEKI20.sales_damage END 
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 死傷者数 人
            (SELECT 
                11 AS death_num, 
                22 AS missing_num, 
                33 AS wounded_num, 
                11 + 22 + 33 AS death_missing_wounded_num 
            ) SUB01, 

            -- 一般資産等被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM IPPAN_SUMMARY_VIEW  
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) IPPAN01, 
            
            -- 一般資産等被害_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) IPPAN02, 
            
            -- 一般資産等被害_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) IPPAN03, 
            
            -- 一般資産等被害_水害区域面積_宅地・その他 ｈａ
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN04, 
            
            -- 一般資産等被害_水害区域面積_農地 ｈａ
            (SELECT 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN05, 
            
            -- 一般資産等被害_家屋被害_全壊・流失 棟
            (SELECT 
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN07, 
            
            -- 一般資産等被害_家屋被害_半壊 棟
            (SELECT 
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN08, 
            
            -- 一般資産等被害_家屋被害_床上浸水 棟
            (SELECT 
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_above_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN09, 
            
            -- 一般資産等被害_家屋被害_床下浸水 棟
            (SELECT 
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_under_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN10, 
            
            -- 一般資産等被害_被災世帯数等全壊・流失 世帯
            (SELECT 
                SUM(
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_full_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN12, 
            
            -- 一般資産等被害_被災世帯数等_床上浸水 世帯
            (SELECT 
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END) 
                AS family_above_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN13, 
            
            -- 一般資産等被害_被災世帯数等_床下浸水 世帯
            (SELECT 
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_under_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN14, 
            
            -- 一般資産等被害_被災世帯数等_農漁家数 戸
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN15, 
            
            -- 一般資産等被害_被災世帯数等_事業所数 事業所
            (SELECT 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN16, 
            
            -- 一般資産等被害_被災世帯数等_事業所従業者数 人
            (SELECT 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_num 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN17, 
            
            -- 一般資産等被害_被害額_家屋被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END) 
                AS house_damage 
            FROM IPPAN_SUMMARY 
            WHERE deleted_at IS NULL 
            ) IPPAN18, 
            
            -- 一般資産等被害_被害額_家庭用品被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END) 
                AS household_car_damage 
            FROM IPPAN_SUMMARY 
            WHERE deleted_at IS NULL 
            ) IPPAN19, 
            
            -- 一般資産等被害_被害額_農漁家資産被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END) 
                AS farmer_fisher_damage 
            FROM IPPAN_SUMMARY 
            WHERE deleted_at IS NULL 
            ) IPPAN20, 
            
            -- 一般資産等被害_被害額_事業所資産被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END) 
                AS office_dep_inv_damage 
            FROM IPPAN_SUMMARY 
            WHERE deleted_at IS NULL 
            ) IPPAN21, 
            
            -- 一般資産等被害_被害額_家庭応急対策費 百万円
            (SELECT 
                SUM(
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END) 
                AS house_alt_clean_damage 
            FROM IPPAN_SUMMARY 
            WHERE deleted_at IS NULL 
            ) IPPAN22, 
            
            -- 一般資産等被害_被害額_事業所応急対策費 百万円
            (SELECT 
                SUM(
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS office_alt_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN23, 
            
            -- 一般資産等被害_被害額_営業停止損失 百万円
            (SELECT 
                SUM(
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END) 
                AS office_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL
            ) IPPAN25, 
            
            -- 一般資産等被害_被害額_農作物被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN26, 

            -- 公共土木施設被害_水系・沿岸数 TODO TO-DO TO_DO 地方単独事業と補助事業の例えば水系数を重複を省いて合計するか、または重複を省かずに合計するか？
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (
            SELECT 
                weather_id, suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            UNION 
            SELECT 
                weather_id, suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公共土木施設被害_河川・海岸数 TODO TO-DO TO_DO 地方単独事業と補助事業の例えば水系数を重複を省いて合計するか、または重複を省かずに合計するか？
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (
            SELECT 
                weather_id, kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            UNION 
            SELECT 
                weather_id, kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公共土木施設被害_市区町村数 TODO TO-DO TO_DO 地方単独事業と補助事業の例えば水系数を重複を省いて合計するか、または重複を省かずに合計するか？
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (
            SELECT 
                weather_id, city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            UNION 
            SELECT 
                weather_id, city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 地方単独事業被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kasen_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) CHITAN01, 

            -- 地方単独事業被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS kaigan_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) CHITAN02, 

            -- 地方単独事業被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sabou_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) CHITAN03, 

            -- 地方単独事業被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS landslide_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) CHITAN04, 

            -- 地方単独事業被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS steepslope_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) CHITAN05, 

            -- 地方単独事業被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS road_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) CHITAN06, 

            -- 地方単独事業被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS bridge_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) CHITAN07, 

            -- 地方単独事業被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS sewer_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) CHITAN08, 

            -- 地方単独事業被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS park_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) CHITAN09, 

            -- 地方単独事業被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            ) CHITAN10, 

            -- 補助事業被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kasen_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) HOJO01, 

            -- 補助事業被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS kaigan_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) HOJO02, 

            -- 補助事業被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sabou_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) HOJO03, 

            -- 補助事業被害額_地すべり 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS landslide_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) HOJO04, 

            -- 補助事業被害額_急傾斜地 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS steepslope_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) HOJO05, 

            -- 補助事業被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS road_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) HOJO06, 

            -- 補助事業被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS bridge_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) HOJO07, 

            -- 補助事業被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS sewer_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) HOJO08, 

            -- 補助事業被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS park_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) HOJO09, 

            -- 補助事業被害額_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KASEN)s,%(KAIGAN)s,%(SABOU)s,%(LANDSLIDE)s,%(STEEPSLOPE)s,%(ROAD)s,%(BRIDGE)s,%(PORT)s,%(SEWER)s,%(PARK)s,%(FACILITY)s) 
            ) HOJO10, 

            -- 公益事業等被害_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                weather_id, suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, suikei_code 
            ) SUB00 
            ) KOEKI01, 

            -- 公益事業等被害_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                weather_id, kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, kasen_code 
            ) SUB00 
            ) KOEKI02, 

            -- 公益事業等被害_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                weather_id, city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            GROUP BY weather_id, city_code 
            ) SUB00 
            ) KOEKI03, 

            -- 公益事業等被害_運輸_物的被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS transport_physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(RAIL_CARGO)s,%(ROAD_PASSENGER)s,%(ROAD_CARGO)s,%(SEA_PASSENGER)s,%(SEA_CARGO)s,%(AIR_PASSENGER)s,%(AIR_CARGO)s) 
            ) KOEKI04, 

            -- 公益事業等被害_運輸_営業停止損失 百万円
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS transport_sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(RAIL_CARGO)s,%(ROAD_PASSENGER)s,%(ROAD_CARGO)s,%(SEA_PASSENGER)s,%(SEA_CARGO)s,%(AIR_PASSENGER)s,%(AIR_CARGO)s) 
            ) KOEKI05, 

            -- 公益事業等被害_運輸_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS transport_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(RAIL_CARGO)s,%(ROAD_PASSENGER)s,%(ROAD_CARGO)s,%(SEA_PASSENGER)s,%(SEA_CARGO)s,%(AIR_PASSENGER)s,%(AIR_CARGO)s) 
            ) KOEKI06, 

            -- 公益事業等被害_通信_物的被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS communicate_physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(COMMUNICATE)s 
            ) KOEKI07, 

            -- 公益事業等被害_通信_営業停止損失 百万円
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS communicate_sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(COMMUNICATE)s 
            ) KOEKI08, 

            -- 公益事業等被害_通信_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS communicate_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(COMMUNICATE)s 
            ) KOEKI09, 

            -- 公益事業等被害_電力_物的被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS electric_physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(ELECTRIC)s 
            ) KOEKI10, 

            -- 公益事業等被害_電力_営業停止損失 百万円
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS electric_sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(ELECTRIC)s 
            ) KOEKI11, 

            -- 公益事業等被害_電力_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS electric_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(ELECTRIC)s 
            ) KOEKI12, 

            -- 公益事業等被害_ガス_物的被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS gas_physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(GAS)s 
            ) KOEKI13, 

            -- 公益事業等被害_ガス_営業停止損失 百万円
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS gas_sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(GAS)s 
            ) KOEKI14, 

            -- 公益事業等被害_ガス_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS gas_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(GAS)s 
            ) KOEKI15, 

            -- 公益事業等被害_水道_物的被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS water_physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(WATER)s 
            ) KOEKI16, 

            -- 公益事業等被害_水道_営業停止損失 百万円
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS water_sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(WATER)s 
            ) KOEKI17, 

            -- 公益事業等被害_水道_合計 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS water_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code=%(WATER)s 
            ) KOEKI18, 

            -- 公益事業等被害_物的被害額 百万円
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END) 
                AS physical_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(RAIL_CARGO)s,%(ROAD_PASSENGER)s,%(ROAD_CARGO)s,%(COMMUNICATE)s,%(ELECTRIC)s,%(GAS)s,%(WATER)s,%(SEA_PASSENGER)s,%(SEA_CARGO)s,%(AIR_PASSENGER)s,%(AIR_CARGO)s) 
            ) KOEKI19, 

            -- 公益事業等被害_営業停止損失 百万円
            (SELECT 
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS sales_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND business_code IN (%(RAIL_PASSENGER)s,%(RAIL_CARGO)s,%(ROAD_PASSENGER)s,%(ROAD_CARGO)s,%(COMMUNICATE)s,%(ELECTRIC)s,%(GAS)s,%(WATER)s,%(SEA_PASSENGER)s,%(SEA_CARGO)s,%(AIR_PASSENGER)s,%(AIR_CARGO)s) 
            ) KOEKI20 

            """, params)
                
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo01()関数 STEP 3/3.', 'DEBUG')
        return True, hyo01_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo01()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo01()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo01()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_01水害被害一覧.xlsx
### 関数名：hyo01_view(request)
### urlpattern：path('hyo01/', hyo01_views.hyo01_view, name='hyo01_view'),
###############################################################################
### @login_required(None, login_url='/P0100Login/')
### def hyo01_view(request):
###     try:
###         #######################################################################
###         ### 引数チェック処理(0000)
###         ### ブラウザからのリクエストと引数をチェックする。
###         #######################################################################
###         reset_log()
###         print_log('[INFO] P0700EStat.hyo01_view()関数が開始しました。', 'INFO')
###         print_log('[DEBUG] P0700EStat.hyo01_view()関数 request={}'.format(request.method), 'DEBUG')
###         print_log('[DEBUG] P0700EStat.hyo01_view()関数 STEP 1/4.', 'DEBUG')
###         #######################################################################
###         ### DBアクセス処理(0010)
###         ### DBにアクセスして、データを取得する。
###         #######################################################################
###         print_log('[DEBUG] P0700EStat.hyo01_view()関数 STEP 2/4.', 'DEBUG')
###         bool_return, hyo01_list = get_hyo01()
###         if bool_return == False:
###             raise Exception
###         #######################################################################
###         ### 計算処理(0020)
###         ### 計算して局所変数に値をセットする。
###         #######################################################################
###         print_log('[DEBUG] P0700EStat.hyo01_view()関数 STEP 3/4.', 'DEBUG')
###         for i, hyo01 in enumerate(hyo01_list):
###             print('hyo01.death_num={}'.format(hyo01.death_num), flush=True)
###         #######################################################################
###         ### レスポンスセット処理(0030)
###         ### コンテキストを設定して、レスポンスをブラウザに戻す。
###         #######################################################################
###         print_log('[DEBUG] P0700EStat.hyo01_view()関数 STEP 4/4.', 'DEBUG')
###         template = loader.get_template('P0700EStat/index.html')
###         context = {
###             'cat_code': 'hyo01', 
###             'hyo01_list': hyo01_list, 
###         }
###         print_log('[INFO] P0700EStat.hyo01_view()関数が正常終了しました。', 'INFO')
###         return HttpResponse(template.render(context, request))
###     except:
###         print_log('[ERROR] P0700EStat.hyo01_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
###         print_log('[ERROR] P0700EStat.hyo01_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
###         print_log('[ERROR] P0700EStat.hyo01_view()関数が異常終了しました。', 'ERROR')
###         template = loader.get_template('P0700EStat/index.html')
###         context = {
###             'alert_log': get_alert_log(), 
###         }
###         return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_01水害被害一覧.xlsx
### 関数名：hyo01_download_view(request)
### urlpattern：path('download/hyo01/', hyo01_views.hyo01_download_view, name='hyo01_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo01_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo01_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo01_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo01_download_view()関数 STEP 1/5.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo01_download_view()関数 STEP 2/5.', 'DEBUG')
        bool_return, hyo01_list = get_hyo01()
        if bool_return == False:
            raise Exception
        
        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo01_download_view()関数 STEP 3/5.', 'DEBUG')
        for i, hyo01 in enumerate(hyo01_list):
            print('hyo01.death_num={}'.format(hyo01.death_num), flush=True)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo01_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo01.xlsx'
        ### download_file_path = 'static/download_hyo01.xlsx'
        template_file_path = 'static/template/template_hyo01.xlsx'
        download_file_path = 'static/tmp/download_hyo01.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo01'
        
        ws.cell(row=1, column=1).value = '１．全国の被害'
        ws.cell(row=3, column=1).value = '表－１　平成１７年水害被害一覧'
        ws.cell(row=5, column=1).value = '事項'
        ws.cell(row=5, column=5).value = '単位'
        ws.cell(row=5, column=6).value = '被害'
        ws.cell(row=5, column=7).value = '事項'
        ws.cell(row=5, column=11).value = '単位'
        ws.cell(row=5, column=12).value = '被害'
        ws.cell(row=6, column=1).value = '死傷者数'
        ws.cell(row=6, column=2).value = '死　　者'
        ws.cell(row=6, column=5).value = '人'
        ws.cell(row=6, column=6).value = ''
        ws.cell(row=6, column=7).value = '公共土木施設被害'
        ws.cell(row=6, column=8).value = '水系・沿岸数'
        ws.cell(row=6, column=11).value = ''
        ws.cell(row=6, column=12).value = ''
        ws.cell(row=7, column=2).value = '行方不明'
        ws.cell(row=7, column=5).value = '人'
        ws.cell(row=7, column=6).value = ''
        ws.cell(row=7, column=8).value = '河川・海岸数'
        ws.cell(row=7, column=11).value = ''
        ws.cell(row=7, column=12).value = ''
        ws.cell(row=8, column=2).value = '負 傷 者'
        ws.cell(row=8, column=5).value = '人'
        ws.cell(row=8, column=6).value = ''
        ws.cell(row=8, column=8).value = '市区町村数'
        ws.cell(row=8, column=11).value = ''
        ws.cell(row=8, column=12).value = ''
        ws.cell(row=9, column=2).value = '計'
        ws.cell(row=9, column=5).value = '人'
        ws.cell(row=9, column=6).value = ''
        ws.cell(row=9, column=8).value = '被害額'
        ws.cell(row=9, column=9).value = '河川'
        ws.cell(row=9, column=11).value = '百万円'
        ws.cell(row=9, column=12).value = ''
        ws.cell(row=10, column=2).value = '水系・沿岸数'
        ws.cell(row=10, column=5).value = ''
        ws.cell(row=10, column=6).value = ''
        ws.cell(row=10, column=9).value = '海岸・港湾'
        ws.cell(row=10, column=11).value = '百万円'
        ws.cell(row=10, column=12).value = ''
        ws.cell(row=11, column=2).value = '河川・海岸数'
        ws.cell(row=11, column=5).value = ''
        ws.cell(row=11, column=6).value = ''
        ws.cell(row=11, column=9).value = '砂防設備'
        ws.cell(row=11, column=11).value = '百万円'
        ws.cell(row=11, column=12).value = ''
        ws.cell(row=12, column=2).value = '市区町村数'
        ws.cell(row=12, column=5).value = ''
        ws.cell(row=12, column=6).value = ''
        ws.cell(row=12, column=9).value = '地すべり防止施設'
        ws.cell(row=12, column=11).value = '百万円'
        ws.cell(row=12, column=12).value = ''
        ws.cell(row=13, column=2).value = '水害区域面積'
        ws.cell(row=13, column=3).value = '宅地・その他'
        ws.cell(row=13, column=5).value = 'ｈａ'
        ws.cell(row=13, column=6).value = ''
        ws.cell(row=13, column=9).value = '急傾斜地崩壊防止施設'
        ws.cell(row=13, column=11).value = '百万円'
        ws.cell(row=13, column=12).value = ''
        ws.cell(row=14, column=3).value = '農地'
        ws.cell(row=14, column=5).value = 'ｈａ'
        ws.cell(row=14, column=6).value = ''
        ws.cell(row=14, column=9).value = '道路'
        ws.cell(row=14, column=11).value = '百万円'
        ws.cell(row=14, column=12).value = ''
        ws.cell(row=15, column=3).value = '計'
        ws.cell(row=15, column=5).value = 'ｈａ'
        ws.cell(row=15, column=6).value = ''
        ws.cell(row=15, column=9).value = '橋梁'
        ws.cell(row=15, column=11).value = '百万円'
        ws.cell(row=15, column=12).value = ''
        ws.cell(row=16, column=2).value = '家屋被害'
        ws.cell(row=16, column=3).value = '全壊・流出'
        ws.cell(row=16, column=5).value = '棟'
        ws.cell(row=16, column=6).value = ''
        ws.cell(row=16, column=9).value = '下水道'
        ws.cell(row=16, column=11).value = '百万円'
        ws.cell(row=16, column=12).value = ''
        ws.cell(row=17, column=3).value = '半壊'
        ws.cell(row=17, column=5).value = '棟'
        ws.cell(row=17, column=6).value = ''
        ws.cell(row=17, column=9).value = '公園・都市施設'
        ws.cell(row=17, column=11).value = '百万円'
        ws.cell(row=17, column=12).value = ''
        ws.cell(row=18, column=3).value = '床上浸水'
        ws.cell(row=18, column=5).value = '棟'
        ws.cell(row=18, column=6).value = ''
        ws.cell(row=18, column=9).value = '計'
        ws.cell(row=18, column=11).value = '百万円'
        ws.cell(row=18, column=12).value = ''
        ws.cell(row=19, column=3).value = '床下浸水'
        ws.cell(row=19, column=5).value = '棟'
        ws.cell(row=19, column=6).value = ''
        ws.cell(row=19, column=7).value = '公益事業等被害'
        ws.cell(row=19, column=8).value = '水系・沿岸数'
        ws.cell(row=19, column=11).value = ''
        ws.cell(row=19, column=12).value = ''
        ws.cell(row=20, column=3).value = '計'
        ws.cell(row=20, column=5).value = '棟'
        ws.cell(row=20, column=6).value = ''
        ws.cell(row=20, column=8).value = '河川・海岸数'
        ws.cell(row=20, column=11).value = ''
        ws.cell(row=20, column=12).value = ''
        ws.cell(row=21, column=2).value = '被災世帯数等'
        ws.cell(row=21, column=3).value = '全壊・流出'
        ws.cell(row=21, column=5).value = '世帯'
        ws.cell(row=21, column=6).value = ''
        ws.cell(row=21, column=8).value = '市区町村数'
        ws.cell(row=21, column=11).value = ''
        ws.cell(row=21, column=12).value = ''
        ws.cell(row=22, column=3).value = '－'
        ws.cell(row=22, column=5).value = '－'
        ws.cell(row=22, column=6).value = '－'
        ws.cell(row=22, column=8).value = '被害額'
        ws.cell(row=22, column=9).value = ''
        ws.cell(row=22, column=10).value = '物的被害額'
        ws.cell(row=22, column=11).value = '百万円'
        ws.cell(row=22, column=12).value = ''
        ws.cell(row=23, column=3).value = '床上浸水'
        ws.cell(row=23, column=5).value = '世帯'
        ws.cell(row=23, column=6).value = ''
        ws.cell(row=23, column=9).value = '運輸'
        ws.cell(row=23, column=10).value = '営業停止損失'
        ws.cell(row=23, column=11).value = '百万円'
        ws.cell(row=23, column=12).value = ''
        ws.cell(row=24, column=3).value = '床下浸水'
        ws.cell(row=24, column=5).value = '世帯'
        ws.cell(row=24, column=6).value = ''
        ws.cell(row=24, column=9).value = ''
        ws.cell(row=24, column=10).value = '計'
        ws.cell(row=24, column=11).value = '百万円'
        ws.cell(row=24, column=12).value = ''
        ws.cell(row=25, column=3).value = '農漁家数'
        ws.cell(row=25, column=5).value = '戸'
        ws.cell(row=25, column=6).value = ''
        ws.cell(row=25, column=9).value = ''
        ws.cell(row=25, column=10).value = '物的被害額'
        ws.cell(row=25, column=11).value = '百万円'
        ws.cell(row=25, column=12).value = ''
        ws.cell(row=26, column=3).value = '事業所数'
        ws.cell(row=26, column=5).value = '事業所'
        ws.cell(row=26, column=6).value = ''
        ws.cell(row=26, column=9).value = '通信'
        ws.cell(row=26, column=10).value = '営業停止損失'
        ws.cell(row=26, column=11).value = '百万円'
        ws.cell(row=26, column=12).value = ''
        ws.cell(row=27, column=3).value = '事業所従業者数'
        ws.cell(row=27, column=5).value = '人'
        ws.cell(row=27, column=6).value = ''
        ws.cell(row=27, column=9).value = ''
        ws.cell(row=27, column=10).value = '計'
        ws.cell(row=27, column=11).value = '百万円'
        ws.cell(row=27, column=12).value = ''
        ws.cell(row=28, column=2).value = '被害額'
        ws.cell(row=28, column=3).value = '一般資産'
        ws.cell(row=28, column=4).value = '家屋'
        ws.cell(row=28, column=5).value = '百万円'
        ws.cell(row=28, column=6).value = ''
        ws.cell(row=28, column=9).value = ''
        ws.cell(row=28, column=10).value = '物的被害額'
        ws.cell(row=28, column=11).value = '百万円'
        ws.cell(row=28, column=12).value = ''
        ws.cell(row=29, column=4).value = '家庭用品'
        ws.cell(row=29, column=5).value = '百万円'
        ws.cell(row=29, column=6).value = ''
        ws.cell(row=29, column=9).value = '電力'
        ws.cell(row=29, column=10).value = '営業停止損失'
        ws.cell(row=29, column=11).value = '百万円'
        ws.cell(row=29, column=12).value = ''
        ws.cell(row=30, column=4).value = '農漁家資産'
        ws.cell(row=30, column=5).value = '百万円'
        ws.cell(row=30, column=6).value = ''
        ws.cell(row=30, column=9).value = ''
        ws.cell(row=30, column=10).value = '計'
        ws.cell(row=30, column=11).value = '百万円'
        ws.cell(row=30, column=12).value = ''
        ws.cell(row=31, column=4).value = '事業所資産'
        ws.cell(row=31, column=5).value = '百万円'
        ws.cell(row=31, column=6).value = ''
        ws.cell(row=31, column=9).value = ''
        ws.cell(row=31, column=10).value = '物的被害額'
        ws.cell(row=31, column=11).value = '百万円'
        ws.cell(row=31, column=12).value = ''
        ws.cell(row=32, column=4).value = '家庭応急対策費'
        ws.cell(row=32, column=5).value = '百万円'
        ws.cell(row=32, column=6).value = ''
        ws.cell(row=32, column=9).value = 'ガス'
        ws.cell(row=32, column=10).value = '営業停止損失'
        ws.cell(row=32, column=11).value = '百万円'
        ws.cell(row=32, column=12).value = ''
        ws.cell(row=33, column=9).value = ''
        ws.cell(row=33, column=10).value = '計'
        ws.cell(row=33, column=11).value = '百万円'
        ws.cell(row=33, column=12).value = ''
        ws.cell(row=34, column=4).value = '事業所応急対策費'
        ws.cell(row=34, column=5).value = '百万円'
        ws.cell(row=34, column=6).value = ''
        ws.cell(row=34, column=9).value = ''
        ws.cell(row=34, column=10).value = '物的被害額'
        ws.cell(row=34, column=11).value = '百万円'
        ws.cell(row=34, column=12).value = ''
        ws.cell(row=35, column=9).value = '水道'
        ws.cell(row=35, column=10).value = '営業停止損失'
        ws.cell(row=35, column=11).value = '百万円'
        ws.cell(row=35, column=12).value = ''
        ws.cell(row=36, column=4).value = '計'
        ws.cell(row=36, column=5).value = '百万円'
        ws.cell(row=36, column=6).value = ''
        ws.cell(row=36, column=9).value = ''
        ws.cell(row=36, column=10).value = '計'
        ws.cell(row=36, column=11).value = '百万円'
        ws.cell(row=36, column=12).value = ''
        ws.cell(row=37, column=3).value = '営業停止損失'
        ws.cell(row=37, column=5).value = '百万円'
        ws.cell(row=37, column=6).value = ''
        ws.cell(row=37, column=9).value = ''
        ws.cell(row=37, column=10).value = '物的被害額'
        ws.cell(row=37, column=11).value = '百万円'
        ws.cell(row=37, column=12).value = ''
        ws.cell(row=38, column=3).value = '農作物'
        ws.cell(row=38, column=5).value = '百万円'
        ws.cell(row=38, column=6).value = ''
        ws.cell(row=38, column=9).value = '計'
        ws.cell(row=38, column=10).value = '営業停止損失'
        ws.cell(row=38, column=11).value = '百万円'
        ws.cell(row=38, column=12).value = ''
        ws.cell(row=39, column=3).value = '計'
        ws.cell(row=39, column=5).value = '百万円'
        ws.cell(row=39, column=6).value = ''
        ws.cell(row=39, column=9).value = ''
        ws.cell(row=39, column=10).value = '計'
        ws.cell(row=39, column=11).value = '百万円'
        ws.cell(row=39, column=12).value = ''
        ws.cell(row=40, column=1).value = '被害額合計'
        ws.cell(row=40, column=11).value = '百万円'
        ws.cell(row=40, column=12).value = ''
        ws.cell(row=41, column=1).value = '（注１）死傷者数は、消防庁資料による。'
        ws.cell(row=42, column=1).value = '（注２）水系・沿岸数、河川・海岸数、市区町村数については延べ数である。'
        ws.cell(row=43, column=1).value = '（注３）被害額については表示単位未満を四捨五入しているため、内訳の合計数値と計は一致しない場合がある。'
        
        for i, hyo01 in enumerate(hyo01_list):
            ### 死傷者数
            ws.cell(row=6, column=6).value = hyo01.death_num
            ws.cell(row=7, column=6).value = hyo01.missing_num
            ws.cell(row=8, column=6).value = hyo01.wounded_num
            ws.cell(row=9, column=6).value = hyo01.death_missing_wounded_num
            
            ### 一般資産等被害
            ws.cell(row=10, column=6).value = hyo01.ippan_suikei_num
            ws.cell(row=11, column=6).value = hyo01.ippan_kasen_num
            ws.cell(row=12, column=6).value = hyo01.ippan_city_num
            
            ### 一般資産等被害_水害区域面積
            ws.cell(row=13, column=6).value = hyo01.residential_underground_area
            ws.cell(row=14, column=6).value = hyo01.agricultural_area
            ws.cell(row=15, column=6).value = hyo01.residential_underground_agricultural_area
            
            ### 一般資産等被害_家屋被害
            ws.cell(row=16, column=6).value = hyo01.building_full_num
            ws.cell(row=17, column=6).value = hyo01.building_half_num
            ws.cell(row=18, column=6).value = hyo01.building_above_num
            ws.cell(row=19, column=6).value = hyo01.building_under_num
            ws.cell(row=20, column=6).value = hyo01.building_full_half_above_under_num
            
            ### 一般資産等被害_被災世帯数等
            ws.cell(row=21, column=6).value = hyo01.family_full_num
            ws.cell(row=22, column=6).value = '－'
            ws.cell(row=23, column=6).value = hyo01.family_above_num
            ws.cell(row=24, column=6).value = hyo01.family_under_num
            ws.cell(row=25, column=6).value = hyo01.farmer_fisher_num
            ws.cell(row=26, column=6).value = hyo01.office_num
            ws.cell(row=27, column=6).value = hyo01.employee_num
            
            ### 一般資産等被害_被害額_一般資産
            ws.cell(row=28, column=6).value = hyo01.house_damage
            ws.cell(row=29, column=6).value = hyo01.household_car_damage
            ws.cell(row=30, column=6).value = hyo01.farmer_fisher_damage
            ws.cell(row=31, column=6).value = hyo01.office_dep_inv_damage
            ws.cell(row=32, column=6).value = hyo01.house_alt_clean_damage
            ws.cell(row=34, column=6).value = hyo01.office_alt_damage
            ws.cell(row=36, column=6).value = hyo01.ippan_asset_damage
            
            ### 一般資産等被害_被害額
            ws.cell(row=37, column=6).value = hyo01.office_sales_damage
            ws.cell(row=38, column=6).value = hyo01.crop_damage
            ws.cell(row=39, column=6).value = hyo01.ippan_damage
            
            ### 公共土木施設被害
            ws.cell(row=6, column=12).value = hyo01.kokyo_suikei_num
            ws.cell(row=7, column=12).value = hyo01.kokyo_kasen_num
            ws.cell(row=8, column=12).value = hyo01.kokyo_city_num
            
            ### 公共土木施設被害_被害額
            ws.cell(row=9, column=12).value = hyo01.kasen_damage
            ws.cell(row=10, column=12).value = hyo01.kaigan_damage
            ws.cell(row=11, column=12).value = hyo01.sabou_damage
            ws.cell(row=12, column=12).value = hyo01.landslide_damage
            ws.cell(row=13, column=12).value = hyo01.steepslope_damage
            ws.cell(row=14, column=12).value = hyo01.road_damage
            ws.cell(row=15, column=12).value = hyo01.bridge_damage
            ws.cell(row=16, column=12).value = hyo01.sewer_damage
            ws.cell(row=17, column=12).value = hyo01.park_damage
            ws.cell(row=18, column=12).value = hyo01.kokyo_damage
            
            ### 公益事業等被害
            ws.cell(row=19, column=12).value = hyo01.koeki_suikei_num
            ws.cell(row=20, column=12).value = hyo01.koeki_kasen_num
            ws.cell(row=21, column=12).value = hyo01.koeki_city_num
            
            ### 公益事業等被害_被害額_運輸
            ws.cell(row=22, column=12).value = hyo01.transport_physical_damage
            ws.cell(row=23, column=12).value = hyo01.transport_sales_damage
            ws.cell(row=24, column=12).value = hyo01.transport_damage
            
            ### 公益事業等被害_被害額_通信
            ws.cell(row=25, column=12).value = hyo01.communicate_physical_damage
            ws.cell(row=26, column=12).value = hyo01.communicate_sales_damage
            ws.cell(row=27, column=12).value = hyo01.communicate_damage
            
            ### 公益事業等被害_被害額_電力
            ws.cell(row=28, column=12).value = hyo01.electric_physical_damage
            ws.cell(row=29, column=12).value = hyo01.electric_sales_damage
            ws.cell(row=30, column=12).value = hyo01.electric_damage
            
            ### 公益事業等被害_被害額_ガス
            ws.cell(row=31, column=12).value = hyo01.gas_physical_damage
            ws.cell(row=32, column=12).value = hyo01.gas_sales_damage
            ws.cell(row=33, column=12).value = hyo01.gas_damage
            
            ### 公益事業等被害_被害額_水道
            ws.cell(row=34, column=12).value = hyo01.water_physical_damage
            ws.cell(row=35, column=12).value = hyo01.water_sales_damage
            ws.cell(row=36, column=12).value = hyo01.water_damage
            
            ### 公益事業等被害_被害額_計
            ws.cell(row=37, column=12).value = hyo01.physical_damage
            ws.cell(row=38, column=12).value = hyo01.sales_damage
            ws.cell(row=39, column=12).value = hyo01.koeki_damage
            
            ### 被害額合計
            ws.cell(row=40, column=12).value = hyo01.ippan_chitan_hojo_koeki_damage
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo01_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo01_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo01.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo01_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo01_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo01_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
