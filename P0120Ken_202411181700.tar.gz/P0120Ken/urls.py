from django.urls import path
from . import views

app_name = 'P0120Ken'
urlpatterns = [
    path('', views.index_view, name='index_view'),                                                                        ### /P0120Ken/ => /P0120Ken/bucket/ リダイレクト用
    path('bucket/', views.bucket_view, name='bucket_view'),                                                               ### 都道府県用バケット Add 2023/01/27
    path('browser/', views.browser_view, name='browser_view'),                                                            ### 都道府県用オブジェクトブラウザ都アップロードファイル Add 2023/01/27
    path('browser/city/<slug:city_code>/', views.browser_city_code_view, name='browser_city_code_view'),                  ### 都道府県用オブジェクトブラウザ市アップロードファイル Add 2023/01/27

    path('slide/ippan/header/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view'),
    path('slide/chitan/header/<slug:header_id>/', views.slide_chitan_header_id_view, name='slide_chitan_header_id_view'),
    path('slide/hojo/header/<slug:header_id>/', views.slide_hojo_header_id_view, name='slide_hojo_header_id_view'),
    path('slide/koeki/header/<slug:header_id>/', views.slide_koeki_header_id_view, name='slide_koeki_header_id_view'),

    path('apply/chitan/header/<slug:header_id>/', views.apply_chitan_header_id_view, name='apply_chitan_header_id_view'),
    path('apply/hojo/header/<slug:header_id>/', views.apply_hojo_header_id_view, name='apply_hojo_header_id_view'),
    path('apply/koeki/header/<slug:header_id>/', views.apply_koeki_header_id_view, name='apply_koeki_header_id_view'),

    path('linkage/ippan/header/<slug:header_id>/weather/<slug:weather_id>/', views.linkage_ippan_header_id_weather_id_view, name='linkage_ippan_header_id_weather_id_view'), 
    path('approve/ippan/header/<slug:header_id>/', views.approve_ippan_header_id_view, name='approve_ippan_header_id_view'),
    path('disapprove/ippan/header/<slug:header_id>/', views.disapprove_ippan_header_id_view, name='disapprove_ippan_header_id_view'),

    path('delete/chitan/header/<slug:header_id>/', views.delete_chitan_header_id_view, name='delete_chitan_header_id_view'),
    path('delete/hojo/header/<slug:header_id>/', views.delete_hojo_header_id_view, name='delete_hojo_header_id_view'),
    path('delete/koeki/header/<slug:header_id>/', views.delete_koeki_header_id_view, name='delete_koeki_header_id_view'),

    path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view'), 
    path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view'), 
    path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view'), 
    path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view'), 
    path('download/chitan/chosa/excel/header/<slug:header_id>/', views.download_chitan_chosa_excel_header_id_view, name='download_chitan_chosa_excel_header_id_view'), 
    path('download/chitan/chosa/csv/header/<slug:header_id>/', views.download_chitan_chosa_csv_header_id_view, name='download_chitan_chosa_csv_header_id_view'), 
    path('download/chitan/summary/excel/header/<slug:header_id>/', views.download_chitan_summary_excel_header_id_view, name='download_chitan_summary_excel_header_id_view'), 
    path('download/chitan/summary/csv/header/<slug:header_id>/', views.download_chitan_summary_csv_header_id_view, name='download_chitan_summary_csv_header_id_view'), 
    path('download/hojo/chosa/excel/header/<slug:header_id>/', views.download_hojo_chosa_excel_header_id_view, name='download_hojo_chosa_excel_header_id_view'), 
    path('download/hojo/chosa/csv/header/<slug:header_id>/', views.download_hojo_chosa_csv_header_id_view, name='download_hojo_chosa_csv_header_id_view'), 
    path('download/hojo/summary/excel/header/<slug:header_id>/', views.download_hojo_summary_excel_header_id_view, name='download_hojo_summary_excel_header_id_view'), 
    path('download/hojo/summary/csv/header/<slug:header_id>/', views.download_hojo_summary_csv_header_id_view, name='download_hojo_summary_csv_header_id_view'), 
    path('download/koeki/chosa/excel/header/<slug:header_id>/', views.download_koeki_chosa_excel_header_id_view, name='download_koeki_chosa_excel_header_id_view'), 
    path('download/koeki/chosa/csv/header/<slug:header_id>/', views.download_koeki_chosa_csv_header_id_view, name='download_koeki_chosa_csv_header_id_view'), 
    path('download/koeki/summary/excel/header/<slug:header_id>/', views.download_koeki_summary_excel_header_id_view, name='download_koeki_summary_excel_header_id_view'), 
    path('download/koeki/summary/csv/header/<slug:header_id>/', views.download_koeki_summary_csv_header_id_view, name='download_koeki_summary_csv_header_id_view'), 
]
