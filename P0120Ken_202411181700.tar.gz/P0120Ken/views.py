###############################################################################
### ファイル名：P0120Ken/views.py
### 都道府県用ファイル管理
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### def add_comment(ws, ws_result, row, column, fill, message_id, message)
### def custom_decorator(arg1)
### def browser_get(request)
### def browser_post_chitan(request)
### def browser_post_hojo(request)
### def browser_post_koeki(request)
### 
### ビュー関数：ブラウザから呼ばれる関数
### def index_view(request)
### def bucket_view(request)
### def browser_view(request)
### def browser_city_code_view(request, city_code)
### 
### def slide_ippan_header_id_view(request, header_id)
### def slide_chitan_header_id_view(request, header_id)
### def slide_hojo_header_id_view(request, header_id)
### def slide_koeki_header_id_view(request, header_id)
### 
### def apply_chitan_header_id_view(request, header_id)
### def apply_hojo_header_id_view(request, header_id)
### def apply_koeki_header_id_view(request, header_id)
### def linkage_ippan_header_id_weather_id_view(request, header_id, weather_id)
### def approve_ippan_header_id_view(request, header_id)
### def disapprove_ippan_header_id_view(request, header_id) ### ADD 2024/09/15 O.OKADA
### 
### def delete_chitan_header_id_view(request, header_id)
### def delete_hojo_header_id_view(request, header_id)
### def delete_koeki_header_id_view(request, header_id)
### 
### def download_ippan_chosa_excel_header_id_view(request, header_id)
### def download_ippan_chosa_csv_header_id_view(request, header_id)
### def download_ippan_summary_excel_header_id_view(request, header_id)
### def download_ippan_summary_csv_header_id_view(request, header_id)
### def download_chitan_chosa_excel_header_id_view(request, header_id)
### def download_chitan_chosa_csv_header_id_view(request, header_id)
### def download_chitan_summary_excel_header_id_view(request, header_id)
### def download_chitan_summary_csv_header_id_view(request, header_id)
### def download_hojo_chosa_excel_header_id_view(request, header_id)
### def download_hojo_chosa_csv_header_id_view(request, header_id)
### def download_hojo_summary_excel_header_id_view(request, header_id)
### def download_hojo_summary_csv_header_id_view(request, header_id)
### def download_koeki_chosa_excel_header_id_view(request, header_id)
### def download_koeki_chosa_csv_header_id_view(request, header_id)
### def download_koeki_summary_excel_header_id_view(request, header_id)
### def download_koeki_summary_csv_header_id_view(request, header_id)
### 更新履歴：
### 2024/07/25 custom_decorator 追加 requestをチェックしてUSER_PROXYからcity_codeを取得する処理を共通化した。
### 2024/09/06 PARAM、SQL文をEXECUTEと別にセットして、EXECUTE周辺のコードを読みやすくした。
### 2024/09/06 水害区域図DB版との統合のため、AREAをKUIKIに変更した。
### 2024/10/13 画面制御用コード（暫定値、確報値）に対応した。
### 2024/11/05 水害区域図DB化をDB化対象外とするように修正した。
###############################################################################

import json
import os
import sys

from datetime import date, datetime
from datetime import timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound
from django.http.response import JsonResponse
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView
from django.views.decorators.csrf import csrf_exempt

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ
from P0000Common.models import PROVISIONED_CONFIRMED   ### 0000: 画面制御用コード（暫定値、確報値）

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

### from P0000Common.models import KUIKI               ### 7000: アップロードデータ_水害区域 ### 2024/11/06 comment out
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ
### from P0000Common.models import KUIKI_TRIGGER       ### 10060: キューデータ_水害区域図_トリガーメッセージ ### 2024/11/06 comment out

from P0000Common.models import IPPAN_HISTORY           ### 11000: ヒストリーデータ_一般資産調査票_調査員用
from P0000Common.models import CHITAN_HISTORY          ### 11010: ヒストリーデータ_公共土木施設調査票_地方単独事業
from P0000Common.models import HOJO_HISTORY            ### 11020: ヒストリーデータ_公共土木施設調査票_補助事業
from P0000Common.models import KOEKI_HISTORY           ### 11030: ヒストリーデータ_公益事業等調査票
### from P0000Common.models import KUIKI_HISTORY       ### 11040: ヒストリーデータ_水害区域図 ### 2024/11/06 comment out

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.common import split_name_code
from P0000Common.common import isdate
from P0000Common.common import convert_empty_to_none

from P0000Common.services import get_ippan_chosa_csv_excel
from P0000Common.services import get_ippan_summary_csv_excel
from P0000Common.services import get_chitan_chosa_csv_excel
from P0000Common.services import get_chitan_summary_csv_excel
from P0000Common.services import get_hojo_chosa_csv_excel
from P0000Common.services import get_hojo_summary_csv_excel
from P0000Common.services import get_koeki_chosa_csv_excel
from P0000Common.services import get_koeki_summary_csv_excel

from . import constants

from .forms import UploadChitanForm
from .forms import UploadHojoForm
from .forms import UploadKoekiForm

from MessageQueue.views import publish_message 
from MessageQueue.views import delete_message 

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'

_CHI_ACT_01 = 'CHI_ACT_01'
_CHI_ACT_02 = 'CHI_ACT_02'
_CHI_ACT_03 = 'CHI_ACT_03'

_HOJ_ACT_01 = 'HOJ_ACT_01'
_HOJ_ACT_02 = 'HOJ_ACT_02'
_HOJ_ACT_03 = 'HOJ_ACT_03'

_KOE_ACT_01 = 'KOE_ACT_01'
_KOE_ACT_02 = 'KOE_ACT_02'
_KOE_ACT_03 = 'KOE_ACT_03'

### STATUSテーブル.STATUS_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_RUNNING = 'RUNNING'

### 局所定数 ※DELETE関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP = 'IPP'
_CHI = 'CHI'
_HOJ = 'HOJ'
_KOE = 'KOE'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'
_CHI_CHO_EXC = 'CHI_CHO_EXC'
_CHI_CHO_CSV = 'CHI_CHO_CSV'
_CHI_SUM_EXC = 'CHI_SUM_EXC'
_CHI_SUM_CSV = 'CHI_SUM_CSV'
_HOJ_CHO_EXC = 'HOJ_CHO_EXC'
_HOJ_CHO_CSV = 'HOJ_CHO_CSV'
_HOJ_SUM_EXC = 'HOJ_SUM_EXC'
_HOJ_SUM_CSV = 'HOJ_SUM_CSV'
_KOE_CHO_EXC = 'KOE_CHO_EXC'
_KOE_CHO_CSV = 'KOE_CHO_CSV'
_KOE_SUM_EXC = 'KOE_SUM_EXC'
_KOE_SUM_CSV = 'KOE_SUM_CSV'

### 局所定数 暫定値確報値
_PROVISIONED = 'PROVISIONED'
_CONFIRMED = 'CONFIRMED'

### 局所定数 ワークフロー履歴
_PROVISIONED_IPPAN_CITY_UPLOAD = 'PROVISIONED_IPPAN_CITY_UPLOAD'
_PROVISIONED_IPPAN_CITY_APPLY = 'PROVISIONED_IPPAN_CITY_APPLY'
_PROVISIONED_IPPAN_CITY_DELETE = 'PROVISIONED_IPPAN_CITY_DELETE'
_PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER = 'PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER'
_PROVISIONED_IPPAN_KEN_APPROVE = 'PROVISIONED_IPPAN_KEN_APPROVE'
_PROVISIONED_IPPAN_KEN_DISAPPROVE = 'PROVISIONED_IPPAN_KEN_DISAPPROVE'
_PROVISIONED_IPPAN_MANAGE_APPROVE = 'PROVISIONED_IPPAN_MANAGE_APPROVE'
_PROVISIONED_IPPAN_MANAGE_DISAPPROVE = 'PROVISIONED_IPPAN_MANAGE_DISAPPROVE'

_CONFIRMED_IPPAN_CITY_UPLOAD = 'CONFIRMED_IPPAN_CITY_UPLOAD'
_CONFIRMED_IPPAN_CITY_APPLY = 'CONFIRMED_IPPAN_CITY_APPLY'
_CONFIRMED_IPPAN_CITY_DELETE = 'CONFIRMED_IPPAN_CITY_DELETE'
_CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER = 'CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER'
_CONFIRMED_IPPAN_KEN_APPROVE = 'CONFIRMED_IPPAN_KEN_APPROVE'
_CONFIRMED_IPPAN_KEN_DISAPPROVE = 'CONFIRMED_IPPAN_KEN_DISAPPROVE'
_CONFIRMED_IPPAN_MANAGE_APPROVE = 'CONFIRMED_IPPAN_MANAGE_APPROVE'
_CONFIRMED_IPPAN_MANAGE_DISAPPROVE = 'CONFIRMED_IPPAN_MANAGE_DISAPPROVE'

_PROVISIONED_CHITAN_KEN_UPLOAD = 'PROVISIONED_CHITAN_KEN_UPLOAD'
_PROVISIONED_CHITAN_KEN_APPLY = 'PROVISIONED_CHITAN_KEN_APPLY'
_PROVISIONED_CHITAN_KEN_DELETE = 'PROVISIONED_CHITAN_KEN_DELETE'
_PROVISIONED_CHITAN_MANAGE_APPROVE = 'PROVISIONED_CHITAN_MANAGE_APPROVE'
_PROVISIONED_CHITAN_MANAGE_DISAPPROVE = 'PROVISIONED_CHITAN_MANAGE_DISAPPROVE'

_CONFIRMED_CHITAN_KEN_UPLOAD = 'CONFIRMED_CHITAN_KEN_UPLOAD'
_CONFIRMED_CHITAN_KEN_APPLY = 'CONFIRMED_CHITAN_KEN_APPLY'
_CONFIRMED_CHITAN_KEN_DELETE = 'CONFIRMED_CHITAN_KEN_DELETE'
_CONFIRMED_CHITAN_MANAGE_APPROVE = 'CONFIRMED_CHITAN_MANAGE_APPROVE'
_CONFIRMED_CHITAN_MANAGE_DISAPPROVE = 'CONFIRMED_CHITAN_MANAGE_DISAPPROVE'

_PROVISIONED_HOJO_KEN_UPLOAD = 'PROVISIONED_HOJO_KEN_UPLOAD'
_PROVISIONED_HOJO_KEN_APPLY = 'PROVISIONED_HOJO_KEN_APPLY'
_PROVISIONED_HOJO_KEN_DELETE = 'PROVISIONED_HOJO_KEN_DELETE'
_PROVISIONED_HOJO_MANAGE_APPROVE = 'PROVISIONED_HOJO_MANAGE_APPROVE'
_PROVISIONED_HOJO_MANAGE_DISAPPROVE = 'PROVISIONED_HOJO_MANAGE_DISAPPROVE'

_CONFIRMED_HOJO_KEN_UPLOAD = 'CONFIRMED_HOJO_KEN_UPLOAD'
_CONFIRMED_HOJO_KEN_APPLY = 'CONFIRMED_HOJO_KEN_APPLY'
_CONFIRMED_HOJO_KEN_DELETE = 'CONFIRMED_HOJO_KEN_DELETE'
_CONFIRMED_HOJO_MANAGE_APPROVE = 'CONFIRMED_HOJO_MANAGE_APPROVE'
_CONFIRMED_HOJO_MANAGE_DISAPPROVE = 'CONFIRMED_HOJO_MANAGE_DISAPPROVE'

_PROVISIONED_KOEKI_KEN_UPLOAD = 'PROVISIONED_KOEKI_KEN_UPLOAD'
_PROVISIONED_KOEKI_KEN_APPLY = 'PROVISIONED_KOEKI_KEN_APPLY'
_PROVISIONED_KOEKI_KEN_DELETE = 'PROVISIONED_KOEKI_KEN_DELETE'
_PROVISIONED_KOEKI_MANAGE_APPROVE = 'PROVISIONED_KOEKI_MANAGE_APPROVE'
_PROVISIONED_KOEKI_MANAGE_DISAPPROVE = 'PROVISIONED_KOEKI_MANAGE_DISAPPROVE'

_CONFIRMED_KOEKI_KEN_UPLOAD = 'CONFIRMED_KOEKI_KEN_UPLOAD'
_CONFIRMED_KOEKI_KEN_APPLY = 'CONFIRMED_KOEKI_KEN_APPLY'
_CONFIRMED_KOEKI_KEN_DELETE = 'CONFIRMED_KOEKI_KEN_DELETE'
_CONFIRMED_KOEKI_MANAGE_APPROVE = 'CONFIRMED_KOEKI_MANAGE_APPROVE'
_CONFIRMED_KOEKI_MANAGE_DISAPPROVE = 'CONFIRMED_KOEKI_MANAGE_DISAPPROVE'

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### ※調査票の種類に応じてエラーメッセージが異なるため、共通化せずに、個々のviews.pyに記述する。
###############################################################################
def add_comment(ws, ws_result, row, column, fill, message_id, message):
    ws.cell(row=row, column=column).fill = fill
    ws_result.cell(row=row, column=column).fill = fill
    
    msg_str = message[message_id][3] + message[message_id][4]
    ### msg_str = message[message_id][2] + message[message_id][3]              ### 2024/11/13 地単、補助、公益アップロード機能公開時、こちらに変更する予定。

    if ws.cell(row=row, column=column).comment is None:
        ws.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws.cell(row=row, column=column).comment = Comment(str(ws.cell(row=row, column=column).comment.text) + msg_str, '')
        
    if ws_result.cell(row=row, column=column).comment is None:
        ws_result.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws_result.cell(row=row, column=column).comment = Comment(str(ws_result.cell(row=row, column=column).comment.text) + msg_str, '')
        
    return True

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def custom_decorator(arg1):

    def outer_wrapper(view_func):
        
        def inner_wrapper(request, *args, **kwargs):
            try:
                reset_log()
                print_log('[DEBUG] P0120Ken.custom_decorator()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
                print_log('[DEBUG] P0120Ken.custom_decorator()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
                print_log('[DEBUG] P0120Ken.custom_decorator()関数 arg1={}'.format(arg1), 'DEBUG')
                PARAMS_SELECT_USER_PROXY = dict({
                    'USERNAME': str(request.user), 
                    'ROLE_CODE': _ROLE_KEN
                })
                SQL_SELECT_USER_PROXY = """
                    SELECT 
                        P1.ID, 
                        A1.USERNAME, 
                        P1.ROLE_CODE, 
                        P1.KEN_CODE, 
                        P1.CITY_CODE 
                    FROM USER_PROXY P1 
                    LEFT JOIN (
                        SELECT 
                            * 
                        FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                    WHERE 
                        A1.USERNAME=%(USERNAME)s AND 
                        P1.ROLE_CODE=%(ROLE_CODE)s"""
                SQL_SELECT_PROVISIONED_CONFIRMED = """
                    SELECT 
                        *
                    FROM PROVISIONED_CONFIRMED"""
                ### decoratorでビュー関数に変数を返す方法が不明のため、グローバル変数を使用した。
                global user_proxy_list
                global provisioned_confirmed_list
                user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
                provisioned_confirmed_list = PROVISIONED_CONFIRMED.objects.raw(SQL_SELECT_PROVISIONED_CONFIRMED)
        
                print_log('[DEBUG] P0120Ken.custom_decorator()関数 user_proxy_list={}'.format(user_proxy_list), 'DEBUG')
                print_log('[DEBUG] P0120Ken.custom_decorator()関数 len(user_proxy_list)={}'.format(len(user_proxy_list)), 'DEBUG')
                print_log('[DEBUG] P0120Ken.custom_decorator()関数 provisioned_confirmed_list={}'.format(provisioned_confirmed_list), 'DEBUG')
                print_log('[DEBUG] P0120Ken.custom_decorator()関数 len(provisioned_confirmed_list)={}'.format(len(provisioned_confirmed_list)), 'DEBUG')
                    
                ### デコレータの処理で警告が発生したら（user_proxy_listが正常に取得できなかったら）、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                if (user_proxy_list == False) or (
                    user_proxy_list == True and user_proxy_list[0].ken_code == False):
                    print_log('[WARN] P0120Ken.custom_decorator()が警告終了しました。', 'WARN')
                    if (arg1 == 'bucket_view'):
                        template = loader.get_template('P0120Ken/bucket/bucket.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'browser_view'):
                        template = loader.get_template('P0120Ken/browser/browser.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'browser_city_code_view'):
                        template = loader.get_template('P0120Ken/browser/browser_city_code.html')
                        context = {
                            'alert_log': get_alert_log(), 
                        }
                        return HttpResponse(template.render(context, request))
                    elif (arg1 == 'slide_ippan_header_id_view') or (
                          arg1 == 'slide_chitan_header_id_view') or (
                          arg1 == 'slide_hojo_header_id_view') or (
                          arg1 == 'slide_koeki_header_id_view') or (
                                  
                          arg1 == 'apply_chitan_header_id_view') or (
                          arg1 == 'apply_hojo_header_id_view') or (
                          arg1 == 'apply_koeki_header_id_view') or (

                          arg1 == 'linkage_ippan_header_id_weather_id_view') or (
                          arg1 == 'approve_ippan_header_id_view') or (
                          arg1 == 'disapprove_ippan_header_id_view') or (
                                  
                          arg1 == 'delete_ippan_header_id_view') or (
                          arg1 == 'delete_chitan_header_id_view') or (
                          arg1 == 'delete_hojo_header_id_view') or (
                          arg1 == 'delete_koeki_header_id_view'):
                        data = {
                            'return_code': ["FALSE"], 
                        }
                        response = JsonResponse(data)
                        response['Access-Control-Allow-Origin'] = 'localhost:8000'
                        response['Access-Control-Allow-Credentials'] = 'true'
                        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
                        response['Access-Control-Allow-Methods'] = 'GET'
                        return response
                    elif (arg1 == 'download_ippan_chosa_excel_header_id_view') or (
                          arg1 == 'download_ippan_chosa_csv_header_id_view') or (
                          arg1 == 'download_ippan_summary_excel_header_id_view') or (
                          arg1 == 'download_ippan_summary_csv_header_id_view') or (
                          arg1 == 'download_chitan_chosa_excel_header_id_view') or (
                          arg1 == 'download_chitan_chosa_csv_header_id_view') or (
                          arg1 == 'download_chitan_summary_excel_header_id_view') or (
                          arg1 == 'download_chitan_summary_csv_header_id_view') or (
                          arg1 == 'download_hojo_chosa_excel_header_id_view') or (
                          arg1 == 'download_hojo_chosa_csv_header_id_view') or (
                          arg1 == 'download_hojo_summary_excel_header_id_view') or (
                          arg1 == 'download_hojo_summary_csv_header_id_view') or (
                          arg1 == 'download_koeki_chosa_excel_header_id_view') or (
                          arg1 == 'download_koeki_chosa_csv_header_id_view') or (
                          arg1 == 'download_koeki_summary_excel_header_id_view') or (
                          arg1 == 'download_koeki_summary_csv_header_id_view'):
                        return HttpResponseNotFound("")
                
                ### ここまで正常に処理できたら、ビュー関数を戻して、ビュー関数の処理に移行する。
                return view_func(request, *args, **kwargs)
            
            except:
                ### デコレータの処理で異常が発生したら、
                ### ブラウザにレスポンスを返して、ビュー関数の処理に移行しない。
                print_log('[WARN] P0120Ken.custom_decorator()が異常終了しました。', 'WARN')
                if (arg1 == 'bucket_view'):
                    template = loader.get_template('P0120Ken/bucket/bucket.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'browser_view'):
                    template = loader.get_template('P0120Ken/browser/browser.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'browser_city_code_view'):
                    template = loader.get_template('P0120Ken/browser/browser_city_code.html')
                    context = {
                        'alert_log': get_alert_log(), 
                    }
                    return HttpResponse(template.render(context, request))
                elif (arg1 == 'slide_ippan_header_id_view') or (
                      arg1 == 'slide_chitan_header_id_view') or (
                      arg1 == 'slide_hojo_header_id_view') or (
                      arg1 == 'slide_koeki_header_id_view') or (
                              
                      arg1 == 'apply_chitan_header_id_view') or (
                      arg1 == 'apply_hojo_header_id_view') or (
                      arg1 == 'apply_koeki_header_id_view') or (
                              
                      arg1 == 'linkage_ippan_header_id_weather_id_view') or (
                      arg1 == 'approve_ippan_header_id_view') or (
                      arg1 == 'disapprove_ippan_header_id_view') or (
                              
                      arg1 == 'delete_ippan_header_id_view') or (
                      arg1 == 'delete_chitan_header_id_view') or (
                      arg1 == 'delete_hojo_header_id_view') or (
                      arg1 == 'delete_koeki_header_id_view'):
                    data = {
                        'return_code': ["FALSE"], 
                    }
                    response = JsonResponse(data)
                    response['Access-Control-Allow-Origin'] = 'localhost:8000'
                    response['Access-Control-Allow-Credentials'] = 'true'
                    response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
                    response['Access-Control-Allow-Methods'] = 'GET'
                    return response
                elif (arg1 == 'download_ippan_chosa_excel_header_id_view') or (
                      arg1 == 'download_ippan_chosa_csv_header_id_view') or (
                      arg1 == 'download_ippan_summary_excel_header_id_view') or (
                      arg1 == 'download_ippan_summary_csv_header_id_view') or (
                      arg1 == 'download_chitan_chosa_excel_header_id_view') or (
                      arg1 == 'download_chitan_chosa_csv_header_id_view') or (
                      arg1 == 'download_chitan_summary_excel_header_id_view') or (
                      arg1 == 'download_chitan_summary_csv_header_id_view') or (
                      arg1 == 'download_hojo_chosa_excel_header_id_view') or (
                      arg1 == 'download_hojo_chosa_csv_header_id_view') or (
                      arg1 == 'download_hojo_summary_excel_header_id_view') or (
                      arg1 == 'download_hojo_summary_csv_header_id_view') or (
                      arg1 == 'download_koeki_chosa_excel_header_id_view') or (
                      arg1 == 'download_koeki_chosa_csv_header_id_view') or (
                      arg1 == 'download_koeki_summary_excel_header_id_view') or (
                      arg1 == 'download_koeki_summary_csv_header_id_view'):
                    return HttpResponseNotFound("")
        
        return inner_wrapper
            
    return outer_wrapper

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def browser_get(request):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code,
                'CHITAN_KEN_UPLOAD': _PROVISIONED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _PROVISIONED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _PROVISIONED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _PROVISIONED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _PROVISIONED_CHITAN_MANAGE_DISAPPROVE,
                'HOJO_KEN_UPLOAD': _PROVISIONED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _PROVISIONED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _PROVISIONED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _PROVISIONED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _PROVISIONED_HOJO_MANAGE_DISAPPROVE,
                'KOEKI_KEN_UPLOAD': _PROVISIONED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _PROVISIONED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _PROVISIONED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _PROVISIONED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _PROVISIONED_KOEKI_MANAGE_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code,
                'CHITAN_KEN_UPLOAD': _CONFIRMED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _CONFIRMED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _CONFIRMED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _CONFIRMED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _CONFIRMED_CHITAN_MANAGE_DISAPPROVE,
                'HOJO_KEN_UPLOAD': _CONFIRMED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _CONFIRMED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _CONFIRMED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _CONFIRMED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _CONFIRMED_HOJO_MANAGE_DISAPPROVE,
                'KOEKI_KEN_UPLOAD': _CONFIRMED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _CONFIRMED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _CONFIRMED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _CONFIRMED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _CONFIRMED_KOEKI_MANAGE_DISAPPROVE,
            })
        SQL_SELECT_KEN_BUCKET = """
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, -- ディスク使用量
                FILES -- ファイル格納数 
            FROM KEN_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s"""
        SQL_SELECT_CITY_BUCKET = """
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, -- ディスク使用量
                FILES -- ファイル格納数 
            FROM CITY_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s
            ORDER BY 
                CAST(CITY_CODE AS INTEGER)"""
        SQL_SELECT_CHITAN_HEADER = """
            SELECT 
                C1.CHITAN_HEADER_ID, 
                C1.CHITAN_HEADER_NAME, 
                C1.KEN_CODE, 
                C1.UPLOAD_FILE_PATH, 
                C1.UPLOAD_FILE_NAME, 
                C1.UPLOAD_FILE_SIZE, 
                C1.SUMMARY_FILE_PATH, 
                C1.SUMMARY_FILE_NAME, 
                C1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', C1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', C1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                S1.CHITAN_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM CHITAN_HEADER  C1
            LEFT JOIN (
                SELECT
                    CHITAN_HISTORY_ID,
                    CHITAN_HEADER_ID,
                    WORKFLOW_CODE
                FROM CHITAN_HISTORY
                WHERE
                    CHITAN_HISTORY_ID IN (
                        SELECT
                            MAX(CHITAN_HISTORY_ID)
                        FROM CHITAN_HISTORY
                        GROUP BY CHITAN_HEADER_ID
                    )
            ) S1 ON C1.CHITAN_HEADER_ID=S1.CHITAN_HEADER_ID
            WHERE 
                C1.KEN_CODE=%(KEN_CODE)s AND 
                C1.DELETED_AT IS NULL
            ORDER BY C1.CHITAN_HEADER_ID"""
        SQL_SELECT_HOJO_HEADER = """
            SELECT 
                H1.HOJO_HEADER_ID, 
                H1.HOJO_HEADER_NAME, 
                H1.KEN_CODE, 
                H1.UPLOAD_FILE_PATH, 
                H1.UPLOAD_FILE_NAME, 
                H1.UPLOAD_FILE_SIZE, 
                H1.SUMMARY_FILE_PATH, 
                H1.SUMMARY_FILE_NAME, 
                H1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', H1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', H1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT,
                S1.HOJO_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM HOJO_HEADER H1
            LEFT JOIN (
                SELECT
                    HOJO_HISTORY_ID,
                    HOJO_HEADER_ID,
                    WORKFLOW_CODE
                FROM HOJO_HISTORY
                WHERE
                    HOJO_HISTORY_ID IN (
                        SELECT
                            MAX(HOJO_HISTORY_ID)
                        FROM HOJO_HISTORY
                        GROUP BY HOJO_HEADER_ID
                    )
            ) S1 ON H1.HOJO_HEADER_ID=S1.HOJO_HEADER_ID
            WHERE 
                H1.KEN_CODE=%(KEN_CODE)s AND 
                H1.DELETED_AT IS NULL
            ORDER BY H1.HOJO_HEADER_ID"""
        SQL_SELECT_KOEKI_HEADER = """
            SELECT 
                K1.KOEKI_HEADER_ID, 
                K1.KOEKI_HEADER_NAME, 
                K1.KEN_CODE, 
                K1.UPLOAD_FILE_PATH, 
                K1.UPLOAD_FILE_NAME, 
                K1.UPLOAD_FILE_SIZE, 
                K1.SUMMARY_FILE_PATH, 
                K1.SUMMARY_FILE_NAME, 
                K1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', K1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', K1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                S1.KOEKI_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM KOEKI_HEADER K1
            LEFT JOIN (
                SELECT
                    KOEKI_HISTORY_ID,
                    KOEKI_HEADER_ID,
                    WORKFLOW_CODE
                FROM KOEKI_HISTORY
                WHERE 
                    KOEKI_HISTORY_ID IN (
                        SELECT
                            MAX(KOEKI_HISTORY_ID)
                        FROM KOEKI_HISTORY
                        GROUP BY KOEKI_HEADER_ID
                    )
            ) S1 ON K1.KOEKI_HEADER_ID=S1.KOEKI_HEADER_ID
            WHERE 
                K1.KEN_CODE=%(KEN_CODE)s AND 
                K1.DELETED_AT IS NULL
            ORDER BY K1.KOEKI_HEADER_ID"""
        SQL_SELECT_WEATHER = """
            SELECT
                WEATHER_ID,
                WEATHER_NAME,
                BEGIN_DATE,
                END_DATE,
                KEN_CODE,
                COMMITTED_AT,
                DELETED_AT
            FROM WEATHER
            WHERE
                KEN_CODE=%(KEN_CODE)s AND
                DELETED_AT IS NULL 
            ORDER BY WEATHER_ID"""
                
        ### HTMLタイトル部分表示用
        ken_bucket_list = KEN_BUCKET.objects.raw(SQL_SELECT_KEN_BUCKET, PARAMS)
        ### HTML一覧部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw(SQL_SELECT_CITY_BUCKET, PARAMS)
        ### HTML一覧部分表示用
        chitan_header_list = CHITAN_HEADER.objects.raw(SQL_SELECT_CHITAN_HEADER, PARAMS)
        ### HTML一覧部分表示用
        hojo_header_list = HOJO_HEADER.objects.raw(SQL_SELECT_HOJO_HEADER, PARAMS)
        ### HTML一覧部分表示用
        koeki_header_list = KOEKI_HEADER.objects.raw(SQL_SELECT_KOEKI_HEADER, PARAMS)
        ### HTML右スライド部分
        weather_list = WEATHER.objects.raw(SQL_SELECT_WEATHER, PARAMS)

        print_log('[DEBUG] P0120Ken.browser_get()関数 ken_bucket_list={}'.format(ken_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 len(ken_bucket_list)={}'.format(len(ken_bucket_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 city_bucket_list={}'.format(city_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 len(city_bucket_list)={}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 chitan_header_list={}'.format(chitan_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 len(chitan_header_list)={}'.format(len(chitan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 hojo_header_list={}'.format(hojo_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 len(hojo_header_list)={}'.format(len(hojo_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 koeki_header_list={}'.format(koeki_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 len(koeki_header_list)={}'.format(len(koeki_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 weather_list={}'.format(weather_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 len(weather_list)={}'.format(len(weather_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 2/3.', 'DEBUG')
        if (ken_bucket_list == False) or (city_bucket_list == False):
            print_log('[WARN] P0120Ken.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0120Ken.browser_get()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'ken_bucket_list': ken_bucket_list, 
            'city_bucket_list': city_bucket_list, 
            'chitan_header_list': chitan_header_list, 
            'hojo_header_list': hojo_header_list, 
            'koeki_header_list': koeki_header_list, 
            'weather_list': weather_list,
        }
        return True, HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0120Ken.browser_get()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_get()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_get()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def browser_post_chitan(request):

    ###########################################################################
    ### 関数内関数：EXCELセルデータ必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal require_warn
            nonlocal require_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0000）
            ### (1)セル[8:2]からセル[8:21]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_require()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=1).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 1, constants.CHI_REQ_MSG[0][0], constants.CHI_REQ_MSG[0][1], constants.CHI_REQ_MSG[0][2], constants.CHI_REQ_MSG[0][3], constants.CHI_REQ_MSG[0][4]])
                    else:
                        require_info.append([ws[0].title, j, 1, 0])
                        
                    ### セル[8:2]: 水系・沿岸名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 2, constants.CHI_REQ_MSG[1][0], constants.CHI_REQ_MSG[1][1], constants.CHI_REQ_MSG[1][2], constants.CHI_REQ_MSG[1][3], constants.CHI_REQ_MSG[1][4]])
                    else:
                        require_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=3).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 3, constants.CHI_REQ_MSG[2][0], constants.CHI_REQ_MSG[2][1], constants.CHI_REQ_MSG[2][2], constants.CHI_REQ_MSG[2][3], constants.CHI_REQ_MSG[2][4]])
                    else:
                        require_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 4, constants.CHI_REQ_MSG[3][0], constants.CHI_REQ_MSG[3][1], constants.CHI_REQ_MSG[3][2], constants.CHI_REQ_MSG[3][3], constants.CHI_REQ_MSG[3][4]])
                    else:
                        require_info.append([ws[i].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 5, constants.CHI_REQ_MSG[4][0], constants.CHI_REQ_MSG[4][1], constants.CHI_REQ_MSG[4][2], constants.CHI_REQ_MSG[4][3], constants.CHI_REQ_MSG[4][4]])
                    else:
                        require_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 代表被災地区名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 6, constants.CHI_REQ_MSG[5][0], constants.CHI_REQ_MSG[5][1], constants.CHI_REQ_MSG[5][2], constants.CHI_REQ_MSG[5][3], constants.CHI_REQ_MSG[5][4]])
                    else:
                        require_info.append([ws[0].title, j, 6, 5])
                    
                    ### セル[8:7]: 都道府県名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 7, constants.CHI_REQ_MSG[6][0], constants.CHI_REQ_MSG[6][1], constants.CHI_REQ_MSG[6][2], constants.CHI_REQ_MSG[6][3], constants.CHI_REQ_MSG[6][4]])
                    else:
                        require_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[8:8]: 市区町村名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 8, constants.CHI_REQ_MSG[7][0], constants.CHI_REQ_MSG[7][1], constants.CHI_REQ_MSG[7][2], constants.CHI_REQ_MSG[7][3], constants.CHI_REQ_MSG[7][4]])
                    else:
                        require_info.append([ws[0].title, j, 8, 7])
                    
                    ### セル[8:9]: 都道府県コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 9, constants.CHI_REQ_MSG[8][0], constants.CHI_REQ_MSG[8][1], constants.CHI_REQ_MSG[8][2], constants.CHI_REQ_MSG[8][3], constants.CHI_REQ_MSG[8][4]])
                    else:
                        require_info.append([ws[0].title, j, 9, 8])
                    
                    ### セル[8:10]: 
                    ### セル[8:11]: 異常気象コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 11, constants.CHI_REQ_MSG[10][0], constants.CHI_REQ_MSG[10][1], constants.CHI_REQ_MSG[10][2], constants.CHI_REQ_MSG[10][3], constants.CHI_REQ_MSG[10][4]])
                    else:
                        require_info.append([ws[0].title, j, 11, 10])
                    
                    ### セル[8:12]: 水害発生月に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=12).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 12, constants.CHI_REQ_MSG[11][0], constants.CHI_REQ_MSG[11][1], constants.CHI_REQ_MSG[11][2], constants.CHI_REQ_MSG[11][3], constants.CHI_REQ_MSG[11][4]])
                    else:
                        require_info.append([ws[0].title, j, 12, 11])
                    
                    ### セル[8:13]: 水害発生日に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 13, constants.CHI_REQ_MSG[12][0], constants.CHI_REQ_MSG[12][1], constants.CHI_REQ_MSG[12][2], constants.CHI_REQ_MSG[12][3], constants.CHI_REQ_MSG[12][4]])
                    else:
                        require_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[8:14]: 水害発生月に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=13, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 14, constants.CHI_REQ_MSG[13][0], constants.CHI_REQ_MSG[13][1], constants.CHI_REQ_MSG[13][2], constants.CHI_REQ_MSG[13][3], constants.CHI_REQ_MSG[13][4]])
                    else:
                        require_info.append([ws[0].title, j, 14, 13])
                    
                    ### セル[8:15]: 水害発生日に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 15, constants.CHI_REQ_MSG[14][0], constants.CHI_REQ_MSG[14][1], constants.CHI_REQ_MSG[14][2], constants.CHI_REQ_MSG[14][3], constants.CHI_REQ_MSG[14][4]])
                    else:
                        require_info.append([ws[0].title, j, 15, 14])
                    
                    ### セル[8:16]: 工種区分に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 16, constants.CHI_REQ_MSG[15][0], constants.CHI_REQ_MSG[15][1], constants.CHI_REQ_MSG[15][2], constants.CHI_REQ_MSG[15][3], constants.CHI_REQ_MSG[15][4]])
                    else:
                        require_info.append([ws[0].title, j, 16, 15])
                    
                    ### セル[8:17]: 
                    ### セル[8:18]: 市区町村コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=18).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 18, constants.CHI_REQ_MSG[17][0], constants.CHI_REQ_MSG[17][1], constants.CHI_REQ_MSG[17][2], constants.CHI_REQ_MSG[17][3], constants.CHI_REQ_MSG[17][4]])
                    else:
                        require_info.append([ws[0].title, j, 18, 17])
                    
                    ### セル[8:19]: 災害復旧箇所に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=19).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 19, constants.CHI_REQ_MSG[18][0], constants.CHI_REQ_MSG[18][1], constants.CHI_REQ_MSG[18][2], constants.CHI_REQ_MSG[18][3], constants.CHI_REQ_MSG[18][4]])
                    else:
                        require_info.append([ws[0].title, j, 19, 18])
                    
                    ### セル[8:20]: 災害復旧査定額千円に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=20).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 20, constants.CHI_REQ_MSG[19][0], constants.CHI_REQ_MSG[19][1], constants.CHI_REQ_MSG[19][2], constants.CHI_REQ_MSG[19][3], constants.CHI_REQ_MSG[19][4]])
                    else:
                        require_info.append([ws[0].title, j, 20, 19])
                    
                    ### セル[8:21]: 備考に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=21).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 21, constants.CHI_REQ_MSG[20][0], constants.CHI_REQ_MSG[20][1], constants.CHI_REQ_MSG[20][2], constants.CHI_REQ_MSG[20][3], constants.CHI_REQ_MSG[20][4]])
                    else:
                        require_info.append([ws[0].title, j, 21, 20])
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal format_warn
            nonlocal format_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0000）
            ### (1)セル[8:2]からセル[8:21]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_format()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=1).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=1).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 1, constants.CHI_FOR_MSG[0][0], constants.CHI_FOR_MSG[0][1], constants.CHI_FOR_MSG[0][2], constants.CHI_FOR_MSG[0][3], constants.CHI_FOR_MSG[0][4]])
                        else:
                            format_info.append([ws[0].title, j, 1, 100])
    
                    ### セル[8:2]: 水系・沿岸名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=2).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 2, constants.CHI_FOR_MSG[1][0], constants.CHI_FOR_MSG[1][1], constants.CHI_FOR_MSG[1][2], constants.CHI_FOR_MSG[1][3], constants.CHI_FOR_MSG[1][4]])
                        else:
                            format_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=3).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=3).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 3, constants.CHI_FOR_MSG[2][0], constants.CHI_FOR_MSG[2][1], constants.CHI_FOR_MSG[2][2], constants.CHI_FOR_MSG[2][3], constants.CHI_FOR_MSG[2][4]])
                        else:
                            format_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=4).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 4, constants.CHI_FOR_MSG[3][0], constants.CHI_FOR_MSG[3][1], constants.CHI_FOR_MSG[3][2], constants.CHI_FOR_MSG[3][3], constants.CHI_FOR_MSG[3][4]])
                        else:
                            format_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=5).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 5, constants.CHI_FOR_MSG[4][0], constants.CHI_FOR_MSG[4][1], constants.CHI_FOR_MSG[4][2], constants.CHI_FOR_MSG[4][3], constants.CHI_FOR_MSG[4][4]])
                        else:
                            format_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 代表被災地区名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=6).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=6).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 6, constants.CHI_FOR_MSG[5][0], constants.CHI_FOR_MSG[5][1], constants.CHI_FOR_MSG[5][2], constants.CHI_FOR_MSG[5][3], constants.CHI_FOR_MSG[5][4]])
                        else:
                            format_info.append([ws[0].title, j, 6, 5])
                        
                    ### セル[8:7]: 都道府県名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=7).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=7).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 7, constants.CHI_FOR_MSG[6][0], constants.CHI_FOR_MSG[6][1], constants.CHI_FOR_MSG[6][2], constants.CHI_FOR_MSG[6][3], constants.CHI_FOR_MSG[6][4]])
                        else:
                            format_info.append([ws[0].title, j, 7, 6])
                        
                    ### セル[8:8]: 市区町村名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=8).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=8).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 8, constants.CHI_FOR_MSG[7][0], constants.CHI_FOR_MSG[7][1], constants.CHI_FOR_MSG[7][2], constants.CHI_FOR_MSG[7][3], constants.CHI_FOR_MSG[7][4]])
                        else:
                            format_info.append([ws[0].title, j, 8, 7])
                        
                    ### セル[8:9]: 都道府県コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=9).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=9).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 9, constants.CHI_FOR_MSG[8][0], constants.CHI_FOR_MSG[8][1], constants.CHI_FOR_MSG[8][2], constants.CHI_FOR_MSG[8][3], constants.CHI_FOR_MSG[8][4]])
                        else:
                            format_info.append([ws[0].title, j, 9, 8])
                        
                    ### セル[8:10]: 
                    ### セル[8:11]: 異常気象コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=11).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=11).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 11, constants.CHI_FOR_MSG[10][0], constants.CHI_FOR_MSG[10][1], constants.CHI_FOR_MSG[10][2], constants.CHI_FOR_MSG[10][3], constants.CHI_FOR_MSG[10][4]])
                        else:
                            format_info.append([ws[0].title, j, 11, 10])
                        
                    ### セル[8:12]: 水害発生月について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=12).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=12).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=12).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 12, constants.CHI_FOR_MSG[11][0], constants.CHI_FOR_MSG[11][1], constants.CHI_FOR_MSG[11][2], constants.CHI_FOR_MSG[11][3], constants.CHI_FOR_MSG[11][4]])
                        else:
                            format_info.append([ws[0].title, j, 12, 11])
                        
                    ### セル[8:13]: 水害発生日について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=13).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=13).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 13, constants.CHI_FOR_MSG[12][0], constants.CHI_FOR_MSG[12][1], constants.CHI_FOR_MSG[12][2], constants.CHI_FOR_MSG[12][3], constants.CHI_FOR_MSG[12][4]])
                        else:
                            format_info.append([ws[0].title, j, 13, 12])
                        
                    ### セル[8:14]: 水害発生月について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=14).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=14).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 14, constants.CHI_FOR_MSG[13][0], constants.CHI_FOR_MSG[13][1], constants.CHI_FOR_MSG[13][2], constants.CHI_FOR_MSG[13][3], constants.CHI_FOR_MSG[13][4]])
                        else:
                            format_info.append([ws[0].title, j, 14, 13])
                        
                    ### セル[8:15]: 水害発生日について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=15).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=15).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 15, constants.CHI_FOR_MSG[14][0], constants.CHI_FOR_MSG[14][1], constants.CHI_FOR_MSG[14][2], constants.CHI_FOR_MSG[14][3], constants.CHI_FOR_MSG[14][4]])
                        else:
                            format_info.append([ws[0].title, j, 15, 14])
                        
                    ### セル[8:16]: 工種区分について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=16).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=16).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 16, constants.CHI_FOR_MSG[15][0], constants.CHI_FOR_MSG[15][1], constants.CHI_FOR_MSG[15][2], constants.CHI_FOR_MSG[15][3], constants.CHI_FOR_MSG[15][4]])
                        else:
                            format_info.append([ws[0].title, j, 16, 15])
                        
                    ### セル[8:17]: 
                    ### セル[8:18]: 市区町村コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=18).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=18).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=18).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 18, constants.CHI_FOR_MSG[17][0], constants.CHI_FOR_MSG[17][1], constants.CHI_FOR_MSG[17][2], constants.CHI_FOR_MSG[17][3], constants.CHI_FOR_MSG[17][4]])
                        else:
                            format_info.append([ws[0].title, j, 18, 17])
                        
                    ### セル[8:19]: 災害復旧箇所について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=19).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=19).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=19).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 19, constants.CHI_FOR_MSG[18][0], constants.CHI_FOR_MSG[18][1], constants.CHI_FOR_MSG[18][2], constants.CHI_FOR_MSG[18][3], constants.CHI_FOR_MSG[18][4]])
                        else:
                            format_info.append([ws[0].title, j, 19, 18])
                        
                    ### セル[8:20]: 災害復旧査定額千円について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=20).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=20).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=20).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 20, constants.CHI_FOR_MSG[19][0], constants.CHI_FOR_MSG[19][1], constants.CHI_FOR_MSG[19][2], constants.CHI_FOR_MSG[19][3], constants.CHI_FOR_MSG[19][4]])
                        else:
                            format_info.append([ws[0].title, j, 20, 19])
                        
                    ### セル[8:21]: 備考について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=21).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=21).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=21).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 21, constants.CHI_FOR_MSG[20][0], constants.CHI_FOR_MSG[20][1], constants.CHI_FOR_MSG[20][2], constants.CHI_FOR_MSG[20][3], constants.CHI_FOR_MSG[20][4]])
                        else:
                            format_info.append([ws[0].title, j, 21, 20])
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal range_warn
            nonlocal range_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0000）
            ### (1)セル[8:2]からセル[8:21]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_range()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について範囲が正しいことをチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:3]: 水系種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:4]: 河川・海岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:5]: 河川種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:6]: 代表被災地区名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=6).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=6).value, float) == True):
                            if (float(ws[0].cell(row=j, column=6).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 6, constants.CHI_RAN_MSG[5][0], constants.CHI_RAN_MSG[5][1], constants.CHI_RAN_MSG[5][2], constants.CHI_RAN_MSG[5][3], constants.CHI_RAN_MSG[5][4]])
                            else:
                                range_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[8:7]: 都道府県名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=7).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=7).value, float) == True):
                            if (float(ws[0].cell(row=j, column=7).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 7, constants.CHI_RAN_MSG[6][0], constants.CHI_RAN_MSG[6][1], constants.CHI_RAN_MSG[6][2], constants.CHI_RAN_MSG[6][3], constants.CHI_RAN_MSG[6][4]])
                            else:
                                range_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[8:8]: 市区町村名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=8).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=8).value, float) == True):
                            if (float(ws[0].cell(row=j, column=8).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 8, constants.CHI_RAN_MSG[7][0], constants.CHI_RAN_MSG[7][1], constants.CHI_RAN_MSG[7][2], constants.CHI_RAN_MSG[7][3], constants.CHI_RAN_MSG[7][4]])
                            else:
                                range_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 都道府県コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=9).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=9).value, float) == True):
                            if (float(ws[0].cell(row=j, column=9).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 9, constants.CHI_RAN_MSG[8][0], constants.CHI_RAN_MSG[8][1], constants.CHI_RAN_MSG[8][2], constants.CHI_RAN_MSG[8][3], constants.CHI_RAN_MSG[8][4]])
                            else:
                                range_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]: 
                    ### セル[8:11]: 異常気象コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=11).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=11).value, float) == True):
                            if (float(ws[0].cell(row=j, column=11).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 11, constants.CHI_RAN_MSG[10][0], constants.CHI_RAN_MSG[10][1], constants.CHI_RAN_MSG[10][2], constants.CHI_RAN_MSG[10][3], constants.CHI_RAN_MSG[10][4]])
                            else:
                                range_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 水害発生月について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=12).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=12).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=12).value, float) == True):
                            if (float(ws[0].cell(row=j, column=12).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 12, constants.CHI_RAN_MSG[11][0], constants.CHI_RAN_MSG[11][1], constants.CHI_RAN_MSG[11][2], constants.CHI_RAN_MSG[11][3], constants.CHI_RAN_MSG[11][4]])
                            else:
                                range_info.append([ws[0].title, j, 12, 11])
    
                    ### セル[8:13]: 水害発生日について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=13).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=13).value, float) == True):
                            if (float(ws[0].cell(row=j, column=13).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 13, constants.CHI_RAN_MSG[12][0], constants.CHI_RAN_MSG[12][1], constants.CHI_RAN_MSG[12][2], constants.CHI_RAN_MSG[12][3], constants.CHI_RAN_MSG[12][4]])
                            else:
                                range_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[8:14]: 水害発生月について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=14).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=14).value, float) == True):
                            if (float(ws[0].cell(row=j, column=14).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 14, constants.CHI_RAN_MSG[13][0], constants.CHI_RAN_MSG[13][1], constants.CHI_RAN_MSG[13][2], constants.CHI_RAN_MSG[13][3], constants.CHI_RAN_MSG[13][4]])
                            else:
                                range_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[8:15]: 水害発生日について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=15).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=15).value, float) == True):
                            if (float(ws[0].cell(row=j, column=15).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 15, constants.CHI_RAN_MSG[14][0], constants.CHI_RAN_MSG[14][1], constants.CHI_RAN_MSG[14][2], constants.CHI_RAN_MSG[14][3], constants.CHI_RAN_MSG[14][4]])
                            else:
                                range_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[8:16]: 工種区分について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=16).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=16).value, float) == True):
                            if (float(ws[0].cell(row=j, column=16).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 16, constants.CHI_RAN_MSG[15][0], constants.CHI_RAN_MSG[15][1], constants.CHI_RAN_MSG[15][2], constants.CHI_RAN_MSG[15][3], constants.CHI_RAN_MSG[15][4]])
                            else:
                                range_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]: 
                    ### セル[8:18]: 市区町村コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=18).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=18).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=18).value, float) == True):
                            if (float(ws[0].cell(row=j, column=18).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 18, constants.CHI_RAN_MSG[17][0], constants.CHI_RAN_MSG[17][1], constants.CHI_RAN_MSG[17][2], constants.CHI_RAN_MSG[17][3], constants.CHI_RAN_MSG[17][4]])
                            else:
                                range_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[8:19]: 災害復旧箇所について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=19).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=19).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=19).value, float) == True):
                            if (float(ws[0].cell(row=j, column=19).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 19, constants.CHI_RAN_MSG[18][0], constants.CHI_RAN_MSG[18][1], constants.CHI_RAN_MSG[18][2], constants.CHI_RAN_MSG[18][3], constants.CHI_RAN_MSG[18][4]])
                            else:
                                range_info.append([ws[0].title, j, 19, 18])
    
                    ### セル[8:20]: 災害復旧査定額千円について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=20).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=20).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=20).value, float) == True):
                            if (float(ws[0].cell(row=j, column=20).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 20, constants.CHI_RAN_MSG[19][0], constants.CHI_RAN_MSG[19][1], constants.CHI_RAN_MSG[19][2], constants.CHI_RAN_MSG[19][3], constants.CHI_RAN_MSG[19][4]])
                            else:
                                range_info.append([ws[0].title, j, 20, 19])
    
                    ### セル[8:21]: 備考について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=21).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=21).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=21).value, float) == True):
                            if float(ws[0].cell(row=j, column=21).value) < 0:
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 21, constants.CHI_RAN_MSG[20][0], constants.CHI_RAN_MSG[20][1], constants.CHI_RAN_MSG[20][2], constants.CHI_RAN_MSG[20][3], constants.CHI_RAN_MSG[20][4]])
                            else:
                                range_info.append([ws[0].title, j, 21, 20])
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal correlate_warn
            nonlocal correlate_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0000）
            ### (1)セル[8,2]からセル[8,21]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_correlate()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    pass
                    ### セル[8:1]: NO.が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:2]: 水系・沿岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:3]: 水系種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:4]: 河川・海岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:5]: 河川種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:6]: 代表被災地区名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:7]: 都道府県名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:8]: 市区町村名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:9]: 都道府県コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:10]
                    ### セル[8:11]: 異常気象コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:12]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:13]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:14]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:15]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:16]: 工種区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:17]
                    ### セル[8:18]: 市区町村コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:19]: 災害復旧箇所が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:20]: 災害復旧査定額千円が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:21]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal compare_warn
            nonlocal compare_info
            ### nonlocal max_row
            ### nonlocal ken_code_list
            ### nonlocal ken_name_list
            ### nonlocal ken_name_code_list
            ### nonlocal city_code_list
            ### nonlocal city_name_list
            ### nonlocal city_name_code_list
            ### nonlocal suikei_code_list
            ### nonlocal suikei_name_list
            ### nonlocal suikei_name_code_list
            ### nonlocal suikei_type_code_list
            ### nonlocal suikei_type_name_list
            ### nonlocal suikei_type_name_code_list
            ### nonlocal kasen_code_list
            ### nonlocal kasen_name_list
            ### nonlocal kasen_name_code_list
            ### nonlocal kasen_type_code_list
            ### nonlocal kasen_type_name_list
            ### nonlocal kasen_type_name_code_list
            ### nonlocal kasen_kaigan_code_list
            ### nonlocal kasen_kaigan_name_list
            ### nonlocal kasen_kaigan_name_code_list
            ### nonlocal weather_id_list
            ### nonlocal weather_name_list
            ### nonlocal weather_name_id_list
            ### nonlocal business_code_list
            ### nonlocal business_name_list
            ### nonlocal business_name_code_list
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0000）
            ### (1)セル[8,2]からセル[8,21]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_compare()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=2).value not in list(building_code_list)) and (
                            ws[0].cell(row=j, column=2).value not in list(building_name_list)) and (
                            ws[0].cell(row=j, column=2).value not in list(building_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 2, constants.CHI_COM_MSG[1][0], constants.CHI_COM_MSG[1][1], constants.CHI_COM_MSG[1][2], constants.CHI_COM_MSG[1][3], constants.CHI_COM_MSG[1][4]])
                        else:
                            compare_info.append([ws[0].title, j, 2, 1])
                    
                    ### セル[8:3]: 水系種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=3).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=3).value not in list(building_code_list)) and (
                            ws[0].cell(row=j, column=3).value not in list(building_name_list)) and (
                            ws[0].cell(row=j, column=3).value not in list(building_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 3, constants.CHI_COM_MSG[2][0], constants.CHI_COM_MSG[2][1], constants.CHI_COM_MSG[2][2], constants.CHI_COM_MSG[2][3], constants.CHI_COM_MSG[2][4]])
                        else:
                            compare_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=4).value not in list(underground_code_list)) and (
                            ws[0].cell(row=j, column=4).value not in list(underground_name_list)) and (
                            ws[0].cell(row=j, column=4).value not in list(underground_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 4, constants.CHI_COM_MSG[3][0], constants.CHI_COM_MSG[3][1], constants.CHI_COM_MSG[3][2], constants.CHI_COM_MSG[3][3], constants.CHI_COM_MSG[3][4]])
                        else:
                            compare_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=5).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 5, constants.CHI_COM_MSG[4][0], constants.CHI_COM_MSG[4][1], constants.CHI_COM_MSG[4][2], constants.CHI_COM_MSG[4][3], constants.CHI_COM_MSG[4][4]])
                        else:
                            compare_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 代表被災地区名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:7]: 都道府県名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=7).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=7).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=7).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 7, constants.CHI_COM_MSG[6][0], constants.CHI_COM_MSG[6][1], constants.CHI_COM_MSG[6][2], constants.CHI_COM_MSG[6][3], constants.CHI_COM_MSG[6][4]])
                        else:
                            compare_info.append([ws[0].title, j, 7, 6])
    
                    ### セル[8:8]: 市区町村名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=8).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=8).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=8).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 8, constants.CHI_COM_MSG[7][0], constants.CHI_COM_MSG[7][1], constants.CHI_COM_MSG[7][2], constants.CHI_COM_MSG[7][3], constants.CHI_COM_MSG[7][4]])
                        else:
                            compare_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 都道府県コードについてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=9).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=9).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=9).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 9, constants.CHI_COM_MSG[8][0], constants.CHI_COM_MSG[8][1], constants.CHI_COM_MSG[8][2], constants.CHI_COM_MSG[8][3], constants.CHI_COM_MSG[8][4]])
                        else:
                            compare_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]:
                    ### セル[8:11]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=11).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=11).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=11).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 11, constants.CHI_COM_MSG[10][0], constants.CHI_COM_MSG[10][1], constants.CHI_COM_MSG[10][2], constants.CHI_COM_MSG[10][3], constants.CHI_COM_MSG[10][4]])
                        else:
                            compare_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:13]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:14]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:15]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:16]: 工種区分についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=16).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=16).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=16).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 16, constants.CHI_COM_MSG[15][0], constants.CHI_COM_MSG[15][1], constants.CHI_COM_MSG[15][2], constants.CHI_COM_MSG[15][3], constants.CHI_COM_MSG[15][4]])
                        else:
                            compare_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]:
                    ### セル[8:18]: 市区町村コードについてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=18).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=18).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=18).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=18).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 18, constants.CHI_COM_MSG[17][0], constants.CHI_COM_MSG[17][1], constants.CHI_COM_MSG[17][2], constants.CHI_COM_MSG[17][3], constants.CHI_COM_MSG[17][4]])
                        else:
                            compare_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[8:19]: 災害復旧箇所についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:20]: 災害復旧査定額千円についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:21]: 備考についてデータベースに登録されている値と突合せチェックする。
            return True
        
        except:
            return False

    try:
        #######################################################################
        #######################################################################
        ### 局所変数セット処理(0010)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 1/18.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info = []
        require_warn = []

        ### 形式チェック用の局所変数を初期化する。
        format_info = []
        format_warn = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info = []
        range_warn = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info = []
        correlate_warn = []

        ### 突合せチェックの結果を格納するために局所変数をセットする。
        compare_info = []
        compare_warn = []

        #######################################################################
        ### フォーム検証処理(0020)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 2/18.', 'DEBUG')
        form = UploadChitanForm(request.POST, request.FILES)
        if form.is_valid() == False:
            print_log('[WARN] P0120Ken.browser_post_chitan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた地方単独事業調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 3/18.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + output_file_name

        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
        
        #######################################################################
        ### EXCEL入出力処理(0040)
        ### (1)アップロードされた地方単独事業調査票ファイルのワークブックを読み込む。
        ### (2)CHITANワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 4/18.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        for ws_temp in wb.worksheets:
            if 'CHITAN' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)
                
        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)
        
        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(0050)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の7はNO.、水系・沿岸名等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 5/18.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 7
            for i in range(ws_temp.max_row+1, 7, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(0060)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 6/18.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(0070)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 7/18.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        ### cause_list
        ### kuiki_list
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### gradient_list
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        ### building_list
        ### underground_list
        ### flood_sediment_list
        ### industry_list
        business_list = BUSINESS.objects.raw("""SELECT * FROM BUSINESS ORDER BY CAST(BUSINESS_CODE AS INTEGER)""")
        ### usage_list
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        ### cause_code_list
        ### cause_name_list
        ### cause_name_code_list
        ### kuiki_id_list
        ### kuiki_name_list
        ### kuiki_name_id_list
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        ### gradient_code_list
        ### gradient_name_list
        ### gradient_name_code_list
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        ### building_code_list
        ### building_name_list
        ### building_name_code_list
        ### underground_code_list
        ### underground_name_list
        ### underground_name_code_list
        ### flood_sediment_code_list
        ### flood_sediment_name_list
        ### flood_sediment_name_code_list
        ### industry_code_list
        ### industry_name_list
        ### industry_name_code_list
        business_code_list = [business.business_code for business in business_list]
        business_name_list = [business.business_name for business in business_list]
        business_name_code_list = [str(business.business_name) + ":" + str(business.business_code) for business in business_list]
        ### usage_code_list
        ### usage_name_list
        ### usage_name_code_list

        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(0080)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 8/18.', 'DEBUG')
        bool_return_01 = check_require()
        bool_return_02 = check_format()
        bool_return_03 = check_range()
        bool_return_04 = check_correlate()
        bool_return_05 = check_compare()
        
        if (bool_return_01 == False) or (bool_return_02 == False) or (bool_return_03 == False) or (bool_return_04 == False) or (bool_return_05 == False):
            print_log('[ERROR] P0120Ken.browser_post_chitan()関数 check_()関数が異常終了しました。', 'ERROR')
            raise Exception

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0090)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 9/18.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0100)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 10/18.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(require_warn)={}'.format(len(require_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(format_warn)={}'.format(len(format_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(range_warn)={}'.format(len(range_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(correlate_warn)={}'.format(len(correlate_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(compare_warn)={}'.format(len(compare_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(require_info)={}'.format(len(require_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(format_info)={}'.format(len(format_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(range_info)={}'.format(len(range_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(correlate_info)={}'.format(len(correlate_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(compare_info)={}'.format(len(compare_info)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0110)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 11/18.', 'DEBUG')
        info_str = ''
        warn_str = ''
        for i in range(len(require_info)):
            info_str = info_str + \
                str(require_info[i][0]) + ',' + str(require_info[i][1]) + ',' + str(require_info[i][2]) + ',' + \
                str(constants.CHI_REQ_MSG[require_info[i][3]][0]) + ',' + str(constants.CHI_REQ_MSG[require_info[i][3]][1]) + ',' + str(constants.CHI_REQ_MSG[require_info[i][3]][2]) + '\n'        
        
        for i in range(len(format_info)):
            info_str = info_str + \
                str(format_info[i][0]) + ',' + str(format_info[i][1]) + ',' + str(format_info[i][2]) + ',' + \
                str(constants.CHI_FOR_MSG[format_info[i][3]][0]) + ',' + str(constants.CHI_FOR_MSG[format_info[i][3]][1]) + ',' + str(constants.CHI_FOR_MSG[format_info[i][3]][2]) + '\n'        

        for i in range(len(range_info)):
            info_str = info_str + \
                str(range_info[i][0]) + ',' + str(range_info[i][1]) + ',' + str(range_info[i][2]) + ',' + \
                str(constants.CHI_RAN_MSG[range_info[i][3]][0]) + ',' + str(constants.CHI_RAN_MSG[range_info[i][3]][1]) + ',' + str(constants.CHI_RAN_MSG[range_info[i][3]][2]) + '\n'        

        for i in range(len(correlate_info)):
            info_str = info_str + \
                str(correlate_info[i][0]) + ',' + str(correlate_info[i][1]) + ',' + str(correlate_info[i][2]) + ',' + \
                str(constants.CHI_COR_MSG[correlate_info[i][3]][0]) + ',' + str(constants.CHI_COR_MSG[correlate_info[i][3]][1]) + ',' + str(constants.CHI_COR_MSG[correlate_info[i][3]][2]) + '\n'        

        for i in range(len(compare_info)):
            info_str = info_str + \
                str(compare_info[i][0]) + ',' + str(compare_info[i][1]) + ',' + str(compare_info[i][2]) + ',' + \
                str(constants.CHI_COM_MSG[compare_info[i][3]][0]) + ',' + str(constants.CHI_COM_MSG[compare_info[i][3]][1]) + ',' + str(constants.CHI_COM_MSG[compare_info[i][3]][2]) + '\n'        

        for i in range(len(require_warn)):
            warn_str = warn_str + \
                str(require_warn[i][0]) + ',' + str(require_warn[i][1]) + ',' + str(require_warn[i][2]) + ',' + \
                str(constants.CHI_REQ_MSG[require_warn[i][3]][0]) + ',' + str(constants.CHI_REQ_MSG[require_warn[i][3]][1]) + ',' + str(constants.CHI_REQ_MSG[require_warn[i][3]][2]) + '\n'        
        
        for i in range(len(format_warn)):
            warn_str = warn_str + \
                str(format_warn[i][0]) + ',' + str(format_warn[i][1]) + ',' + str(format_warn[i][2]) + ',' + \
                str(constants.CHI_FOR_MSG[format_warn[i][3]][0]) + ',' + str(constants.CHI_FOR_MSG[format_warn[i][3]][1]) + ',' + str(constants.CHI_FOR_MSG[format_warn[i][3]][2]) + '\n'        

        for i in range(len(range_warn)):
            warn_str = warn_str + \
                str(range_warn[i][0]) + ',' + str(range_warn[i][1]) + ',' + str(range_warn[i][2]) + ',' + \
                str(constants.CHI_RAN_MSG[range_warn[i][3]][0]) + ',' + str(constants.CHI_RAN_MSG[range_warn[i][3]][1]) + ',' + str(constants.CHI_RAN_MSG[range_warn[i][3]][2]) + '\n'        

        for i in range(len(correlate_warn)):
            warn_str = warn_str + \
                str(correlate_warn[i][0]) + ',' + str(correlate_warn[i][1]) + ',' + str(correlate_warn[i][2]) + ',' + \
                str(constants.CHI_COR_MSG[correlate_warn[i][3]][0]) + ',' + str(constants.CHI_COR_MSG[correlate_warn[i][3]][1]) + ',' + str(constants.CHI_COR_MSG[correlate_warn[i][3]][2]) + '\n'        

        for i in range(len(compare_warn)):
            warn_str = warn_str + \
                str(compare_warn[i][0]) + ',' + str(compare_warn[i][1]) + ',' + str(compare_warn[i][2]) + ',' + \
                str(constants.CHI_COM_MSG[compare_warn[i][3]][0]) + ',' + str(constants.CHI_COM_MSG[compare_warn[i][3]][1]) + ',' + str(constants.CHI_COM_MSG[compare_warn[i][3]][2]) + '\n'        

        #######################################################################
        #######################################################################
        ### 【警告】条件分岐処理(1000)
        ### ※入力チェックでエラーが発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 12/18.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or len(range_warn) > 0 or len(correlate_warn) > 0 or len(compare_warn) > 0:

            ###################################################################
            ### 【警告】DBアクセス処理(1010)
            ### ※入力チェックで警告が発見された場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 13/18.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")

                PARAMS = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=8, column=9).value)[-1]
                })
                SQL_UPDATE_CHITAN_HEADER = """
                    UPDATE CHITAN_HEADER SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE CHITAN_HEADER_ID IN (
                    SELECT 
                        CHITAN_HEADER_ID 
                    FROM CHITAN_HEADER 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_CHITAN = """
                    UPDATE CHITAN SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE CHITAN_ID IN (
                    SELECT 
                        CHITAN_ID 
                    FROM CHITAN_VIEW 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_CHITAN_SUMMARY = """ 
                    UPDATE CHITAN_SUMMARY SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE CHITAN_ID IN ( 
                    SELECT 
                        CHITAN_ID 
                    FROM CHITAN_SUMMARY_VIEW 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                
                connection_cursor.execute(SQL_UPDATE_CHITAN_HEADER,  PARAMS)
                connection_cursor.execute(SQL_UPDATE_CHIAN,          PARAMS)
                connection_cursor.execute(SQL_UPDATE_CHITAN_SUMMARY, PARAMS)

                ### _CHI_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
                ### _CHI_ACT_02等でも良い。
                ### 同じ都道府県コードのトリガーが削除済に更新される。
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': split_name_code(ws[0].cell(row=8, column=9).value)[-1], 
                    'action_code': _CHI_ACT_01
                })
                bool_return = delete_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[ERROR] P0120Ken.browser_post_chitan()関数 publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] P0120Ken.browser_post_chitan()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_chitan()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_chitan()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### 【警告】レスポンスセット処理(1020)
            ### ※入力チェックで警告が発見された場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 14/18.', 'DEBUG')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'browser_post_chitan_warn': 'browser_post_chitan_warn',
                'require_warn': require_warn,
                'format_warn': format_warn,
                'range_warn': range_warn,
                'correlate_warn': correlate_warn,
                'compare_warn': compare_warn,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0120Ken.browser_post_chitan()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        #######################################################################
        ### 【正常】DBアクセス処理(2000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 15/18.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")

            ###################################################################
            ### 【正常】DBアクセス処理(2010) STEP1
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存データの削除日に値をセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 16/18.', 'DEBUG')
            PARAMS = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=9).value)[-1]
            })
            SQL_UPDATE_CHITAN_HEADER = """
                    UPDATE CHITAN_HEADER SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE CHITAN_HEADER_ID IN (
                    SELECT 
                        CHITAN_HEADER_ID 
                    FROM CHITAN_HEADER 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
            SQL_UPDATE_CHITAN = """
                UPDATE CHITAN SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_ID IN (
                SELECT 
                    CHITAN_ID 
                FROM CHITAN_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_CHITAN_SUMMARY = """
                UPDATE CHITAN_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_ID IN (
                SELECT 
                    CHITAN_ID 
                FROM CHITAN_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
           
            connection_cursor.execute(SQL_UPDATE_CHITAN_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_CHITAN,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_CHITAN_SUMMARY, PARAMS)

            ### _CHI_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _CHI_ACT_02等でも良い。
            ### 同じ都道府県コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': split_name_code(ws[0].cell(row=8, column=9).value)[-1], 
                'city_code': None, 
                'action_code': _CHI_ACT_01
            })
            bool_return = delete_message(PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0120Ken.browser_post_chitan()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            ###################################################################
            ### 【正常】DBアクセス処理(2020) STEP2
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※アップロードされたデータを登録する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 17/18.', 'DEBUG')
            for i, _ in enumerate(ws):
                chitan_header_id = CHITAN_HEADER.objects.all().aggregate(Max('chitan_header_id'))['chitan_header_id__max']
                if chitan_header_id is None:
                    chitan_header_id = 1
                else:
                    chitan_header_id += 1

                if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
                    PARAMS = dict({
                        'CHITAN_HEADER_ID': chitan_header_id, 
                        'CHITAN_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=9).value)[-1]), 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None, 
                        'DELETED_AT': None,
                        'CHITAN_KEN_UPLOAD': _PROVISIONED_CHITAN_KEN_UPLOAD,
                    })
                else:
                    PARAMS = dict({
                        'CHITAN_HEADER_ID': chitan_header_id, 
                        'CHITAN_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=9).value)[-1]), 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None, 
                        'DELETED_AT': None,
                        'CHITAN_KEN_UPLOAD': _CONFIRMED_CHITAN_KEN_UPLOAD,
                    })
                SQL_INSERT_CHITAN_HEADER = """
                    INSERT INTO CHITAN_HEADER (
                        CHITAN_HEADER_ID, CHITAN_HEADER_NAME, KEN_CODE, 
                        UPLOAD_FILE_PATH, UPLOAD_FILE_NAME, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME, 
                        COMMITTED_AT, DELETED_AT 
                    ) VALUES (
                        %(CHITAN_HEADER_ID)s, 
                        %(CHITAN_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s, 
                        CURRENT_TIMESTAMP,  -- COMMITTED_AT 
                        %(DELETED_AT)s)"""
                SQL_INSERT_CHITAN_HISTORY = """
                    INSERT INTO CHITAN_HISTORY (
                        CHITAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
                    ) VALUES (
                        %(CHITAN_HEADER_ID)s,
                        %(CHITAN_KEN_UPLOAD)s,
                        CURRENT_TIMESTAMP)"""

                connection_cursor.execute(SQL_INSERT_CHITAN_HEADER,  PARAMS)
                connection_cursor.execute(SQL_INSERT_CHITAN_HISTORY, PARAMS)
                    
                ###############################################################
                ### 【正常】DBアクセス処理(2030) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※アップロードされたデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 17_1/18.', 'DEBUG')
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if (max_row[i] >= 8):
                    for j in range(8, max_row[i]+1):
                        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 j={}'.format(j), 'DEBUG')
                        PARAMS_INSERT_CHITAN = dict({
                            'CHITAN_NAME': convert_empty_to_none(ws[i].cell(row=j, column=6).value), 
                            'CHITAN_HEADER_ID': chitan_header_id, 
                            'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=10).value)[-1]), 
                            'BEGIN_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=12).value)[-1]), 
                            'END_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=14).value)[-1]), 
                            'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=2).value)[-1]), 
                            'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=3).value)[-1]), 
                            'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=5).value)[-1]), 
                            'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=16).value)[-1]), 
                            'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=11).value)[-1]), 
                            'DISASTER_POINT': convert_empty_to_none(ws[i].cell(row=j, column=19).value), 
                            'ESTIMATED_COST': convert_empty_to_none(ws[i].cell(row=j, column=20).value), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=21).value), 
                            'DELETED_AT': None
                        })
                        SQL_INSERT_CHITAN = """ 
                            INSERT INTO CHITAN (
                                CHITAN_ID, CHITAN_NAME, CHITAN_HEADER_ID, 
                                CITY_CODE, BEGIN_DATE, END_DATE, 
                                SUIKEI_CODE, SUIKEI_TYPE_CODE, KASEN_CODE, KASEN_TYPE_CODE, KASEN_KAIGAN_CODE, WEATHER_ID, 
                                DISASTER_POINT, ESTIMATED_COST, COMMENT, 
                                COMMITTED_AT, DELETED_AT 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(CHITAN_ID+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(CHITAN_ID+1) AS INTEGER) END AS chitan_id FROM CHITAN), -- chitan_id 
                                %(CHITAN_NAME)s, 
                                %(CHITAN_HEADER_ID)s, 
                                %(CITY_CODE)s, 
                                TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                                TO_DATE(%(END_DATE)s, 'YYYY/MM/DD'), 
                                %(SUIKEI_CODE)s, 
                                %(SUIKEI_TYPE_CODE)s, 
                                %(KASEN_CODE)s, 
                                %(KASEN_TYPE_CODE)s, 
                                %(KASEN_KAIGAN_CODE)s, 
                                %(WEATHER_ID)s, 
                                %(DISATER_POINT)s, 
                                %(ESTIMATED_COST)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- COMMITTED_AT 
                                %(DELETED_AT)s)"""

                        connection_cursor.execute(SQL_INSERT_CHITAN, PARAMS_INSERT_CHITAN)

                ###############################################################
                ### 【正常】DBアクセス処理(2040) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにCHI_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 17_2/18.', 'DEBUG')
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': chitan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=8, column=9).value)[-1]), 
                    'city_code': None, 
                    'action_code': _CHI_ACT_01, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[ERROR] P0120Ken.browser_post_chitan()関数 publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")     
            
        except:
            print_log('[ERROR] P0120Ken.browser_post_chitan()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_chitan()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_chitan()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        finally:
            connection_cursor.close()
        
        #######################################################################
        ### 【正常】レスポンスセット処理(2050)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 18/18.', 'DEBUG')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'browser_post_chitan_info': 'browser_post_chitan_info',
            'require_info': require_info, 
            'format_info': format_info,
            'range_info': range_info,
            'correlate_info': correlate_info,
            'compare_info': compare_info,
        }
        print_log('[INFO] P0120Ken.browser_post_chitan()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0120Ken.browser_post_chitan()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_chitan()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_chitan()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def browser_post_hojo(request):

    ###########################################################################
    ### 関数内関数：EXCELセルデータ必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal require_warn
            nonlocal require_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_require()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=1).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 1, constants.HOJ_REQ_MSG[0][0], constants.HOJ_REQ_MSG[0][1], constants.HOJ_REQ_MSG[0][2], constants.HOJ_REQ_MSG[0][3], constants.HOJ_REQ_MSG[0][4]])
                    else:
                        require_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[8:2]: 水系・沿岸名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 2, constants.HOJ_REQ_MSG[1][0], constants.HOJ_REQ_MSG[1][1], constants.HOJ_REQ_MSG[1][2], constants.HOJ_REQ_MSG[1][3], constants.HOJ_REQ_MSG[1][4]])
                    else:
                        require_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=3).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 3, constants.HOJ_REQ_MSG[2][0], constants.HOJ_REQ_MSG[2][1], constants.HOJ_REQ_MSG[2][2], constants.HOJ_REQ_MSG[2][3], constants.HOJ_REQ_MSG[2][4]])
                    else:
                        require_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 4, constants.HOJ_REQ_MSG[3][0], constants.HOJ_REQ_MSG[3][1], constants.HOJ_REQ_MSG[3][2], constants.HOJ_REQ_MSG[3][3], constants.HOJ_REQ_MSG[3][4]])
                    else:
                        require_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 5, constants.HOJ_REQ_MSG[4][0], constants.HOJ_REQ_MSG[4][1], constants.HOJ_REQ_MSG[4][2], constants.HOJ_REQ_MSG[4][3], constants.HOJ_REQ_MSG[4][4]])
                    else:
                        require_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 都道府県コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 6, constants.HOJ_REQ_MSG[5][0], constants.HOJ_REQ_MSG[5][1], constants.HOJ_REQ_MSG[5][2], constants.HOJ_REQ_MSG[5][3], constants.HOJ_REQ_MSG[5][4]])
                    else:
                        require_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[8:7]: 工事番号に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 7, constants.HOJ_REQ_MSG[6][0], constants.HOJ_REQ_MSG[6][1], constants.HOJ_REQ_MSG[6][2], constants.HOJ_REQ_MSG[6][3], constants.HOJ_REQ_MSG[6][4]])
                    else:
                        require_info.append([ws[0].title, j, 7, 6])
    
                    ### セル[8:8]: 枝番に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 8, constants.HOJ_REQ_MSG[7][0], constants.HOJ_REQ_MSG[7][1], constants.HOJ_REQ_MSG[7][2], constants.HOJ_REQ_MSG[7][3], constants.HOJ_REQ_MSG[7][4]])
                    else:
                        require_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 工事区分に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 9, constants.HOJ_REQ_MSG[8][0], constants.HOJ_REQ_MSG[8][1], constants.HOJ_REQ_MSG[8][2], constants.HOJ_REQ_MSG[8][3], constants.HOJ_REQ_MSG[8][4]])
                    else:
                        require_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]: 市区町村コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=10).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 10, constants.HOJ_REQ_MSG[9][0], constants.HOJ_REQ_MSG[9][1], constants.HOJ_REQ_MSG[9][2], constants.HOJ_REQ_MSG[9][3], constants.HOJ_REQ_MSG[9][4]])
                    else:
                        require_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[8:11]: 工種区分に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 11, constants.HOJ_REQ_MSG[10][0], constants.HOJ_REQ_MSG[10][1], constants.HOJ_REQ_MSG[10][2], constants.HOJ_REQ_MSG[10][3], constants.HOJ_REQ_MSG[10][4]])
                    else:
                        require_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 13, constants.HOJ_REQ_MSG[12][0], constants.HOJ_REQ_MSG[12][1], constants.HOJ_REQ_MSG[12][2], constants.HOJ_REQ_MSG[12][3], constants.HOJ_REQ_MSG[12][4]])
                    else:
                        require_info.append([ws[0].title, j, 13, 12])
    
                    ### セル[8:14]: 水害発生月に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 14, constants.HOJ_REQ_MSG[13][0], constants.HOJ_REQ_MSG[13][1], constants.HOJ_REQ_MSG[13][2], constants.HOJ_REQ_MSG[13][3], constants.HOJ_REQ_MSG[13][4]])
                    else:
                        require_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[8:15]: 水害発生日に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 15, constants.HOJ_REQ_MSG[14][0], constants.HOJ_REQ_MSG[14][1], constants.HOJ_REQ_MSG[14][2], constants.HOJ_REQ_MSG[14][3], constants.HOJ_REQ_MSG[14][4]])
                    else:
                        require_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[8:16]: 決定額(千円)に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 16, constants.HOJ_REQ_MSG[15][0], constants.HOJ_REQ_MSG[15][1], constants.HOJ_REQ_MSG[15][2], constants.HOJ_REQ_MSG[15][3], constants.HOJ_REQ_MSG[15][4]])
                    else:
                        require_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]: 備考に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=17).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 17, constants.HOJ_REQ_MSG[16][0], constants.HOJ_REQ_MSG[16][1], constants.HOJ_REQ_MSG[16][2], constants.HOJ_REQ_MSG[16][3], constants.HOJ_REQ_MSG[16][4]])
                    else:
                        require_info.append([ws[0].title, j, 17, 16])
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal format_warn
            nonlocal format_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_format()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=1).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=1).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 1, constants.HOJ_FOR_MSG[0][0], constants.HOJ_FOR_MSG[0][1], constants.HOJ_FOR_MSG[0][2], constants.HOJ_FOR_MSG[0][3], constants.HOJ_FOR_MSG[0][4]])
                        else:
                            format_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[8:2]: 水系・沿岸名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=2).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 2, constants.HOJ_FOR_MSG[1][0], constants.HOJ_FOR_MSG[1][1], constants.HOJ_FOR_MSG[1][2], constants.HOJ_FOR_MSG[1][3], constants.HOJ_FOR_MSG[1][4]])
                        else:
                            format_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=3).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=3).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 3, constants.HOJ_FOR_MSG[2][0], constants.HOJ_FOR_MSG[2][1], constants.HOJ_FOR_MSG[2][2], constants.HOJ_FOR_MSG[2][3], constants.HOJ_FOR_MSG[2][4]])
                        else:
                            format_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=4).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 4, constants.HOJ_FOR_MSG[3][0], constants.HOJ_FOR_MSG[3][1], constants.HOJ_FOR_MSG[3][2], constants.HOJ_FOR_MSG[3][3], constants.HOJ_FOR_MSG[3][4]])
                        else:
                            format_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=5).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 5, constants.HOJ_FOR_MSG[4][0], constants.HOJ_FOR_MSG[4][1], constants.HOJ_FOR_MSG[4][2], constants.HOJ_FOR_MSG[4][3], constants.HOJ_FOR_MSG[4][4]])
                        else:
                            format_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 都道府県コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=6).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=6).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 6, constants.HOJ_FOR_MSG[5][0], constants.HOJ_FOR_MSG[5][1], constants.HOJ_FOR_MSG[5][2], constants.HOJ_FOR_MSG[5][3], constants.HOJ_FOR_MSG[5][4]])
                        else:
                            format_info.append([ws[0].title, j, 6, 5])
                        
                    ### セル[8:7]: 工事番号について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=7).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=7).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 7, constants.HOJ_FOR_MSG[6][0], constants.HOJ_FOR_MSG[6][1], constants.HOJ_FOR_MSG[6][2], constants.HOJ_FOR_MSG[6][3], constants.HOJ_FOR_MSG[6][4]])
                        else:
                            format_info.append([ws[0].title, j, 7, 6])
                        
                    ### セル[8:8]: 枝番について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=8).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=8).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 8, constants.HOJ_FOR_MSG[7][0], constants.HOJ_FOR_MSG[7][1], constants.HOJ_FOR_MSG[7][2], constants.HOJ_FOR_MSG[7][3], constants.HOJ_FOR_MSG[7][4]])
                        else:
                            format_info.append([ws[0].title, j, 8, 7])
                        
                    ### セル[8:9]: 工事区分について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=9).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=9).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 9, constants.HOJ_FOR_MSG[8][0], constants.HOJ_FOR_MSG[8][1], constants.HOJ_FOR_MSG[8][2], constants.HOJ_FOR_MSG[8][3], constants.HOJ_FOR_MSG[8][4]])
                        else:
                            format_info.append([ws[0].title, j, 9, 8])
                        
                    ### セル[8:10]: 市区町村コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=10).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=10).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=10).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 10, constants.HOJ_FOR_MSG[9][0], constants.HOJ_FOR_MSG[9][1], constants.HOJ_FOR_MSG[9][2], constants.HOJ_FOR_MSG[9][3], constants.HOJ_FOR_MSG[9][4]])
                        else:
                            format_info.append([ws[0].title, j, 10, 9])
                        
                    ### セル[8:11]: 工種区分について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=11).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=11).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 11, constants.HOJ_FOR_MSG[10][0], constants.HOJ_FOR_MSG[10][1], constants.HOJ_FOR_MSG[10][2], constants.HOJ_FOR_MSG[10][3], constants.HOJ_FOR_MSG[10][4]])
                        else:
                            format_info.append([ws[0].title, j, 11, 10])
                        
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードについて形式が正しいことをチェックする。
                    if (ws[i].cell(row=j, column=13).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=13).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=13).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 13, constants.HOJ_FOR_MSG[12][0], constants.HOJ_FOR_MSG[12][1], constants.HOJ_FOR_MSG[12][2], constants.HOJ_FOR_MSG[12][3], constants.HOJ_FOR_MSG[12][4]])
                        else:
                            format_info.append([ws[0].title, j, 13, 12])
                        
                    ### セル[8:14]: 水害発生月について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=14).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=14).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 14, constants.HOJ_FOR_MSG[13][0], constants.HOJ_FOR_MSG[13][1], constants.HOJ_FOR_MSG[13][2], constants.HOJ_FOR_MSG[13][3], constants.HOJ_FOR_MSG[13][4]])
                        else:
                            format_info.append([ws[0].title, j, 14, 13])
                        
                    ### セル[8:15]: 水害発生日について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=15).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=15).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 15, constants.HOJ_FOR_MSG[14][0], constants.HOJ_FOR_MSG[14][1], constants.HOJ_FOR_MSG[14][2], constants.HOJ_FOR_MSG[14][3], constants.HOJ_FOR_MSG[14][4]])
                        else:
                            format_info.append([ws[0].title, j, 15, 14])
                        
                    ### セル[8:16]: 決定額(千円)について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=16).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=16).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 16, constants.HOJ_FOR_MSG[15][0], constants.HOJ_FOR_MSG[15][1], constants.HOJ_FOR_MSG[15][2], constants.HOJ_FOR_MSG[15][3], constants.HOJ_FOR_MSG[15][4]])
                        else:
                            format_info.append([ws[0].title, j, 16, 15])
                        
                    ### セル[8:17]: 備考について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=17).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=17).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=17).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 17, constants.HOJ_FOR_MSG[16][0], constants.HOJ_FOR_MSG[16][1], constants.HOJ_FOR_MSG[16][2], constants.HOJ_FOR_MSG[16][3], constants.HOJ_FOR_MSG[16][4]])
                        else:
                            format_info.append([ws[0].title, j, 17, 16])
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal range_warn
            nonlocal range_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_range()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について範囲が正しいことをチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:3]: 水系種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:4]: 河川・海岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:5]: 河川種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:6]: 都道府県コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=6).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=6).value, float) == True):
                            if (float(ws[0].cell(row=j, column=6).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 6, constants.HOJ_RAN_MSG[5][0], constants.HOJ_RAN_MSG[5][1], constants.HOJ_RAN_MSG[5][2], constants.HOJ_RAN_MSG[5][3], constants.HOJ_RAN_MSG[5][4]])
                            else:
                                range_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[8:7]: 工事番号について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=7).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=7).value, float) == True):
                            if (float(ws[0].cell(row=j, column=7).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 7, constants.HOJ_RAN_MSG[6][0], constants.HOJ_RAN_MSG[6][1], constants.HOJ_RAN_MSG[6][2], constants.HOJ_RAN_MSG[6][3], constants.HOJ_RAN_MSG[6][4]])
                            else:
                                range_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[8:8]: 枝番について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=8).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=8).value, float) == True):
                            if (float(ws[0].cell(row=j, column=8).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 8, constants.HOJ_RAN_MSG[7][0], constants.HOJ_RAN_MSG[7][1], constants.HOJ_RAN_MSG[7][2], constants.HOJ_RAN_MSG[7][3], constants.HOJ_RAN_MSG[7][4]])
                            else:
                                range_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 工事区分について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=9).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=9).value, float) == True):
                            if (float(ws[0].cell(row=j, column=9).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 9, constants.HOJ_RAN_MSG[8][0], constants.HOJ_RAN_MSG[8][1], constants.HOJ_RAN_MSG[8][2], constants.HOJ_RAN_MSG[8][3], constants.HOJ_RAN_MSG[8][4]])
                            else:
                                range_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]: 市区町村コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=10).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=10).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=10).value, float) == True):
                            if (float(ws[0].cell(row=j, column=10).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 10, constants.HOJ_RAN_MSG[9][0], constants.HOJ_RAN_MSG[9][1], constants.HOJ_RAN_MSG[9][2], constants.HOJ_RAN_MSG[9][3], constants.HOJ_RAN_MSG[9][4]])
                            else:
                                range_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[8:11]: 工種区分について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=11).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=11).value, float) == True):
                            if (float(ws[0].cell(row=j, column=11).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 11, constants.HOJ_RAN_MSG[10][0], constants.HOJ_RAN_MSG[10][1], constants.HOJ_RAN_MSG[10][2], constants.HOJ_RAN_MSG[10][3], constants.HOJ_RAN_MSG[10][4]])
                            else:
                                range_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=13).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=13).value, float) == True):
                            if (float(ws[0].cell(row=j, column=13).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 13, constants.HOJ_RAN_MSG[12][0], constants.HOJ_RAN_MSG[12][1], constants.HOJ_RAN_MSG[12][2], constants.HOJ_RAN_MSG[12][3], constants.HOJ_RAN_MSG[12][4]])
                            else:
                                range_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[8:14]: 水害発生月について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=14).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=14).value, float) == True):
                            if (float(ws[0].cell(row=j, column=14).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 14, constants.HOJ_RAN_MSG[13][0], constants.HOJ_RAN_MSG[13][1], constants.HOJ_RAN_MSG[13][2], constants.HOJ_RAN_MSG[13][3], constants.HOJ_RAN_MSG[13][4]])
                            else:
                                range_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[8:15]: 水害発生日について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=15).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=15).value, float) == True):
                            if (float(ws[0].cell(row=j, column=15).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 15, constants.HOJ_RAN_MSG[14][0], constants.HOJ_RAN_MSG[14][1], constants.HOJ_RAN_MSG[14][2], constants.HOJ_RAN_MSG[14][3], constants.HOJ_RAN_MSG[14][4]])
                            else:
                                range_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[8:16]: 決定額(千円)について範囲が正しいことをチェックする。
                    if (ws[i].cell(row=j, column=16).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=16).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=16).value, float) == True):
                            if (float(ws[0].cell(row=j, column=16).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 16, constants.HOJ_RAN_MSG[15][0], constants.HOJ_RAN_MSG[15][1], constants.HOJ_RAN_MSG[15][2], constants.HOJ_RAN_MSG[15][3], constants.HOJ_RAN_MSG[15][4]])
                            else:
                                range_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]: 備考について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=17).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=17).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=17).value, float) == True):
                            if (float(ws[0].cell(row=j, column=17).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 17, constants.HOJ_RAN_MSG[16][0], constants.HOJ_RAN_MSG[16][1], constants.HOJ_RAN_MSG[16][2], constants.HOJ_RAN_MSG[16][3], constants.HOJ_RAN_MSG[16][4]])
                            else:
                                range_info.append([ws[0].title, j, 17, 16])
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal correlate_warn
            nonlocal correlate_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_correlate()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[i]+1):
                    pass
                    ### セル[8:1]: NO.が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:2]: 水系・沿岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:3]: 水系種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:4]: 河川・海岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:5]: 河川種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:6]: 都道府県コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:7]: 工事番号が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:8]: 枝番が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:9]: 工事区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:10]: 市区町村コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:11]: 工種区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:12]:
                    ### セル[8:13]: 異常気象コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:14]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:15]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:16]: 決定額(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:17]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal compare_warn
            nonlocal compare_info
            ### nonlocal max_row
            ### nonlocal ken_code_list
            ### nonlocal ken_name_list
            ### nonlocal ken_name_code_list
            ### nonlocal city_code_list
            ### nonlocal city_name_list
            ### nonlocal city_name_code_list
            ### nonlocal suikei_code_list
            ### nonlocal suikei_name_list
            ### nonlocal suikei_name_code_list
            ### nonlocal suikei_type_code_list
            ### nonlocal suikei_type_name_list
            ### nonlocal suikei_type_name_code_list
            ### nonlocal kasen_code_list
            ### nonlocal kasen_name_list
            ### nonlocal kasen_name_code_list
            ### nonlocal kasen_type_code_list
            ### nonlocal kasen_type_name_list
            ### nonlocal kasen_type_name_code_list
            ### nonlocal kasen_kaigan_code_list
            ### nonlocal kasen_kaigan_name_list
            ### nonlocal kasen_kaigan_name_code_list
            ### nonlocal weather_id_list
            ### nonlocal weather_name_list
            ### nonlocal weather_name_id_list
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_compare()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 8):
                for j in range(8, max_row[i]+1):
                    ### セル[8:1]: NO.についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=2).value not in list(building_code_list)) and (
                            ws[0].cell(row=j, column=2).value not in list(building_name_list)) and (
                            ws[0].cell(row=j, column=2).value not in list(building_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 2, constants.HOJ_COM_MSG[1][0], constants.HOJ_COM_MSG[1][1], constants.HOJ_COM_MSG[1][2], constants.HOJ_COM_MSG[1][3], constants.HOJ_COM_MSG[1][4]])
                        else:
                            compare_info.append([ws[0].title, j, 2, 1])
                    
                    ### セル[8:3]: 水系種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=3).value not in list(building_code_list)) and (
                            ws[0].cell(row=j, column=3).value not in list(building_name_list)) and (
                            ws[0].cell(row=j, column=3).value not in list(building_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 3, constants.HOJ_COM_MSG[2][0], constants.HOJ_COM_MSG[2][1], constants.HOJ_COM_MSG[2][2], constants.HOJ_COM_MSG[2][3], constants.HOJ_COM_MSG[2][4]])
                        else:
                            compare_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=4).value not in list(underground_code_list)) and (
                            ws[0].cell(row=j, column=4).value not in list(underground_name_list)) and (
                            ws[0].cell(row=j, column=4).value not in list(underground_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 4, constants.HOJ_COM_MSG[3][0], constants.HOJ_COM_MSG[3][1], constants.HOJ_COM_MSG[3][2], constants.HOJ_COM_MSG[3][3], constants.HOJ_COM_MSG[3][4]])
                        else:
                            compare_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        pass
                    else:
                        if (ws[0].cell(row=j, column=5).value not in list(flood_sediment_code_list)) and (
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_list)) and (
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_code_list)):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 5, constants.HOJ_COM_MSG[4][0], constants.HOJ_COM_MSG[4][1], constants.HOJ_COM_MSG[4][2], constants.HOJ_COM_MSG[4][3], constants.HOJ_COM_MSG[4][4]])
                        else:
                            compare_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 都道府県コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:7]: 工事番号についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:8]: 枝番についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:9]: 工事区分についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:10]: 市区町村コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:11]: 工種区分についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:14]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:15]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:16]: 決定額(千円)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:17]: 備考についてデータベースに登録されている値と突合せチェックする。
            return True
        
        except:
            return False

    try:
        #######################################################################
        #######################################################################
        ### 局所変数セット処理(0010)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120ken.browser_post_hojo()関数 STEP 1/18.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info = []
        require_warn = []

        ### 形式チェック用の局所変数を初期化する。
        format_info = []
        format_warn = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info = []
        range_warn = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info = []
        correlate_warn = []

        ### 突合せチェックの結果を格納する
        compare_info = []
        compare_warn = []
    
        #######################################################################
        ### フォーム検証処理(0020)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 2/18.', 'DEBUG')
        form = UploadHojoForm(request.POST, request.FILES)
        if form.is_valid() == False:
            print_log('[WARN] P0120Ken.browser_post_hojo()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた公共土木施設補助事業調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 3/18.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + output_file_name
        
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
                
        #######################################################################
        ### EXCEL入出力処理(0040)
        ### (1)アップロードされた補助事業調査票ファイルのワークブックを読み込む。
        ### (2)HOJOワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 4/18.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        for ws_temp in wb.worksheets:
            if 'HOJO' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)
                
        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)
        
        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(0050)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の7はNO.、水系・沿岸名等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 5/18.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 7
            for i in range(ws_temp.max_row+1, 7, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(0060)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 6/18.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(0070)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 7/18.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        ### cause_list
        ### kuiki_list
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### gradient_list
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        ### building_list
        ### underground_list
        ### flood_sediment_list
        industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
        ### business_list
        ### usage_list
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        ### cause_code_list
        ### cause_name_list
        ### cause_name_code_list
        ### kuiki_id_list
        ### kuiki_name_list
        ### kuiki_name_id_list
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        ### gradient_code_list
        ### gradient_name_list
        ### gradient_name_code_list
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        ### building_code_list
        ### building_name_list
        ### building_name_code_list
        ### underground_code_list
        ### underground_name_list
        ### underground_name_code_list
        ### flood_sediment_code_list
        ### flood_sediment_name_list
        ### flood_sediment_name_code_list
        ### industry_code_list
        ### industry_name_list
        ### industry_name_code_list
        ### business_code_list
        ### business_name_list
        ### business_name_code_list
        ### usage_code_list
        ### usage_name_list
        ### usage_name_code_list
    
        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(0080)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 8/18.', 'DEBUG')
        bool_return_01 = check_require()
        bool_return_02 = check_format()
        bool_return_03 = check_range()
        bool_return_04 = check_correlate()
        bool_return_05 = check_compare()

        if (bool_return_01 == False) or (bool_return_02 == False) or (bool_return_03 == False) or (bool_return_04 == False) or (bool_return_05 == False):
            print_log('[ERROR] P0120Ken.browser_post_hojo()関数 check_()関数が異常終了しました。', 'ERROR')
            raise Exception

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0090)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 9/18.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0100)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 10/18.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(require_warn)={}'.format(len(require_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(format_warn)={}'.format(len(format_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(range_warn)={}'.format(len(range_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(correlate_warn)={}'.format(len(correlate_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(compare_warn)={}'.format(len(compare_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(require_info)={}'.format(len(require_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(format_info)={}'.format(len(format_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(range_info)={}'.format(len(range_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(correlate_info)={}'.format(len(correlate_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(compare_info)={}'.format(len(compare_info)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(1010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 11/18.', 'DEBUG')
        info_str = ''
        warn_str = ''
        for i in range(len(require_info)):
            info_str = info_str + \
                str(require_info[i][0]) + ',' + str(require_info[i][1]) + ',' + str(require_info[i][2]) + ',' + \
                str(constants.HOJ_REQ_MSG[require_info[i][3]][0]) + ',' + str(constants.HOJ_REQ_MSG[require_info[i][3]][1]) + ',' + str(constants.HOJ_REQ_MSG[require_info[i][3]][2]) + '\n'        
        
        for i in range(len(format_info)):
            info_str = info_str + \
                str(format_info[i][0]) + ',' + str(format_info[i][1]) + ',' + str(format_info[i][2]) + ',' + \
                str(constants.HOJ_FOR_MSG[format_info[i][3]][0]) + ',' + str(constants.HOJ_FOR_MSG[format_info[i][3]][1]) + ',' + str(constants.HOJ_FOR_MSG[format_info[i][3]][2]) + '\n'        

        for i in range(len(range_info)):
            info_str = info_str + \
                str(range_info[i][0]) + ',' + str(range_info[i][1]) + ',' + str(range_info[i][2]) + ',' + \
                str(constants.HOJ_RAN_MSG[range_info[i][3]][0]) + ',' + str(constants.HOJ_RAN_MSG[range_info[i][3]][1]) + ',' + str(constants.HOJ_RAN_MSG[range_info[i][3]][2]) + '\n'        

        for i in range(len(correlate_info)):
            info_str = info_str + \
                str(correlate_info[i][0]) + ',' + str(correlate_info[i][1]) + ',' + str(correlate_info[i][2]) + ',' + \
                str(constants.HOJ_COR_MSG[correlate_info[i][3]][0]) + ',' + str(constants.HOJ_COR_MSG[correlate_info[i][3]][1]) + ',' + str(constants.HOJ_COR_MSG[correlate_info[i][3]][2]) + '\n'        

        for i in range(len(compare_info)):
            info_str = info_str + \
                str(compare_info[i][0]) + ',' + str(compare_info[i][1]) + ',' + str(compare_info[i][2]) + ',' + \
                str(constants.HOJ_COM_MSG[compare_info[i][3]][0]) + ',' + str(constants.HOJ_COM_MSG[compare_info[i][3]][1]) + ',' + str(constants.HOJ_COM_MSG[compare_info[i][3]][2]) + '\n'        

        for i in range(len(require_warn)):
            warn_str = warn_str + \
                str(require_warn[i][0]) + ',' + str(require_warn[i][1]) + ',' + str(require_warn[i][2]) + ',' + \
                str(constants.HOJ_REQ_MSG[require_warn[i][3]][0]) + ',' + str(constants.HOJ_REQ_MSG[require_warn[i][3]][1]) + ',' + str(constants.HOJ_REQ_MSG[require_warn[i][3]][2]) + '\n'        
        
        for i in range(len(format_warn)):
            warn_str = warn_str + \
                str(format_warn[i][0]) + ',' + str(format_warn[i][1]) + ',' + str(format_warn[i][2]) + ',' + \
                str(constants.HOJ_FOR_MSG[format_warn[i][3]][0]) + ',' + str(constants.HOJ_FOR_MSG[format_warn[i][3]][1]) + ',' + str(constants.HOJ_FOR_MSG[format_warn[i][3]][2]) + '\n'        

        for i in range(len(range_warn)):
            warn_str = warn_str + \
                str(range_warn[i][0]) + ',' + str(range_warn[i][1]) + ',' + str(range_warn[i][2]) + ',' + \
                str(constants.HOJ_RAN_MSG[range_warn[i][3]][0]) + ',' + str(constants.HOJ_RAN_MSG[range_warn[i][3]][1]) + ',' + str(constants.HOJ_RAN_MSG[range_warn[i][3]][2]) + '\n'

        for i in range(len(correlate_warn)):
            warn_str = warn_str + \
                str(correlate_warn[i][0]) + ',' + str(correlate_warn[i][1]) + ',' + str(correlate_warn[i][2]) + ',' + \
                str(constants.HOJ_COR_MSG[correlate_warn[i][3]][0]) + ',' + str(constants.HOJ_COR_MSG[correlate_warn[i][3]][1]) + ',' + str(constants.HOJ_COR_MSG[correlate_warn[i][3]][2]) + '\n'        

        for i in range(len(compare_warn)):
            warn_str = warn_str + \
                str(compare_warn[i][0]) + ',' + str(compare_warn[i][1]) + ',' + str(compare_warn[i][2]) + ',' + \
                str(constants.HOJ_COM_MSG[compare_warn[i][3]][0]) + ',' + str(constants.HOJ_COM_MSG[compare_warn[i][3]][1]) + ',' + str(constants.HOJ_COM_MSG[compare_warn[i][3]][2]) + '\n'        

        #######################################################################
        #######################################################################
        ### 【警告】条件分岐処理(1000)
        ### ※入力チェックで警告が発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 12/18.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or len(range_warn) > 0 or len(correlate_warn) > 0 or len(compare_warn) > 0:

            ###################################################################
            ### 【警告】DBアクセス処理(1010)
            ### ※入力チェックで警告が発見された場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 13/18.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")

                PARAMS = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
                })
                SQL_UPDATE_HOJO_HEADER = """
                    UPDATE HOJO_HEADER SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE HOJO_HEADER_ID IN (
                    SELECT 
                        HOJO_HEADER_ID 
                    FROM HOJO_HEADER 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_HOJO = """
                    UPDATE HOJO SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE HOJO_ID IN (
                    SELECT 
                        HOJO_ID 
                    FROM HOJO_VIEW 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_HOJO_SUMMARY = """
                    UPDATE HOJO_SUMMARY SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE HOJO_ID IN (
                    SELECT 
                        HOJO_ID 
                    FROM HOJO_SUMMARY_VIEW 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                
                connection_cursor.execute(SQL_UPDATE_HOJO_HEADER,  PARAMS)
                connection_cursor.execute(SQL_UPDATE_HOJO,         PARAMS)
                connection_cursor.execute(SQL_UPDATE_HOJO_SUMMARY, PARAMS)
    
                ### _HOJ_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
                ### _HOJ_ACT_02等でも良い。
                ### 同じ都道府県コードのトリガーが削除済に更新される。
                PARAMS_MESSAGE  = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': split_name_code(ws[0].cell(row=8, column=6).value)[-1], 
                    'action_code': _HOJ_ACT_01
                })
                bool_return = delete_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[ERROR] P0120Ken.browser_post_hojo()関数 delete_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] P0120Ken.browser_post_hojo()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_hojo()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_hojo()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### 【警告】レスポンスセット処理(1020)
            ### ※入力チェックで警告が発見された場合、
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 14/18.', 'DEBUG')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'browser_post_hojo_warn': 'browser_post_hojo_warn',
                'require_warn': require_warn,
                'format_warn': format_warn,
                'range_warn': range_warn,
                'correlate_warn': correlate_warn,
                'compare_warn': compare_warn,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0120Ken.browser_post_hojo()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        #######################################################################
        ### 【正常】DBアクセス処理(2000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 15/18.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")

            ###################################################################
            ### 【正常】DBアクセス処理(2010) STEP1
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存データの削除日に値をセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 16/18.', 'DEBUG')
            PARAMS = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
            })
            SQL_UPDATE_HOJO_HEADER = """
                UPDATE HOJO_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_HEADER_ID IN (
                SELECT 
                    HOJO_HEADER_ID 
                FROM HOJO_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_HOJO = """
                UPDATE HOJO SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_ID IN (
                SELECT 
                    HOJO_ID 
                FROM HOJO_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_HOJO_SUMMARY = """
                UPDATE HOJO_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_ID IN (
                SELECT 
                    HOJO_ID 
                FROM HOJO_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            
            connection_cursor.execute(SQL_UPDATE_HOJO_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_HOJO,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_HOJO_SUMMARY, PARAMS)

            ### _HOJ_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _HOJ_ACT_02等でも良い。
            ### 同じ都道府県コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': split_name_code(ws[0].cell(row=8, column=6).value)[-1], 
                'city_code': None, 
                'action_code': _HOJ_ACT_01
            })
            bool_return = delete_message(PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0120Ken.browser_post_hojo()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            ###################################################################
            ### 【正常】DBアクセス処理(2020) STEP2
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※アップロードされたデータを登録する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 17/18.', 'DEBUG')
            for i, _ in enumerate(ws):
                hojo_header_id = HOJO_HEADER.objects.all().aggregate(Max('hojo_header_id'))['hojo_header_id__max']
                if hojo_header_id is None:
                    hojo_header_id = 1
                else:
                    hojo_header_id += 1

                if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
                    PARAMS = dict({
                        'HOJO_HEADER_ID': hojo_header_id, 
                        'HOJO_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=6).value)[-1]), 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None, 
                        'DELETED_AT': None,
                        'HOJO_KEN_UPLOAD': _PROVISIONED_HOJO_KEN_UPLOAD,
                    })
                else:
                    PARAMS = dict({
                        'HOJO_HEADER_ID': hojo_header_id, 
                        'HOJO_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=6).value)[-1]), 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None, 
                        'DELETED_AT': None,
                        'HOJO_KEN_UPLOAD': _CONFIRMED_HOJO_KEN_UPLOAD,
                    })
                SQL_INSERT_HOJO_HEADER = """
                    INSERT INTO HOJO_HEADER (
                        HOJO_HEADER_ID, HOJO_HEADER_NAME, KEN_CODE, 
                        UPLOAD_FILE_PATH, UPLOAD_FILE_NAME, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME, 
                        COMMITTED_AT, DELETED_AT 
                    ) VALUES (
                        %(HOJO_HEADER_ID)s, 
                        %(HOJO_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s, 
                        CURRENT_TIMESTAMP,  -- committed_at 
                        %(DELETED_AT)s)"""
                SQL_INSERT_HOJO_HISTORY = """
                    INSERT INTO HOJO_HISTORY (
                        HOJO_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
                    ) VALUES (
                        %(HOJO_HEADER_ID)s,
                        %(HOJO_KEN_UPLOAD)s,
                        CURRENT_TIMESTAMP)"""

                connection_cursor.execute(SQL_INSERT_HOJO_HEADER,  PARAMS)
                connection_cursor.execute(SQL_INSERT_HOJO_HISTORY, PARAMS)
                    
                ###############################################################
                ### 【正常】DBアクセス処理(2030) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※アップロードされたデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 17_1/18.', 'DEBUG')
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if (max_row[i] >= 8):
                    for j in range(8, max_row[i]+1):
                        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 j={}'.format(j), 'DEBUG')
                        PARAMS_INSERT_HOJO = dict({
                            'HOJO_NAME': convert_empty_to_none(ws[i].cell(row=j, column=2).value), 
                            'HOJO_HEADER_ID': hojo_header_id, 
                            'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=10).value)[-1]), 
                            'BEGIN_DATE': convert_empty_to_none(ws[i].cell(row=j, column=14).value), 
                            'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=2).value)[-1]), 
                            'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=3).value)[-1]), 
                            'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=5).value)[-1]), 
                            'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=10).value)[-1]), 
                            'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=13).value)[-1]), 
                            'KOJI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=7).value)[-1]), 
                            'BRANCH_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=8).value)[-1]), 
                            'KOJI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=9).value)[-1]), 
                            'KOSH_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=11).value)[-1]), 
                            'DETERMINED_COST': convert_empty_to_none(ws[i].cell(row=j, column=16).value), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=17).value), 
                            'DELETED_AT': None
                        })
                        SQL_INSERT_HOJO = """ 
                            INSERT INTO HOJO (
                                HOJO_ID, HOJO_NAME, HOJO_HEADER_ID, 
                                CITY_CODE, BEGIN_DATE, 
                                SUIKEI_CODE, SUIKEI_TYPE_CODE, KASEN_CODE, KASEN_TYPE_CODE, KASEN_KAIGAN_CODE, WEATHER_ID, 
                                KOJI_CODE, BRANCH_CODE, KOJI_TYPE_CODE, KOSH_TYPE_CODE, DETERMINED_COST, COMMENT, 
                                COMMITTED_AT, DELETED_AT 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(HOJO_ID+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(HOJO_ID+1) AS INTEGER) END AS HOJO_ID FROM HOJO), -- hojo_id 
                                %(HOJO_NAME)s, 
                                %(HOJO_HEADER_ID)s, 
                                %(CITY_CODE)s, 
                                TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                                %(SUIKEI_CODE)s, 
                                %(SUIKEI_TYPE_CODE)s, 
                                %(KASEN_CODE)s, 
                                %(KASEN_TYPE_CODE)s, 
                                %(KASEN_KAIGAN_CODE)s, 
                                %(WEATHER_ID)s, 
                                %(KOJI_CODE)s, 
                                %(BRANCH_CODE)s, 
                                %(KOJI_TYPE_CODE)s, 
                                %(KOSH_TYPE_CODE)s, 
                                %(DETERMINED_COST)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- COMMITTED_AT 
                                %(DELETED_AT)s)"""

                        connection_cursor.execute(SQL_INSERT_HOJO, PARAMS_INSERT_HOJO)

                ###############################################################
                ### 【正常】DBアクセス処理(2040) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにHOJ_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 17_2/18.', 'DEBUG')
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': hojo_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=6).value)[-1]), 
                    'city_code': None, 
                    'action_code': _HOJ_ACT_01, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[ERROR] P0120Ken.browser_post_hojo()関数 publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")   
            
        except:
            print_log('[ERROR] P0120Ken.browser_post_hojo()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_hojo()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_hojo()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        finally:
            connection_cursor.close()
        
        #######################################################################
        ### 【正常】レスポンスセット処理(2050)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 18/18.', 'DEBUG')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'browser_post_hojo_info': 'browser_post_hojo_info',
            'require_info': require_info, 
            'format_info': format_info,
            'range_info': range_info,
            'correlate_info': correlate_info,
            'compare_info': compare_info,
        }
        print_log('[INFO] P0120Ken.browser_post_hojo()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0120Ken.browser_post_hojo()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_hojo()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_hojo()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
###############################################################################
def browser_post_koeki(request):

    ###########################################################################
    ### 関数内関数：EXCELセルデータ必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal require_warn
            nonlocal require_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### ※max_rowの9は入力部分の開始EXCEL行番号である。
            ### ※max_rowの9はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_require()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 9):
                for j in range(9, max_row[0]+1):
                    ### セル[9:1]: NO.に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=1).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 1, constants.KOE_REQ_MSG[0][0], constants.KOE_REQ_MSG[0][1], constants.KOE_REQ_MSG[0][2], constants.KOE_REQ_MSG[0][3], constants.KOE_REQ_MSG[0][4]])
                    else:
                        require_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[9:2]: 水害発生開始月に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 2, constants.KOE_REQ_MSG[1][0], constants.KOE_REQ_MSG[1][1], constants.KOE_REQ_MSG[1][2], constants.KOE_REQ_MSG[1][3], constants.KOE_REQ_MSG[1][4]])
                    else:
                        require_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[9:3]: 水害発生開始日に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=3).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 3, constants.KOE_REQ_MSG[2][0], constants.KOE_REQ_MSG[2][1], constants.KOE_REQ_MSG[2][2], constants.KOE_REQ_MSG[2][3], constants.KOE_REQ_MSG[2][4]])
                    else:
                        require_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[9:4]: 水害発生終了月に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 4, constants.KOE_REQ_MSG[3][0], constants.KOE_REQ_MSG[3][1], constants.KOE_REQ_MSG[3][2], constants.KOE_REQ_MSG[3][3], constants.KOE_REQ_MSG[3][4]])
                    else:
                        require_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[9:5]: 水害発生終了日に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 5, constants.KOE_REQ_MSG[4][0], constants.KOE_REQ_MSG[4][1], constants.KOE_REQ_MSG[4][2], constants.KOE_REQ_MSG[4][3], constants.KOE_REQ_MSG[4][4]])
                    else:
                        require_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[9:6]: 被害箇所_都道府県名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 6, constants.KOE_REQ_MSG[5][0], constants.KOE_REQ_MSG[5][1], constants.KOE_REQ_MSG[5][2], constants.KOE_REQ_MSG[5][3], constants.KOE_REQ_MSG[5][4]])
                    else:
                        require_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[9:7]: 被害箇所_都道府県コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 7, constants.KOE_REQ_MSG[6][0], constants.KOE_REQ_MSG[6][1], constants.KOE_REQ_MSG[6][2], constants.KOE_REQ_MSG[6][3], constants.KOE_REQ_MSG[6][4]])
                    else:
                        require_info.append([ws[0].title, j, 7, 6])
    
                    ### セル[9:8]: 被害箇所_市区町村名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 8, constants.KOE_REQ_MSG[7][0], constants.KOE_REQ_MSG[7][1], constants.KOE_REQ_MSG[7][2], constants.KOE_REQ_MSG[7][3], constants.KOE_REQ_MSG[7][4]])
                    else:
                        require_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[9:9]: 被害箇所_市区町村コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 9, constants.KOE_REQ_MSG[8][0], constants.KOE_REQ_MSG[8][1], constants.KOE_REQ_MSG[8][2], constants.KOE_REQ_MSG[8][3], constants.KOE_REQ_MSG[8][4]])
                    else:
                        require_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=10).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 10, constants.KOE_REQ_MSG[9][0], constants.KOE_REQ_MSG[9][1], constants.KOE_REQ_MSG[9][2], constants.KOE_REQ_MSG[9][3], constants.KOE_REQ_MSG[9][4]])
                    else:
                        require_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 11, constants.KOE_REQ_MSG[10][0], constants.KOE_REQ_MSG[10][1], constants.KOE_REQ_MSG[10][2], constants.KOE_REQ_MSG[10][3], constants.KOE_REQ_MSG[10][4]])
                    else:
                        require_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=12).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 12, constants.KOE_REQ_MSG[11][0], constants.KOE_REQ_MSG[11][1], constants.KOE_REQ_MSG[11][2], constants.KOE_REQ_MSG[11][3], constants.KOE_REQ_MSG[11][4]])
                    else:
                        require_info.append([ws[0].title, j, 12, 11])
    
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 13, constants.KOE_REQ_MSG[12][0], constants.KOE_REQ_MSG[12][1], constants.KOE_REQ_MSG[12][2], constants.KOE_REQ_MSG[12][3], constants.KOE_REQ_MSG[12][4]])
                    else:
                        require_info.append([ws[0].title, j, 13, 12])
    
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 14, constants.KOE_REQ_MSG[13][0], constants.KOE_REQ_MSG[13][1], constants.KOE_REQ_MSG[13][2], constants.KOE_REQ_MSG[13][3], constants.KOE_REQ_MSG[13][4]])
                    else:
                        require_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[9:15]: 工種区分に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 15, constants.KOE_REQ_MSG[14][0], constants.KOE_REQ_MSG[14][1], constants.KOE_REQ_MSG[14][2], constants.KOE_REQ_MSG[14][3], constants.KOE_REQ_MSG[14][4]])
                    else:
                        require_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[9:16]: 水害原因コード1に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 16, constants.KOE_REQ_MSG[15][0], constants.KOE_REQ_MSG[15][1], constants.KOE_REQ_MSG[15][2], constants.KOE_REQ_MSG[15][3], constants.KOE_REQ_MSG[15][4]])
                    else:
                        require_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[9:17]: 水害原因コード2に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=17).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 17, constants.KOE_REQ_MSG[16][0], constants.KOE_REQ_MSG[16][1], constants.KOE_REQ_MSG[16][2], constants.KOE_REQ_MSG[16][3], constants.KOE_REQ_MSG[16][4]])
                    else:
                        require_info.append([ws[0].title, j, 17, 16])
    
                    ### セル[9:18]: 水害原因コード3に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=18).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 18, constants.KOE_REQ_MSG[17][0], constants.KOE_REQ_MSG[17][1], constants.KOE_REQ_MSG[17][2], constants.KOE_REQ_MSG[17][3], constants.KOE_REQ_MSG[17][4]])
                    else:
                        require_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[9:19]: 異常気象コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=19).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 19, constants.KOE_REQ_MSG[18][0], constants.KOE_REQ_MSG[18][1], constants.KOE_REQ_MSG[18][2], constants.KOE_REQ_MSG[18][3], constants.KOE_REQ_MSG[18][4]])
                    else:
                        require_info.append([ws[0].title, j, 19, 18])
    
                    ### セル[9:20]: 事業コードに値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=20).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 20, constants.KOE_REQ_MSG[19][0], constants.KOE_REQ_MSG[19][1], constants.KOE_REQ_MSG[19][2], constants.KOE_REQ_MSG[19][3], constants.KOE_REQ_MSG[19][4]])
                    else:
                        require_info.append([ws[0].title, j, 20, 19])
    
                    ### セル[9:21]: 調査対象機関名称に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=21).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 21, constants.KOE_REQ_MSG[20][0], constants.KOE_REQ_MSG[20][1], constants.KOE_REQ_MSG[20][2], constants.KOE_REQ_MSG[20][3], constants.KOE_REQ_MSG[20][4]])
                    else:
                        require_info.append([ws[0].title, j, 21, 20])
    
                    ### セル[9:22]: 被害金額_物的被害額(千円)に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=22).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=21, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 22, constants.KOE_REQ_MSG[21][0], constants.KOE_REQ_MSG[21][1], constants.KOE_REQ_MSG[21][2], constants.KOE_REQ_MSG[21][3], constants.KOE_REQ_MSG[21][4]])
                    else:
                        require_info.append([ws[0].title, j, 22, 21])
    
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=23).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=22, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 23, constants.KOE_REQ_MSG[22][0], constants.KOE_REQ_MSG[22][1], constants.KOE_REQ_MSG[22][2], constants.KOE_REQ_MSG[22][3], constants.KOE_REQ_MSG[22][4]])
                    else:
                        require_info.append([ws[0].title, j, 23, 22])
    
                    ### セル[9:24]: 被害金額_代替活動費(外注費)に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=24).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=23, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 24, constants.KOE_REQ_MSG[23][0], constants.KOE_REQ_MSG[23][1], constants.KOE_REQ_MSG[23][2], constants.KOE_REQ_MSG[23][3], constants.KOE_REQ_MSG[23][4]])
                    else:
                        require_info.append([ws[0].title, j, 24, 23])
    
                    ### セル[9:25]: 被害金額_その他に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=25).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=25, fill=fill, message_id=24, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 25, constants.KOE_REQ_MSG[24][0], constants.KOE_REQ_MSG[24][1], constants.KOE_REQ_MSG[24][2], constants.KOE_REQ_MSG[24][3], constants.KOE_REQ_MSG[24][4]])
                    else:
                        require_info.append([ws[0].title, j, 25, 24])
    
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=26).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=26, fill=fill, message_id=25, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 26, constants.KOE_REQ_MSG[25][0], constants.KOE_REQ_MSG[25][1], constants.KOE_REQ_MSG[25][2], constants.KOE_REQ_MSG[25][3], constants.KOE_REQ_MSG[25][4]])
                    else:
                        require_info.append([ws[0].title, j, 26, 25])
    
                    ### セル[9:27]: 営業停止期間等_営業停止期間日に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=27).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=27, fill=fill, message_id=26, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 27, constants.KOE_REQ_MSG[26][0], constants.KOE_REQ_MSG[26][1], constants.KOE_REQ_MSG[26][2], constants.KOE_REQ_MSG[26][3], constants.KOE_REQ_MSG[26][4]])
                    else:
                        require_info.append([ws[0].title, j, 27, 26])
    
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=28).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=28, fill=fill, message_id=27, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 28, constants.KOE_REQ_MSG[27][0], constants.KOE_REQ_MSG[27][1], constants.KOE_REQ_MSG[27][2], constants.KOE_REQ_MSG[27][3], constants.KOE_REQ_MSG[27][4]])
                    else:
                        require_info.append([ws[0].title, j, 28, 27])
    
                    ### セル[9:29]: 営業停止期間等_停止数量に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=29).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=29, fill=fill, message_id=28, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 29, constants.KOE_REQ_MSG[28][0], constants.KOE_REQ_MSG[28][1], constants.KOE_REQ_MSG[28][2], constants.KOE_REQ_MSG[28][3], constants.KOE_REQ_MSG[28][4]])
                    else:
                        require_info.append([ws[0].title, j, 29, 28])
    
                    ### セル[9:30]: 照会先_調査担当課名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=30).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=30, fill=fill, message_id=29, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 30, constants.KOE_REQ_MSG[29][0], constants.KOE_REQ_MSG[29][1], constants.KOE_REQ_MSG[29][2], constants.KOE_REQ_MSG[29][3], constants.KOE_REQ_MSG[29][4]])
                    else:
                        require_info.append([ws[0].title, j, 30, 29])
    
                    ### セル[9:31]: 照会先_調査担当者名[全角]に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=31).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=31, fill=fill, message_id=30, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 31, constants.KOE_REQ_MSG[30][0], constants.KOE_REQ_MSG[30][1], constants.KOE_REQ_MSG[30][2], constants.KOE_REQ_MSG[30][3], constants.KOE_REQ_MSG[30][4]])
                    else:
                        require_info.append([ws[0].title, j, 31, 30])
    
                    ### セル[9:32]: 照会先_電話番号に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=32).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=32, fill=fill, message_id=31, message=constants.KOE_REQ_MSGvv)
                        require_warn.append([ws[0].title, j, 32, constants.KOE_REQ_MSG[31][0], constants.KOE_REQ_MSG[31][1], constants.KOE_REQ_MSG[31][2], constants.KOE_REQ_MSG[31][3], constants.KOE_REQ_MSG[31][4]])
                    else:
                        require_info.append([ws[0].title, j, 32, 31])
    
                    ### セル[9:33]: 備考に値がセットされていることをチェックする。
                    if (ws[0].cell(row=j, column=33).value is None):
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=33, fill=fill, message_id=32, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 33, constants.KOE_REQ_MSG[32][0], constants.KOE_REQ_MSG[32][1], constants.KOE_REQ_MSG[32][2], constants.KOE_REQ_MSG[32][3], constants.KOE_REQ_MSG[32][4]])
                    else:
                        require_info.append([ws[0].title, j, 33, 32])
            
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal format_warn
            nonlocal format_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_format()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 9):
                for j in range(9, max_row[0]+1):
                    ### セル[9:1]: NO.について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=1).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=1).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 1, constants.KOE_FOR_MSG[0][0], constants.KOE_FOR_MSG[0][1], constants.KOE_FOR_MSG[0][2], constants.KOE_FOR_MSG[0][3], constants.KOE_FOR_MSG[0][4]])
                        else:
                            format_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[9:2]: 水害発生開始月について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=2).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=2).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 2, constants.KOE_FOR_MSG[1][0], constants.KOE_FOR_MSG[1][1], constants.KOE_FOR_MSG[1][2], constants.KOE_FOR_MSG[1][3], constants.KOE_FOR_MSG[1][4]])
                        else:
                            format_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[9:3]: 水害発生開始日について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=3).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=3).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 3, constants.KOE_FOR_MSG[2][0], constants.KOE_FOR_MSG[2][1], constants.KOE_FOR_MSG[2][2], constants.KOE_FOR_MSG[2][3], constants.KOE_FOR_MSG[2][4]])
                        else:
                            format_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[9:4]: 水害発生終了月について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=4).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=4).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 4, constants.KOE_FOR_MSG[3][0], constants.KOE_FOR_MSG[3][1], constants.KOE_FOR_MSG[3][2], constants.KOE_FOR_MSG[3][3], constants.KOE_FOR_MSG[3][4]])
                        else:
                            format_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[9:5]: 水害発生終了日について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=5).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=5).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 5, constants.KOE_FOR_MSG[4][0], constants.KOE_FOR_MSG[4][1], constants.KOE_FOR_MSG[4][2], constants.KOE_FOR_MSG[4][3], constants.KOE_FOR_MSG[4][4]])
                        else:
                            format_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[9:6]: 被害箇所_都道府県名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=6).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=6).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 6, constants.KOE_FOR_MSG[5][0], constants.KOE_FOR_MSG[5][1], constants.KOE_FOR_MSG[5][2], constants.KOE_FOR_MSG[5][3], constants.KOE_FOR_MSG[5][4]])
                        else:
                            format_info.append([ws[0].title, j, 6, 5])
                        
                    ### セル[9:7]: 被害箇所_都道府県コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=7).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=7).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 7, constants.KOE_FOR_MSG[6][0], constants.KOE_FOR_MSG[6][1], constants.KOE_FOR_MSG[6][2], constants.KOE_FOR_MSG[6][3], constants.KOE_FOR_MSG[6][4]])
                        else:
                            format_info.append([ws[0].title, j, 7, 6])
                        
                    ### セル[9:8]: 被害箇所_市区町村名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=8).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=8).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 8, constants.KOE_FOR_MSG[7][0], constants.KOE_FOR_MSG[7][1], constants.KOE_FOR_MSG[7][2], constants.KOE_FOR_MSG[7][3], constants.KOE_FOR_MSG[7][4]])
                        else:
                            format_info.append([ws[0].title, j, 8, 7])
                        
                    ### セル[9:9]: 被害箇所_市区町村コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=9).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=9).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 9, constants.KOE_FOR_MSG[8][0], constants.KOE_FOR_MSG[8][1], constants.KOE_FOR_MSG[8][2], constants.KOE_FOR_MSG[8][3], constants.KOE_FOR_MSG[8][4]])
                        else:
                            format_info.append([ws[0].title, j, 9, 8])
                        
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=10).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=10).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=10).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 10, constants.KOE_FOR_MSG[9][0], constants.KOE_FOR_MSG[9][1], constants.KOE_FOR_MSG[9][2], constants.KOE_FOR_MSG[9][3], constants.KOE_FOR_MSG[9][4]])
                        else:
                            format_info.append([ws[0].title, j, 10, 9])
                        
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=11).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=11).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 11, constants.KOE_FOR_MSG[10][0], constants.KOE_FOR_MSG[10][1], constants.KOE_FOR_MSG[10][2], constants.KOE_FOR_MSG[10][3], constants.KOE_FOR_MSG[10][4]])
                        else:
                            format_info.append([ws[0].title, j, 11, 10])
                        
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=12).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=12).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=12).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.KOE_FOR_MSGvvvv)
                            format_warn.append([ws[0].title, j, 12, constants.KOE_FOR_MSG[11][0], constants.KOE_FOR_MSG[11][1], constants.KOE_FOR_MSG[11][2], constants.KOE_FOR_MSG[11][3], constants.KOE_FOR_MSG[11][4]])
                        else:
                            format_info.append([ws[0].title, j, 12, 11])
                        
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=13).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=13).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 13, constants.KOE_FOR_MSG[12][0], constants.KOE_FOR_MSG[12][1], constants.KOE_FOR_MSG[12][2], constants.KOE_FOR_MSG[12][3], constants.KOE_FOR_MSG[12][4]])
                        else:
                            format_info.append([ws[0].title, j, 13, 12])
                        
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=14).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=14).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 14, constants.KOE_FOR_MSG[13][0], constants.KOE_FOR_MSG[13][1], constants.KOE_FOR_MSG[13][2], constants.KOE_FOR_MSG[13][3], constants.KOE_FOR_MSG[13][4]])
                        else:
                            format_info.append([ws[0].title, j, 14, 13])
                        
                    ### セル[9:15]: 工種区分について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=15).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=15).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 15, constants.KOE_FOR_MSG[14][0], constants.KOE_FOR_MSG[14][1], constants.KOE_FOR_MSG[14][2], constants.KOE_FOR_MSG[14][3], constants.KOE_FOR_MSG[14][4]])
                        else:
                            format_info.append([ws[0].title, j, 15, 14])
                        
                    ### セル[9:16]: 水害原因コード1について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=16).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=16).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 16, constants.KOE_FOR_MSG[15][0], constants.KOE_FOR_MSG[15][1], constants.KOE_FOR_MSG[15][2], constants.KOE_FOR_MSG[15][3], constants.KOE_FOR_MSG[15][4]])
                        else:
                            format_info.append([ws[0].title, j, 16, 15])
                        
                    ### セル[9:17]: 水害原因コード2について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=17).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=17).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=17).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 17, constants.KOE_FOR_MSG[16][0], constants.KOE_FOR_MSG[16][1], constants.KOE_FOR_MSG[16][2], constants.KOE_FOR_MSG[16][3], constants.KOE_FOR_MSG[16][4]])
                        else:
                            format_info.append([ws[0].title, j, 17, 16])
                        
                    ### セル[9:18]: 水害原因コード3について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=18).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=18).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=18).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 18, constants.KOE_FOR_MSG[17][0], constants.KOE_FOR_MSG[17][1], constants.KOE_FOR_MSG[17][2], constants.KOE_FOR_MSG[17][3], constants.KOE_FOR_MSG[17][4]])
                        else:
                            format_info.append([ws[0].title, j, 18, 17])
                        
                    ### セル[9:19]: 異常気象コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=19).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=19).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=19).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 19, constants.KOE_FOR_MSG[18][0], constants.KOE_FOR_MSG[18][1], constants.KOE_FOR_MSG[18][2], constants.KOE_FOR_MSG[18][3], constants.KOE_FOR_MSG[18][4]])
                        else:
                            format_info.append([ws[0].title, j, 19, 18])
                        
                    ### セル[9:20]: 事業コードについて形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=20).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=20).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=20).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 20, constants.KOE_FOR_MSG[19][0], constants.KOE_FOR_MSG[19][1], constants.KOE_FOR_MSG[19][2], constants.KOE_FOR_MSG[19][3], constants.KOE_FOR_MSG[19][4]])
                        else:
                            format_info.append([ws[0].title, j, 20, 19])
                        
                    ### セル[9:21]: 調査対象機関名称[全角]について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=21).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=21).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=21).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 21, constants.KOE_FOR_MSG[20][0], constants.KOE_FOR_MSG[20][1], constants.KOE_FOR_MSG[20][2], constants.KOE_FOR_MSG[20][3], constants.KOE_FOR_MSG[20][4]])
                        else:
                            format_info.append([ws[0].title, j, 21, 20])
                        
                    ### セル[9:22]: 被害金額_物的被害額(千円)について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=22).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=22).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=22).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=21, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 22, constants.KOE_FOR_MSG[21][0], constants.KOE_FOR_MSG[21][1], constants.KOE_FOR_MSG[21][2], constants.KOE_FOR_MSG[21][3], constants.KOE_FOR_MSG[21][4]])
                        else:
                            format_info.append([ws[0].title, j, 22, 21])
                        
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=23).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=23).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=23).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=22, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 23, constants.KOE_FOR_MSG[22][0], constants.KOE_FOR_MSG[22][1], constants.KOE_FOR_MSG[22][2], constants.KOE_FOR_MSG[22][3], constants.KOE_FOR_MSG[22][4]])
                        else:
                            format_info.append([ws[0].title, j, 23, 22])
                        
                    ### セル[9:24]: 被害金額_代替活動費(外注費)について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=24).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=24).value, int) == False) and (
                            isinstance(ws[0].cell(row=j, column=24).value, float) == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=23, message=constants.KOE_FOR_MSGvvvv)
                            format_warn.append([ws[0].title, j, 24, constants.KOE_FOR_MSG[23][0], constants.KOE_FOR_MSG[23][1], constants.KOE_FOR_MSG[23][2], constants.KOE_FOR_MSG[23][3], constants.KOE_FOR_MSG[23][4]])
                        else:
                            format_info.append([ws[0].title, j, 24, 23])
                        
                    ### セル[9:25]: 被害金額_その他について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=25).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=25).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=25, fill=fill, message_id=24, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 25, constants.KOE_FOR_MSG[24][0], constants.KOE_FOR_MSG[24][1], constants.KOE_FOR_MSG[24][2], constants.KOE_FOR_MSG[24][3], constants.KOE_FOR_MSG[24][4]])
                        else:
                            format_info.append([ws[0].title, j, 25, 24])
                        
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)について形式が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=26).value is None):
                        pass
                    else:
                        if (split_name_code(ws[0].cell(row=j, column=26).value)[-1].isdecimal() == False):
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=26, fill=fill, message_id=25, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 26, constants.KOE_FOR_MSG[25][0], constants.KOE_FOR_MSG[25][1], constants.KOE_FOR_MSG[25][2], constants.KOE_FOR_MSG[25][3], constants.KOE_FOR_MSG[25][4]])
                        else:
                            format_info.append([ws[0].title, j, 26, 25])
                        
                    ### セル[9:27]: 営業停止期間等_営業停止期間日について形式が正しいことをチェックする。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間について形式が正しいことをチェックする。
                    ### セル[9:29]: 営業停止期間等_停止数量について形式が正しいことをチェックする。
                    ### セル[9:30]: 照会先_調査担当課名[全角]について形式が正しいことをチェックする。
                    ### セル[9:31]: 照会先_調査担当者名[全角]について形式が正しいことをチェックする。
                    ### セル[9:32]: 照会先_電話番号について形式が正しいことをチェックする。
                    ### セル[9:33]: 備考について形式が正しいことをチェックする。
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal range_warn
            nonlocal range_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_range()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 9):
                for j in range(9, max_row[0]+1):
                    ### セル[9:1]: NO.について範囲が正しいことをチェックする。
                    ### セル[9:2]: 水害発生開始月について範囲が正しいことをチェックする。
                    ### セル[9:3]: 水害発生開始日について範囲が正しいことをチェックする。
                    ### セル[9:4]: 水害発生終了月について範囲が正しいことをチェックする。
                    ### セル[9:5]: 水害発生終了日について範囲が正しいことをチェックする。
                    ### セル[9:6]: 被害箇所_都道府県名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=6).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=6).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=6).value, float) == True):
                            if (float(ws[0].cell(row=j, column=6).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 6, constants.KOE_RAN_MSG[5][0], constants.KOE_RAN_MSG[5][1], constants.KOE_RAN_MSG[5][2], constants.KOE_RAN_MSG[5][3], constants.KOE_RAN_MSG[5][4]])
                            else:
                                range_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[9:7]: 被害箇所_都道府県コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=7).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=7).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=7).value, float) == True):
                            if (float(ws[0].cell(row=j, column=7).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 7, constants.KOE_RAN_MSG[6][0], constants.KOE_RAN_MSG[6][1], constants.KOE_RAN_MSG[6][2], constants.KOE_RAN_MSG[6][3], constants.KOE_RAN_MSG[6][4]])
                            else:
                                range_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[9:8]: 被害箇所_市区町村名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=8).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=8).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=8).value, float) == True):
                            if (float(ws[0].cell(row=j, column=8).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 8, constants.KOE_RAN_MSG[7][0], constants.KOE_RAN_MSG[7][1], constants.KOE_RAN_MSG[7][2], constants.KOE_RAN_MSG[7][3], constants.KOE_RAN_MSG[7][4]])
                            else:
                                range_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[9:9]: 被害箇所_市区町村コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=9).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=9).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=9).value, float) == True):
                            if (float(ws[0].cell(row=j, column=9).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 9, constants.KOE_RAN_MSG[8][0], constants.KOE_RAN_MSG[8][1], constants.KOE_RAN_MSG[8][2], constants.KOE_RAN_MSG[8][3], constants.KOE_RAN_MSG[8][4]])
                            else:
                                range_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=10).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=10).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=10).value, float) == True):
                            if (float(ws[0].cell(row=j, column=10).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 10, constants.KOE_RAN_MSG[9][0], constants.KOE_RAN_MSG[9][1], constants.KOE_RAN_MSG[9][2], constants.KOE_RAN_MSG[9][3], constants.KOE_RAN_MSG[9][4]])
                            else:
                                range_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=11).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=11).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=11).value, float) == True):
                            if (float(ws[0].cell(row=j, column=11).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 11, constants.KOE_RAN_MSG[10][0], constants.KOE_RAN_MSG[10][1], constants.KOE_RAN_MSG[10][2], constants.KOE_RAN_MSG[10][3], constants.KOE_RAN_MSG[10][4]])
                            else:
                                range_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=12).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=12).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=12).value, float) == True):
                            if (float(ws[0].cell(row=j, column=12).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 12, constants.KOE_RAN_MSG[11][0], constants.KOE_RAN_MSG[11][1], constants.KOE_RAN_MSG[11][2], constants.KOE_RAN_MSG[11][3], constants.KOE_RAN_MSG[11][4]])
                            else:
                                range_info.append([ws[0].title, j, 12, 11])
    
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=13).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=13).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=13).value, float) == True):
                            if float(ws[0].cell(row=j, column=13).value) < 0:
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 13, constants.KOE_RAN_MSG[12][0], constants.KOE_RAN_MSG[12][1], constants.KOE_RAN_MSG[12][2], constants.KOE_RAN_MSG[12][3], constants.KOE_RAN_MSG[12][4]])
                            else:
                                range_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=14).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=14).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=14).value, float) == True):
                            if (float(ws[0].cell(row=j, column=14).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 14, constants.KOE_RAN_MSG[13][0], constants.KOE_RAN_MSG[13][1], constants.KOE_RAN_MSG[13][2], constants.KOE_RAN_MSG[13][3], constants.KOE_RAN_MSG[13][4]])
                            else:
                                range_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[9:15]: 工種区分について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=15).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=15).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=15).value, float) == True):
                            if (float(ws[0].cell(row=j, column=15).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 15, constants.KOE_RAN_MSG[14][0], constants.KOE_RAN_MSG[14][1], constants.KOE_RAN_MSG[14][2], constants.KOE_RAN_MSG[14][3], constants.KOE_RAN_MSG[14][4]])
                            else:
                                range_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[9:16]: 水害原因コード1について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=16).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=16).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=16).value, float) == True):
                            if (float(ws[0].cell(row=j, column=16).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 16, constants.KOE_RAN_MSG[15][0], constants.KOE_RAN_MSG[15][1], constants.KOE_RAN_MSG[15][2], constants.KOE_RAN_MSG[15][3], constants.KOE_RAN_MSG[15][4]])
                            else:
                                range_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[9:17]: 水害原因コード2について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=17).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=17).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=17).value, float) == True):
                            if (float(ws[0].cell(row=j, column=17).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 17, constants.KOE_RAN_MSG[16][0], constants.KOE_RAN_MSG[16][1], constants.KOE_RAN_MSG[16][2], constants.KOE_RAN_MSG[16][3], constants.KOE_RAN_MSG[16][4]])
                            else:
                                range_info.append([ws[0].title, j, 17, 16])
    
                    ### セル[9:18]: 水害原因コード3について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=18).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=18).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=18).value, float) == True):
                            if (float(ws[0].cell(row=j, column=18).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 18, constants.KOE_RAN_MSG[17][0], constants.KOE_RAN_MSG[17][1], constants.KOE_RAN_MSG[17][2], constants.KOE_RAN_MSG[17][3], constants.KOE_RAN_MSG[17][4]])
                            else:
                                range_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[9:19]: 異常気象コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=19).value is None:
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=19).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=19).value, float) == True):
                            if (float(ws[0].cell(row=j, column=19).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 19, constants.KOE_RAN_MSG[18][0], constants.KOE_RAN_MSG[18][1], constants.KOE_RAN_MSG[18][2], constants.KOE_RAN_MSG[18][3], constants.KOE_RAN_MSG[18][4]])
                            else:
                                range_info.append([ws[0].title, j, 19, 18])
    
                    ### セル[9:20]: 事業コードについて範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=20).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=20).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=20).value, float) == True):
                            if (float(ws[0].cell(row=j, column=20).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 20, constants.KOE_RAN_MSG[19][0], constants.KOE_RAN_MSG[19][1], constants.KOE_RAN_MSG[19][2], constants.KOE_RAN_MSG[19][3], constants.KOE_RAN_MSG[19][4]])
                            else:
                                range_info.append([ws[0].title, j, 20, 19])
    
                    ### セル[9:21]: 調査対象機関名称[全角]について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=21).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=21).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=21).value, float) == True):
                            if (float(ws[0].cell(row=j, column=21).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 21, constants.KOE_RAN_MSG[20][0], constants.KOE_RAN_MSG[20][1], constants.KOE_RAN_MSG[20][2], constants.KOE_RAN_MSG[20][3], constants.KOE_RAN_MSG[20][4]])
                            else:
                                range_info.append([ws[0].title, j, 21, 20])
    
                    ### セル[9:22]: 被害金額_物的被害額(千円)について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=22).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=22).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=22).value, float) == True):
                            if (float(ws[0].cell(row=j, column=22).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=21, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 22, constants.KOE_RAN_MSG[21][0], constants.KOE_RAN_MSG[21][1], constants.KOE_RAN_MSG[21][2], constants.KOE_RAN_MSG[21][3], constants.KOE_RAN_MSG[21][4]])
                            else:
                                range_info.append([ws[0].title, j, 22, 21])
    
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=23).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=23).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=23).value, float) == True):
                            if (float(ws[0].cell(row=j, column=23).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=22, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 23, constants.KOE_RAN_MSG[22][0], constants.KOE_RAN_MSG[22][1], constants.KOE_RAN_MSG[22][2], constants.KOE_RAN_MSG[22][3], constants.KOE_RAN_MSG[22][4]])
                            else:
                                range_info.append([ws[0].title, j, 23, 22])
    
                    ### セル[9:24]: 被害金額_代替活動費(外注費)について範囲が正しいことをチェックする。
                    if (ws[0].cell(row=j, column=24).value is None):
                        pass
                    else:
                        if (isinstance(ws[0].cell(row=j, column=24).value, int) == True) or (
                            isinstance(ws[0].cell(row=j, column=24).value, float) == True):
                            if (float(ws[0].cell(row=j, column=24).value) < 0):
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=23, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 24, constants.KOE_RAN_MSG[23][0], constants.KOE_RAN_MSG[23][1], constants.KOE_RAN_MSG[23][2], constants.KOE_RAN_MSG[23][3], constants.KOE_RAN_MSG[23][4]])
                            else:
                                range_info.append([ws[0].title, j, 24, 23])
    
                    ### セル[9:25]: 被害金額_その他について範囲が正しいことをチェックする。
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)について範囲が正しいことをチェックする。
                    ### セル[9:27]: 営業停止期間等_営業停止期間日について範囲が正しいことをチェックする。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間について範囲が正しいことをチェックする。
                    ### セル[9:29]: 営業停止期間等_停止数量について範囲が正しいことをチェックする。
                    ### セル[9:30]: 照会先_調査担当課名[全角]について範囲が正しいことをチェックする。
                    ### セル[9:31]: 照会先_調査担当者名[全角]について範囲が正しいことをチェックする。
                    ### セル[9:32]: 照会先_電話番号について範囲が正しいことをチェックする。
                    ### セル[9:33]: 備考について範囲が正しいことをチェックする。
            
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal correlate_warn
            nonlocal correlate_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_correlate()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 9):
                for j in range(9, max_row[0]+1):
                    pass
                    ### セル[9:1]: NO.が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:2]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:3]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:4]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:5]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:6]: 被害箇所_都道府県名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:7]: 被害箇所_都道府県コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:8]: 被害箇所_市区町村名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:9]: 被害箇所_市区町村コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:15]: 工種区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:16]: 水害原因コード1が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:17]: 水害原因コード2が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:18]: 水害原因コード3が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:19]: 異常気象コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:20]: 事業コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:21]: 調査対象機関名称[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:22]: 被害金額_物的被害額(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:24]: 被害金額_代替活動費(外注費)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:25]: 被害金額_その他が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:27]: 営業停止期間等_営業停止期間日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:29]: 営業停止期間等_停止数量が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:30]: 照会先_調査担当課名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:31]: 照会先_調査担当者名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:32]: 照会先_電話番号が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:33]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            
            return True
        
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal compare_warn
            nonlocal compare_info
            ### nonlocal max_row
            ### nonlocal ken_code_list
            ### nonlocal ken_name_list
            ### nonlocal ken_name_code_list
            ### nonlocal city_code_list
            ### nonlocal city_name_list
            ### nonlocal city_name_code_list
            ### nonlocal suikei_code_list
            ### nonlocal suikei_name_list
            ### nonlocal suikei_name_code_list
            ### nonlocal suikei_type_code_list
            ### nonlocal suikei_type_name_list
            ### nonlocal suikei_type_name_code_list
            ### nonlocal kasen_code_list
            ### nonlocal kasen_name_list
            ### nonlocal kasen_name_code_list
            ### nonlocal kasen_type_code_list
            ### nonlocal kasen_type_name_list
            ### nonlocal kasen_type_name_code_list
            ### nonlocal kasen_kaigan_code_list
            ### nonlocal kasen_kaigan_name_list
            ### nonlocal kasen_kaigan_name_code_list
            ### nonlocal weather_id_list
            ### nonlocal weather_name_list
            ### nonlocal weather_name_id_list
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_compare()関数 STEP 1/1.', 'DEBUG')
            if (max_row[0] >= 9):
                for j in range(9, max_row[0]+1):
                    pass
                    ### セル[9:1]: NO.についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:2]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:3]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:4]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:5]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:6]: 被害箇所_都道府県名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:7]: 被害箇所_都道府県コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:8]: 被害箇所_市区町村名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:9]: 被害箇所_市区町村コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:15]: 工種区分についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:16]: 水害原因コード1についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:17]: 水害原因コード2についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:18]: 水害原因コード3についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:19]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:20]: 事業コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:21]: 調査対象機関名称[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:22]: 被害金額_物的被害額(千円)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:24]: 被害金額_代替活動費(外注費)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:25]: 被害金額_その他についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:27]: 営業停止期間等_営業停止期間日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:29]: 営業停止期間等_停止数量についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:30]: 照会先_調査担当課名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:31]: 照会先_調査担当者名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:32]: 照会先_電話番号についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:33]: 備考についてデータベースに登録されている値と突合せチェックする。
            
            return True
        
        except:
            return False

    try:
        #######################################################################
        #######################################################################
        ### 局所変数セット処理(0010)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 1/18.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info = []
        require_warn = []

        ### 形式チェック用の局所変数を初期化する。
        format_info = []
        format_warn = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info = []
        range_warn = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info = []
        correlate_warn = []

        ### 突合せチェックの結果を格納するために局所変数をセットする。
        compare_info = []
        compare_warn = []

        #######################################################################
        ### フォーム検証処理(0020)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 2/18.', 'DEBUG')
        form = UploadKoekiForm(request.POST, request.FILES)
        if form.is_valid() == False:
            print_log('[WARN] P0120Ken.browser_post_koeki()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた公益事業等調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 3/18.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + output_file_name
        
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
                
        #######################################################################
        ### EXCEL入出力処理(0040)
        ### (1)アップロードされた公益事業等調査票ファイルのワークブックを読み込む。
        ### (2)KOEKIワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 4/18.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        for ws_temp in wb.worksheets:
            if 'KOEKI' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)
                
        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)
        
        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(0050)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の8はNO.、水系・沿岸名等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 5/18.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 8
            for i in range(ws_temp.max_row+1, 8, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(0060)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 6/18.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(0070)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 7/18.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        ### cause_list
        ### kuiki_list
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### gradient_list
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        ### building_list
        ### underground_list
        ### flood_sediment_list
        ### industry_list
        ### business_list
        ### usage_list
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        ### cause_code_list
        ### cause_name_list
        ### cause_name_code_list
        ### kuiki_id_list
        ### kuiki_name_list
        ### kuiki_name_id_list
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        ### gradient_code_list
        ### gradient_name_list
        ### gradient_name_code_list
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        ### building_code_list
        ### building_name_list
        ### building_name_code_list
        ### underground_code_list
        ### underground_name_list
        ### underground_name_code_list
        ### flood_sediment_code_list
        ### flood_sediment_name_list
        ### flood_sediment_name_code_list
        ### industry_code_list
        ### industry_name_list
        ### industry_name_code_list
        ### business_code_list
        ### business_name_list
        ### business_name_code_list
        ### usage_code_list
        ### usage_name_list
        ### usage_name_code_list

        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(0080)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 8/18.', 'DEBUG')
        bool_return_01 = check_require()
        bool_return_02 = check_format()
        bool_return_03 = check_range()
        bool_return_04 = check_correlate()
        bool_return_05 = check_compare()
        
        if (bool_return_01 == False) or (bool_return_02 == False) or (bool_return_03 == False) or (bool_return_04 == False) or (bool_return_05 == False):
            print_log('[ERROR] P0120Ken.browser_post_koeki()関数 check_()関数が異常終了しました。', 'ERROR')
            raise Exception

        #######################################################################
        ### ファイル入出力処理(0090)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 9/18.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0100)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 10/18.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(require_warn)={}'.format(len(require_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(format_warn)={}'.format(len(format_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(range_warn)={}'.format(len(range_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(correlate_warn)={}'.format(len(correlate_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(compare_warn)={}'.format(len(compare_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(require_info)={}'.format(len(require_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(format_info)={}'.format(len(format_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(range_info)={}'.format(len(range_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(correlate_info)={}'.format(len(correlate_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(compare_info)={}'.format(len(compare_info)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(0110)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 11/18.', 'DEBUG')
        info_str = ''
        warn_str = ''
        for i in range(len(require_info)):
            info_str = info_str + \
                str(require_info[i][0]) + ',' + str(require_info[i][1]) + ',' + str(require_info[i][2]) + ',' + \
                str(constants.KOE_REQ_MSG[require_info[i][3]][0]) + ',' + str(constants.KOE_REQ_MSG[require_info[i][3]][1]) + ',' + str(constants.KOE_REQ_MSG[require_info[i][3]][2]) + '\n'        
        
        for i in range(len(format_info)):
            info_str = info_str + \
                str(format_info[i][0]) + ',' + str(format_info[i][1]) + ',' + str(format_info[i][2]) + ',' + \
                str(constants.KOE_FOR_MSG[format_info[i][3]][0]) + ',' + str(constants.KOE_FOR_MSG[format_info[i][3]][1]) + ',' + str(constants.KOE_FOR_MSG[format_info[i][3]][2]) + '\n'        

        for i in range(len(range_info)):
            info_str = info_str + \
                str(range_info[i][0]) + ',' + str(range_info[i][1]) + ',' + str(range_info[i][2]) + ',' + \
                str(constants.KOE_RAN_MSG[range_info[i][3]][0]) + ',' + str(constants.KOE_RAN_MSG[range_info[i][3]][1]) + ',' + str(constants.KOE_RAN_MSG[range_info[i][3]][2]) + '\n'        

        for i in range(len(correlate_info)):
            info_str = info_str + \
                str(correlate_info[i][0]) + ',' + str(correlate_info[i][1]) + ',' + str(correlate_info[i][2]) + ',' + \
                str(constants.KOE_COR_MSG[correlate_info[i][3]][0]) + ',' + str(constants.KOE_COR_MSG[correlate_info[i][3]][1]) + ',' + str(constants.KOE_COR_MSG[correlate_info[i][3]][2]) + '\n'        

        for i in range(len(compare_info)):
            info_str = info_str + \
                str(compare_info[i][0]) + ',' + str(compare_info[i][1]) + ',' + str(compare_info[i][2]) + ',' + \
                str(constants.KOE_COM_MSG[compare_info[i][3]][0]) + ',' + str(constants.KOE_COM_MSG[compare_info[i][3]][1]) + ',' + str(constants.KOE_COM_MSG[compare_info[i][3]][2]) + '\n'        

        for i in range(len(require_warn)):
            warn_str = warn_str + \
                str(require_warn[i][0]) + ',' + str(require_warn[i][1]) + ',' + str(require_warn[i][2]) + ',' + \
                str(constants.KOE_REQ_MSG[require_warn[i][3]][0]) + ',' + str(constants.KOE_REQ_MSG[require_warn[i][3]][1]) + ',' + str(constants.KOE_REQ_MSG[require_warn[i][3]][2]) + '\n'        
        
        for i in range(len(format_warn)):
            warn_str = warn_str + \
                str(format_warn[i][0]) + ',' + str(format_warn[i][1]) + ',' + str(format_warn[i][2]) + ',' + \
                str(constants.KOE_FOR_MSG[format_warn[i][3]][0]) + ',' + str(constants.KOE_FOR_MSG[format_warn[i][3]][1]) + ',' + str(constants.KOE_FOR_MSG[format_warn[i][3]][2]) + '\n'        

        for i in range(len(range_warn)):
            warn_str = warn_str + \
                str(range_warn[i][0]) + ',' + str(range_warn[i][1]) + ',' + str(range_warn[i][2]) + ',' + \
                str(constants.KOE_RAN_MSG[range_warn[i][3]][0]) + ',' + str(constants.KOE_RAN_MSG[range_warn[i][3]][1]) + ',' + str(constants.KOE_RAN_MSG[range_warn[i][3]][2]) + '\n'        

        for i in range(len(correlate_warn)):
            warn_str = warn_str + \
                str(correlate_warn[i][0]) + ',' + str(correlate_warn[i][1]) + ',' + str(correlate_warn[i][2]) + ',' + \
                str(constants.KOE_COR_MSG[correlate_warn[i][3]][0]) + ',' + str(constants.KOE_COR_MSG[correlate_warn[i][3]][1]) + ',' + str(constants.KOE_COR_MSG[correlate_warn[i][3]][2]) + '\n'        

        for i in range(len(compare_warn)):
            warn_str = warn_str + \
                str(compare_warn[i][0]) + ',' + str(compare_warn[i][1]) + ',' + str(compare_warn[i][2]) + ',' + \
                str(constants.KOE_COM_MSG[compare_warn[i][3]][0]) + ',' + str(constants.KOE_COM_MSG[compare_warn[i][3]][1]) + ',' + str(constants.KOE_COM_MSG[compare_warn[i][3]][2]) + '\n'        

        #######################################################################
        #######################################################################
        ### 【警告】条件分岐処理(1000)
        ### ※入力チェックで警告が発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 12/18.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or len(range_warn) > 0 or len(correlate_warn) > 0 or len(compare_warn) > 0:

            ###################################################################
            ### 【警告】DBアクセス処理(1010)
            ### ※入力チェックで警告が発見された場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 13/18.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                PARAMS = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
                })
                SQL_UPDATE_KOEKI_HEADER = """
                    UPDATE KOEKI_HEADER SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE KOEKI_HEADER_ID IN (
                    SELECT 
                        KOEKI_HEADER_ID 
                    FROM KOEKI_HEADER 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_KOEKI = """
                    UPDATE KOEKI SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE KOEKI_ID IN (
                    SELECT 
                        KOEKI_ID 
                    FROM KOEKI_VIEW 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""
                SQL_UPDATE_KOEKI_SUMMARY = """
                    UPDATE KOEKI_SUMMARY SET 
                        DELETED_AT=CURRENT_TIMESTAMP 
                    WHERE KOEKI_ID IN (
                    SELECT 
                        KOEKI_ID 
                    FROM KOEKI_SUMMARY_VIEW 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s AND 
                        DELETED_AT IS NULL)"""

                connection_cursor.execute(SQL_UPDATE_KOEKI_HEADER,  PARAMS)
                connection_cursor.execute(SQL_UPDATE_KOEKI,         PARAMS)
                connection_cursor.execute(SQL_UPDATE_KOEKI_SUMMARY, PARAMS)
    
                ### _KOE_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
                ### _KOE_ACT_02等でも良い。
                ### 同じ都道府県コードのトリガーが削除済に更新される。
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1], 
                    'action_code': _KOE_ACT_01
                })
                bool_return = delete_message(PARAMS_MESSAGE)
                if bool_return == False:
                    print_log('[ERROR] P0120Ken.browser_post_koeki()関数 publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                connection_cursor.execute("""COMMIT""");
                
            except:
                print_log('[ERROR] P0120Ken.browser_post_koeki()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_koeki()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_koeki()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### 【警告】レスポンスセット処理(1020)
            ### ※入力チェックでエラーが発見された場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 14/18.', 'DEBUG')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'browser_post_koeki_warn': 'browser_post_koeki_warn',
                'require_warn': require_warn,
                'format_warn': format_warn,
                'range_warn': range_warn,
                'correlate_warn': correlate_warn,
                'compare_warn': compare_warn,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0120Ken.browser_post_koeki()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        #######################################################################
        ### 【正常】DBアクセス処理(2000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 15/18.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            
            ###################################################################
            ### DBアクセス処理(2010) STEP1
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存データの削除日に値をセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 16/18.', 'DEBUG')
            PARAMS = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
            })
            SQL_UPDATE_KOEKI_HEADER = """
                UPDATE KOEKI_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_HEADER_ID IN (
                SELECT 
                    KOEKI_HEADER_ID 
                FROM KOEKI_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_KOEKI = """
                UPDATE KOEKI SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_ID IN (
                SELECT 
                    KOEKI_ID 
                FROM KOEKI_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_KOEKI_SUMMARY = """
                UPDATE KOEKI_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_ID IN (
                SELECT 
                    KOEKI_ID 
                FROM KOEKI_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""

            connection_cursor.execute(SQL_UPDATE_KOEKI_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_KOEKI,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_KOEKI_SUMMARY, PARAMS)

            ### _KOE_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _KOE_ACT_02等でも良い。
            ### 同じ都道府県コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': split_name_code(ws[0].cell(row=9, column=7).value)[-1], 
                'city_code': None, 
                'action_code': _KOE_ACT_01
            })
            bool_return = delete_message(PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0120Ken.browser_post_koeki()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            ###################################################################
            ### 【正常】DBアクセス処理(2020) STEP2
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※アップロードされたデータを登録する。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 17/18.', 'DEBUG')
            for i, _ in enumerate(ws):
                koeki_header_id = KOEKI_HEADER.objects.all().aggregate(Max('koeki_header_id'))['koeki_header_id__max']
                if koeki_header_id is None:
                    koeki_header_id = 1
                else:
                    koeki_header_id += 1
                
                if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
                    PARAMS = dict({
                        'KOEKI_HEADER_ID': koeki_header_id, 
                        'KOEKI_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=9, column=7).value)[-1]), 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None, 
                        'DELETED_AT': None,
                        'KOEKI_KEN_UPLOAD': _PROVISIONED_KOEKI_KEN_UPLOAD,
                    })
                else:
                    PARAMS = dict({
                        'KOEKI_HEADER_ID': koeki_header_id, 
                        'KOEKI_HEADER_NAME': ws_title[i], 
                        'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=9, column=7).value)[-1]), 
                        'UPLOAD_FILE_PATH': upload_file_path, 
                        'UPLOAD_FILE_NAME': upload_file_name, 
                        'SUMMARY_FILE_PATH': None, 
                        'SUMMARY_FILE_NAME': None, 
                        'DELETED_AT': None,
                        'KOEKI_KEN_UPLOAD': _CONFIRMED_KOEKI_KEN_UPLOAD,
                    })
                SQL_INSERT_KOEKI_HEADER = """
                    INSERT INTO KOEKI_HEADER (
                        KOEKI_HEADER_ID, KOEKI_HEADER_NAME, KEN_CODE, 
                        UPLOAD_FILE_PATH, UPLOAD_FILE_NAME, SUMMARY_FILE_PATH, SUMMARY_FILE_NAME, 
                        COMMITTED_AT, DELETED_AT 
                    ) VALUES (
                        %(KOEKI_HEADER_ID)s, 
                        %(KOEKI_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s, 
                        CURRENT_TIMESTAMP,  -- COMMITTED_AT 
                        %(DELETED_AT)s)"""
                SQL_INSERT_KOEKI_HISTORY = """
                    INSERT INTO KOEKI_HISTORY (
                        KOEKI_HEADER_ID,
                        WORKFLOW_CODE,
                        COMMITTED_AT
                    ) VALUES (
                        %(KOEKI_HEADER_ID)s,
                        %(KOEKI_KEN_UPLOAD)s,
                        CURRENT_TIMESTAMP)"""

                connection_cursor.execute(SQL_INSERT_KOEKI_HEADER,  PARAMS)
                connection_cursor.execute(SQL_INSERT_KOEKI_HISTORY, PARAMS)
                    
                ###############################################################
                ### 【正常】DBアクセス処理(2030) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※アップロードされたデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 17_1/18.', 'DEBUG')
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if (max_row[i] >= 9):
                    for j in range(9, max_row[i]+1):
                        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 j={}'.format(j), 'DEBUG')
                        PARAMS_INSERT_KOEKI = dict({
                            'KOEKI_NAME': convert_empty_to_none(ws[i].cell(row=j, column=2).value), 
                            'KOEKI_HEADER_ID': koeki_header_id, 
                            'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=9).value)[-1]), 
                            'BEGIN_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=2).value)[-1]), 
                            'END_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=11).value)[-1]), 
                            'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=12).value)[-1]), 
                            'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=13).value)[-1]), 
                            'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=14).value)[-1]), 
                            'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=15).value)[-1]), 
                            'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=19).value)[-1]), 
                            'CAUSE_1_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=16).value)[-1]), 
                            'CAUSE_2_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=17).value)[-1]), 
                            'CAUSE_3_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=18).value)[-1]), 
                            'BUSINESS_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=20).value)[-1]), 
                            'ORGANIZATION_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=21).value)[-1]), 
                            'PHYSICAL_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=22).value), 
                            'SALES_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=23).value), 
                            'ALT_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=24).value), 
                            'OTHER_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=25).value), 
                            'TOTAL_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=26).value), 
                            'SUSPENDED_DAYS': convert_empty_to_none(ws[i].cell(row=j, column=27).value), 
                            'SUSPENDED_HOURS': convert_empty_to_none(ws[i].cell(row=j, column=28).value), 
                            'SUSPENDED_AMOUNTS': convert_empty_to_none(ws[i].cell(row=j, column=29).value), 
                            'DEPARTMENT_NAME': convert_empty_to_none(ws[i].cell(row=j, column=30).value), 
                            'EMPLOYEE_NAME': convert_empty_to_none(ws[i].cell(row=j, column=31).value), 
                            'TELEPHONE': convert_empty_to_none(ws[i].cell(row=j, column=32).value), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=33).value), 
                            'DELETED_AT': None
                        })
                        SQL_INSERT_KOEKI = """ 
                            INSERT INTO KOEKI (
                                KOEKI_ID, KOEKI_NAME, KOEKI_HEADER_ID, 
                                CITY_CODE, BEGIN_DATE, END_DATE, 
                                SUIKEI_CODE, SUIKEI_TYPE_CODE, KASEN_CODE, KASEN_TYPE_CODE, KASEN_KAIGAN_CODE, WEATHER_ID, 
                                CAUSE_1_CODE, CAUSE_2_CODE, CAUSE_3_CODE, BUSINESS_CODE, ORGANIZATION_NAME, 
                                PHYSICAL_DAMAGE, SALES_DAMAGE, ALT_DAMAGE, OTHER_DAMAGE, TOTAL_DAMAGE, 
                                SUSPENDED_DAYS, SUSPENDED_HOURS, SUSPENDED_AMOUNTS, 
                                DEPARTMENT_NAME, EMPLOYEE_NAME, TELEPHONE, COMMENT, 
                                COMMITTED_AT, DELETED_AT 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(koeki_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(koeki_id+1) AS INTEGER) END AS koeki_id FROM KOEKI), -- koeki_id 
                                %(KOEKI_NAME)s, 
                                %(KOEKI_HEADER_ID)s, 
                                %(CITY_CODE)s, 
                                TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                                TO_DATE(%(END_DATE)s, 'YYYY/MM/DD'), 
                                %(SUIKEI_CODE)s, 
                                %(SUIKEI_TYPE_CODE)s, 
                                %(KASEN_CODE)s, 
                                %(KASEN_TYPE_CODE)s, 
                                %(KASEN_KAIGAN_CODE)s, 
                                %(WEATHER_ID)s, 
                                %(CAUSE_1_CODE)s, 
                                %(CAUSE_2_CODE)s, 
                                %(CAUSE_3_CODE)s, 
                                %(BUSINESS_CODE)s, 
                                %(ORGANIZATION_NAME)s, 
                                %(PHYSICAL_DAMAGE)s, 
                                %(SALES_DAMAGE)s, 
                                %(ALT_DAMAGE)s, 
                                %(OTHER_DAMAGE)s, 
                                %(TOTAL_DAMAGE)s, 
                                %(SUSPENDED_DAYS)s, 
                                %(SUSPENDED_HOURS)s, 
                                %(SUSPENDED_AMOUNTS)s, 
                                %(DEPARTMENT_NAME)s, 
                                %(EMPLOYEE_NAME)s, 
                                %(TELEPHONE)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- COMMITTED_AT
                                %(DELETED_AT)s) """

                        connection_cursor.execute(SQL_INSERT_KOEKI, PARAMS_INSERT_KOEKI)

                ###############################################################
                ### 【正常】DBアクセス処理(2040) STEP2
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにKOE_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 17_2/18.', 'DEBUG')
                PARAMS_MESSAGE = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': koeki_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _KOE_ACT_01, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(PARAMS_MESSAGE)
                
                if bool_return == False:
                    print_log('[ERROR] P0120Ken.browser_post_koeki()関数 publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0120Ken.browser_post_koeki()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_koeki()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_koeki()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        finally:
            connection_cursor.close()
        
        #######################################################################
        ### 【正常】レスポンスセット処理(2050)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 18/18.', 'DEBUG')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'browser_post_koeki_info': 'browser_post_koeki_info',
            'require_info': require_info, 
            'format_info': format_info,
            'range_info': range_info,
            'correlate_info': correlate_info,
            'compare_info': compare_info,
        }
        print_log('[INFO] P0120Ken.browser_post_koeki()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0120Ken.browser_post_koeki()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_koeki()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_koeki()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### /P0120Ken/ => /P0120Ken/bucket/ リダイレクト用
### urlpattern：path('', views.index_view, name='index_view')
### ※リダイレクトのみのため、custom_decoratorはセットしない。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    return redirect('bucket/')

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 都道府県バケット
### urlpattern：path('bucket/', views.bucket_view, name='bucket_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='bucket_view')
def bucket_view(request):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### KEN_BUCKET: バケットデータ_都道府県
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.bucket_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        
        PARAMS = dict({
            'KEN_CODE': user_proxy_list[0].ken_code 
        })
        SQL_SELECT_KEN_BUCKET = """
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, 
                FILES 
            FROM KEN_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s"""
        ken_bucket_list = KEN_BUCKET.objects.raw(SQL_SELECT_KEN_BUCKET, PARAMS)
        
        print_log('[DEBUG] P0120Ken.bucket_view()関数 ken_bucket_list={}'.format(ken_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.bucket_view()関数 len(ken_bucket_list)={}'.format(len(ken_bucket_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 2/3.', 'DEBUG')
        if ken_bucket_list == False:
            print_log('[WARN] P0120Ken.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0120Ken.bucket_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0120Ken/bucket/bucket.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'ken_bucket_list': ken_bucket_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0120Ken.bucket_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.bucket_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.bucket_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/bucket/bucket.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 都道府県ブラウザ
### urlpattern：path('browser/', views.browser_view, name='browser_view')
### (1)GETの場合、ファイル管理画面を表示する。
### (2)POSTの場合、アップロードされた地方単独事業調査票、補助事業調査票、公益事業調査票ファイルをチェックして、正常ケースの場合、DBに登録する。
### ※複数EXCELシート未対応版
### ※DELEGATE処理のため、関数からの戻り値のbool_returnを処理しない。
### ※except、異常処理は関数からの戻り値のresponseに含めること。
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='browser_view')
def browser_view(request):
    if request.method == 'GET':
        bool_return, response = browser_get(request)
        return response
    
    if request.method == 'POST':
        if 'upload_chitan_button' in request.POST:
            bool_return, response = browser_post_chitan(request)
            return response
        
        if 'upload_hojo_button' in request.POST:
            bool_return, response = browser_post_hojo(request)
            return response
        
        if 'upload_koeki_button' in request.POST:
            bool_return, response = browser_post_koeki(request)
            return response
        
        return redirect('/P0120Ken/browser/')
    
    return redirect('/P0120Ken/browser/')

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 市区町村ブラウザ
### urlpattern：path('browser/city/<slug:city_code>/', views.browser_city_code_view, name='browser_city_code_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='browser_city_code_view')
def browser_city_code_view(request, city_code):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### CITY_BUCKET: 
        ### IPPAN_HEADER: 
        ### KUIKI: 
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 city_code={}'.format(city_code), 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'CITY_CODE': city_code,
                'IPPAN_CITY_UPLOAD': _PROVISIONED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _PROVISIONED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _PROVISIONED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _PROVISIONED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _PROVISIONED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _PROVISIONED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _PROVISIONED_IPPAN_MANAGE_DISAPPROVE,
                'LIKE_KEN_CODE': '%' + user_proxy_list[0].ken_code + '%',
            })
        else:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'CITY_CODE': city_code,
                'IPPAN_CITY_UPLOAD': _CONFIRMED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _CONFIRMED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _CONFIRMED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _CONFIRMED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _CONFIRMED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _CONFIRMED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _CONFIRMED_IPPAN_MANAGE_DISAPPROVE,
                'LIKE_KEN_CODE': '%' + user_proxy_list[0].ken_code + '%',
            })
        SQL_SELECT_CITY_BUCKET = """
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, -- ディスク使用量 
                FILES -- ファイル格納数
            FROM CITY_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                CITY_CODE=%(CITY_CODE)s"""
        SQL_SELECT_IPPAN_HEADER = """
            SELECT 
                I1.IPPAN_HEADER_ID, 
                I1.IPPAN_HEADER_NAME, 
                I1.KEN_CODE, 
                I1.CITY_CODE, 
                I1.KUIKI_ID,
                I1.WEATHER_ID,
                I1.UPLOAD_FILE_PATH, 
                I1.UPLOAD_FILE_NAME, 
                I1.UPLOAD_FILE_SIZE, 
                I1.SUMMARY_FILE_PATH, 
                I1.SUMMARY_FILE_NAME, 
                I1.SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', I1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', I1.DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT, 
                S1.IPPAN_HISTORY_ID,
                S1.WORKFLOW_CODE
            FROM IPPAN_HEADER I1
            LEFT JOIN (
                SELECT
                    IPPAN_HISTORY_ID,
                    IPPAN_HEADER_ID,
                    WORKFLOW_CODE
                FROM IPPAN_HISTORY
                WHERE
                    IPPAN_HISTORY_ID IN (
                        SELECT
                            MAX(IPPAN_HISTORY_ID)
                        FROM IPPAN_HISTORY
                        GROUP BY IPPAN_HEADER_ID
                    )
            ) S1 ON I1.IPPAN_HEADER_ID=S1.IPPAN_HEADER_ID
            WHERE 
                I1.KEN_CODE=%(KEN_CODE)s AND 
                I1.CITY_CODE=%(CITY_CODE)s AND 
                I1.DELETED_AT IS NULL
            ORDER BY I1.IPPAN_HEADER_ID"""
        SQL_SELECT_WEATHER = """
            SELECT
                WEATHER_ID,
                WEATHER_NAME,
                BEGIN_DATE,
                END_DATE,
                KEN_CODE,
                COMMITTED_AT,
                DELETED_AT
            FROM WEATHER
            WHERE
                KEN_CODE LIKE %(LIKE_KEN_CODE)s AND
                DELETED_AT IS NULL 
            ORDER BY WEATHER_ID"""
        
        ### HTMLタイトル部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw(SQL_SELECT_CITY_BUCKET, PARAMS)
        ### HTML一覧部分表示用
        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS)
        ### HTML一覧部分表示用
        ### HTML右スライド部分
        weather_list = WEATHER.objects.raw(SQL_SELECT_WEATHER, PARAMS)
        
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 city_bucket_list={}'.format(city_bucket_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 len(city_bucket_list)={}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 len(ippan_header_list)={}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 weather_list={}'.format(weather_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 len(weather_list)={}'.format(len(weather_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 2/3.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0120Ken.browser_city_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser_city_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        ### 一般資産調査員調査票ファイルの0件は正常であるため、チェックしない。
        ### 水害区域図ファイルの0件は正常であるため、チェックしない。

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0120Ken.browser_city_code_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0120Ken/browser/browser_city_code.html')
        context = {
            'provisioned_confirmed': provisioned_confirmed_list[0].provisioned_confirmed,
            'city_bucket_list': city_bucket_list, 
            'ippan_header_list': ippan_header_list, 
            'weather_list': weather_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0120Ken.browser_city_code_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_city_code_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_city_code_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser_city_code.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 右スライドメニュー表示
### urlpattern：path('slide/ippan/header/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_ippan_header_id_view')
def slide_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### IPPAN_HEADER: アップロードデータ_一般資産調査員調査票_ヘッダ部分
        ### IPPAN_HISTORY:
        ### ※IPPAN_HEADER_IDを指定して他都道府県の参照ができないように、ユーザ情報から取得した都道府県コードも検索条件に含める。
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_UPLOAD': _PROVISIONED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _PROVISIONED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _PROVISIONED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _PROVISIONED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _PROVISIONED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _PROVISIONED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _PROVISIONED_IPPAN_MANAGE_DISAPPROVE,
                'IPP_ACT_01': _IPP_ACT_01,
                'IPP_ACT_02': _IPP_ACT_02,
                'IPP_ACT_03': _IPP_ACT_03,
            })
        else:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'IPPAN_HEADER_ID': header_id, 
                'IPPAN_CITY_UPLOAD': _CONFIRMED_IPPAN_CITY_UPLOAD,
                'IPPAN_CITY_APPLY': _CONFIRMED_IPPAN_CITY_APPLY,
                'IPPAN_CITY_DELETE': _CONFIRMED_IPPAN_CITY_DELETE,
                'IPPAN_KEN_LINKAGE_WEATHER': _CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER,
                'IPPAN_KEN_APPROVE': _CONFIRMED_IPPAN_KEN_APPROVE,
                'IPPAN_KEN_DISAPPROVE': _CONFIRMED_IPPAN_KEN_DISAPPROVE,
                'IPPAN_MANAGE_APPROVE': _CONFIRMED_IPPAN_MANAGE_APPROVE,
                'IPPAN_MANAGE_DISAPPROVE': _CONFIRMED_IPPAN_MANAGE_DISAPPROVE,
                'IPP_ACT_01': _IPP_ACT_01,
                'IPP_ACT_02': _IPP_ACT_02,
                'IPP_ACT_03': _IPP_ACT_03,
            })
        SQL_SELECT_IPPAN_HEADER = """
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                KUIKI_ID, -- ADD 2024/10/02
                WEATHER_ID, -- ADD 2024/10/02
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s"""
        SQL_SELECT_IPPAN_HISTORY = """
            SELECT
                IPPAN_HISTORY_ID,
                IPPAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM IPPAN_HISTORY
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s
            ORDER BY IPPAN_HISTORY_ID"""
        SQL_SELECT_IPPAN_HISTORY_LATEST = """
            SELECT
                IPPAN_HISTORY_ID,
                IPPAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM IPPAN_HISTORY
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s
            ORDER BY IPPAN_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_IPPAN_TRIGGER = """
            SELECT
                IPPAN_TRIGGER_ID,
                IPPAN_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM IPPAN_TRIGGER
            WHERE
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND
                ACTION_CODE IN (%(IPP_ACT_01)s, %(IPP_ACT_02)s, %(IPP_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY IPPAN_TRIGGER_ID"""
            
        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS)
        ippan_history_list = IPPAN_HISTORY.objects.raw(SQL_SELECT_IPPAN_HISTORY, PARAMS)
        ippan_history_latest_list = IPPAN_HISTORY.objects.raw(SQL_SELECT_IPPAN_HISTORY_LATEST, PARAMS)
        ippan_trigger_list = IPPAN_TRIGGER.objects.raw(SQL_SELECT_IPPAN_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 len(ippan_header_list)={}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 ippan_history_list={}'.format(ippan_history_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 len(ippan_history_list)={}'.format(len(ippan_history_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 ippan_history_latest_list={}'.format(ippan_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 len(ippan_history_latest_list)={}'.format(len(ippan_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 ippan_trigger_list={}'.format(ippan_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 len(ippan_trigger_list)={}'.format(len(ippan_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if ippan_header_list == False:
            print_log('[WARN] P0120Ken.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'return_code': ["TRUE"], 
            'ippan_header_id': ippan_header_list[0].ippan_header_id, 
            'ippan_header_name': ippan_header_list[0].ippan_header_name, 
            'ken_code': ippan_header_list[0].ken_code, 
            'city_code': ippan_header_list[0].city_code, 
            'kuiki_id': ippan_header_list[0].kuiki_id,
            'weather_id': ippan_header_list[0].weather_id, 
            'upload_file_path': ippan_header_list[0].upload_file_path, 
            'upload_file_name': ippan_header_list[0].upload_file_name, 
            'upload_file_size': ippan_header_list[0].upload_file_size, 
            'summary_file_path': ippan_header_list[0].summary_file_path, 
            'summary_file_name': ippan_header_list[0].summary_file_name, 
            'summary_file_size': ippan_header_list[0].summary_file_size, 
            'committed_at': ippan_header_list[0].committed_at, 
            'deleted_at': ippan_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if ippan_history_latest_list:
            latest = {
                'latest_workflow_code': ippan_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if ippan_history_list:
            for ippan_history in ippan_history_list:
                history_list.append({'workflow_code': ippan_history.workflow_code, 'committed_at': ippan_history.committed_at})

        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if ippan_trigger_list:
            for ippan_trigger in ippan_trigger_list:
                trigger_list.append({'action_code': ippan_trigger.action_code, 'status_code': ippan_trigger.status_code, 'consumed_at': ippan_trigger.consumed_at})
        
        print_log('[INFO] P0120Ken.slide_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 右スライドメニュー表示
### urlpattern：path('slide/chitan/header/<slug:header_id>/', views.slide_chitan_header_id_view, name='slide_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_chitan_header_id_view')
def slide_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### CHITAN_HEADER: 
        ### CHITAN_HISTORY:
        ### ※CHITAN_HEADER_IDを指定した他都道府県情報の参照ができないように、ユーザ情報から取得した都道府県コードでも条件指定する。
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'CHITAN_HEADER_ID': header_id, 
                'CHITAN_KEN_UPLOAD': _PROVISIONED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _PROVISIONED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _PROVISIONED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _PROVISIONED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _PROVISIONED_CHITAN_MANAGE_DISAPPROVE,
                'CHI_ACT_01': _CHI_ACT_01,
                'CHI_ACT_02': _CHI_ACT_02,
                'CHI_ACT_03': _CHI_ACT_03,
            })
        else:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'CHITAN_HEADER_ID': header_id, 
                'CHITAN_KEN_UPLOAD': _CONFIRMED_CHITAN_KEN_UPLOAD,
                'CHITAN_KEN_APPLY': _CONFIRMED_CHITAN_KEN_APPLY,
                'CHITAN_KEN_DELETE': _CONFIRMED_CHITAN_KEN_DELETE,
                'CHITAN_MANAGE_APPROVE': _CONFIRMED_CHITAN_MANAGE_APPROVE,
                'CHITAN_MANAGE_DISAPPROVE': _CONFIRMED_CHITAN_MANAGE_DISAPPROVE,
                'CHI_ACT_01': _CHI_ACT_01,
                'CHI_ACT_02': _CHI_ACT_02,
                'CHI_ACT_03': _CHI_ACT_03,
            })
        SQL_SELECT_CHITAN_HEADER = """
            SELECT 
                CHITAN_HEADER_ID, 
                CHITAN_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM CHITAN_HEADER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s"""
        SQL_SELECT_CHITAN_HISTORY = """
            SELECT
                CHITAN_HISTORY_ID,
                CHITAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM CHITAN_HISTORY
            WHERE
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s
            ORDER BY CHITAN_HISTORY_ID"""
        SQL_SELECT_CHITAN_HISTORY_LATEST = """
            SELECT
                CHITAN_HISTORY_ID,
                CHITAN_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM CHITAN_HISTORY
            WHERE
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s
            ORDER BY CHITAN_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_CHITAN_TRIGGER = """
            SELECT
                CHITAN_TRIGGER_ID,
                CHITAN_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM CHITAN_TRIGGER
            WHERE
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND
                ACTION_CODE IN (%(CHI_ACT_01)s, %(CHI_ACT_02)s, %(CHI_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY CHITAN_TRIGGER_ID"""

        chitan_header_list = CHITAN_HEADER.objects.raw(SQL_SELECT_CHITAN_HEADER, PARAMS)
        chitan_history_list = CHITAN_HISTORY.objects.raw(SQL_SELECT_CHITAN_HISTORY, PARAMS)
        chitan_history_latest_list = CHITAN_HISTORY.objects.raw(SQL_SELECT_CHITAN_HISTORY_LATEST, PARAMS)
        chitan_trigger_list = CHITAN_TRIGGER.objects.raw(SQL_SELECT_CHITAN_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 chitan_header_list={}'.format(chitan_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 len(chitan_header_list)={}'.format(len(chitan_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 chitan_history_list={}'.format(chitan_history_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 len(chitan_history_list)={}'.format(len(chitan_history_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 chitan_history_latest_list={}'.format(chitan_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 len(chitan_history_latest_list)={}'.format(len(chitan_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 chitan_trigger_list={}'.format(chitan_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 len(chitan_trigger_list)={}'.format(len(chitan_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if chitan_header_list == False:
            print_log('[WARN] P0120Ken.slide_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'return_code': ["TRUE"], 
            'chitan_header_id': chitan_header_list[0].chitan_header_id, 
            'chitan_header_name': chitan_header_list[0].chitan_header_name, 
            'ken_code': chitan_header_list[0].ken_code, 
            'upload_file_path': chitan_header_list[0].upload_file_path, 
            'upload_file_name': chitan_header_list[0].upload_file_name, 
            'upload_file_size': chitan_header_list[0].upload_file_size, 
            'summary_file_path': chitan_header_list[0].summary_file_path, 
            'summary_file_name': chitan_header_list[0].summary_file_name, 
            'summary_file_size': chitan_header_list[0].summary_file_size, 
            'committed_at': chitan_header_list[0].committed_at, 
            'deleted_at': chitan_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if chitan_history_latest_list:
            latest = {
                'latest_workflow_code': chitan_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if chitan_history_list:
            for chitan_history in chitan_history_list:
                history_list.append({'workflow_code': chitan_history.workflow_code, 'committed_at': chitan_history.committed_at})

        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if chitan_trigger_list:
            for chitan_trigger in chitan_trigger_list:
                trigger_list.append({'action_code': chitan_trigger.action_code, 'status_code': chitan_trigger.status_code, 'consumed_at': chitan_trigger.consumed_at})

        print_log('[INFO] P0120Ken.slide_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_chitan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_chitan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 右スライドメニュー表示
### urlpattern：path('slide/hojo/header/<slug:header_id>/', views.slide_hojo_header_id_view, name='slide_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_hojo_header_id_view')
def slide_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### HOJO_HEADER: 
        ### HOJO_HISTORY:
        ### ※HOJO_HEADER_IDを指定した他都道府県情報の参照ができないように、ユーザ情報から取得した都道府県コードでも条件指定する。
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'HOJO_HEADER_ID': header_id, 
                'HOJO_KEN_UPLOAD': _PROVISIONED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _PROVISIONED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _PROVISIONED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _PROVISIONED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _PROVISIONED_HOJO_MANAGE_DISAPPROVE,
                'HOJ_ACT_01': _HOJ_ACT_01,
                'HOJ_ACT_02': _HOJ_ACT_02,
                'HOJ_ACT_03': _HOJ_ACT_03,
            })
        else:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'HOJO_HEADER_ID': header_id, 
                'HOJO_KEN_UPLOAD': _CONFIRMED_HOJO_KEN_UPLOAD,
                'HOJO_KEN_APPLY': _CONFIRMED_HOJO_KEN_APPLY,
                'HOJO_KEN_DELETE': _CONFIRMED_HOJO_KEN_DELETE,
                'HOJO_MANAGE_APPROVE': _CONFIRMED_HOJO_MANAGE_APPROVE,
                'HOJO_MANAGE_DISAPPROVE': _CONFIRMED_HOJO_MANAGE_DISAPPROVE,
                'HOJ_ACT_01': _HOJ_ACT_01,
                'HOJ_ACT_02': _HOJ_ACT_02,
                'HOJ_ACT_03': _HOJ_ACT_03,
            })
        SQL_SELECT_HOJO_HEADER = """
            SELECT 
                HOJO_HEADER_ID, 
                HOJO_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM HOJO_HEADER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s"""
        SQL_SELECT_HOJO_HISTORY = """
            SELECT
                HOJO_HISTORY_ID,
                HOJO_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM HOJO_HISTORY
            WHERE
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s
            ORDER BY HOJO_HISTORY_ID"""
        SQL_SELECT_HOJO_HISTORY_LATEST = """
            SELECT
                HOJO_HISTORY_ID,
                HOJO_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM HOJO_HISTORY
            WHERE
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s
            ORDER BY HOJO_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_HOJO_TRIGGER = """
            SELECT
                HOJO_TRIGGER_ID,
                HOJO_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM HOJO_TRIGGER
            WHERE
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND
                ACTION_CODE IN (%(HOJ_ACT_01)s, %(HOJ_ACT_02)s, %(HOJ_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY HOJO_TRIGGER_ID"""
                
        hojo_header_list = HOJO_HEADER.objects.raw(SQL_SELECT_HOJO_HEADER, PARAMS)
        hojo_history_list = HOJO_HISTORY.objects.raw(SQL_SELECT_HOJO_HISTORY, PARAMS)
        hojo_history_latest_list = HOJO_HISTORY.objects.raw(SQL_SELECT_HOJO_HISTORY_LATEST, PARAMS)
        hojo_trigger_list = HOJO_TRIGGER.objects.raw(SQL_SELECT_HOJO_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 hojo_header_list={}'.format(hojo_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 len(hojo_header_list)={}'.format(len(hojo_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 hojo_history_list={}'.format(hojo_history_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 len(hojo_history_list)={}'.format(len(hojo_history_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 hojo_history_latest_list={}'.format(hojo_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 len(hojo_history_latest_list)={}'.format(len(hojo_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 hojo_trigger_list={}'.format(hojo_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 len(hojo_trigger_list)={}'.format(len(hojo_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if hojo_header_list == False:
            print_log('[WARN] P0120Ken.slide_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'return_code': ["TRUE"], 
            'hojo_header_id': hojo_header_list[0].hojo_header_id, 
            'hojo_header_name': hojo_header_list[0].hojo_header_name, 
            'ken_code': hojo_header_list[0].ken_code, 
            'upload_file_path': hojo_header_list[0].upload_file_path, 
            'upload_file_name': hojo_header_list[0].upload_file_name, 
            'upload_file_size': hojo_header_list[0].upload_file_size, 
            'summary_file_path': hojo_header_list[0].summary_file_path, 
            'summary_file_name': hojo_header_list[0].summary_file_name, 
            'summary_file_size': hojo_header_list[0].summary_file_size, 
            'committed_at': hojo_header_list[0].committed_at, 
            'deleted_at': hojo_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if hojo_history_latest_list:
            latest = {
                'latest_workflow_code': hojo_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if hojo_history_list:
            for hojo_history in hojo_history_list:
                history_list.append({'workflow_code': hojo_history.workflow_code, 'committed_at': hojo_history.committed_at})

        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if hojo_trigger_list:
            for hojo_trigger in hojo_trigger_list:
                trigger_list.append({'action_code': hojo_trigger.action_code, 'status_code': hojo_trigger.status_code, 'consumed_at': hojo_trigger.consumed_at})

        print_log('[INFO] P0120Ken.slide_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_hojo_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_hojo_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 右スライドメニュー表示
### urlpattern：path('slide/koeki/header/<slug:header_id>/', views.slide_koeki_header_id_view, name='slide_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='slide_koeki_header_id_view')
def slide_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### KOEKI_HEADER: 
        ### KOEKI_HISTORY:
        ### ※KOEKI_HEADER_IDを指定した他都道府県情報の参照ができないように、ユーザ情報から取得した都道府県コードでも条件指定する。
        ### ※LATESTはユーザアクションのみを条件に検索する。HISTORYは自動チェック、自動集計も含めるように修正した。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'KOEKI_HEADER_ID': header_id, 
                'KOEKI_KEN_UPLOAD': _PROVISIONED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _PROVISIONED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _PROVISIONED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _PROVISIONED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _PROVISIONED_KOEKI_MANAGE_DISAPPROVE,
                'KOE_ACT_01': _KOE_ACT_01,
                'KOE_ACT_02': _KOE_ACT_02,
                'KOE_ACT_03': _KOE_ACT_03,
            })
        else:
            PARAMS = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'KOEKI_HEADER_ID': header_id, 
                'KOEKI_KEN_UPLOAD': _CONFIRMED_KOEKI_KEN_UPLOAD,
                'KOEKI_KEN_APPLY': _CONFIRMED_KOEKI_KEN_APPLY,
                'KOEKI_KEN_DELETE': _CONFIRMED_KOEKI_KEN_DELETE,
                'KOEKI_MANAGE_APPROVE': _CONFIRMED_KOEKI_MANAGE_APPROVE,
                'KOEKI_MANAGE_DISAPPROVE': _CONFIRMED_KOEKI_MANAGE_DISAPPROVE,
                'KOE_ACT_01': _KOE_ACT_01,
                'KOE_ACT_02': _KOE_ACT_02,
                'KOE_ACT_03': _KOE_ACT_03,
            })
        SQL_SELECT_KOEKI_HEADER = """
            SELECT 
                KOEKI_HEADER_ID, 
                KOEKI_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM KOEKI_HEADER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s"""
        SQL_SELECT_KOEKI_HISTORY = """
            SELECT
                KOEKI_HISTORY_ID,
                KOEKI_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM KOEKI_HISTORY
            WHERE
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s
            ORDER BY KOEKI_HISTORY_ID"""
        SQL_SELECT_KOEKI_HISTORY_LATEST = """
            SELECT
                KOEKI_HISTORY_ID,
                KOEKI_HEADER_ID,
                WORKFLOW_CODE,
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT
            FROM KOEKI_HISTORY
            WHERE
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s
            ORDER BY KOEKI_HISTORY_ID DESC LIMIT 1"""
        SQL_SELECT_KOEKI_TRIGGER = """
            SELECT
                KOEKI_TRIGGER_ID,
                KOEKI_HEADER_ID,
                KEN_CODE,
                CITY_CODE,
                ACTION_CODE,
                STATUS_CODE,
                TO_CHAR(TIMEZONE('JST', PUBLISHED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS PUBLISHED_AT,
                TO_CHAR(TIMEZONE('JST', CONSUMED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT,
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS CONSUMED_AT
            FROM KOEKI_TRIGGER
            WHERE
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND
                ACTION_CODE IN (%(KOE_ACT_01)s, %(KOE_ACT_02)s, %(KOE_ACT_03)s) AND
                DELETED_AT IS NULL
            ORDER BY KOEKI_TRIGGER_ID"""

        koeki_header_list = KOEKI_HEADER.objects.raw(SQL_SELECT_KOEKI_HEADER, PARAMS)
        koeki_history_list = KOEKI_HISTORY.objects.raw(SQL_SELECT_KOEKI_HISTORY, PARAMS)
        koeki_history_latest_list = KOEKI_HISTORY.objects.raw(SQL_SELECT_KOEKI_HISTORY_LATEST, PARAMS)
        koeki_trigger_list = KOEKI_TRIGGER.objects.raw(SQL_SELECT_KOEKI_TRIGGER, PARAMS)
        
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 koeki_header_list={}'.format(koeki_header_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 len(koeki_header_list)={}'.format(len(koeki_header_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 koeki_history_list={}'.format(koeki_history_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 len(koeki_history_list)={}'.format(len(koeki_history_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 koeki_history_latest_list={}'.format(koeki_history_latest_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 len(koeki_history_latest_list)={}'.format(len(koeki_history_latest_list)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 koeki_trigger_list={}'.format(koeki_trigger_list), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 len(koeki_trigger_list)={}'.format(len(koeki_trigger_list)), 'DEBUG')

        #######################################################################
        ### 【警告】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 2/3.', 'DEBUG')
        if koeki_header_list == False:
            print_log('[WARN] P0120Ken.slide_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 3/3.', 'DEBUG')
        data = {
            'return_code': ["TRUE"], 
            'koeki_header_id': koeki_header_list[0].koeki_header_id, 
            'koeki_header_name': koeki_header_list[0].koeki_header_name, 
            'ken_code': koeki_header_list[0].ken_code, 
            'upload_file_path': koeki_header_list[0].upload_file_path, 
            'upload_file_name': koeki_header_list[0].upload_file_name, 
            'upload_file_size': koeki_header_list[0].upload_file_size, 
            'summary_file_path': koeki_header_list[0].summary_file_path, 
            'summary_file_name': koeki_header_list[0].summary_file_name, 
            'summary_file_size': koeki_header_list[0].summary_file_size, 
            'committed_at': koeki_header_list[0].committed_at, 
            'deleted_at': koeki_header_list[0].deleted_at, 
        }

        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 3_1/3.', 'DEBUG')
        if koeki_history_latest_list:
            latest = {
                'latest_workflow_code': koeki_history_latest_list[0].workflow_code,
            }
        else:
            latest = {
                'latest_workflow_code': None,
            }
        data.update(latest)

        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 3_2/3.', 'DEBUG')
        history_list = []
        if koeki_history_list:
            for koeki_history in koeki_history_list:
                history_list.append({'workflow_code': koeki_history.workflow_code, 'committed_at': koeki_history.committed_at})

        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 3_3/3.', 'DEBUG')
        trigger_list = []
        if koeki_trigger_list:
            for koeki_trigger in koeki_trigger_list:
                trigger_list.append({'action_code': koeki_trigger.action_code, 'status_code': koeki_trigger.status_code, 'consumed_at': koeki_trigger.consumed_at})

        print_log('[INFO] P0120Ken.slide_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse({'meta': data, 'history_list': history_list, 'trigger_list': trigger_list}, safe=False)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_koeki_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_koeki_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 申請
### urlpattern：path('apply/chitan/header/<slug:header_id>/', views.apply_chitan_header_id_view, name='apply_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='apply_chitan_header_id_view')
def apply_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.apply_chitan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_chitan_header_id_view()関数 _PROVISIONED_CHITAN_KEN_APPLY={}'.format(_PROVISIONED_CHITAN_KEN_APPLY), 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_chitan_header_id_view()関数 _CONFIRMED_CHITAN_KEN_APPLY={}'.format(_CONFIRMED_CHITAN_KEN_APPLY), 'DEBUG')
        
        connection_cursor = connection.cursor()

        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id,
                'CHITAN_KEN_APPLY': _PROVISIONED_CHITAN_KEN_APPLY,
            })
        else:
            PARAMS = dict({
                'CHITAN_HEADER_ID': header_id,
                'CHITAN_KEN_APPLY': _CONFIRMED_CHITAN_KEN_APPLY,
            })
        SQL_INSERT_CHITAN_HISTORY = """
            INSERT INTO CHITAN_HISTORY (
                CHITAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(CHITAN_HEADER_ID)s,
                %(CHITAN_KEN_APPLY)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_CHITAN_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.apply_chitan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.apply_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.apply_chitan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.apply_chitan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.apply_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 申請
### urlpattern：path('apply/hojo/header/<slug:header_id>/', views.apply_hojo_header_id_view, name='apply_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='apply_hojo_header_id_view')
def apply_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.apply_hojo_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_hojo_header_id_view()関数 _PROVISIONED_HOJO_KEN_APPLY={}'.format(_PROVISIONED_HOJO_KEN_APPLY), 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_hojo_header_id_view()関数 _CONFIRMED_HOJO_KEN_APPLY={}'.format(_CONFIRMED_HOJO_KEN_APPLY), 'DEBUG')

        connection_cursor = connection.cursor()

        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id,
                'HOJO_KEN_APPLY': _PROVISIONED_HOJO_KEN_APPLY,
            })
        else:
            PARAMS = dict({
                'HOJO_HEADER_ID': header_id,
                'HOJO_KEN_APPLY': _CONFIRMED_HOJO_KEN_APPLY,
            })
        SQL_INSERT_HOJO_HISTORY = """
            INSERT INTO HOJO_HISTORY (
                HOJO_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(HOJO_HEADER_ID)s,
                %(HOJO_KEN_APPLY)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_HOJO_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.apply_hojo_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.apply_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.apply_hojo_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.apply_hojo_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.apply_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業等調査票 申請
### urlpattern：path('apply/koeki/header/<slug:header_id>/', views.apply_koeki_header_id_view, name='apply_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='apply_koeki_header_id_view')
def apply_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.apply_koeki_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_koeki_header_id_view()関数 _PROVISIONED_KOEKI_KEN_APPLY={}'.format(_PROVISIONED_KOEKI_KEN_APPLY), 'DEBUG')
        print_log('[DEBUG] P0120Ken.apply_koeki_header_id_view()関数 _CONFIRMED_KOEKI_KEN_APPLY={}'.format(_CONFIRMED_KOEKI_KEN_APPLY), 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id,
                'KOEKI_KEN_APPLY': _PROVISIONED_KOEKI_KEN_APPLY,
            })
        else:
            PARAMS = dict({
                'KOEKI_HEADER_ID': header_id,
                'KOEKI_KEN_APPLY': _CONFIRMED_KOEKI_KEN_APPLY,
            })
        SQL_INSERT_KOEKI_HISTORY = """
            INSERT INTO KOEKI_HISTORY (
                KOEKI_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(KOEKI_HEADER_ID)s,
                %(KOEKI_KEN_APPLY)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_KOEKI_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.apply_koeki_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.apply_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.apply_koeki_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.apply_koeki_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.apply_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 vs 異常気象コード紐付け
### urlpattern：path('linkage/ippan/header/<slug:header_id>/weather/<slug:weather_id>', views.linkage_ippan_header_id_weather_id_view, name='linkage_ippan_header_id_weather_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='linkage_ippan_header_id_weather_id_view')
def linkage_ippan_header_id_weather_id_view(request, header_id, weather_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 weather_id={}'.format(weather_id), 'DEBUG')

        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:        
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'WEATHER_ID': weather_id,
                'IPPAN_KEN_LINKAGE_WEATHER': _PROVISIONED_IPPAN_KEN_LINKAGE_WEATHER,
            })
        else:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'WEATHER_ID': weather_id,
                'IPPAN_KEN_LINKAGE_WEATHER': _CONFIRMED_IPPAN_KEN_LINKAGE_WEATHER,
            })
            
        SQL_UPDATE_IPPAN_HEADER = """
            UPDATE IPPAN_HEADER SET
                WEATHER_ID=%(WEATHER_ID)s
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s"""
        SQL_INSERT_IPPAN_HISTORY = """
            INSERT INTO IPPAN_HISTORY (
                IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(IPPAN_HEADER_ID)s,
                %(IPPAN_KEN_LINKAGE_WEATHER)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor = connection.cursor()
        
        try:
            connection_cursor.execute("""BEGIN""")
            
            connection_cursor.execute(SQL_UPDATE_IPPAN_HEADER,  PARAMS)
            connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)
            
            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.linkage_ippan_header_id_weather_id_view()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.linkage_ippan_header_id_weather_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.linkage_ippan_header_id_weather_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.linkage_ippan_header_id_weather_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 承認
### urlpattern：path('approve/ippan/header/<slug:header_id>/', views.approve_ippan_header_id_view, name='approve_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='approve_ippan_header_id_view')
def approve_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 _PROVISIONED_IPPAN_KEN_APPROVE={}'.format(_PROVISIONED_IPPAN_KEN_APPROVE), 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 _CONFIRMED_IPPAN_KEN_APPROVE={}'.format(_CONFIRMED_IPPAN_KEN_APPROVE), 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_KEN_APPROVE': _PROVISIONED_IPPAN_KEN_APPROVE,
            })
        else:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_KEN_APPROVE': _CONFIRMED_IPPAN_KEN_APPROVE,
            })
        SQL_INSERT_IPPAN_HISTORY = """
            INSERT INTO IPPAN_HISTORY (
                IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(IPPAN_HEADER_ID)s,
                %(IPPAN_KEN_APPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.approve_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.approve_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.approve_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.approve_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 差し戻し
### urlpattern：path('disapprove/ippan/header/<slug:header_id>/', views.disapprove_ippan_header_id_view, name='disapprove_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='disapprove_ippan_header_id_view')
def disapprove_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.disapprove_ippan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.disapprove_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.disapprove_ippan_header_id_view()関数 _PROVISIONED_IPPAN_KEN_DISAPPROVE={}'.format(_PROVISIONED_IPPAN_KEN_DISAPPROVE), 'DEBUG')
        print_log('[DEBUG] P0120Ken.disapprove_ippan_header_id_view()関数 _CONFIRMED_IPPAN_KEN_DISAPPROVE={}'.format(_CONFIRMED_IPPAN_KEN_DISAPPROVE), 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_KEN_DISAPPROVE': _PROVISIONED_IPPAN_KEN_DISAPPROVE,
            })
        else:
            PARAMS = dict({
                'IPPAN_HEADER_ID': header_id,
                'IPPAN_KEN_DISAPPROVE': _CONFIRMED_IPPAN_KEN_DISAPPROVE,
            })
        SQL_INSERT_IPPAN_HISTORY = """
            INSERT INTO IPPAN_HISTORY (
                IPPAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
            ) VALUES (
                %(IPPAN_HEADER_ID)s,
                %(IPPAN_KEN_DISAPPROVE)s,
                CURRENT_TIMESTAMP)"""
            
        connection_cursor.execute(SQL_INSERT_IPPAN_HISTORY, PARAMS)

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.disapprove_ippan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.disapprove_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.disapprove_ippan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.disapprove_ippan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.disapprove_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 削除
### urlpattern：path('delete/chitan/header/<slug:header_id>/', views.delete_chitan_header_id_view, name='delete_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='delete_chitan_header_id_view')
def delete_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### CHITAN_HEADER: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
        ### CHITAN: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
        ### CHITAN_SUMMARY: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
        ### CHITAN_TRIGGER: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 _PROVISIONED_CHITAN_KEN_DELETE={}'.format(_PROVISIONED_CHITAN_KEN_DELETE), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 _CONFIRMED_CHITAN_KEN_DELETE={}'.format(_CONFIRMED_CHITAN_KEN_DELETE), 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        try:
            connection_cursor.execute("""BEGIN""")
            
            if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
                PARAMS = dict({
                    'KEN_CODE': user_proxy_list[0].ken_code, 
                    'CHITAN_HEADER_ID': header_id, 
                    'CHITAN_KEN_DELETE': _PROVISIONED_CHITAN_KEN_DELETE,
                })
            else:
                PARAMS = dict({
                    'KEN_CODE': user_proxy_list[0].ken_code, 
                    'CHITAN_HEADER_ID': header_id, 
                    'CHITAN_KEN_DELETE': _CONFIRMED_CHITAN_KEN_DELETE,
                })
            SQL_UPDATE_CHITAN_HEADER = """
                UPDATE CHITAN_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_HEADER_ID IN (
                SELECT 
                    CHITAN_HEADER_ID 
                FROM CHITAN_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_CHITAN = """
                UPDATE CHITAN SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_ID IN (
                SELECT 
                    CHITAN_ID 
                FROM CHITAN_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_CHITAN_SUMMARY = """
                UPDATE CHITAN_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_ID IN (
                SELECT 
                    CHITAN_ID 
                FROM CHITAN_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            ### TODO TO-DO TO_DO 削除はシートごとではなく、都道府県ごとに実施する？ため、HEADER_IDで絞り込んではNGである。
            SQL_INSERT_CHITAN_HISTORY = """
                INSERT INTO CHITAN_HISTORY (
                    CHITAN_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
                ) VALUES (
                    %(CHITAN_HEADER_ID)s,
                    %(CHITAN_KEN_DELETE)s,
                    CURRENT_TIMESTAMP)"""
                        
            connection_cursor.execute(SQL_UPDATE_CHITAN_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_CHITAN,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_CHITAN_SUMMARY, PARAMS)
            connection_cursor.execute(SQL_INSERT_CHITAN_HISTORY, PARAMS)

            ### _CHI_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _CHI_ACT_02等でも良い。
            ### 同じ都道府県コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': None, 
                'action_code': _CHI_ACT_01
            })
            bool_return = delete_message(metadata=PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.delete_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 削除
### urlpattern：path('delete/hojo/header/<slug:header_id>/', views.delete_hojo_header_id_view, name='delete_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='delete_hojo_header_id_view')
def delete_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### HOJO_HEADER: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
        ### HOJO: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
        ### HOJO_SUMMARY: 集計データ_公共土木施設調査票_補助事業_一覧表部分
        ### HOJO_TRIGGER: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 _PROVISIONED_HOJO_KEN_DELETE={}'.format(_PROVISIONED_HOJO_KEN_DELETE), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 _CONFIRMED_HOJO_KEN_DELETE={}'.format(_CONFIRMED_HOJO_KEN_DELETE), 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        try:
            connection_cursor.execute("""BEGIN""")
            
            if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
                PARAMS = dict({
                    'KEN_CODE': user_proxy_list[0].ken_code, 
                    'HOJO_HEADER_ID': header_id, 
                    'HOJO_KEN_DELETE': _PROVISIONED_HOJO_KEN_DELETE,
                })
            else:
                PARAMS = dict({
                    'KEN_CODE': user_proxy_list[0].ken_code, 
                    'HOJO_HEADER_ID': header_id, 
                    'HOJO_KEN_DELETE': _CONFIRMED_HOJO_KEN_DELETE,
                })
            SQL_UPDATE_HOJO_HEADER = """
                UPDATE HOJO_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_HEADER_ID IN (
                SELECT 
                    HOJO_HEADER_ID 
                FROM HOJO_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_HOJO = """
                UPDATE HOJO SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_ID IN (
                SELECT 
                    HOJO_ID 
                FROM HOJO_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_HOJO_SUMMARY = """
                UPDATE HOJO_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_ID IN (
                SELECT 
                    HOJO_ID 
                FROM HOJO_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            ### TODO TO-DO TO_DO 削除はシートごとではなく、都道府県ごとに実施する？ため、HEADER_IDで絞り込んではNGである。
            SQL_INSERT_HOJO_HISTORY = """
                INSERT INTO HOJO_HISTORY (
                    HOJO_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
                ) VALUES (
                    %(HOJO_HEADER_ID)s,
                    %(HOJO_KEN_DELETE)s,
                    CURRENT_TIMESTAMP)"""
                        
            connection_cursor.execute(SQL_UPDATE_HOJO_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_HOJO,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_HOJO_SUMMARY, PARAMS)
            connection_cursor.execute(SQL_INSERT_HOJO_HISTORY, PARAMS)

            ### _HOJ_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _HOJ_ACT_02等でも良い。
            ### 同じ都道府県コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': None, 
                'action_code': _HOJ_ACT_01
            })
            bool_return = delete_message(metadata=PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.delete_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 削除
### urlpattern：path('delete/koeki/header/<slug:header_id>/', views.delete_koeki_header_id_view, name='delete_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='delete_koeki_header_id_view')
def delete_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### KOEKI_HEADER: アップロードデータ_公益事業等調査票_ヘッダ部分
        ### KOEKI: アップロードデータ_公益事業等調査票_一覧表部分
        ### KOEKI_SUMMARY: 集計データ_公益事業等調査票_一覧表部分
        ### KOEKI_TRIGGER: キューデータ_公益事業等調査票_トリガーメッセージ
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 1/2.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 ken_code={}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 _PROVISIONED_KOEKI_KEN_DELETE={}'.format(_PROVISIONED_KOEKI_KEN_DELETE), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 _CONFIRMED_KOEKI_KEN_DELETE={}'.format(_CONFIRMED_KOEKI_KEN_DELETE), 'DEBUG')
        
        connection_cursor = connection.cursor()
        
        try:
            connection_cursor.execute("""BEGIN""")
            
            if provisioned_confirmed_list[0].provisioned_confirmed == _PROVISIONED:
                PARAMS = dict({
                    'KEN_CODE': user_proxy_list[0].ken_code, 
                    'KOEKI_HEADER_ID': header_id, 
                    'KOEKI_KEN_DELETE': _PROVISIONED_KOEKI_KEN_DELETE,
                })
            else:
                PARAMS = dict({
                    'KEN_CODE': user_proxy_list[0].ken_code, 
                    'KOEKI_HEADER_ID': header_id, 
                    'KOEKI_KEN_DELETE': _CONFIRMED_KOEKI_KEN_DELETE,
                })
            SQL_UPDATE_KOEKI_HEADER = """
                UPDATE KOEKI_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_HEADER_ID IN (
                SELECT 
                    KOEKI_HEADER_ID 
                FROM KOEKI_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_KOEKI = """
                UPDATE KOEKI SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_ID IN (
                SELECT 
                    KOEKI_ID 
                FROM KOEKI_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            SQL_UPDATE_KOEKI_SUMMARY = """
                UPDATE KOEKI_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_ID IN (
                SELECT 
                    KOEKI_ID 
                FROM KOEKI_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)"""
            ### TODO TO-DO TO_DO 削除はシートごとではなく、都道府県ごとに実施する？ため、HEADER_IDで絞り込んではNGである。
            SQL_INSERT_KOEKI_HISTORY = """
                INSERT INTO KOEKI_HISTORY (
                    KOEKI_HEADER_ID, WORKFLOW_CODE, COMMITTED_AT
                ) VALUES (
                    %(KOEKI_HEADER_ID)s,
                    %(KOEKI_KEN_DELETE)s,
                    CURRENT_TIMESTAMP)"""

            connection_cursor.execute(SQL_UPDATE_KOEKI_HEADER,  PARAMS)
            connection_cursor.execute(SQL_UPDATE_KOEKI,         PARAMS)
            connection_cursor.execute(SQL_UPDATE_KOEKI_SUMMARY, PARAMS)
            connection_cursor.execute(SQL_INSERT_KOEKI_HISTORY, PARAMS)

            ### _KOE_ACT_01は一般資産調査員調査票、公共土木施設地方単独事業調査票、公共土木施設補助事業調査票、公益事業調査票を識別するためのダミーである。
            ### _KOE_ACT_02等でも良い。
            ### 同じ都道府県コードのトリガーが削除済に更新される。
            PARAMS_MESSAGE = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': None, 
                'action_code': _KOE_ACT_01
            })
            bool_return = delete_message(metadata=PARAMS_MESSAGE)
            if bool_return == False:
                print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数 delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 2/2.', 'DEBUG')
        print_log('[INFO] P0120Ken.delete_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 EXCELダウンロード
### urlpattern：path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_chosa_excel_header_id_view')
def download_ippan_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_IPPAN_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_CHO_EXC
        })
        bool_return, file_path = get_ippan_chosa_csv_excel(request, PARAMS_IPPAN_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_ippan_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産調査員調査票 CSVダウンロード
### urlpattern：path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_chosa_csv_header_id_view')
def download_ippan_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_IPPAN_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_CHO_CSV
        })
        bool_return, file_path = get_ippan_chosa_csv_excel(request, PARAMS_IPPAN_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_ippan_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産集計結果 EXCELダウンロード
### urlpattern：path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_summary_excel_header_id_view')
def download_ippan_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_IPPAN_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_SUM_EXC
        })
        bool_return, file_path = get_ippan_summary_csv_excel(request, PARAMS_IPPAN_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_ippan_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 一般資産集計結果 CSVダウンロード
### urlpattern：path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_ippan_summary_csv_header_id_view')
def download_ippan_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_IPPAN_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _IPP_SUM_CSV
        })
        bool_return, file_path = get_ippan_summary_csv_excel(request, PARAMS_IPPAN_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_ippan_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_ippan_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 EXCELダウンロード
### urlpattern：path('download/chitan/chosa/excel/header/<slug:header_id>/', views.download_chitan_chosa_excel_header_id_view, name='download_chitan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_chosa_excel_header_id_view')
def download_chitan_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_CHITAN_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_CHO_EXC
        })
        bool_return, file_path = get_chitan_chosa_csv_excel(request, PARAMS_CHITAN_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_chitan_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業調査票 CSVダウンロード
### urlpattern：path('download/chitan/chosa/csv/header/<slug:header_id>/', views.download_chitan_chosa_csv_header_id_view, name='download_chitan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_chosa_csv_header_id_view')
def download_chitan_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_CHITAN_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_CHO_CSV
        })
        bool_return, file_path = get_chitan_chosa_csv_excel(request, PARAMS_CHITAN_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_chitan_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業集計結果 EXCELダウンロード
### urlpattern：path('download/chitan/summary/excel/header/<slug:header_id>/', views.download_chitan_summary_excel_header_id_view, name='download_chitan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_summary_excel_header_id_view')
def download_chitan_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_CHITAN_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_SUM_EXC
        })
        bool_return, file_path = get_chitan_summary_csv_excel(request, PARAMS_CHITAN_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_chitan_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設地方単独事業集計結果 CSVダウンロード
### urlpattern：path('download/chitan/summary/csv/header/<slug:header_id>/', views.download_chitan_summary_csv_header_id_view, name='download_chitan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_chitan_summary_csv_header_id_view')
def download_chitan_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_CHITAN_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _CHI_SUM_CSV
        })
        bool_return, file_path = get_chitan_summary_csv_excel(request, PARAMS_CHITAN_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_chitan_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_chitan_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 EXCELダウンロード
### urlpattern：path('download/hojo/chosa/excel/header/<slug:header_id>/', views.download_hojo_chosa_excel_header_id_view, name='download_hojo_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_chosa_excel_header_id_view')
def download_hojo_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_HOJO_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_CHO_EXC
        })
        bool_return, file_path = get_hojo_chosa_csv_excel(request, PARAMS_HOJO_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_hojo_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業調査票 CSVダウンロード
### urlpattern：path('download/hojo/chosa/csv/header/<slug:header_id>/', views.download_hojo_chosa_csv_header_id_view, name='download_hojo_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_chosa_csv_header_id_view')
def download_hojo_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_HOJO_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_CHO_CSV
        })
        bool_return, file_path = get_hojo_chosa_csv_excel(request, PARAMS_HOJO_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_hojo_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業集計結果 EXCELダウンロード
### urlpattern：path('download/hojo/summary/excel/header/<slug:header_id>/', views.download_hojo_summary_excel_header_id_view, name='download_hojo_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_summary_excel_header_id_view')
def download_hojo_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_HOJO_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_SUM_EXC
        })
        bool_return, file_path = get_hojo_summary_csv_excel(request, PARAMS_HOJO_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_hojo_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公共土木施設補助事業集計結果 CSVダウンロード
### urlpattern：path('download/hojo/summary/csv/header/<slug:header_id>/', views.download_hojo_summary_csv_header_id_view, name='download_hojo_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_hojo_summary_csv_header_id_view')
def download_hojo_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_HOJO_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _HOJ_SUM_CSV
        })
        bool_return, file_path = get_hojo_summary_csv_excel(request, PARAMS_HOJO_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_hojo_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_hojo_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 EXCELダウンロード
### urlpattern：path('download/koeki/chosa/excel/header/<slug:header_id>/', views.download_koeki_chosa_excel_header_id_view, name='download_koeki_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_chosa_excel_header_id_view')
def download_koeki_chosa_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_KOEKI_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_CHO_EXC
        })
        bool_return, file_path = get_koeki_chosa_csv_excel(request, PARAMS_KOEKI_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_koeki_chosa_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_chosa_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_chosa_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業調査票 CSVダウンロード
### urlpattern：path('download/koeki/chosa/csv/header/<slug:header_id>/', views.download_koeki_chosa_csv_header_id_view, name='download_koeki_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_chosa_csv_header_id_view')
def download_koeki_chosa_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_KOEKI_CHOSA = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_CHO_CSV
        })
        bool_return, file_path = get_koeki_chosa_csv_excel(request, PARAMS_KOEKI_CHOSA)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_koeki_chosa_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_chosa_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_chosa_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業集計結果 EXCELダウンロード
### urlpattern：path('download/koeki/summary/excel/header/<slug:header_id>/', views.download_koeki_summary_excel_header_id_view, name='download_koeki_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_summary_excel_header_id_view')
def download_koeki_summary_excel_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_KOEKI_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_SUM_EXC
        })
        bool_return, file_path = get_koeki_summary_csv_excel(request, PARAMS_KOEKI_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_koeki_summary_excel_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_summary_excel_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_summary_excel_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")

###############################################################################
### ビュー関数：ブラウザから呼ばれる関数【済】
### 公益事業集計結果 CSVダウンロード
### urlpattern：path('download/koeki/summary/csv/header/<slug:header_id>/', views.download_koeki_summary_csv_header_id_view, name='download_koeki_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
@custom_decorator(arg1='download_koeki_summary_csv_header_id_view')
def download_koeki_summary_csv_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 関数コール処理(0010)
        #######################################################################
        PARAMS_KOEKI_SUMMARY = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'KUIKI_ID': header_id, 
            'FILE_TYPE': _KOE_SUM_CSV
        })
        bool_return, file_path = get_koeki_summary_csv_excel(request, PARAMS_KOEKI_SUMMARY)
        if bool_return == False:
            raise Exception
            
        #######################################################################
        ### 【正常】レスポンスセット処理(0020)
        #######################################################################
        response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="test.csv"'
        return response
    except:
        print_log('[ERROR] P0120Ken.download_koeki_summary_csv_header_id_view()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_summary_csv_header_id_view()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_koeki_summary_csv_header_id_view()関数が異常終了しました。', 'ERROR')
        return HttpResponseNotFound("")
