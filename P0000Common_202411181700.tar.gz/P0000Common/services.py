###############################################################################
### ファイル名：P0000Common/services.py
### 共通サービス
### 非ビュー関数：ビュー関数からディスパッチで呼ばれる関数等
### def get_ippan_chosa_csv_excel(request, func_params)
### def get_chitan_chosa_csv_excel(request, func_params)
### def get_hojo_chosa_csv_excel(request, func_params)
### def get_koeki_chosa_csv_excel(request, func_params)
### 
### def get_ippan_summary_csv_excel(request, func_params)
### def get_chitan_summary_csv_excel(request, func_params)
### def get_hojo_summary_csv_excel(request, func_params)
### def get_koeki_summary_csv_excel(request, func_params)
### 
### def get_ippan_export_csv(request, func_params) ### ADD 2024/09/26
### 
### 更新履歴：
### 2024/09/05 水害区域図DB版との統合のため、AREAをKUIKIに変更した。
### 2024/09/26 get_ippan_export_csvを追加した。
### 2024/11/11 水系テーブルに県コードを追加して、ユーザの県コードで水系を絞り込めるように変更した。
### 2024/11/15 get_ippan_chosa_csv_excelからcreate_ippan_chosa_workbookを分離した。他から呼べるようにするため。
### 2024/11/15 create_ippan_chosa_workbookのSQLのLEFTJOINで水系種別コードを水系の水系種別コードと紐付けていたが、一般資産調査員調査票ヘッダの水系種別コードと紐付けるように修正した。
### 2024/11/15 create_ippan_chosa_workbookのSQLのLEFTJOINで河川種別コードを河川の河川種別コードと紐付けていたが、一般資産調査員調査票ヘッダの河川種別コードと紐付けるように修正した。
###############################################################################

import csv
import glob
import hashlib
import json
import os
import sys
import time
import shutil

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound
from django.http.response import JsonResponse
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views import View
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import KASEN_SETUBI            ### 1030: マスタデータ_災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import print_log
from P0000Common.common import reset_log

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'
_IPP_EXP_CSV = 'IPP_EXP_CSV' ### ADD 2024/09/26

_CHI_CHO_EXC = 'CHI_CHO_EXC'
_CHI_CHO_CSV = 'CHI_CHO_CSV'
_CHI_SUM_EXC = 'CHI_SUM_EXC'
_CHI_SUM_CSV = 'CHI_SUM_CSV'

_HOJ_CHO_EXC = 'HOJ_CHO_EXC'
_HOJ_CHO_CSV = 'HOJ_CHO_CSV'
_HOJ_SUM_EXC = 'HOJ_SUM_EXC'
_HOJ_SUM_CSV = 'HOJ_SUM_CSV'

_KOE_CHO_EXC = 'KOE_CHO_EXC'
_KOE_CHO_CSV = 'KOE_CHO_CSV'
_KOE_SUM_EXC = 'KOE_SUM_EXC'
_KOE_SUM_CSV = 'KOE_SUM_CSV'

### 局所定数 ※エクセルの列用
VLOOK_VALUE = [
    'B', 'G', 'L', 'Q', 'V', 'AA', 'AF', 'AK', 'AP', 'AU', 
    'AZ', 'BE', 'BJ', 'BO', 'BT', 'BY', 'CD', 'CI', 'CN', 'CS', 
    'CX', 'DC', 'DH', 'DM', 'DR', 'DW', 'EB', 'EG', 'EL', 'EQ', 
    'EV', 'FA', 'FF', 'FK', 'FP', 'FU', 'FZ', 'GE', 'GJ', 'GO', 
    'GT', 'GY', 'HD', 'HI', 'HN', 'HS', 'HX', 'IC', 'IH', 'IM', 
    'IR', 'IW', 'JB', 'JG', 'JL', 'JQ', 'JV', 'KA', 'KF', 'KK', 
    'KP', 'KU', 'KZ', 'LE', 'LJ', 'LO', 'LT', 'LY', 'MD', 'MI', 
    'MN', 'MS', 'MX', 'NC', 'NH', 'NM', 'NR', 'NW', 'OB', 'OG', 
    'OL', 'OQ', 'OV', 'PA', 'PF', 'PK', 'PP', 'PU', 'PZ', 'QE', 
    'QJ', 'QO', 'QT', 'QY', 'RD', 'RI', 'RN', 'RS', 'RX', 'SC', 
    'SH', 'SM', 'SR', 'SW', 'TB', 'TG', 'TL', 'TQ', 'TV', 'UA', 
    'UF', 'UK', 'UP', 'UU', 'UZ', 'VE', 'VJ', 'VO', 'VT', 'VY', 
    'WD', 'WI', 'WN', 'WS', 'WX', 'XC', 'XH', 'XM', 'XR', 'XW', 
    'YB', 'YG', 'YL', 'YQ', 'YV', 'ZA', 'ZF', 'ZK', 'ZP', 'ZU', 
    'ZZ', 'AAE', 'AAJ', 'AAO', 'AAT', 'AAY', 'ABD', 'ABI', 'ABN', 'ABS', 
    'ABX', 'ACC', 'ACH', 'ACM', 'ACR', 'ACW', 'ADB', 'ADG', 'ADL', 'ADQ', 
    'ADV', 'AEA', 'AEF', 'AEK', 'AEP', 'AEU', 'AEZ', 'AFE', 'AFJ', 'AFO', 
    'AFT', 'AFY', 'AGD', 'AGI', 'AGN', 'AGS', 'AGX', 'AHC', 'AHH', 'AHM', 
    'AHR', 'AHW', 'AIB', 'AIG', 'AIL', 'AIQ', 'AIV', 'AJA', 'AJF', 'AJK', 
    'AJP', 'AJU', 'AJZ', 'AKE', 'AKJ', 'AKO', 'AKT', 'AKY', 'ALD', 'ALI', 
    'ALN', 'ALS', 'ALX', 'AMC', 'AMH', 'AMM', 'AMR', 'AMW', 'ANB', 'ANG', 
    'ANL', 'ANQ', 'ANV', 'AOA', 'AOF', 'AOK', 'AOP', 'AOU', 'AOZ', 'APE', 
    'APJ', 'APO', 'APT', 'APY', 'AQD', 'AQI', 'AQN', 'AQS', 'AQX', 'ARC', 
    'ARH', 'ARM', 'ARR', 'ARW', 'ASB', 'ASG', 'ASL', 'ASQ', 'ASV', 'ATA', 
    'ATF', 'ATK', 'ATP', 'ATU', 'ATZ', 'AUE', 'AUJ', 'AUO', 'AUT', 'AUY', 
    'AVD', 'AVI', 'AVN', 'AVS', 'AVX', 'AWC', 'AWH', 'AWM', 'AWR', 'AWW', 
    'AXB', 'AXG', 'AXL', 'AXQ', 'AXV', 'AYA', 'AYF', 'AYK', 'AYP', 'AYU', 
    'AYZ', 'AZE', 'AZJ', 'AZO', 'AZT', 'AZY'
    ]

MAX_SHEET_NUMBER = 25                                                          ### IPPANシートの数の最大値 ex 25

###############################################################################
### ワークブック生成処理
### ※複数EXCELシート対応版
### [I] template_file_path: エクセルテンプレートファイルのパス
### [I] ippan_header_list: 一般資産調査員調査票ヘッダー部の一覧（0件の場合あり）
### [I] ken_code: 県コード、県プルダウンリストの初期値、および、水系の県コードでの絞り込みに使用
### [I] city_code: 市区町村コード、市区町村プルダウンリストの初期値に使用
### [I] ken_name: 県名、県プルダウンリストの初期値に使用
### [I] city_name: 市区町村名、市区町村プルダウンリストの初期値に使用
### [I] MAX_SHEET_NUMBER: IPPANシートの数の最大値 ex 25
### [O] bool_return: True: 正常終了、False: 警告または異常終了
### [O] workbook: 生成したエクセルワークブック
###############################################################################
def create_ippan_chosa_workbook(template_file_path, ippan_header_list, ken_code, city_code, ken_name, city_name, MAX_SHEET_NUMBER):
    try:
        #######################################################################
        ### 関数内関数：ワークブック生成処理(0010)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        print_log('[INFO] P0000Common.create_ippan_chosa_workbook()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 1/11.', 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 template_file_path={}'.format(template_file_path), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 ippan_header_list={}'.format(ippan_header_list), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 ken_code={}'.format(ken_code), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 city_code={}'.format(city_code), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 ken_name={}'.format(ken_name), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 city_name={}'.format(city_name), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 MAX_SHEET_NUMBER={}'.format(MAX_SHEET_NUMBER), 'DEBUG')

        PARAMS_SELECT_SUIKEI = dict({
            'KEN_CODE': '%' + str(ken_code) + '%',
        })
        building_list = BUILDING.objects.raw("""SELECT * FROM BUILDING ORDER BY CAST(BUILDING_CODE AS INTEGER)""")
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI WHERE KEN_CODE LIKE %(KEN_CODE)s ORDER BY CAST(SUIKEI_CODE AS INTEGER)""", PARAMS_SELECT_SUIKEI)
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        cause_list = CAUSE.objects.raw("""SELECT * FROM CAUSE ORDER BY CAST(CAUSE_CODE AS INTEGER)""")
        underground_list = UNDERGROUND.objects.raw("""SELECT * FROM UNDERGROUND ORDER BY CAST(UNDERGROUND_CODE AS INTEGER)""")
        usage_list = USAGE.objects.raw("""SELECT * FROM USAGE ORDER BY CAST(USAGE_CODE AS INTEGER)""")
        flood_sediment_list = FLOOD_SEDIMENT.objects.raw("""SELECT * FROM FLOOD_SEDIMENT ORDER BY CAST(FLOOD_SEDIMENT_CODE AS INTEGER)""")
        gradient_list = GRADIENT.objects.raw("""SELECT * FROM GRADIENT ORDER BY CAST(GRADIENT_CODE AS INTEGER)""")
        industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0020)
        ### ワークシートを局所変数にセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 2/11.', 'DEBUG')
        workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
        
        ### 一般資産調査員調査票 ユーザ入力用シート ※25シート固定
        ### print_log('1', 'DEBUG')
        ws_ippan = []
        ws_ippan.append(workbook["IPPAN"])
        ws_ippan[0].title = 'IPPAN01'

        ### for i in range(24):
        for i in range(MAX_SHEET_NUMBER - 1):
            ws_ippan.append(workbook.copy_worksheet(workbook["IPPAN01"]))
            ws_ippan[i+1].title = 'IPPAN' + str(i+2).zfill(2)
            
        workbook.move_sheet('IPPAN01', offset=-45)
        ### for i in range(24):
        for i in range(MAX_SHEET_NUMBER - 1):
            workbook.move_sheet('IPPAN' + str(i+2).zfill(2), offset=-21)
            
        ### 一般資産調査員調査票 プルダウン等の制御用シート
        ws_header = workbook["HEADER"]                                         ### 2024/10/15 EDIT
        
        ws_building = workbook["BUILDING"]
        ws_ken = workbook["KEN"]
        ws_city = workbook["CITY"]
        ws_kasen_kaigan = workbook["KASEN_KAIGAN"]
        ws_suikei = workbook["SUIKEI"]
        ws_suikei_type = workbook["SUIKEI_TYPE"]
        ws_kasen = workbook["KASEN"]
        ws_kasen_type = workbook["KASEN_TYPE"]
        ws_cause = workbook["CAUSE"]
        ws_underground = workbook["UNDERGROUND"]
        ws_usage = workbook["USAGE"]
        ws_flood_sediment = workbook["FLOOD_SEDIMENT"]
        ws_gradient = workbook["GRADIENT"]
        ws_industry = workbook["INDUSTRY"]
        ws_weather = workbook["WEATHER"]
        
        ws_city_vlook = workbook["CITY_VLOOK"]
        ws_kasen_vlook = workbook["KASEN_VLOOK"]
        ws_suikei_type_vlook = workbook["SUIKEI_TYPE_VLOOK"]
        ws_kasen_type_vlook = workbook["KASEN_TYPE_VLOOK"]

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0020)
        ### 各EXCELシートで枠線を表示しないにセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 3/11.', 'DEBUG')
        ### 一般資産調査員調査票 ユーザ入力用シート ※25シート固定
        ### for i in range(25):                                                ### ADD 2024/10/15
        for i in range(MAX_SHEET_NUMBER):                                      ### ADD 2024/11/15
            ws_ippan[i].sheet_view.showGridLines = False
            
        ### 一般資産調査員調査票 プルダウン等の制御用シート
        ws_header.sheet_view.showGridLines = False                             ### ADD 2024/10/15

        ws_building.sheet_view.showGridLines = False
        ws_ken.sheet_view.showGridLines = False
        ws_city.sheet_view.showGridLines = False
        ws_kasen_kaigan.sheet_view.showGridLines = False
        ws_suikei.sheet_view.showGridLines = False
        ws_suikei_type.sheet_view.showGridLines = False
        ws_kasen.sheet_view.showGridLines = False
        ws_kasen_type.sheet_view.showGridLines = False
        ws_cause.sheet_view.showGridLines = False
        ws_underground.sheet_view.showGridLines = False
        ws_usage.sheet_view.showGridLines = False
        ws_flood_sediment.sheet_view.showGridLines = False
        ws_gradient.sheet_view.showGridLines = False
        ws_industry.sheet_view.showGridLines = False
        ws_weather.sheet_view.showGridLines = False
        
        ws_city_vlook.sheet_view.showGridLines = False
        ws_kasen_vlook.sheet_view.showGridLines = False
        ws_suikei_type_vlook.sheet_view.showGridLines = False
        ws_kasen_type_vlook.sheet_view.showGridLines = False

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0030)
        ### プルダウン等の制御用シートに値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 4/11.', 'DEBUG')
        ### 1000: 建物区分シート
        ### print("create_ippan_chosa_workbook_4_1", flush=True)
        if bool(building_list) == True:
            for i, building in enumerate(building_list):
                ws_building.cell(row=i+1, column=1).value = building.building_code
                ws_building.cell(row=i+1, column=2).value = str(building.building_name) + ":" + str(building.building_code)

        ### 1010: 都道府県シート
        ### print("create_ippan_chosa_workbook_4_2", flush=True)
        if bool(ken_list) == True:
            for i, ken in enumerate(ken_list):
                ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)

        ### 1020: 市区町村シート
        ### print("create_ippan_chosa_workbook_4_3", flush=True)
        cities_list = []
        if bool(ken_list) == True:
            for i, ken in enumerate(ken_list):
                PARAMS_SELECT_CITY = dict({
                    'KEN_CODE': ken.ken_code
                })
                SQL_SELECT_CITY = """
                    SELECT 
                        * 
                    FROM CITY 
                    WHERE 
                        KEN_CODE=%(KEN_CODE)s 
                    ORDER BY 
                        CAST(CITY_CODE AS INTEGER)"""
                cities_list.append(CITY.objects.raw(SQL_SELECT_CITY, PARAMS_SELECT_CITY))

        if bool(cities_list) == True:
            for i, cities in enumerate(cities_list):
                if cities:
                    for j, city in enumerate(cities):
                        ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                        ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                        ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                        ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                        ws_city.cell(row=j+1, column=i*5+5).value = city.city_area

        ### 1030: 水害発生地点工種（河川海岸区分）
        ### print("create_ippan_chosa_workbook_4_5", flush=True)
        if bool(kasen_kaigan_list) == True:
            for i, kasen_kaigan in enumerate(kasen_kaigan_list):
                ws_kasen_kaigan.cell(row=i+1, column=1).value = kasen_kaigan.kasen_kaigan_code
                ws_kasen_kaigan.cell(row=i+1, column=2).value = str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code)

        ### 1040: 水系（水系・沿岸）
        ### print("create_ippan_chosa_workbook_4_6", flush=True)
        if bool(suikei_list) == True:
            for i, suikei in enumerate(suikei_list):
                ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code

        ### 1050: 水系種別（水系・沿岸種別）
        ### print("create_ippan_chosa_workbook_4_7", flush=True)
        if bool(suikei_type_list) == True:
            for i, suikei_type in enumerate(suikei_type_list):
                ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)

        ### 1060: 河川（河川・海岸）、連動プルダウン用
        ### print("create_ippan_chosa_workbook_4_8", flush=True)
        kasens_list = []
        if bool(suikei_list) == True:
            for i, suikei in enumerate(suikei_list):
                PARAMS_SELECT_KASEN = dict({
                    'SUIKEI_CODE': suikei.suikei_code
                })
                SQL_SELECT_KASEN = """
                    SELECT 
                        * 
                    FROM KASEN 
                    WHERE 
                        SUIKEI_CODE=%(SUIKEI_CODE)s 
                    ORDER BY 
                        CAST(KASEN_CODE AS INTEGER)"""
                kasens_list.append(KASEN.objects.raw(SQL_SELECT_KASEN, PARAMS_SELECT_KASEN))

        if bool(kasens_list) == True:
            for i, kasens in enumerate(kasens_list):
                if kasens:
                    for j, kasen in enumerate(kasens):
                        ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                        ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                        ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                        ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code

        ### 1070: 河川種別（河川・海岸種別）
        ### print("create_ippan_chosa_workbook_4_10", flush=True)
        if bool(kasen_type_list) == True:
            for i, kasen_type in enumerate(kasen_type_list):
                ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)

        ### 1080: 水害原因
        ### print("create_ippan_chosa_workbook_4_11", flush=True)
        if bool(cause_list) == True:
            for i, cause in enumerate(cause_list):
                ws_cause.cell(row=i+1, column=1).value = cause.cause_code
                ws_cause.cell(row=i+1, column=2).value = str(cause.cause_name) + ":" + str(cause.cause_code)
        
        ### 1090: 地上地下区分
        ### print("create_ippan_chosa_workbook_4_12", flush=True)
        if bool(underground_list) == True:
            for i, underground in enumerate(underground_list):
                ws_underground.cell(row=i+1, column=1).value = underground.underground_code
                ws_underground.cell(row=i+1, column=2).value = str(underground.underground_name) + ":" + str(underground.underground_code)

        ### 1100: 地下空間の利用形態
        ### print("create_ippan_chosa_workbook_4_13", flush=True)
        if bool(usage_list) == True:
            for i, usage in enumerate(usage_list):
                ws_usage.cell(row=i+1, column=1).value = usage.usage_code
                ws_usage.cell(row=i+1, column=2).value = str(usage.usage_name) + ":" + str(usage.usage_code)

        ### 1110: 浸水土砂区分
        ### print("create_ippan_chosa_workbook_4_14", flush=True)
        if bool(flood_sediment_list) == True:
            for i, flood_sediment in enumerate(flood_sediment_list):
                ws_flood_sediment.cell(row=i+1, column=1).value = flood_sediment.flood_sediment_code
                ws_flood_sediment.cell(row=i+1, column=2).value = str(flood_sediment.flood_sediment_name) + ":" + str(flood_sediment.flood_sediment_code)

        ### 1120: 地盤勾配区分
        ### print("create_ippan_chosa_workbook_4_15", flush=True)
        if bool(gradient_list) == True:
            for i, gradient in enumerate(gradient_list):
                ws_gradient.cell(row=i+1, column=1).value = gradient.gradient_code
                ws_gradient.cell(row=i+1, column=2).value = str(gradient.gradient_name) + ":" + str(gradient.gradient_code)

        ### 1130: 産業分類
        ### print("create_ippan_chosa_workbook_4_16", flush=True)
        if bool(industry_list) == True:
            for i, industry in enumerate(industry_list):
                ws_industry.cell(row=i+1, column=1).value = industry.industry_code
                ws_industry.cell(row=i+1, column=2).value = str(industry.industry_name) + ":" + str(industry.industry_code)

        ### 7000: 入力データ_水害区域

        ### 7010: 入力データ_異常気象
        ### print("create_ippan_chosa_workbook_4_18", flush=True)
        if bool(weather_list) == True:
            for i, weather in enumerate(weather_list):
                ws_weather.cell(row=i+1, column=1).value = weather.weather_id
                ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

        ### 7020: 入力データ_ヘッダ部分
        ### print("create_ippan_chosa_workbook_4_19", flush=True)
        if bool(ippan_header_list) == True:
            for i, ippan_header in enumerate(ippan_header_list):
                ws_header.cell(row=i+1, column=1).value = ippan_header.ippan_header_id
                ws_header.cell(row=i+1, column=2).value = str(ippan_header.ippan_header_name) + ":" + str(ippan_header.ippan_header_id)
                ws_header.cell(row=i+1, column=3).value = ippan_header.ken_code
                ws_header.cell(row=i+1, column=4).value = ippan_header.city_code
                ws_header.cell(row=i+1, column=5).value = ippan_header.begin_date
                ws_header.cell(row=i+1, column=6).value = ippan_header.end_date
                ws_header.cell(row=i+1, column=7).value = ippan_header.cause_1_code
                ws_header.cell(row=i+1, column=8).value = ippan_header.cause_2_code
                ws_header.cell(row=i+1, column=9).value = ippan_header.cause_3_code
                ws_header.cell(row=i+1, column=10).value = ippan_header.kuiki_id
                ws_header.cell(row=i+1, column=11).value = ippan_header.suikei_code
                ws_header.cell(row=i+1, column=12).value = ippan_header.kasen_code
                ws_header.cell(row=i+1, column=13).value = ippan_header.gradient_code
                ws_header.cell(row=i+1, column=14).value = ippan_header.residential_area
                ws_header.cell(row=i+1, column=15).value = ippan_header.agricultural_area
                ws_header.cell(row=i+1, column=16).value = ippan_header.underground_area
                ws_header.cell(row=i+1, column=17).value = ippan_header.kasen_kaigan_code
                ws_header.cell(row=i+1, column=18).value = ippan_header.crop_damage
                ws_header.cell(row=i+1, column=19).value = ippan_header.weather_id

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0050)
        ### プルダウン等の制御用シートに値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 5/11.', 'DEBUG')
        ### 1020: 市区町村VLOOKUP
        ### print("create_ippan_chosa_workbook_5_1", flush=True)
        if bool(ken_list) == True and bool(cities_list) == True:
            for i, ken in enumerate(ken_list):
                ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            for i, cities in enumerate(cities_list):
                ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)

        ### 1060: 河川（河川・海岸）VLOOKUP
        ### print("create_ippan_chosa_workbook_5_2", flush=True)
        if bool(suikei_list) == True and bool(kasens_list) == True:
            for i, suikei in enumerate(suikei_list):
                ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)

            for i, kasens in enumerate(kasens_list):
                ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0060)
        ### ユーザ入力用シートのキャプションに値をセットする。
        ### ユーザ入力用シートの入力用セルに空の値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 6/11.', 'DEBUG')
        ### for i in range(25):                                                ### 2024/10/15 EDIT
        for i in range(MAX_SHEET_NUMBER):                                      ### 2024/11/15 EDIT
            ### ユーザ入力用シートのキャプション
            ws_ippan[i].cell(row=5, column=2).value = '都道府県'
            ws_ippan[i].cell(row=5, column=3).value = '市区町村'
            ws_ippan[i].cell(row=5, column=4).value = '水害発生年月日'
            ws_ippan[i].cell(row=5, column=5).value = '水害終了年月日'
            ws_ippan[i].cell(row=5, column=6).value = '水害原因'
            ws_ippan[i].cell(row=5, column=9).value = '水害区域番号'
            ws_ippan[i].cell(row=6, column=6).value = '1'
            ws_ippan[i].cell(row=6, column=7).value = '2'
            ws_ippan[i].cell(row=6, column=8).value = '3'
            ws_ippan[i].cell(row=9, column=2).value = '水系・沿岸名'
            ws_ippan[i].cell(row=9, column=3).value = '水系種別'
            ws_ippan[i].cell(row=9, column=4).value = '河川・海岸名'
            ws_ippan[i].cell(row=9, column=5).value = '河川種別'
            ws_ippan[i].cell(row=9, column=6).value = '地盤勾配区分※1'
            ws_ippan[i].cell(row=12, column=2).value = '水害区域面積（m2）'
            ws_ippan[i].cell(row=12, column=6).value = '工種'
            ws_ippan[i].cell(row=12, column=8).value = '農作物被害額（千円）'
            ws_ippan[i].cell(row=12, column=10).value = '異常気象コード'
            ws_ippan[i].cell(row=16, column=2).value = '町丁名・大字名'
            ws_ippan[i].cell(row=16, column=3).value = '名称'
            ws_ippan[i].cell(row=16, column=4).value = '地上・地下被害の区分※2'
            ws_ippan[i].cell(row=16, column=5).value = '浸水土砂被害の区分※3'
            ws_ippan[i].cell(row=16, column=6).value = '被害建物棟数'
            ws_ippan[i].cell(row=16, column=12).value = '被害建物の延床面積（m2）'
            ws_ippan[i].cell(row=16, column=13).value = '被災世帯数'
            ws_ippan[i].cell(row=16, column=14).value = '被災事業所数'
            ws_ippan[i].cell(row=16, column=15).value = '被害建物内での農業家又は事業所活動'
            ws_ippan[i].cell(row=16, column=25).value = '事業所の産業区分※7'
            ws_ippan[i].cell(row=16, column=26).value = '地下空間の利用形態※8'
            ws_ippan[i].cell(row=16, column=27).value = '備考'
            ws_ippan[i].cell(row=17, column=7).value = '床上浸水・土砂堆積・地下浸水'
            ws_ippan[i].cell(row=17, column=15).value = '農家・漁家戸数※5'
            ws_ippan[i].cell(row=17, column=20).value = '事業所従業者数※6'
            ws_ippan[i].cell(row=18, column=16).value = '床上浸水'
            ws_ippan[i].cell(row=18, column=21).value = '床上浸水'
            ws_ippan[i].cell(row=20, column=7).value = '1cm〜49cm'
            ws_ippan[i].cell(row=20, column=8).value = '50cm〜99cm'
            ws_ippan[i].cell(row=20, column=9).value = '1m以上'
            ws_ippan[i].cell(row=20, column=10).value = '半壊※4'
            ws_ippan[i].cell(row=20, column=11).value = '全壊・流失※4'
            ws_ippan[i].cell(row=20, column=16).value = '1cm〜49cm'
            ws_ippan[i].cell(row=20, column=17).value = '50cm〜99cm'
            ws_ippan[i].cell(row=20, column=18).value = '1m以上半壊'
            ws_ippan[i].cell(row=20, column=19).value = '全壊・流失'
            ws_ippan[i].cell(row=20, column=21).value = '1cm〜49cm'
            ws_ippan[i].cell(row=20, column=22).value = '50cm〜99cm'
            ws_ippan[i].cell(row=20, column=23).value = '1m以上半壊'
            ws_ippan[i].cell(row=20, column=24).value = '全壊・流失'
            
            ### ユーザ入力用シートの入力用セル ※以下の処理も必要。初期化するため。
            ws_ippan[i].cell(row=7, column=2).value = ""
            ws_ippan[i].cell(row=7, column=3).value = ""
            ws_ippan[i].cell(row=7, column=4).value = ""
            ws_ippan[i].cell(row=7, column=5).value = ""
            ws_ippan[i].cell(row=7, column=6).value = ""
            ws_ippan[i].cell(row=7, column=7).value = ""
            ws_ippan[i].cell(row=7, column=8).value = ""
            ws_ippan[i].cell(row=7, column=9).value = ""
            ws_ippan[i].cell(row=10, column=2).value = ""
            ws_ippan[i].cell(row=10, column=3).value = ""
            ws_ippan[i].cell(row=10, column=4).value = ""
            ws_ippan[i].cell(row=10, column=5).value = ""
            ws_ippan[i].cell(row=10, column=6).value = ""
            ws_ippan[i].cell(row=14, column=2).value = ""
            ws_ippan[i].cell(row=14, column=3).value = ""
            ws_ippan[i].cell(row=14, column=4).value = ""
            ws_ippan[i].cell(row=14, column=6).value = ""
            ws_ippan[i].cell(row=14, column=8).value = ""
            ws_ippan[i].cell(row=14, column=10).value = ""
            ws_ippan[i].cell(row=20, column=2).value = ""
            ws_ippan[i].cell(row=20, column=3).value = ""
            ws_ippan[i].cell(row=20, column=4).value = ""
            ws_ippan[i].cell(row=20, column=5).value = ""
            ws_ippan[i].cell(row=20, column=6).value = ""
            ws_ippan[i].cell(row=20, column=7).value = ""
            ws_ippan[i].cell(row=20, column=8).value = ""
            ws_ippan[i].cell(row=20, column=9).value = ""
            ws_ippan[i].cell(row=20, column=10).value = ""
            ws_ippan[i].cell(row=20, column=11).value = ""
            ws_ippan[i].cell(row=20, column=12).value = ""
            ws_ippan[i].cell(row=20, column=13).value = ""
            ws_ippan[i].cell(row=20, column=14).value = ""
            ws_ippan[i].cell(row=20, column=15).value = ""
            ws_ippan[i].cell(row=20, column=16).value = ""
            ws_ippan[i].cell(row=20, column=17).value = ""
            ws_ippan[i].cell(row=20, column=18).value = ""
            ws_ippan[i].cell(row=20, column=19).value = ""
            ws_ippan[i].cell(row=20, column=20).value = ""
            ws_ippan[i].cell(row=20, column=21).value = ""
            ws_ippan[i].cell(row=20, column=22).value = ""
            ws_ippan[i].cell(row=20, column=23).value = ""
            ws_ippan[i].cell(row=20, column=24).value = ""
            ws_ippan[i].cell(row=20, column=25).value = ""
            ws_ippan[i].cell(row=20, column=26).value = ""
            ws_ippan[i].cell(row=20, column=27).value = ""

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0070)
        ### ユーザ入力用シートの背景をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 7/11.', 'DEBUG')
        gray_fill = PatternFill(bgColor='C0C0C0', fill_type='solid')
        white_fill = PatternFill(bgColor='FFFFFF', fill_type='solid')
        ### for i in range(25):                                                ### 2024/10/15 EDIT
        for i in range(MAX_SHEET_NUMBER):                                      ### 2024/11/15 EDIT
            ws_ippan[i].conditional_formatting.add('N20:Y1000', FormulaRule(formula=['$C20="戸建住宅:1"'], fill=gray_fill))
            ws_ippan[i].conditional_formatting.add('N20:Y1000', FormulaRule(formula=['$C20="共同住宅:2"'], fill=gray_fill))
            ws_ippan[i].conditional_formatting.add('N20:Y1000', FormulaRule(formula=['$C20="事業所併用住宅:3"'], fill=white_fill))
            ws_ippan[i].conditional_formatting.add('M20:M1000', FormulaRule(formula=['$C20="事業所:4"'], fill=gray_fill))
            ws_ippan[i].conditional_formatting.add('M20:N1000', FormulaRule(formula=['$C20="その他建物:5"'], fill=gray_fill))
            ws_ippan[i].conditional_formatting.add('T20:Y1000', FormulaRule(formula=['$C20="その他建物:5"'], fill=gray_fill))
            ws_ippan[i].conditional_formatting.add('F20:Z1000', FormulaRule(formula=['$C20="建物以外:6"'], fill=gray_fill))

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0080)
        ### ユーザ入力用シートのプルダウンリストをセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 8/11.', 'DEBUG')
        ### for i in range(25):                                                ### 2024/10/15 EDIT
        for i in range(MAX_SHEET_NUMBER):                                      ### 2024/11/15 EDIT
            ### 1000: 建物区分プルダウンリスト
            if len(building_list) > 0:
                dv_building = DataValidation(type="list", formula1="BUILDING!$B$1:$B$%d" % len(building_list))
                dv_building.ranges = 'C20:C1000'
                ws_ippan[i].add_data_validation(dv_building)
    
            ### 1010: 都道府県プルダウンリスト
            if len(ken_list) > 0:
                dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
                dv_ken.ranges = 'B7:B7'
                ws_ippan[i].add_data_validation(dv_ken)
            
            ### 1020: 市区町村プルダウンリスト
            dv_city = DataValidation(type="list", formula1="=INDIRECT(AD3)")
            dv_city.ranges = 'C7:C7'
            ws_ippan[i].add_data_validation(dv_city)
            ### ws_ippan.cell(row=3, column=30).value = "=VLOOKUP(B7,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ws_ippan[i].cell(row=3, column=30).value = "=VLOOKUP(B7,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS?
            
            ### 1030: 水害発生地点工種（河川海岸区分）プルダウンリスト
            if len(kasen_kaigan_list) > 0:
                dv_kasen_kaigan = DataValidation(type="list", formula1="KASEN_KAIGAN!$B$1:$B$%d" % len(kasen_kaigan_list))
                dv_kasen_kaigan.ranges = 'F14:F14'
                ws_ippan[i].add_data_validation(dv_kasen_kaigan)
            
            ### 1040: 水系（水系・沿岸）プルダウンリスト
            if len(suikei_list) > 0:
                dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
                dv_suikei.ranges = 'B10:B10'
                ws_ippan[i].add_data_validation(dv_suikei)
            
            ### 1050: 水系種別（水系・沿岸種別）プルダウンリスト
            if len(suikei_type_list) > 0:
                dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
                dv_suikei_type.ranges = 'C10:C10'
                ws_ippan[i].add_data_validation(dv_suikei_type)
            
            ### 1060: 河川（河川・海岸）プルダウンリスト
            dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AD4)") ### 2024/11/11 有効に戻す。
            dv_kasen.ranges = 'D10:D10'
            ws_ippan[i].add_data_validation(dv_kasen)
            ### ws_ippan.cell(row=4, column=30).value = "=VLOOKUP(B10,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ws_ippan[i].cell(row=4, column=30).value = "=VLOOKUP(B10,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS?
            
            ### 1070: 河川種別（河川・海岸種別）プルダウンリスト
            if len(kasen_type_list) > 0:
                dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
                dv_kasen_type.ranges = 'E10:E10'
                ws_ippan[i].add_data_validation(dv_kasen_type)
            
            ### 1080: 水害原因プルダウンリスト
            if len(cause_list) > 0:
                dv_cause = DataValidation(type="list", formula1="CAUSE!$B$1:$B$%d" % len(cause_list))
                dv_cause.ranges = 'F7:H7'
                ws_ippan[i].add_data_validation(dv_cause)
            
            ### 1090: 地上地下区分プルダウンリスト
            if len(underground_list) > 0:
                dv_underground = DataValidation(type="list", formula1="UNDERGROUND!$B$1:$B$%d" % len(underground_list))
                dv_underground.ranges = 'D20:D1000'
                ws_ippan[i].add_data_validation(dv_underground)
            
            ### 1100: 地下空間の利用形態プルダウンリスト
            if len(usage_list) > 0:
                dv_usage = DataValidation(type="list", formula1="USAGE!$B$1:$B$%d" % len(usage_list))
                dv_usage.ranges = 'Z20:Z1000'
                ws_ippan[i].add_data_validation(dv_usage)
            
            ### 1110: 浸水土砂区分プルダウンリスト
            if len(flood_sediment_list) > 0:
                dv_flood_sediment = DataValidation(type="list", formula1="FLOOD_SEDIMENT!$B$1:$B$%d" % len(flood_sediment_list))
                dv_flood_sediment.ranges = 'E20:E1000'
                ws_ippan[i].add_data_validation(dv_flood_sediment)
            
            ### 1120: 地盤勾配区分プルダウンリスト
            if len(gradient_list) > 0:
                dv_gradient = DataValidation(type="list", formula1="GRADIENT!$B$1:$B$%d" % len(gradient_list))
                dv_gradient.ranges = 'F10:F10'
                ws_ippan[i].add_data_validation(dv_gradient)
            
            ### 1130: 産業分類プルダウンリスト
            if len(industry_list) > 0:
                dv_industry = DataValidation(type="list", formula1="INDUSTRY!$B$1:$B$%d" % len(industry_list))
                dv_industry.ranges = 'Y20:Y1000'
                ws_ippan[i].add_data_validation(dv_industry)

            ### 7000: 水害区域プルダウンリスト
            
            ### 7010: 異常気象プルダウンリスト ※異常気象はオンラインで紐付けするため。表示もプルダウンもしない。
            ### if len(weather_list) > 0:                                   ### COMMENT OUT 2023/11/21
            ###     dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
            ###     dv_weather.ranges = 'J14:J14'
            ###     ws_ippan[i].add_data_validation(dv_weather)

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0090)
        ### ユーザ入力用シートに値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 9/11.', 'DEBUG')
        ROW = dict({
            'KEN_CODE': 7,
            'CITY_CODE': 7,
            'BEGIN_DATE': 7,
            'END_DATE': 7,
            'CAUSE_1_CODE': 7,
            'CAUSE_2_CODE': 7,
            'CAUSE_3_CODE': 7,
            'KUIKI_ID': 7,
            'SUIKEI_CODE': 10,
            'SUIKEI_TYPE_CODE': 10,
            'KASEN_CODE': 10,
            'KASEN_TYPE_CODE': 10,
            'GRADIENT_CODE': 10,
            'RESIDENTIAL_AREA': 14,
            'AGRICULTURAL_AREA': 14,
            'UNDERGROUND_AREA': 14,
            'KASEN_KAIGAN_CODE': 14,
            'CROP_DAMAGE': 14,
            'WEATHER_ID': 14,
            'IPPAN_HEADER_ID': 3,
        })
        COLUMN = dict({
            'KEN_CODE': 2,                                                     ### ROW 7
            'CITY_CODE': 3,
            'BEGIN_DATE': 4,
            'END_DATE': 5,
            'CAUSE_1_CODE': 6,
            'CAUSE_2_CODE': 7,
            'CAUSE_3_CODE': 8,
            'KUIKI_ID': 9,
            
            'SUIKEI_CODE': 2,                                                  ### ROW 10
            'SUIKEI_TYPE_CODE': 3,
            'KASEN_CODE': 4,
            'KASEN_TYPE_CODE': 5,
            'GRADIENT_CODE': 6,
            
            'RESIDENTIAL_AREA': 2,                                             ### ROW 14
            'AGRICULTURAL_AREA': 3,
            'UNDERGROUND_AREA': 4,
            'KASEN_KAIGAN_CODE': 6,
            'CROP_DAMAGE': 8,
            'WEATHER_ID': 10,
            'IPPAN_HEADER_ID': 28,
            
            'IPPAN_NAME': 2,                                                   ### ROW 20 
            'BUILDING_CODE': 3,
            'UNDERGROUND_CODE': 4,
            'FLOOD_SEDIMENT_CODE': 5,
            'BUILDING_LV00': 6,
            'BUILDING_LV01_49': 7,
            'BUILDING_LV50_99': 8,
            'BUILDING_LV100': 9,
            'BUILDING_HALF': 10,
            'BUILDING_FULL': 11,
            'FLOOR_AREA': 12,
            'FAMILY': 13,
            'OFFICE': 14,
            'FARMER_FISHER_LV00': 15,
            'FARMER_FISHER_LV01_49': 16,
            'FARMER_FISHER_LV50_99': 17,
            'FARMER_FISHER_LV100': 18,
            'FARMER_FISHER_FULL': 19,
            'EMPLOYEE_LV00': 20,
            'EMPLOYEE_LV01_49': 21,
            'EMPLOYEE_LV50_99': 22,
            'EMPLOYEE_LV100': 23,
            'EMPLOYEE_FULL': 24,
            'INDUSTRY_CODE': 25,
            'USAGE_CODE': 26,
            'COMMENT': 27,
            'IPPAN_ID': 28,
        })
        
        SQL_SELECT_IPPAN_HEADER = """
            SELECT 
                IPP1.IPPAN_HEADER_ID AS IPPAN_HEADER_ID,
                IPP1.IPPAN_HEADER_NAME AS IPPAN_HEADER_NAME,
                IPP1.KEN_CODE AS KEN_CODE, 
                KEN1.KEN_NAME AS KEN_NAME,
                IPP1.CITY_CODE AS CITY_CODE,
                CIT1.CITY_NAME AS CITY_NAME,
                TO_CHAR(TIMEZONE('JST', IPP1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE,
                TO_CHAR(TIMEZONE('JST', IPP1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE,
                IPP1.CAUSE_1_CODE AS CAUSE_1_CODE,
                CAU1.CAUSE_NAME AS CAUSE_1_NAME,
                IPP1.CAUSE_2_CODE AS CAUSE_2_CODE,
                CAU2.CAUSE_NAME AS CAUSE_2_NAME,
                IPP1.CAUSE_3_CODE AS CAUSE_3_CODE,
                CAU3.CAUSE_NAME AS CAUSE_3_NAME,
                IPP1.KUIKI_ID AS KUIKI_ID,
                IPP1.SUIKEI_CODE AS SUIKEI_CODE,
                SUI1.SUIKEI_NAME AS SUIKEI_NAME,
                SUT1.SUIKEI_TYPE_CODE AS SUIKEI_TYPE_CODE,
                SUT1.SUIKEI_TYPE_NAME AS SUIKEI_TYPE_NAME,
                IPP1.KASEN_CODE AS KASEN_CODE,
                KAS1.KASEN_NAME AS KASEN_NAME,
                KAT1.KASEN_TYPE_CODE AS KASEN_TYPE_CODE,
                KAT1.KASEN_TYPE_NAME AS KASEN_TYPE_NAME,
                IPP1.GRADIENT_CODE AS GRADIENT_CODE,
                GRA1.GRADIENT_NAME AS GRADIENT_NAME,
                CASE WHEN (IPP1.RESIDENTIAL_AREA) IS NULL THEN NULL ELSE IPP1.RESIDENTIAL_AREA END AS RESIDENTIAL_AREA,
                CASE WHEN (IPP1.AGRICULTURAL_AREA) IS NULL THEN NULL ELSE IPP1.AGRICULTURAL_AREA END AS AGRICULTURAL_AREA,
                CASE WHEN (IPP1.UNDERGROUND_AREA) IS NULL THEN NULL ELSE IPP1.UNDERGROUND_AREA END AS UNDERGROUND_AREA,
                IPP1.KASEN_KAIGAN_CODE AS KASEN_KAIGAN_CODE,
                KAK1.KASEN_KAIGAN_NAME AS KASEN_KAIGAN_NAME,
                CASE WHEN (IPP1.CROP_DAMAGE) IS NULL THEN NULL ELSE IPP1.CROP_DAMAGE END AS CROP_DAMAGE,
                IPP1.WEATHER_ID AS WEATHER_ID,
                WEA1.WEATHER_NAME AS WEATHER_NAME
            FROM IPPAN_HEADER IPP1 
            LEFT JOIN KEN KEN1 ON IPP1.KEN_CODE=KEN1.KEN_CODE 
            LEFT JOIN CITY CIT1 ON IPP1.CITY_CODE=CIT1.CITY_CODE 
            LEFT JOIN CAUSE CAU1 ON IPP1.CAUSE_1_CODE=CAU1.CAUSE_CODE 
            LEFT JOIN CAUSE CAU2 ON IPP1.CAUSE_2_CODE=CAU2.CAUSE_CODE 
            LEFT JOIN CAUSE CAU3 ON IPP1.CAUSE_3_CODE=CAU3.CAUSE_CODE 
            LEFT JOIN SUIKEI SUI1 ON IPP1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
            -- LEFT JOIN SUIKEI_TYPE SUT1 ON SUI1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE -- 2024/11/15 COMMENT OUT
            LEFT JOIN SUIKEI_TYPE SUT1 ON IPP1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE    -- 2024/11/15 ADD
            LEFT JOIN KASEN KAS1 ON IPP1.KASEN_CODE=KAS1.KASEN_CODE 
            -- LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE    -- 2024/11/15 COMMENT OUT
            LEFT JOIN KASEN_TYPE KAT1 ON IPP1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE       -- 2024/11/15 ADD
            LEFT JOIN GRADIENT GRA1 ON IPP1.GRADIENT_CODE=GRA1.GRADIENT_CODE 
            LEFT JOIN KASEN_KAIGAN KAK1 ON IPP1.KASEN_KAIGAN_CODE=KAK1.KASEN_KAIGAN_CODE 
            LEFT JOIN WEATHER WEA1 ON IPP1.WEATHER_ID=WEA1.WEATHER_ID 
            WHERE 
                IPP1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s LIMIT 1"""            ### LIMIT 1で正しい。※ippan_header_listは、ippan_header_idしか保持していないため、ここで入力用シートに必要なデータを取得する。
        SQL_SELECT_IPPAN = """
            SELECT 
                IPP1.IPPAN_ID AS IPPAN_ID,
                IPP1.IPPAN_NAME AS IPPAN_NAME,
                IPP1.BUILDING_CODE AS BUILDING_CODE,
                BUI1.BUILDING_NAME AS BUILDING_NAME,
                IPP1.UNDERGROUND_CODE AS UNDERGROUND_CODE,
                UND1.UNDERGROUND_NAME AS UNDERGROUND_NAME,
                IPP1.FLOOD_SEDIMENT_CODE AS FLOOD_SEDIMENT_CODE,
                FLO1.FLOOD_SEDIMENT_NAME AS FLOOD_SEDIMENT_NAME,
                CASE WHEN (IPP1.BUILDING_LV00) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV00 AS NUMERIC(20,10)) END AS BUILDING_LV00,
                CASE WHEN (IPP1.BUILDING_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV01_49 AS NUMERIC(20,10)) END AS BUILDING_LV01_49,
                CASE WHEN (IPP1.BUILDING_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV50_99 AS NUMERIC(20,10)) END AS BUILDING_LV50_99,
                CASE WHEN (IPP1.BUILDING_LV100) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV100 AS NUMERIC(20,10)) END AS BUILDING_LV100,
                CASE WHEN (IPP1.BUILDING_HALF) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_HALF AS NUMERIC(20,10)) END AS BUILDING_HALF,
                CASE WHEN (IPP1.BUILDING_FULL) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_FULL AS NUMERIC(20,10)) END AS BUILDING_FULL,
                CASE WHEN (IPP1.FLOOR_AREA) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA AS NUMERIC(20,10)) END AS FLOOR_AREA,
                CASE WHEN (IPP1.FAMILY) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY AS NUMERIC(20,10)) END AS FAMILY,
                CASE WHEN (IPP1.OFFICE) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE AS NUMERIC(20,10)) END AS OFFICE,
                CASE WHEN (IPP1.FLOOR_AREA_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV00 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV00,
                CASE WHEN (IPP1.FLOOR_AREA_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV01_49 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV01_49,
                CASE WHEN (IPP1.FLOOR_AREA_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV50_99 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV50_99,
                CASE WHEN (IPP1.FLOOR_AREA_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV100 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV100,
                CASE WHEN (IPP1.FLOOR_AREA_HALF) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_HALF AS NUMERIC(20,10)) END AS FLOOR_AREA_HALF,
                CASE WHEN (IPP1.FLOOR_AREA_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_FULL AS NUMERIC(20,10)) END AS FLOOR_AREA_FULL,
                CASE WHEN (IPP1.FAMILY_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV00 AS NUMERIC(20,10)) END AS FAMILY_LV00,
                CASE WHEN (IPP1.FAMILY_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV01_49 AS NUMERIC(20,10)) END AS FAMILY_LV01_49,
                CASE WHEN (IPP1.FAMILY_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV50_99 AS NUMERIC(20,10)) END AS FAMILY_LV50_99,
                CASE WHEN (IPP1.FAMILY_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV100 AS NUMERIC(20,10)) END AS FAMILY_LV100,
                CASE WHEN (IPP1.FAMILY_HALF) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_HALF AS NUMERIC(20,10)) END AS FAMILY_HALF,
                CASE WHEN (IPP1.FAMILY_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_FULL AS NUMERIC(20,10)) END AS FAMILY_FULL,
                CASE WHEN (IPP1.OFFICE_LV00) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV00 AS NUMERIC(20,10)) END AS OFFICE_LV00,
                CASE WHEN (IPP1.OFFICE_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV01_49 AS NUMERIC(20,10)) END AS OFFICE_LV01_49,
                CASE WHEN (IPP1.OFFICE_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV50_99 AS NUMERIC(20,10)) END AS OFFICE_LV50_99,
                CASE WHEN (IPP1.OFFICE_LV100) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV100 AS NUMERIC(20,10)) END AS OFFICE_LV100,
                CASE WHEN (IPP1.OFFICE_HALF) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_HALF AS NUMERIC(20,10)) END AS OFFICE_HALF,
                CASE WHEN (IPP1.OFFICE_FULL) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_FULL AS NUMERIC(20,10)) END AS OFFICE_FULL,
                CASE WHEN (IPP1.FARMER_FISHER_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV00 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV00,
                CASE WHEN (IPP1.FARMER_FISHER_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV01_49 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV01_49,
                CASE WHEN (IPP1.FARMER_FISHER_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV50_99 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV50_99,
                CASE WHEN (IPP1.FARMER_FISHER_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV100 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV100,
                CASE WHEN (IPP1.FARMER_FISHER_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_FULL AS NUMERIC(20,10)) END AS FARMER_FISHER_FULL,
                CASE WHEN (IPP1.EMPLOYEE_LV00) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV00 AS NUMERIC(20,10)) END AS EMPLOYEE_LV00,
                CASE WHEN (IPP1.EMPLOYEE_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV01_49 AS NUMERIC(20,10)) END AS EMPLOYEE_LV01_49,
                CASE WHEN (IPP1.EMPLOYEE_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV50_99 AS NUMERIC(20,10)) END AS EMPLOYEE_LV50_99,
                CASE WHEN (IPP1.EMPLOYEE_LV100) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV100 AS NUMERIC(20,10)) END AS EMPLOYEE_LV100,
                CASE WHEN (IPP1.EMPLOYEE_FULL) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_FULL AS NUMERIC(20,10)) END AS EMPLOYEE_FULL,
                IPP1.INDUSTRY_CODE AS INDUSTRY_CODE,
                IND1.INDUSTRY_NAME AS INDUSTRY_NAME,
                IPP1.USAGE_CODE AS USAGE_CODE,
                USA1.USAGE_NAME AS USAGE_NAME,
                IPP1.COMMENT AS COMMENT 
            FROM IPPAN_VIEW IPP1 
            LEFT JOIN BUILDING BUI1 ON IPP1.BUILDING_CODE=BUI1.BUILDING_CODE 
            LEFT JOIN UNDERGROUND UND1 ON IPP1.UNDERGROUND_CODE=UND1.UNDERGROUND_CODE 
            LEFT JOIN FLOOD_SEDIMENT FLO1 ON IPP1.FLOOD_SEDIMENT_CODE=FLO1.FLOOD_SEDIMENT_CODE 
            LEFT JOIN INDUSTRY IND1 ON IPP1.INDUSTRY_CODE=IND1.INDUSTRY_CODE 
            LEFT JOIN USAGE USA1 ON IPP1.USAGE_CODE=USA1.USAGE_CODE 
            WHERE 
                IPP1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s 
            ORDER BY 
                CAST (IPP1.IPPAN_ID AS INTEGER)"""
  
        #######################################################################
        ### 関数内関数：ワークブック生成処理(0100)
        ### ユーザ入力用シートに値をセットする。
        ### ※25シート分ループする。または、ippan_header_listの数分ループする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10/11.', 'DEBUG')
        ### if len(ippan_header_list) > 25:
        if len(ippan_header_list) > MAX_SHEET_NUMBER:
            ### TODO TO-DO TO_DO
            ### エラー処理を記述する。または、25シートという固定数を用いる方法を再検討する。
            pass
        
        for i, ippan_header in enumerate(ippan_header_list, 0):                ### STARTS AT 0
            
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10_1/11.', 'DEBUG')
            PARAMS_SELECT_IPPAN_HEADER = dict({
                'IPPAN_HEADER_ID': ippan_header.ippan_header_id
            })

            ### ippan_header_listは、ippan_header_idしか保持していないため、ここで入力用シートに必要なデータを取得する。
            ### 別の変数detail_ippan_header_list、detail_ippan_listに格納する。
            detail_ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS_SELECT_IPPAN_HEADER)
            detail_ippan_list = IPPAN.objects.raw(SQL_SELECT_IPPAN, PARAMS_SELECT_IPPAN_HEADER)

            ###################################################################
            ### ユーザ入力用シートのヘッダ部のセルに、入力データ_ヘッダ部分の値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10_2/11.', 'DEBUG')
            if bool(detail_ippan_header_list) == True:                         ### ADD 2024/10/15
                for detail_ippan_header in detail_ippan_header_list:           ### ADD 2024/10/15
                    
                    if (bool(str(detail_ippan_header.ken_name)) and bool(str(detail_ippan_header.ken_code)) and 
                        bool(detail_ippan_header.ken_name) and bool(detail_ippan_header.ken_code)):
                        ws_ippan[i].cell(row=ROW["KEN_CODE"], column=COLUMN["KEN_CODE"]).value = (str(detail_ippan_header.ken_name) + ":" + str(detail_ippan_header.ken_code))
                    
                    if (bool(str(detail_ippan_header.city_name)) and bool(str(detail_ippan_header.city_code)) and 
                        bool(detail_ippan_header.city_name) and bool(detail_ippan_header.city_code)):
                        ws_ippan[i].cell(row=ROW["CITY_CODE"], column=COLUMN["CITY_CODE"]).value = (str(detail_ippan_header.city_name) + ":" + str(detail_ippan_header.city_code))

                    if (bool(str(detail_ippan_header.begin_date)) and bool(detail_ippan_header.begin_date)):
                        ws_ippan[i].cell(row=ROW["BEGIN_DATE"], column=COLUMN["BEGIN_DATE"]).value = (str(detail_ippan_header.begin_date))

                    if (bool(str(detail_ippan_header.end_date)) and bool(detail_ippan_header.end_date)):
                        ws_ippan[i].cell(row=ROW["END_DATE"], column=COLUMN["END_DATE"]).value = (str(detail_ippan_header.end_date))

                    if (bool(str(detail_ippan_header.cause_1_name)) and bool(str(detail_ippan_header.cause_1_code)) and 
                        bool(detail_ippan_header.cause_1_name) and bool(detail_ippan_header.cause_1_code)):
                        ws_ippan[i].cell(row=ROW["CAUSE_1_CODE"], column=COLUMN["CAUSE_1_CODE"]).value = (str(detail_ippan_header.cause_1_name) + ":" + str(detail_ippan_header.cause_1_code))

                    if (bool(str(detail_ippan_header.cause_2_name)) and bool(str(detail_ippan_header.cause_2_code)) and 
                        bool(detail_ippan_header.cause_2_name) and bool(detail_ippan_header.cause_2_code)):
                        ws_ippan[i].cell(row=ROW["CAUSE_2_CODE"], column=COLUMN["CAUSE_2_CODE"]).value = (str(detail_ippan_header.cause_2_name) + ":" + str(detail_ippan_header.cause_2_code))

                    if (bool(str(detail_ippan_header.cause_3_name)) and bool(str(detail_ippan_header.cause_3_code)) and 
                        bool(detail_ippan_header.cause_3_name) and bool(detail_ippan_header.cause_3_code)):
                        ws_ippan[i].cell(row=ROW["CAUSE_3_CODE"], column=COLUMN["CAUSE_3_CODE"]).value = (str(detail_ippan_header.cause_3_name) + ":" + str(detail_ippan_header.cause_3_code))

                    ###########################################################
                    ###########################################################
                    if (bool(str(detail_ippan_header.kuiki_id)) and bool(detail_ippan_header.kuiki_id)): ### 2024/11/08 ADD ### 2024/11/11 TODO TO-DO TO_DO水害区域コードにすべきか？
                        ws_ippan[i].cell(row=ROW["KUIKI_ID"], column=COLUMN["KUIKI_ID"]).value = (detail_ippan_header.kuiki_id)
                    ###########################################################
                    ###########################################################

                    if (bool(str(detail_ippan_header.suikei_name)) and bool(str(detail_ippan_header.suikei_code)) and 
                        bool(detail_ippan_header.suikei_name) and bool(detail_ippan_header.suikei_code)):
                        ws_ippan[i].cell(row=ROW["SUIKEI_CODE"], column=COLUMN["SUIKEI_CODE"]).value = (str(detail_ippan_header.suikei_name) + ":" + str(detail_ippan_header.suikei_code))

                    if (bool(str(detail_ippan_header.suikei_type_name)) and bool(str(detail_ippan_header.suikei_type_code)) and 
                        bool(detail_ippan_header.suikei_type_name) and bool(detail_ippan_header.suikei_type_code)):
                        ws_ippan[i].cell(row=ROW["SUIKEI_TYPE_CODE"], column=COLUMN["SUIKEI_TYPE_CODE"]).value = (str(detail_ippan_header.suikei_type_name) + ":" + str(detail_ippan_header.suikei_type_code))

                    if (bool(str(detail_ippan_header.kasen_name)) and bool(str(detail_ippan_header.kasen_code)) and 
                        bool(detail_ippan_header.kasen_name) and bool(detail_ippan_header.kasen_code)):
                        ws_ippan[i].cell(row=ROW["KASEN_CODE"], column=COLUMN["KASEN_CODE"]).value = (str(detail_ippan_header.kasen_name) + ":" + str(detail_ippan_header.kasen_code))

                    if (bool(str(detail_ippan_header.kasen_type_name)) and bool(str(detail_ippan_header.kasen_type_code)) and 
                        bool(detail_ippan_header.kasen_type_name) and bool(detail_ippan_header.kasen_type_code)):
                        ws_ippan[i].cell(row=ROW["KASEN_TYPE_CODE"], column=COLUMN["KASEN_TYPE_CODE"]).value = (str(detail_ippan_header.kasen_type_name) + ":" + str(detail_ippan_header.kasen_type_code))

                    if (bool(str(detail_ippan_header.gradient_name)) and bool(str(detail_ippan_header.gradient_code)) and 
                        bool(detail_ippan_header.gradient_name) and bool(detail_ippan_header.gradient_code)):
                        ws_ippan[i].cell(row=ROW["GRADIENT_CODE"], column=COLUMN["GRADIENT_CODE"]).value = (str(detail_ippan_header.gradient_name) + ":" + str(detail_ippan_header.gradient_code))

                    if (bool(str(detail_ippan_header.residential_area)) and bool(detail_ippan_header.residential_area)):
                        ws_ippan[i].cell(row=ROW["RESIDENTIAL_AREA"], column=COLUMN["RESIDENTIAL_AREA"]).value = (detail_ippan_header.residential_area)

                    if (bool(str(detail_ippan_header.agricultural_area)) and bool(detail_ippan_header.agricultural_area)):
                        ws_ippan[i].cell(row=ROW["AGRICULTURAL_AREA"], column=COLUMN["AGRICULTURAL_AREA"]).value = (detail_ippan_header.agricultural_area)

                    if (bool(str(detail_ippan_header.underground_area)) and bool(detail_ippan_header.underground_area)):
                        ws_ippan[i].cell(row=ROW["UNDERGROUND_AREA"], column=COLUMN["UNDERGROUND_AREA"]).value = (detail_ippan_header.underground_area)

                    if (bool(str(detail_ippan_header.kasen_kaigan_name)) and bool(str(detail_ippan_header.kasen_kaigan_code)) and 
                        bool(detail_ippan_header.kasen_kaigan_name) and bool(detail_ippan_header.kasen_kaigan_code)):
                        ws_ippan[i].cell(row=ROW["KASEN_KAIGAN_CODE"], column=COLUMN["KASEN_KAIGAN_CODE"]).value = (str(detail_ippan_header.kasen_kaigan_name) + ":" + str(detail_ippan_header.kasen_kaigan_code))

                    if (bool(str(detail_ippan_header.crop_damage)) and bool(detail_ippan_header.crop_damage)):
                        ws_ippan[i].cell(row=ROW["CROP_DAMAGE"], column=COLUMN["CROP_DAMAGE"]).value = (detail_ippan_header.crop_damage)

                    if (bool(str(detail_ippan_header.weather_name)) and bool(str(detail_ippan_header.weather_id)) and 
                        bool(detail_ippan_header.weather_name) and bool(detail_ippan_header.weather_id)):
                        ws_ippan[i].cell(row=ROW["WEATHER_ID"], column=COLUMN["WEATHER_ID"]).value = (str(detail_ippan_header.weather_name) + ":" + str(detail_ippan_header.weather_id))

                    if (bool(str(detail_ippan_header.ippan_header_id)) and bool(detail_ippan_header.ippan_header_id)):
                        ws_ippan[i].cell(row=ROW["IPPAN_HEADER_ID"], column=COLUMN["IPPAN_HEADER_ID"]).value = (detail_ippan_header.ippan_header_id)

            ###################################################################
            ### ユーザ入力用シートの一覧部のセルに、入力データ_一覧部分の値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10_4/11.', 'DEBUG')
            if bool(detail_ippan_list) == True:                                ### ADD 2024/10/15
                for row_num, detail_ippan in enumerate(detail_ippan_list, 20): ### ADD 2024/10/15 ### SECOND ARGUMENT MEANS STARTS AT 20
                    
                    if (bool(str(detail_ippan.ippan_name)) and bool(detail_ippan.ippan_name)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["IPPAN_NAME"]).value = (str(detail_ippan.ippan_name))
                    
                    if (bool(str(detail_ippan.building_name)) and bool(str(detail_ippan.building_code)) and 
                        bool(detail_ippan.building_name) and bool(detail_ippan.building_code)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["BUILDING_CODE"]).value = (str(detail_ippan.building_name) + ":" + str(detail_ippan.building_code))

                    if (bool(str(detail_ippan.underground_name)) and bool(str(detail_ippan.underground_code)) and 
                        bool(detail_ippan.underground_name) and bool(detail_ippan.underground_code)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["UNDERGROUND_CODE"]).value = (str(detail_ippan.underground_name) + ":" + str(detail_ippan.underground_code))

                    if (bool(str(detail_ippan.flood_sediment_name)) and bool(str(detail_ippan.flood_sediment_code)) and 
                        bool(detail_ippan.flood_sediment_name) and bool(detail_ippan.flood_sediment_code)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FLOOD_SEDIMENT_CODE"]).value = (str(detail_ippan.flood_sediment_name) + ":" + str(detail_ippan.flood_sediment_code))

                    if (bool(str(detail_ippan.building_lv00)) and bool(detail_ippan.building_lv00)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["BUILDING_LV00"]).value = (detail_ippan.building_lv00)

                    if (bool(str(detail_ippan.building_lv01_49)) and bool(detail_ippan.building_lv01_49)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["BUILDING_LV01_49"]).value = (detail_ippan.building_lv01_49)

                    if (bool(str(detail_ippan.building_lv50_99)) and bool(detail_ippan.building_lv50_99)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["BUILDING_LV50_99"]).value = (detail_ippan.building_lv50_99)

                    if (bool(str(detail_ippan.building_lv100)) and bool(detail_ippan.building_lv100)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["BUILDING_LV100"]).value = (detail_ippan.building_lv100)

                    if (bool(str(detail_ippan.building_half)) and bool(detail_ippan.building_half)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["BUILDING_HALF"]).value = (detail_ippan.building_half)

                    if (bool(str(detail_ippan.building_full)) and bool(detail_ippan.building_full)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["BUILDING_FULL"]).value = (detail_ippan.building_full)

                    if (bool(str(detail_ippan.floor_area)) and bool(detail_ippan.floor_area)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FLOOR_AREA"]).value = (detail_ippan.floor_area)

                    if (bool(str(detail_ippan.family)) and bool(detail_ippan.family)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FAMILY"]).value = (detail_ippan.family)

                    if (bool(str(detail_ippan.office)) and bool(detail_ippan.office)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["OFFICE"]).value = (detail_ippan.office)

                    if (bool(str(detail_ippan.farmer_fisher_lv00)) and bool(detail_ippan.farmer_fisher_lv00)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV00"]).value = (detail_ippan.farmer_fisher_lv00)

                    if (bool(str(detail_ippan.farmer_fisher_lv01_49)) and bool(detail_ippan.farmer_fisher_lv01_49)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV01_49"]).value = (detail_ippan.farmer_fisher_lv01_49)

                    if (bool(str(detail_ippan.farmer_fisher_lv50_99)) and bool(detail_ippan.farmer_fisher_lv50_99)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV50_99"]).value = (detail_ippan.farmer_fisher_lv50_99)

                    if (bool(str(detail_ippan.farmer_fisher_lv100)) and bool(detail_ippan.farmer_fisher_lv100)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV100"]).value = (detail_ippan.farmer_fisher_lv100)

                    if (bool(str(detail_ippan.farmer_fisher_full)) and bool(detail_ippan.farmer_fisher_full)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["FARMER_FISHER_FULL"]).value = (detail_ippan.farmer_fisher_full)

                    if (bool(str(detail_ippan.employee_lv00)) and bool(detail_ippan.employee_lv00)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["EMPLOYEE_LV00"]).value = (detail_ippan.employee_lv00)

                    if (bool(str(detail_ippan.employee_lv01_49)) and bool(detail_ippan.employee_lv01_49)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["EMPLOYEE_LV01_49"]).value = (detail_ippan.employee_lv01_49)

                    if (bool(str(detail_ippan.employee_lv50_99)) and bool(detail_ippan.employee_lv50_99)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["EMPLOYEE_LV50_99"]).value = (detail_ippan.employee_lv50_99)

                    if (bool(str(detail_ippan.employee_lv100)) and bool(detail_ippan.employee_lv100)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["EMPLOYEE_LV100"]).value = (detail_ippan.employee_lv100)

                    if (bool(str(detail_ippan.employee_full)) and bool(detail_ippan.employee_full)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["EMPLOYEE_FULL"]).value = (detail_ippan.employee_full)

                    if (bool(str(detail_ippan.industry_name)) and bool(str(detail_ippan.industry_code)) and 
                        bool(detail_ippan.industry_name) and bool(detail_ippan.industry_code)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["INDUSTRY_CODE"]).value = (str(detail_ippan.industry_name) + ":" + str(detail_ippan.industry_code))

                    if (bool(str(detail_ippan.usage_name)) and bool(str(detail_ippan.usage_code)) and 
                        bool(detail_ippan.usage_name) and bool(detail_ippan.usage_code)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["USAGE_CODE"]).value = (str(detail_ippan.usage_name) + ":" + str(detail_ippan.usage_code))

                    if (bool(str(detail_ippan.comment)) and bool(detail_ippan.comment)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["COMMENT"]).value = (detail_ippan.comment)

                    if (bool(str(detail_ippan.ippan_id)) and bool(detail_ippan.ippan_id)):
                        ws_ippan[i].cell(row=row_num, column=COLUMN["IPPAN_ID"]).value = (detail_ippan.ippan_id)

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0110)
        ### 都道府県、市区町村のセルがNONE（NULL）の場合、デフォルト値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 11/12.', 'DEBUG')
        ### print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        ### PARAMS_SELECT_USER_PROXY = dict({
        ###     'USERNAME': str(request.user),
        ### })
        ### SQL_SELECT_USER_PROXY = """
        ###     SELECT
        ###         P1.ID,
        ###         A1.USERNAME,
        ###         P1.ROLE_CODE,
        ###         P1.KEN_CODE,
        ###         P1.CITY_CODE,
        ###         K1.KEN_NAME,
        ###         C1.CITY_NAME
        ###     FROM USER_PROXY P1
        ###     LEFT JOIN (SELECT * FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID
        ###     LEFT JOIN (SELECT * FROM KEN) K1 ON P1.KEN_CODE=K1.KEN_CODE
        ###     LEFT JOIN (SELECT * FROM CITY) C1 ON P1.CITY_CODE=C1.CITY_CODE
        ###     WHERE 
        ###         A1.USERNAME=%(USERNAME)s"""
        ### user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
        
        ### for i in range(25):
        for i in range(MAX_SHEET_NUMBER):
            if (ws_ippan[i].cell(row=7, column=2).value == "") and (
                ws_ippan[i].cell(row=7, column=3).value == ""):
                ws_ippan[i].cell(row=7, column=2).value = str(ken_name) + ":" + str(ken_code)
                ws_ippan[i].cell(row=7, column=3).value = str(city_name) + ":" + str(city_code)

        #######################################################################
        ### 関数内関数：ワークブック生成処理(0120)
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 12/12.', 'DEBUG')
        print_log('[INFO] P0000Common.create_ippan_chosa_workbook()関数が正常終了しました。', 'INFO')
        return True, workbook
    
    except:
        return False, ""

###############################################################################
### 一般資産調査員調査票ファイル生成処理【済】
### arguments["IPPAN_HEADER_ID"]
### arguments["FILE_TYPE"]
###############################################################################
def get_ippan_chosa_csv_excel(request, arguments):
        
    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ### ※当面使用しない。複数シートに対応するためには、複数CSVファイルに対応する必要があるため。
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_ippan_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        ### ※単数EXCELファイル、複数EXCELシートに対応するため、
        ### ※IPPAN_HEADER_ID(=1シートに対応)から、UPLOAD_FILE_PATHを経由して、IPPAN_HEADER_IDのリスト(=全シートに対応)を取得する。
        ### ※この処理の前提条件は、UPLOAD_FILE_PATHがユニークである必要があり、そのためにアップロード日時をファイル名に付与している。
        ### ※left joinでもSQLを書けそうと思う。
        ### ※複数シートで１シートを削除した場合、削除したシートが復活してしまうため、SQLをDELETED_ATを見るように変更した。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        ### SQL_SELECT_IPPAN_HEADER_01 = """                                   ### 2024/11/14 COMMENT OUT
        ###     SELECT 
        ###         * 
        ###     FROM IPPAN_HEADER 
        ###     WHERE 
        ###         IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s LIMIT 1"""
        ### SQL_SELECT_IPPAN_HEADER_02 = """
        ###     SELECT 
        ###         * 
        ###     FROM IPPAN_HEADER 
        ###     WHERE 
        ###         UPLOAD_FILE_PATH=%(UPLOAD_FILE_PATH)s
        ###     ORDER BY CAST(IPPAN_HEADER_ID AS INTEGER)"""

        SQL_SELECT_IPPAN_HEADER_01 = """
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                DELETED_AT IS NULL LIMIT 1"""
        SQL_SELECT_IPPAN_HEADER_02 = """
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                UPLOAD_FILE_PATH=%(UPLOAD_FILE_PATH)s AND 
                DELETED_AT IS NULL
            ORDER BY CAST(IPPAN_HEADER_ID AS INTEGER)"""
                
        PARAMS_SELECT_IPPAN_HEADER_01 = dict({
            'IPPAN_HEADER_ID': arguments["IPPAN_HEADER_ID"]
        })

        temporary_ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER_01, PARAMS_SELECT_IPPAN_HEADER_01)

        PARAMS_SELECT_IPPAN_HEADER_02 = dict({
            'UPLOAD_FILE_PATH': temporary_ippan_header_list[0].upload_file_path
        })
    
        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER_02, PARAMS_SELECT_IPPAN_HEADER_02)
        
        if (bool(temporary_ippan_header_list) == False) or (bool(ippan_header_list) == False):
            print_log('[WARN] P0000Common.get_ippan_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        ### if bool(ippan_header_list) == True:                                ### 2024/11/11 comment out
        ###     ippan_header_count = len(ippan_header_list)
        ### else:
        ###     ippan_header_count = 0

        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        
        #######################################################################
        ### 2024/11/11 ADD
        #######################################################################
        ### PARAMS_SELECT_USER_PROXY = dict({
        ###     'USERNAME': str(request.user), 
        ### })
        ### SQL_SELECT_USER_PROXY = """
        ###     SELECT 
        ###         P1.ID, 
        ###         A1.USERNAME, 
        ###         P1.ROLE_CODE, 
        ###         P1.KEN_CODE, 
        ###         P1.CITY_CODE,
        ###         K1.KEN_NAME,
        ###         C1.CITY_NAME
        ###     FROM USER_PROXY P1 
        ###     LEFT JOIN (
        ###         SELECT 
        ###             * 
        ###         FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
        ###     LEFT JOIN KEN K1 ON P1.KEN_CODE=K1.KEN_CODE
        ###     LEFT JOIN CITY C1 ON P1.CITY_CODE=C1.CITY_CODE
        ###     WHERE 
        ###         A1.USERNAME=%(USERNAME)s"""
        ### user_proxy_list = USER_PROXY.objects.raw(SQL_SELECT_USER_PROXY, PARAMS_SELECT_USER_PROXY)
        ### PARAMS_SELECT_SUIKEI = dict({
        ###     'KEN_CODE': '%' + str(user_proxy_list[0].ken_code) + '%',
        ### })
        SQL_SELECT_IPPAN_HEADER_03 = """
            SELECT 
                H1.IPPAN_HEADER_ID,
                H1.KEN_CODE,
                H1.CITY_CODE,
                K1.KEN_NAME,
                C1.CITY_NAME
            FROM 
                IPPAN_HEADER H1
                LEFT JOIN KEN K1 ON H1.KEN_CODE=K1.KEN_CODE
                LEFT JOIN CITY C1 ON H1.CITY_CODE=C1.CITY_CODE
            WHERE
                H1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s"""
        PARAMS_SELECT_IPPAN_HEADER_03 = dict({
            'IPPAN_HEADER_ID': arguments["IPPAN_HEADER_ID"],
        })
        ippan_header_list_03 = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER_03, PARAMS_SELECT_IPPAN_HEADER_03)

        if (bool(temporary_ippan_header_list) == False) or (bool(ippan_header_list) == False):
            print_log('[WARN] P0000Common.get_ippan_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        #######################################################################
        ### 2024/11/11 ADD
        #######################################################################
        
        ### building_list = BUILDING.objects.raw("""SELECT * FROM BUILDING ORDER BY CAST(BUILDING_CODE AS INTEGER)""")
        ### ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        ### kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        ### suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI WHERE KEN_CODE LIKE %(KEN_CODE)s ORDER BY CAST(SUIKEI_CODE AS INTEGER)""", PARAMS_SELECT_SUIKEI) ### 2024/11/11 ADD
        ### suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        ### kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### cause_list = CAUSE.objects.raw("""SELECT * FROM CAUSE ORDER BY CAST(CAUSE_CODE AS INTEGER)""")
        ### underground_list = UNDERGROUND.objects.raw("""SELECT * FROM UNDERGROUND ORDER BY CAST(UNDERGROUND_CODE AS INTEGER)""")
        ### usage_list = USAGE.objects.raw("""SELECT * FROM USAGE ORDER BY CAST(USAGE_CODE AS INTEGER)""")
        ### flood_sediment_list = FLOOD_SEDIMENT.objects.raw("""SELECT * FROM FLOOD_SEDIMENT ORDER BY CAST(FLOOD_SEDIMENT_CODE AS INTEGER)""")
        ### gradient_list = GRADIENT.objects.raw("""SELECT * FROM GRADIENT ORDER BY CAST(GRADIENT_CODE AS INTEGER)""")
        ### industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
        ### weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/ippan_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'ippan_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/ippan_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'ippan_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0060)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_ippan_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_ippan_chosa_workbook(
            template_file_path = template_file_path,
            ippan_header_list = ippan_header_list,
            ken_code = ippan_header_list_03[0].ken_code,
            city_code = ippan_header_list_03[0].city_code,
            ken_name = ippan_header_list_03[0].ken_name,
            city_name = ippan_header_list_03[0].city_name,
            MAX_SHEET_NUMBER = MAX_SHEET_NUMBER
        )
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0080)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        ### print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG') ### 2024/11/14 COMMENT OUT
        ### bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        ### if bool_return == False:
        ###     raise Exception

        #######################################################################
        ### レスポンスセット処理(0090)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if arguments["FILE_TYPE"] == _IPP_CHO_EXC:
            return True, excel_file_path
        ### elif arguments["FILE_TYPE"] == _IPP_CHO_CSV:                       ### 2024/11/14 COMMENT OUT
        ###     return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_ippan_chosa_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_chosa_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 一般資産調査員調査票システム間連携ファイル生成処理
### arguments["IPPAN_HEADER_ID"]
### arguments["FILE_TYPE"]
###############################################################################
def get_ippan_export_csv(request, arguments):
    
    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※複数EXCELシート非対応版
    ###########################################################################
    def create_ippan_export_workbook(ippan_header_id):
        try:
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_ippan_export_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_ippan_export_workbook()関数 STEP 1/4.', 'DEBUG')
            print_log('[DEBUG] P0000Common.create_ippan_export_workbook()関数 ippan_header_id={}'.format(ippan_header_id), 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_export_workbook()関数 STEP 2/4.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_ippan = []
            ws_ippan.append(workbook["IPPAN"])
      
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_export_workbook()関数 STEP 3/4.', 'DEBUG')
            PARAMS_SELECT_IPPAN_HEADER = dict({
                'IPPAN_HEADER_ID': ippan_header_id
            })
            SQL_SELECT_IPPAN_HEADER = """
                SELECT 
                    IPP1.IPPAN_HEADER_ID AS IPPAN_HEADER_ID,
                    IPP1.IPPAN_HEADER_NAME AS IPPAN_HEADER_NAME,
                    IPP1.KEN_CODE AS KEN_CODE, 
                    KEN1.KEN_NAME AS KEN_NAME,
                    IPP1.CITY_CODE AS CITY_CODE,
                    CIT1.CITY_NAME AS CITY_NAME,
                    -- TO_CHAR(TIMEZONE('JST', IPP1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE,
                    -- TO_CHAR(TIMEZONE('JST', IPP1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE,
                    TO_CHAR(TIMEZONE('JST', IPP1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH,
                    TO_CHAR(TIMEZONE('JST', IPP1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY,
                    TO_CHAR(TIMEZONE('JST', IPP1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH,
                    TO_CHAR(TIMEZONE('JST', IPP1.END_DATE::TIMESTAMPTZ), 'DD') AS END_DAY,
                    IPP1.CAUSE_1_CODE AS CAUSE_1_CODE,
                    CAU1.CAUSE_NAME AS CAUSE_1_NAME,
                    IPP1.CAUSE_2_CODE AS CAUSE_2_CODE,
                    CAU2.CAUSE_NAME AS CAUSE_2_NAME,
                    IPP1.CAUSE_3_CODE AS CAUSE_3_CODE,
                    CAU3.CAUSE_NAME AS CAUSE_3_NAME,
                    IPP1.KUIKI_ID AS KUIKI_ID,
                    -- KUI1.KUIKI_NAME AS KUIKI_NAME, 2024/11/08 comment out
                    IPP1.SUIKEI_CODE AS SUIKEI_CODE,
                    SUI1.SUIKEI_NAME AS SUIKEI_NAME,
                    SUT1.SUIKEI_TYPE_CODE AS SUIKEI_TYPE_CODE,
                    SUT1.SUIKEI_TYPE_NAME AS SUIKEI_TYPE_NAME,
                    IPP1.KASEN_CODE AS KASEN_CODE,
                    KAS1.KASEN_NAME AS KASEN_NAME,
                    KAT1.KASEN_TYPE_CODE AS KASEN_TYPE_CODE,
                    KAT1.KASEN_TYPE_NAME AS KASEN_TYPE_NAME,
                    IPP1.GRADIENT_CODE AS GRADIENT_CODE,
                    GRA1.GRADIENT_NAME AS GRADIENT_NAME,
                    -- CASE WHEN (IPP1.RESIDENTIAL_AREA) IS NULL THEN NULL ELSE CAST(IPP1.RESIDENTIAL_AREA AS NUMERIC(20,10)) END AS RESIDENTIAL_AREA,
                    -- CASE WHEN (IPP1.AGRICULTURAL_AREA) IS NULL THEN NULL ELSE CAST(IPP1.AGRICULTURAL_AREA AS NUMERIC(20,10)) END AS AGRICULTURAL_AREA,
                    -- CASE WHEN (IPP1.UNDERGROUND_AREA) IS NULL THEN NULL ELSE CAST(IPP1.UNDERGROUND_AREA AS NUMERIC(20,10)) END AS UNDERGROUND_AREA,
                    CASE WHEN (IPP1.RESIDENTIAL_AREA) IS NULL THEN NULL ELSE IPP1.RESIDENTIAL_AREA END AS RESIDENTIAL_AREA,
                    CASE WHEN (IPP1.AGRICULTURAL_AREA) IS NULL THEN NULL ELSE IPP1.AGRICULTURAL_AREA END AS AGRICULTURAL_AREA,
                    CASE WHEN (IPP1.UNDERGROUND_AREA) IS NULL THEN NULL ELSE IPP1.UNDERGROUND_AREA END AS UNDERGROUND_AREA,
                    IPP1.KASEN_KAIGAN_CODE AS KASEN_KAIGAN_CODE,
                    KAK1.KASEN_KAIGAN_NAME AS KASEN_KAIGAN_NAME,
                    -- CASE WHEN (IPP1.CROP_DAMAGE) IS NULL THEN NULL ELSE CAST(IPP1.CROP_DAMAGE AS NUMERIC(20,10)) END AS CROP_DAMAGE,
                    CASE WHEN (IPP1.CROP_DAMAGE) IS NULL THEN NULL ELSE IPP1.CROP_DAMAGE END AS CROP_DAMAGE,
                    IPP1.WEATHER_ID AS WEATHER_ID,
                    WEA1.WEATHER_NAME AS WEATHER_NAME,
                    IPP1.UPLOAD_FILE_PATH AS UPLOAD_FILE_PATH,
                    IPP1.UPLOAD_FILE_NAME AS UPLOAD_FILE_NAME,
                    TO_CHAR(TIMEZONE('JST', IPP1.COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD') AS COMMITTED_AT
                FROM IPPAN_HEADER IPP1 
                LEFT JOIN KEN KEN1 ON IPP1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON IPP1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN CAUSE CAU1 ON IPP1.CAUSE_1_CODE=CAU1.CAUSE_CODE 
                LEFT JOIN CAUSE CAU2 ON IPP1.CAUSE_2_CODE=CAU2.CAUSE_CODE 
                LEFT JOIN CAUSE CAU3 ON IPP1.CAUSE_3_CODE=CAU3.CAUSE_CODE 
                -- LEFT JOIN KUIKI KUI1 ON IPP1.KUIKI_ID=KUI1.KUIKI_ID 2024/11/08 comment out
                LEFT JOIN SUIKEI SUI1 ON IPP1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                LEFT JOIN SUIKEI_TYPE SUT1 ON SUI1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                LEFT JOIN KASEN KAS1 ON IPP1.KASEN_CODE=KAS1.KASEN_CODE 
                LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                LEFT JOIN GRADIENT GRA1 ON IPP1.GRADIENT_CODE=GRA1.GRADIENT_CODE 
                LEFT JOIN KASEN_KAIGAN KAK1 ON IPP1.KASEN_KAIGAN_CODE=KAK1.KASEN_KAIGAN_CODE 
                LEFT JOIN WEATHER WEA1 ON IPP1.WEATHER_ID=WEA1.WEATHER_ID 
                WHERE 
                    IPP1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s LIMIT 1"""
            SQL_SELECT_IPPAN = """
                SELECT 
                    IPP1.IPPAN_ID AS IPPAN_ID,
                    IPP1.IPPAN_NAME AS IPPAN_NAME,
                    IPP1.BUILDING_CODE AS BUILDING_CODE,
                    BUI1.BUILDING_NAME AS BUILDING_NAME,
                    IPP1.UNDERGROUND_CODE AS UNDERGROUND_CODE,
                    UND1.UNDERGROUND_NAME AS UNDERGROUND_NAME,
                    IPP1.FLOOD_SEDIMENT_CODE AS FLOOD_SEDIMENT_CODE,
                    FLO1.FLOOD_SEDIMENT_NAME AS FLOOD_SEDIMENT_NAME,
                    CASE WHEN (IPP1.BUILDING_LV00) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV00 AS NUMERIC(20,10)) END AS BUILDING_LV00,
                    CASE WHEN (IPP1.BUILDING_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV01_49 AS NUMERIC(20,10)) END AS BUILDING_LV01_49,
                    CASE WHEN (IPP1.BUILDING_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV50_99 AS NUMERIC(20,10)) END AS BUILDING_LV50_99,
                    CASE WHEN (IPP1.BUILDING_LV100) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV100 AS NUMERIC(20,10)) END AS BUILDING_LV100,
                    CASE WHEN (IPP1.BUILDING_HALF) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_HALF AS NUMERIC(20,10)) END AS BUILDING_HALF,
                    CASE WHEN (IPP1.BUILDING_FULL) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_FULL AS NUMERIC(20,10)) END AS BUILDING_FULL,
                    CASE WHEN (IPP1.FLOOR_AREA) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA AS NUMERIC(20,10)) END AS FLOOR_AREA,
                    CASE WHEN (IPP1.FAMILY) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY AS NUMERIC(20,10)) END AS FAMILY,
                    CASE WHEN (IPP1.OFFICE) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE AS NUMERIC(20,10)) END AS OFFICE,
                    CASE WHEN (IPP1.FLOOR_AREA_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV00 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV00,
                    CASE WHEN (IPP1.FLOOR_AREA_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV01_49 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV01_49,
                    CASE WHEN (IPP1.FLOOR_AREA_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV50_99 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV50_99,
                    CASE WHEN (IPP1.FLOOR_AREA_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV100 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV100,
                    CASE WHEN (IPP1.FLOOR_AREA_HALF) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_HALF AS NUMERIC(20,10)) END AS FLOOR_AREA_HALF,
                    CASE WHEN (IPP1.FLOOR_AREA_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_FULL AS NUMERIC(20,10)) END AS FLOOR_AREA_FULL,
                    CASE WHEN (IPP1.FAMILY_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV00 AS NUMERIC(20,10)) END AS FAMILY_LV00,
                    CASE WHEN (IPP1.FAMILY_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV01_49 AS NUMERIC(20,10)) END AS FAMILY_LV01_49,
                    CASE WHEN (IPP1.FAMILY_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV50_99 AS NUMERIC(20,10)) END AS FAMILY_LV50_99,
                    CASE WHEN (IPP1.FAMILY_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV100 AS NUMERIC(20,10)) END AS FAMILY_LV100,
                    CASE WHEN (IPP1.FAMILY_HALF) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_HALF AS NUMERIC(20,10)) END AS FAMILY_HALF,
                    CASE WHEN (IPP1.FAMILY_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_FULL AS NUMERIC(20,10)) END AS FAMILY_FULL,
                    CASE WHEN (IPP1.OFFICE_LV00) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV00 AS NUMERIC(20,10)) END AS OFFICE_LV00,
                    CASE WHEN (IPP1.OFFICE_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV01_49 AS NUMERIC(20,10)) END AS OFFICE_LV01_49,
                    CASE WHEN (IPP1.OFFICE_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV50_99 AS NUMERIC(20,10)) END AS OFFICE_LV50_99,
                    CASE WHEN (IPP1.OFFICE_LV100) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV100 AS NUMERIC(20,10)) END AS OFFICE_LV100,
                    CASE WHEN (IPP1.OFFICE_HALF) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_HALF AS NUMERIC(20,10)) END AS OFFICE_HALF,
                    CASE WHEN (IPP1.OFFICE_FULL) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_FULL AS NUMERIC(20,10)) END AS OFFICE_FULL,
                    CASE WHEN (IPP1.FARMER_FISHER_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV00 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV00,
                    CASE WHEN (IPP1.FARMER_FISHER_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV01_49 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV01_49,
                    CASE WHEN (IPP1.FARMER_FISHER_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV50_99 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV50_99,
                    CASE WHEN (IPP1.FARMER_FISHER_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV100 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV100,
                    CASE WHEN (IPP1.FARMER_FISHER_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_FULL AS NUMERIC(20,10)) END AS FARMER_FISHER_FULL,
                    CASE WHEN (IPP1.EMPLOYEE_LV00) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV00 AS NUMERIC(20,10)) END AS EMPLOYEE_LV00,
                    CASE WHEN (IPP1.EMPLOYEE_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV01_49 AS NUMERIC(20,10)) END AS EMPLOYEE_LV01_49,
                    CASE WHEN (IPP1.EMPLOYEE_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV50_99 AS NUMERIC(20,10)) END AS EMPLOYEE_LV50_99,
                    CASE WHEN (IPP1.EMPLOYEE_LV100) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV100 AS NUMERIC(20,10)) END AS EMPLOYEE_LV100,
                    CASE WHEN (IPP1.EMPLOYEE_FULL) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_FULL AS NUMERIC(20,10)) END AS EMPLOYEE_FULL,
                    IPP1.INDUSTRY_CODE AS INDUSTRY_CODE,
                    IND1.INDUSTRY_NAME AS INDUSTRY_NAME,
                    IPP1.USAGE_CODE AS USAGE_CODE,
                    USA1.USAGE_NAME AS USAGE_NAME,
                    IPP1.COMMENT AS COMMENT 
                FROM IPPAN_VIEW IPP1 
                LEFT JOIN BUILDING BUI1 ON IPP1.BUILDING_CODE=BUI1.BUILDING_CODE 
                LEFT JOIN UNDERGROUND UND1 ON IPP1.UNDERGROUND_CODE=UND1.UNDERGROUND_CODE 
                LEFT JOIN FLOOD_SEDIMENT FLO1 ON IPP1.FLOOD_SEDIMENT_CODE=FLO1.FLOOD_SEDIMENT_CODE 
                LEFT JOIN INDUSTRY IND1 ON IPP1.INDUSTRY_CODE=IND1.INDUSTRY_CODE 
                LEFT JOIN USAGE USA1 ON IPP1.USAGE_CODE=USA1.USAGE_CODE 
                WHERE 
                    IPP1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s 
                ORDER BY 
                    CAST (IPP1.IPPAN_ID AS INTEGER)"""

            ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER, PARAMS_SELECT_IPPAN_HEADER)
            ippan_list = IPPAN.objects.raw(SQL_SELECT_IPPAN, PARAMS_SELECT_IPPAN_HEADER)

            COLUMN = dict({
                'UPLOAD_FILE_NAME': 1,
                'KEN_CODE': 3,
                'CITY_CODE': 4,
                'BEGIN_MONTH': 5,
                'BEGIN_DAY': 6,
                'END_MONTH': 7,
                'END_DAY': 8,
                'CAUSE_1_CODE': 9,
                'CAUSE_2_CODE': 10,
                'CAUSE_3_CODE': 11,
                'KUIKI_ID': 12,
                'SUIKEI_CODE': 13,
                'SUIKEI_TYPE_CODE': 14,
                'KASEN_CODE': 15,
                'KASEN_TYPE_CODE': 16,
                'GRADIENT_CODE': 17,
                'RESIDENTIAL_AREA': 49,
                'AGRICULTURAL_AREA': 50,
                'UNDERGROUND_AREA': 51,
                'KASEN_KAIGAN_CODE': 52,
                'CROP_DAMAGE': 53,
                'WEATHER_ID': 54,
                'IPPAN_HEADER_ID': 55,
                'UPLOAD_FILE_PATH': 58,
                'COMMITTED_AT': 57,
                
                'DEPARTMENT_NAME': 43,       ### NOT INCLUDED IN EXCEL FILE 2024/10/02
                'PERSON_NAME': 44,           ### NOT INCLUDED IN EXCEL FILE 2024/10/02
                'TELEPHONE': 45,             ### NOT INCLUDED IN EXCEL FILE 2024/10/02
                'MAIL': 46,                  ### NOT INCLUDED IN EXCEL FILE 2024/10/02
                
                'IPPAN_NAME': 18,
                'BUILDING_CODE': 19,
                'UNDERGROUND_CODE': 20,
                'FLOOD_SEDIMENT_CODE': 21,
                'BUILDING_LV00': 22,
                'BUILDING_LV01_49': 23,
                'BUILDING_LV50_99': 24,
                'BUILDING_LV100': 25,
                'BUILDING_HALF': 26,
                'BUILDING_FULL': 27,
                'FLOOR_AREA': 28,
                'FAMILY': 29,
                'OFFICE': 30,
                'FARMER_FISHER_LV00': 31,
                'FARMER_FISHER_LV01_49': 32,
                'FARMER_FISHER_LV50_99': 33,
                'FARMER_FISHER_LV100': 34,
                'FARMER_FISHER_FULL': 35,
                'EMPLOYEE_LV00': 36,
                'EMPLOYEE_LV01_49': 37,
                'EMPLOYEE_LV50_99': 38,
                'EMPLOYEE_LV100': 39,
                'EMPLOYEE_FULL': 40,
                'INDUSTRY_CODE': 41,
                'USAGE_CODE': 42,
                'COMMENT': 47,
                'COMMENT2': 48,              ### NOT INCLUDED IN EXCEL FILE 2024/10/02
                'SUMMARY_ID': 56,            ### NOT INCLUDED IN EXCEL FILE 2024/10/02
            })

            ###############################################################
            ### EXCELのヘッダ部のセルに、入力データ_ヘッダ部分の値を埋め込む。
            ###############################################################
            print_log('[DEBUG] P0000Common.create_ippan_export_workbook()関数 STEP 3_2/4.', 'DEBUG')
            if (bool(ippan_header_list) == True and bool(ippan_list) == True):
                for row_num, ippan in enumerate(ippan_list, 1):
                    if (bool(str(ippan_header_list[0].upload_file_name)) and bool(ippan_header_list[0].upload_file_name)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["UPLOAD_FILE_NAME"]).value = (ippan_header_list[0].upload_file_name)
                    
                    if (bool(str(ippan_header_list[0].ken_name)) and bool(str(ippan_header_list[0].ken_code)) and 
                        bool(ippan_header_list[0].ken_name) and bool(ippan_header_list[0].ken_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["KEN_CODE"]).value = (str(ippan_header_list[0].ken_name) + ":" + str(ippan_header_list[0].ken_code))
                    
                    if (bool(str(ippan_header_list[0].city_name)) and bool(str(ippan_header_list[0].city_code)) and 
                        bool(ippan_header_list[0].city_name) and bool(ippan_header_list[0].city_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["CITY_CODE"]).value = (str(ippan_header_list[0].city_name) + ":" + str(ippan_header_list[0].city_code))

                    if (bool(str(ippan_header_list[0].begin_month)) and bool(ippan_header_list[0].begin_month)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BEGIN_MONTH"]).value = (str(ippan_header_list[0].begin_month))

                    if (bool(str(ippan_header_list[0].begin_day)) and bool(ippan_header_list[0].begin_day)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BEGIN_DAY"]).value = (str(ippan_header_list[0].begin_day))

                    if (bool(str(ippan_header_list[0].end_month)) and bool(ippan_header_list[0].end_month)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["END_MONTH"]).value = (str(ippan_header_list[0].end_month))

                    if (bool(str(ippan_header_list[0].end_day)) and bool(ippan_header_list[0].end_day)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["END_DAY"]).value = (str(ippan_header_list[0].end_day))

                    if (bool(str(ippan_header_list[0].cause_1_name)) and bool(str(ippan_header_list[0].cause_1_code)) and 
                        bool(ippan_header_list[0].cause_1_name) and bool(ippan_header_list[0].cause_1_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["CAUSE_1_CODE"]).value = (str(ippan_header_list[0].cause_1_name) + ":" + str(ippan_header_list[0].cause_1_code))

                    if (bool(str(ippan_header_list[0].cause_2_name)) and bool(str(ippan_header_list[0].cause_2_code)) and 
                        bool(ippan_header_list[0].cause_2_name) and bool(ippan_header_list[0].cause_2_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["CAUSE_2_CODE"]).value = (str(ippan_header_list[0].cause_2_name) + ":" + str(ippan_header_list[0].cause_2_code))

                    if (bool(str(ippan_header_list[0].cause_3_name)) and bool(str(ippan_header_list[0].cause_3_code)) and 
                        bool(ippan_header_list[0].cause_3_name) and bool(ippan_header_list[0].cause_3_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["CAUSE_3_CODE"]).value = (str(ippan_header_list[0].cause_3_name) + ":" + str(ippan_header_list[0].cause_3_code))

                    ### if (bool(str(ippan_header_list[0].kuiki_name)) and bool(str(ippan_header_list[0].kuiki_id)) and ### 2024/11/08 comment out
                    ###     bool(ippan_header_list[0].kuiki_name) and bool(ippan_header_list[0].kuiki_id)):
                    ###     ws_ippan[0].cell(row=row_num, column=COLUMN["KUIKI_ID"]).value = (str(ippan_header_list[0].kuiki_name) + ":" + str(ippan_header_list[0].kuiki_id))
                    if (bool(str(ippan_header_list[0].kuiki_id)) and bool(ippan_header_list[0].kuiki_id)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["KUIKI_ID"]).value = (str(ippan_header_list[0].kuiki_id))

                    if (bool(str(ippan_header_list[0].suikei_name)) and bool(str(ippan_header_list[0].suikei_code)) and 
                        bool(ippan_header_list[0].suikei_name) and bool(ippan_header_list[0].suikei_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["SUIKEI_CODE"]).value = (str(ippan_header_list[0].suikei_name) + ":" + str(ippan_header_list[0].suikei_code))

                    if (bool(str(ippan_header_list[0].suikei_type_name)) and bool(str(ippan_header_list[0].suikei_type_code)) and 
                        bool(ippan_header_list[0].suikei_type_name) and bool(ippan_header_list[0].suikei_type_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["SUIKEI_TYPE_CODE"]).value = (str(ippan_header_list[0].suikei_type_name) + ":" + str(ippan_header_list[0].suikei_type_code))

                    if (bool(str(ippan_header_list[0].kasen_name)) and bool(str(ippan_header_list[0].kasen_code)) and 
                        bool(ippan_header_list[0].kasen_name) and bool(ippan_header_list[0].kasen_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["KASEN_CODE"]).value = (str(ippan_header_list[0].kasen_name) + ":" + str(ippan_header_list[0].kasen_code))

                    if (bool(str(ippan_header_list[0].kasen_type_name)) and bool(str(ippan_header_list[0].kasen_type_code)) and 
                        bool(ippan_header_list[0].kasen_type_name) and bool(ippan_header_list[0].kasen_type_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["KASEN_TYPE_CODE"]).value = (str(ippan_header_list[0].kasen_type_name) + ":" + str(ippan_header_list[0].kasen_type_code))

                    if (bool(str(ippan_header_list[0].gradient_name)) and bool(str(ippan_header_list[0].gradient_code)) and 
                        bool(ippan_header_list[0].gradient_name) and bool(ippan_header_list[0].gradient_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["GRADIENT_CODE"]).value = (str(ippan_header_list[0].gradient_name) + ":" + str(ippan_header_list[0].gradient_code))

                    if (bool(str(ippan_header_list[0].residential_area)) and bool(ippan_header_list[0].residential_area)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["RESIDENTIAL_AREA"]).value = (ippan_header_list[0].residential_area)

                    if (bool(str(ippan_header_list[0].agricultural_area)) and bool(ippan_header_list[0].agricultural_area)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["AGRICULTURAL_AREA"]).value = (ippan_header_list[0].agricultural_area)

                    if (bool(str(ippan_header_list[0].underground_area)) and bool(ippan_header_list[0].underground_area)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["UNDERGROUND_AREA"]).value = (ippan_header_list[0].underground_area)

                    if (bool(str(ippan_header_list[0].kasen_kaigan_name)) and bool(str(ippan_header_list[0].kasen_kaigan_code)) and 
                        bool(ippan_header_list[0].kasen_kaigan_name) and bool(ippan_header_list[0].kasen_kaigan_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["KASEN_KAIGAN_CODE"]).value = (str(ippan_header_list[0].kasen_kaigan_name) + ":" + str(ippan_header_list[0].kasen_kaigan_code))

                    if (bool(str(ippan_header_list[0].crop_damage)) and bool(ippan_header_list[0].crop_damage)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["CROP_DAMAGE"]).value = (ippan_header_list[0].crop_damage)

                    if (bool(str(ippan_header_list[0].weather_name)) and bool(str(ippan_header_list[0].weather_id)) and 
                        bool(ippan_header_list[0].weather_name) and bool(ippan_header_list[0].weather_id)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["WEATHER_ID"]).value = (str(ippan_header_list[0].weather_name) + ":" + str(ippan_header_list[0].weather_id))

                    if (bool(str(ippan_header_list[0].upload_file_path)) and bool(ippan_header_list[0].upload_file_path)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["UPLOAD_FILE_PATH"]).value = (ippan_header_list[0].upload_file_path)

                    if (bool(str(ippan_header_list[0].committed_at)) and bool(ippan_header_list[0].committed_at)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["COMMITTED_AT"]).value = (ippan_header_list[0].committed_at)

                    ### if (bool(str(ippan_header_list[0].department_name)) and bool(ippan_header_list[0].department_name)):
                    ###     ws_ippan[0].cell(row=row_num, column=COLUMN["DEPARTMENT_NAME"]).value = (ippan_header_list[0].department_name) ### TODO TO-DO TO_DO

                    ### if (bool(str(ippan_header_list[0].person_name)) and bool(ippan_header_list[0].person_name)):
                    ###     ws_ippan[0].cell(row=row_num, column=COLUMN["PERSON_NAME"]).value = (ippan_header_list[0].person_name)         ### TODO TO-DO TO_DO

                    ### if (bool(str(ippan_header_list[0].telephone)) and bool(ippan_header_list[0].telephone)):
                    ###     ws_ippan[0].cell(row=row_num, column=COLUMN["TELEPHONE"]).value = (ippan_header_list[0].telephone)             ### TODO TO-DO TO_DO

                    ### if (bool(str(ippan_header_list[0].mail)) and bool(ippan_header_list[0].mail)):
                    ###     ws_ippan[0].cell(row=row_num, column=COLUMN["MAIL"]).value = (ippan_header_list[0].mail)                       ### TODO TO-DO TO_DO

                    if (bool(str(ippan.ippan_name)) and bool(ippan.ippan_name)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["IPPAN_NAME"]).value = (str(ippan.ippan_name))
                    
                    if (bool(str(ippan.building_name)) and bool(str(ippan.building_code)) and 
                        bool(ippan.building_name) and bool(ippan.building_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BUILDING_CODE"]).value = (str(ippan.building_name) + ":" + str(ippan.building_code))

                    if (bool(str(ippan.underground_name)) and bool(str(ippan.underground_code)) and 
                        bool(ippan.underground_name) and bool(ippan.underground_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["UNDERGROUND_CODE"]).value = (str(ippan.underground_name) + ":" + str(ippan.underground_code))

                    if (bool(str(ippan.flood_sediment_name)) and bool(str(ippan.flood_sediment_code)) and 
                        bool(ippan.flood_sediment_name) and bool(ippan.flood_sediment_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FLOOD_SEDIMENT_CODE"]).value = (str(ippan.flood_sediment_name) + ":" + str(ippan.flood_sediment_code))

                    if (bool(str(ippan.building_lv00)) and bool(ippan.building_lv00)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BUILDING_LV00"]).value = (ippan.building_lv00)

                    if (bool(str(ippan.building_lv01_49)) and bool(ippan.building_lv01_49)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BUILDING_LV01_49"]).value = (ippan.building_lv01_49)

                    if (bool(str(ippan.building_lv50_99)) and bool(ippan.building_lv50_99)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BUILDING_LV50_99"]).value = (ippan.building_lv50_99)

                    if (bool(str(ippan.building_lv100)) and bool(ippan.building_lv100)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BUILDING_LV100"]).value = (ippan.building_lv100)

                    if (bool(str(ippan.building_half)) and bool(ippan.building_half)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BUILDING_HALF"]).value = (ippan.building_half)

                    if (bool(str(ippan.building_full)) and bool(ippan.building_full)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["BUILDING_FULL"]).value = (ippan.building_full)

                    if (bool(str(ippan.floor_area)) and bool(ippan.floor_area)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FLOOR_AREA"]).value = (ippan.floor_area)

                    if (bool(str(ippan.family)) and bool(ippan.family)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FAMILY"]).value = (ippan.family)

                    if (bool(str(ippan.office)) and bool(ippan.office)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["OFFICE"]).value = (ippan.office)

                    if (bool(str(ippan.farmer_fisher_lv00)) and bool(ippan.farmer_fisher_lv00)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV00"]).value = (ippan.farmer_fisher_lv00)

                    if (bool(str(ippan.farmer_fisher_lv01_49)) and bool(ippan.farmer_fisher_lv01_49)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV01_49"]).value = (ippan.farmer_fisher_lv01_49)

                    if (bool(str(ippan.farmer_fisher_lv50_99)) and bool(ippan.farmer_fisher_lv50_99)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV50_99"]).value = (ippan.farmer_fisher_lv50_99)

                    if (bool(str(ippan.farmer_fisher_lv100)) and bool(ippan.farmer_fisher_lv100)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FARMER_FISHER_LV100"]).value = (ippan.farmer_fisher_lv100)

                    if (bool(str(ippan.farmer_fisher_full)) and bool(ippan.farmer_fisher_full)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["FARMER_FISHER_FULL"]).value = (ippan.farmer_fisher_full)

                    if (bool(str(ippan.employee_lv00)) and bool(ippan.employee_lv00)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["EMPLOYEE_LV00"]).value = (ippan.employee_lv00)

                    if (bool(str(ippan.employee_lv01_49)) and bool(ippan.employee_lv01_49)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["EMPLOYEE_LV01_49"]).value = (ippan.employee_lv01_49)

                    if (bool(str(ippan.employee_lv50_99)) and bool(ippan.employee_lv50_99)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["EMPLOYEE_LV50_99"]).value = (ippan.employee_lv50_99)

                    if (bool(str(ippan.employee_lv100)) and bool(ippan.employee_lv100)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["EMPLOYEE_LV100"]).value = (ippan.employee_lv100)

                    if (bool(str(ippan.employee_full)) and bool(ippan.employee_full)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["EMPLOYEE_FULL"]).value = (ippan.employee_full)

                    if (bool(str(ippan.industry_name)) and bool(str(ippan.industry_code)) and 
                        bool(ippan.industry_name) and bool(ippan.industry_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["INDUSTRY_CODE"]).value = (str(ippan.industry_name) + ":" + str(ippan.industry_code))

                    if (bool(str(ippan.usage_name)) and bool(str(ippan.usage_code)) and 
                        bool(ippan.usage_name) and bool(ippan.usage_code)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["USAGE_CODE"]).value = (str(ippan.usage_name) + ":" + str(ippan.usage_code))

                    if (bool(str(ippan.comment)) and bool(ippan.comment)):
                        ws_ippan[0].cell(row=row_num, column=COLUMN["COMMENT"]).value = (ippan.comment)

                    ### if (bool(str(ippan.comment2)) and bool(ippan.comment2)):
                    ###     ws_ippan[0].cell(row=row_num, column=COLUMN["COMMENT2"]).value = (ippan.comment2)

                    ### if (bool(str(ippan.ippan_id)) and bool(ippan.ippan_id)):
                    ###     ws_ippan[0].cell(row=row_num, column=COLUMN["IPPAN_ID"]).value = (ippan.ippan_id)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_export_workbook()関数 STEP 4/4.', 'DEBUG')
            print_log('[INFO] P0000Common.create_ippan_export_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ### TODO TO-DO TO_DO 複数シート未対応版？複数シート対応版にすること。2024/09/26
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_ippan_export_csv()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 STEP 1/7.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0020)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 STEP 2/7.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 STEP 3/7.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/ippan_export_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'ippan_export_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/ippan_export_'+ str(hash_code) + '.csv'
        csv_file_name = 'ippan_export_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 STEP 4/7.', 'DEBUG')
        template_file_path = 'static/template/template_ippan_export.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0050)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 STEP 5/7.', 'DEBUG')
        bool_return, workbook_return = create_ippan_export_workbook(arguments["IPPAN_HEADER_ID"])
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 STEP 6/7.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0070)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_export_csv()関数 STEP 7/7.', 'DEBUG')
        return True, csv_file_path
    
    except:
        print_log('[ERROR] P0000Common.get_ippan_export_csv()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_export_csv()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_export_csv()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設地方単独事業調査票ファイル生成処理
### arguments["CHITAN_HEADER_ID"]
### arguments["FILE_TYPE"]
### ※公共土木施設地方単独事業調査票エクセルのシート数は１である。
###############################################################################
def get_chitan_chosa_csv_excel(request, arguments):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、単数EXCELシート対応版
    ###########################################################################
    def create_chitan_chosa_workbook():
        try:
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_chitan_chosa_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 1/10.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 2/10.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            
            ### 公共土木施設地方単独事業調査票 ユーザ入力用シート ※１シート固定
            ws_chitan = workbook["CHITAN"]
            
            ### 公共土木施設地方単独事業調査票 プログラム制御用シート？？？
            ### ws_chitan_header = workbook["CHITAN_HEADER"]                   ### DELETE 2024/10/15
            ws_header = workbook["HEADER"]                                     ### ADD 2024/10/15
            
            ### 公共土木施設地方単独事業調査票 プルダウン用シート
            ws_ken = workbook["KEN"]
            ws_city = workbook["CITY"]
            ws_kasen_setubi = workbook["KASEN_SETUBI"]
            ws_suikei = workbook["SUIKEI"]
            ws_suikei_type = workbook["SUIKEI_TYPE"]
            ws_kasen = workbook["KASEN"]
            ws_kasen_type = workbook["KASEN_TYPE"]
            ws_weather = workbook["WEATHER"]

            ### 公共土木施設地方単独事業調査票 プルダウン用シート
            ws_city_vlook = workbook["CITY_VLOOK"]
            ws_kasen_vlook = workbook["KASEN_VLOOK"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 3/10.', 'DEBUG')
            ### 公共土木施設地方単独事業調査票 ユーザ入力用シート ※１シート固定
            ws_chitan.sheet_view.showGridLines = False

            ### 公共土木施設地方単独事業調査票 プログラム制御用シート？？？
            ### ws_chitan_header.sheet_view.showGridLines = False              ### DELETE 2024/10/15
            ws_header.sheet_view.showGridLines = False                         ### ADD 2024/10/15
            
            ### 公共土木施設地方単独事業調査票 プルダウン用シート
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_setubi.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            
            ### 公共土木施設地方単独事業調査票 プルダウン用シート
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 4/10.', 'DEBUG')
            ### 1010: 都道府県シート
            print("create_chitan_chosa_workbook_4_1", flush=True)
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            ### 1020: 市区町村シート
            print("create_chitan_chosa_workbook_4_2", flush=True)
            cities_list = []
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    PARAMS_SELECT_CITY = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    SQL_SELECT_CITY = """
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            KEN_CODE=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(CITY_CODE AS INTEGER)"""
                    cities_list.append(CITY.objects.raw(SQL_SELECT_CITY, PARAMS_SELECT_CITY))
    
            print("create_chitan_chosa_workbook_4_3", flush=True)
            if bool(cities_list) == True:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area
    
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            print("create_chitan_chosa_workbook_4_4", flush=True)
            if bool(kasen_setubi_list) == True:
                for i, kasen_setubi in enumerate(kasen_setubi_list):
                    ws_kasen_setubi.cell(row=i+1, column=1).value = kasen_setubi.kasen_setubi_code
                    ws_kasen_setubi.cell(row=i+1, column=2).value = str(kasen_setubi.kasen_setubi_name) + ":" + str(kasen_setubi.kasen_setubi_code)
    
            ### 1040: 水系（水系・沿岸）
            print("create_chitan_chosa_workbook_4_5", flush=True)
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code
    
            ### 1050: 水系種別（水系・沿岸種別）
            print("create_chitan_chosa_workbook_4_6", flush=True)
            if bool(suikei_type_list) == True:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)
    
            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("create_chitan_chosa_workbook_4_7", flush=True)
            kasens_list = []
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    PARAMS_SELECT_KASEN = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    SQL_SELECT_KASEN = """
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            SUIKEI_CODE=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(KASEN_CODE AS INTEGER)"""
                    kasens_list.append(KASEN.objects.raw(SQL_SELECT_KASEN, PARAMS_SELECT_KASEN))
    
            print("create_chitan_chosa_workbook_4_8", flush=True)
            if bool(kasens_list) == True:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code
    
            ### 1070: 河川種別（河川・海岸種別）
            print("create_chitan_chosa_workbook_4_9", flush=True)
            if bool(kasen_type_list) == True:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)
    
            ### 7010: 入力データ_異常気象
            print("create_chitan_chosa_workbook_4_10", flush=True)
            if bool(weather_list) == True:
                for i, weather in enumerate(weather_list):
                    ws_weather.cell(row=i+1, column=1).value = weather.weather_id
                    ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 5/10.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("create_chitan_chosa_workbook_5_1", flush=True)
            if bool(ken_list) == True and bool(cities_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("create_chitan_chosa_workbook_5_2", flush=True)
            if bool(suikei_list) == True and bool(kasens_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 6/10.', 'DEBUG')
            ### ws_chitan.cell(row=6, column=1).value = 'NO.'
            ### ws_chitan.cell(row=6, column=2).value = '水系・沿岸名[全角]'
            ### ws_chitan.cell(row=6, column=3).value = '水系種別[全角]'
            ### ws_chitan.cell(row=6, column=4).value = '河川・海岸名[全角]'
            ### ws_chitan.cell(row=6, column=5).value = '河川種別[全角]'
            ### ws_chitan.cell(row=6, column=6).value = '代表被災地区名[全角]'
            ### ws_chitan.cell(row=6, column=7).value = '都道府県名[全角]'
            ### ws_chitan.cell(row=6, column=8).value = '市区町村名[全角]'
            ### ws_chitan.cell(row=6, column=9).value = '都道府県コード'
            ### ws_chitan.cell(row=6, column=10).value = ''
            ### ws_chitan.cell(row=6, column=11).value = '異常気象コード'
            ### ws_chitan.cell(row=6, column=12).value = '水害発生'
            ### ws_chitan.cell(row=6, column=13).value = ''
            ### ws_chitan.cell(row=6, column=14).value = ''
            ### ws_chitan.cell(row=6, column=15).value = ''
            ### ws_chitan.cell(row=6, column=16).value = '工種区分'
            ### ws_chitan.cell(row=6, column=17).value = ''
            ### ws_chitan.cell(row=6, column=18).value = '市区町村コード'
            ### ws_chitan.cell(row=6, column=19).value = '災害復旧'
            ### ws_chitan.cell(row=6, column=20).value = ''
            ### ws_chitan.cell(row=6, column=21).value = '備考'
            ### ws_chitan.cell(row=7, column=1).value = ''
            ### ws_chitan.cell(row=7, column=2).value = ''
            ### ws_chitan.cell(row=7, column=3).value = ''
            ### ws_chitan.cell(row=7, column=4).value = ''
            ### ws_chitan.cell(row=7, column=5).value = ''
            ### ws_chitan.cell(row=7, column=6).value = ''
            ### ws_chitan.cell(row=7, column=7).value = ''
            ### ws_chitan.cell(row=7, column=8).value = ''
            ### ws_chitan.cell(row=7, column=9).value = ''
            ### ws_chitan.cell(row=7, column=10).value = ''
            ### ws_chitan.cell(row=7, column=11).value = ''
            ### ws_chitan.cell(row=7, column=12).value = '月'
            ### ws_chitan.cell(row=7, column=13).value = '日'
            ### ws_chitan.cell(row=7, column=14).value = '月'
            ### ws_chitan.cell(row=7, column=15).value = '日'
            ### ws_chitan.cell(row=7, column=16).value = ''
            ### ws_chitan.cell(row=7, column=17).value = ''
            ### ws_chitan.cell(row=7, column=18).value = ''
            ### ws_chitan.cell(row=7, column=19).value = '箇所'
            ### ws_chitan.cell(row=7, column=20).value = '査定額(千円)'
            ### ws_chitan.cell(row=7, column=21).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ### 入力データ用のEXCELシートのプルダウンリストをセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 7/10.', 'DEBUG')
            ### 1040: 水系（水系・沿岸）
            if len(suikei_list) > 0:
                dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
                dv_suikei.ranges = 'B8:B6007'
                ws_chitan.add_data_validation(dv_suikei)

            ### 1050: 水系種別（水系・沿岸種別）
            if len(suikei_type_list) > 0:
                dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
                dv_suikei_type.ranges = 'C8:C6007'
                ws_chitan.add_data_validation(dv_suikei_type)

            ### 1060: 河川（河川・海岸）
            ### dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA8)")
            ### dv_kasen.ranges = 'D8:D8'
            ### ws_chitan.add_data_validation(dv_kasen)
            ### ws_chitan.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_chitan.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA"+str(i)+")")
                dv_kasen.ranges = 'D'+str(i)+':D'+str(i)
                ws_chitan.add_data_validation(dv_kasen)
                ### ws_chitan.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_chitan.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS

            ### 1070: 河川種別（河川・海岸種別）
            if len(kasen_type_list) > 0:
                dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
                dv_kasen_type.ranges = 'E8:E6007'
                ws_chitan.add_data_validation(dv_kasen_type)

            ### 1010: 都道府県
            if len(ken_list) > 0:
                dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
                dv_ken.ranges = 'G8:G6007'
                ws_chitan.add_data_validation(dv_ken)

            ### 1010: 都道府県コード
            for i in range(8, 6008):
                ws_chitan.cell(row=i, column=9).value = "=RIGHT(G"+str(i)+",2)"

            ### 1020: 市区町村
            ### dv_city = DataValidation(type="list", formula1="=INDIRECT(AB8)")
            ### dv_city.ranges = 'H8:H8'
            ### ws_chitan.add_data_validation(dv_city)
            ### ws_chitan.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_chitan.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_city = DataValidation(type="list", formula1="=INDIRECT(AB"+str(i)+")")
                dv_city.ranges = 'H'+str(i)+':H'+str(i)
                ws_chitan.add_data_validation(dv_city)
                ### ws_chitan.cell(row=i, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_chitan.cell(row=i, column=28).value = "=VLOOKUP(G"+str(i)+",CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS

            ### 1020: 市区町村コード
            for i in range(8, 6008):
                ws_chitan.cell(row=i, column=18).value = "=RIGHT(H"+str(i)+",6)"

            ### 7010: 入力データ_異常気象
            if len(weather_list) > 0:
                dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
                dv_weather.ranges = 'K8:K6007'
                ws_chitan.add_data_validation(dv_weather)

            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            if len(kasen_setubi_list) > 0:
                dv_kasen_setubi = DataValidation(type="list", formula1="KASEN_SETUBI!$B$1:$B$%d" % len(kasen_setubi_list))
                dv_kasen_setubi.ranges = 'P8:P6007'
                ws_chitan.add_data_validation(dv_kasen_setubi)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0080)
            ### EXCELのセルに、値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 8/10.', 'DEBUG')
            SQL_SELECT_CHITAN = """
                SELECT 
                    CHI1.CHITAN_ID,
                    CHI1.CHITAN_NAME,
                    CHI1.CHITAN_HEADER_ID, 
                    CHI1.CHITAN_HEADER_NAME, 
                    CHI1.KEN_CODE, 
                    KEN1.KEN_NAME, 
                    CHI1.CITY_CODE, 
                    CIT1.CITY_NAME, 
                    TO_CHAR(TIMEZONE('JST', CHI1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH, 
                    TO_CHAR(TIMEZONE('JST', CHI1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY, 
                    TO_CHAR(TIMEZONE('JST', CHI1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH, 
                    TO_CHAR(TIMEZONE('JST', CHI1.END_DATE::TIMESTAMPTZ), 'DD') AS END_DAY, 
                    CHI1.SUIKEI_CODE, 
                    SUI1.SUIKEI_NAME, 
                    SUI1.SUIKEI_TYPE_CODE, 
                    SUT1.SUIKEI_TYPE_NAME, 
                    CHI1.KASEN_CODE, 
                    KAS1.KASEN_NAME, 
                    KAS1.KASEN_TYPE_CODE, 
                    KAT1.KASEN_TYPE_NAME, 
                    CHI1.WEATHER_ID, 
                    WEA1.WEATHER_NAME, 
                    CHI1.KASEN_SETUBI_CODE,
                    KAB1.KASEN_SETUBI_NAME,  
                    CHI1.DISASTER_POINT,
                    CAST(CHI1.ESTIMATED_COST AS NUMERIC(20,10)) AS ESTIMATED_COST, 
                    CHI1.COMMENT AS COMMENT 
                FROM CHITAN_VIEW CHI1 
                LEFT JOIN KEN KEN1 ON CHI1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON CHI1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN SUIKEI SUI1 ON CHI1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                LEFT JOIN SUIKEI_TYPE SUT1 ON SUI1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                LEFT JOIN KASEN KAS1 ON CHI1.KASEN_CODE=KAS1.KASEN_CODE 
                LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                LEFT JOIN WEATHER WEA1 ON CHI1.WEATHER_ID=WEA1.WEATHER_ID 
                LEFT JOIN KASEN_SETUBI KAB1 ON CHI1.KASEN_SETUBI_CODE=KAB1.KASEN_SETUBI_CODE 
                WHERE 
                    CHI1.CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s 
                ORDER BY 
                    CAST(CHI1.CHITAN_ID AS INTEGER)"""

            PARAMS_SELECT_CHITAN = dict({
                'CHITAN_HEADER_ID': chitan_header_list[0].chitan_header_id
            })
                    
            COLUMN = dict({
                'CHITAN_ID': 1,
                'SUIKEI_CODE': 2,
                'SUIKEI_TYPE_CODE': 3,
                'KASEN_CODE': 4,
                'KASEN_TYPE_CODE': 5,
                'CHITAN_NAME': 6,
                'KEN_CODE': 7,
                'CITY_CODE': 8,
                'KEN_CODE2': 9,
                'WEATHER_ID': 11,
                'BEGIN_MONTH': 12,
                'BEGIN_DAY': 13,
                'END_MONTH': 14,
                'END_DAY': 15,
                'KASEN_SETUBI_CODE': 16,
                'CITY_CODE2': 18,
                'DISASTER_POINT': 19,
                'ESTIMATED_COST': 20,
                'COMMENT': 21,
            })

            detail_chitan_list = CHITAN.objects.raw(SQL_SELECT_CHITAN, PARAMS_SELECT_CHITAN)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0090)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 9/10.', 'DEBUG')
            green_fill = PatternFill(fgColor='CCFFCC', patternType='solid')
            
            ### if bool(chitan_list) == True:                                            ### DELETE 2024/10/15
            ###     for row_num, chitan in enumerate(chitan_list, 8):                    ### DELETE 2024/10/15
            if bool(detail_chitan_list) == True:                                         ### ADD 2024/10/15
                for row_num, detail_chitan in enumerate(detail_chitan_list, 8):          ### ADD 2024/10/15 ### SECOND ARGUMENT MEANS STARTS AT 8
                    
                    if (bool(str(detail_chitan.chitan_id)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["CHITAN_ID"]).value = (str(detail_chitan.chitan_id))
                        ws_chitan.cell(row=row_num, column=COLUMN["CHITAN_ID"]).fill = green_fill
                    
                    if (bool(str(detail_chitan.suikei_name)) == True and bool(str(detail_chitan.suikei_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["SUIKEI_CODE"]).value = (str(detail_chitan.suikei_name) + ":" + str(detail_chitan.suikei_code))

                    if (bool(str(detail_chitan.suikei_type_name)) == True and bool(str(detail_chitan.suikei_type_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["SUIKEI_TYPE_CODE"]).value = (str(detail_chitan.suikei_type_name) + ":" + str(detail_chitan.suikei_type_code))
                    
                    if (bool(str(detail_chitan.kasen_name)) == True and bool(str(detail_chitan.kasen_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["KASEN_CODE"]).value = (str(detail_chitan.kasen_name) + ":" + str(detail_chitan.kasen_code))
                        
                    if (bool(str(detail_chitan.kasen_type_name)) == True and bool(str(detail_chitan.kasen_type_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["KASEN_TYPE_CODE"]).value = (str(detail_chitan.kasen_type_name) + ":" + str(detail_chitan.kasen_type_code))
                    
                    if (bool(str(detail_chitan.chitan_name)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["CHITAN_NAME"]).value = (str(detail_chitan.chitan_name))
                        
                    if (bool(str(detail_chitan.ken_name)) == True and bool(str(detail_chitan.ken_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["KEN_CODE"]).value = (str(detail_chitan.ken_name) + ":" + str(detail_chitan.ken_code))
                    
                    if (bool(str(detail_chitan.city_name)) == True and bool(str(detail_chitan.city_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["CITY_CODE"]).value = (str(detail_chitan.city_name) + ":" + str(detail_chitan.city_code))
                    
                    if (bool(str(detail_chitan.ken_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["KEN_CODE2"]).value = (str(detail_chitan.ken_code))

                    ws_chitan.cell(row=row_num, column=10).value = ""
                    
                    if (bool(str(detail_chitan.weather_name)) == True and bool(str(detail_chitan.weather_id)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["WEATHER_ID"]).value = (str(detail_chitan.weather_name) + ":" + str(detail_chitan.weather_id))
                        
                    if (bool(str(detail_chitan.begin_month)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["BEGIN_MONTH"]).value = (str(detail_chitan.begin_month))

                    if (bool(str(detail_chitan.begin_day)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["BEGIN_DAY"]).value = (str(detail_chitan.begin_day))
                    
                    if (bool(str(detail_chitan.end_month)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["END_MONTH"]).value = (str(detail_chitan.end_month))
                    
                    if (bool(str(detail_chitan.end_day)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["END_DAY"]).value = (str(detail_chitan.end_day))
                        
                    if (bool(str(detail_chitan.kasen_setubi_name)) == True and bool(str(chitan.detail_chitan)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["KASEN_SETUBI_CODE"]).value = (str(detail_chitan.kasen_setubi_name) + ":" + str(detail_chitan.kasen_setubi_code))

                    ws_chitan.cell(row=row_num, column=17).value = ""
                        
                    if (bool(str(detail_chitan.city_code)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["CITY_CODE2"]).value = (str(detail_chitan.city_code))
                        
                    if (bool(str(detail_chitan.disaster_point)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["DISASTER_POINT"]).value = (str(detail_chitan.disaster_point))
                        
                    if (bool(str(detail_chitan.estimated_cost)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["ESTIMATED_COST"]).value = (str(detail_chitan.estimated_cost))
                    
                    if (bool(str(detail_chitan.comment)) == True):
                        ws_chitan.cell(row=row_num, column=COLUMN["COMMENT"]).value = (str(detail_chitan.comment))

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0100)
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 10/10.', 'DEBUG')
            print_log('[INFO] P0000Common.create_chitan_chosa_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_chitan_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        ### ※単数EXCELファイル、単数EXCELシートのため、get_ippan_chosa_excelのような処理は不要である。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        PARAMS_SELECT_CHITAN_HEADER = dict({
            'CHITAN_HEADER_ID': arguments["CHITAN_HEADER_ID"]
        })
        SQL_SELECT_CHITAN_HEADER = """
            SELECT 
                * 
            FROM CHITAN_HEADER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s LIMIT 1"""
                
        chitan_header_list = CHITAN_HEADER.objects.raw(SQL_SELECT_CHITAN_HEADER, PARAMS_SELECT_CHITAN_HEADER)

        if bool(chitan_header_list) == False:
            print_log('[WARN] P0000Common.get_chitan_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_setubi_list = KASEN_SETUBI.objects.raw("""SELECT * FROM KASEN_SETUBI ORDER BY CAST(KASEN_SETUBI_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/chitan_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'chitan_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/chitan_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'chitan_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0060)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_chitan_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_chitan_chosa_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0080)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0090)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if arguments["FILE_TYPE"] == _CHI_CHO_EXC:
            return True, excel_file_path
        elif arguments["FILE_TYPE"] == _CHI_CHO_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_chitan_chosa_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_chosa_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設補助事業調査票ファイル生成処理
### arguments["HOJO_HEADER_ID"]
### arguments["FILE_TYPE"]
###############################################################################
def get_hojo_chosa_csv_excel(request, arguments):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、単数EXCELシート対応版
    ###########################################################################
    def create_hojo_chosa_workbook():
        try:
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_hojo_chosa_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 1/10.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 2/10.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            
            ### 公共土木施設補助事業調査票 ユーザ入力用シート ※１シート固定
            ws_hojo = workbook["HOJO"]

            ### 公共土木施設補助事業調査票 プログラム制御用シート？？？
            ### ws_hojo_header = workbook["HOJO_HEADER"]                       ### DELETE 2024/10/15
            ws_header = workbook["HEADER"]                                     ### ADD 2024/10/15

            ### 公共土木施設補助事業調査票 プルダウン用シート
            ws_ken = workbook["KEN"]
            ws_city = workbook["CITY"]
            ws_kasen_setubi = workbook["KASEN_SETUBI"]
            ws_suikei = workbook["SUIKEI"]
            ws_suikei_type = workbook["SUIKEI_TYPE"]
            ws_kasen = workbook["KASEN"]
            ws_kasen_type = workbook["KASEN_TYPE"]
            ws_weather = workbook["WEATHER"]

            ### 公共土木施設補助事業調査票 プルダウン用シート
            ws_city_vlook = workbook["CITY_VLOOK"]
            ws_kasen_vlook = workbook["KASEN_VLOOK"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 3/10.', 'DEBUG')
            ### 公共土木施設補助事業調査票 ユーザ入力用シート ※１シート固定
            ws_hojo.sheet_view.showGridLines = False

            ### 公共土木施設補助事業調査票 プログラム制御用シート？？？
            ### ws_hojo_header.sheet_view.showGridLines = False                ### DELETE 2024/10/15
            ws_header.sheet_view.showGridLines = False                         ### ADD 2024/10/15
            
            ### 公共土木施設補助事業調査票 プルダウン用シート
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_setubi.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            
            ### 公共土木施設補助事業調査票 プルダウン用シート
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 4/10.', 'DEBUG')
            ### 1010: 都道府県シート
            print("create_hojo_chosa_workbook_4_1", flush=True)
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            ### 1020: 市区町村シート
            print("create_hojo_chosa_workbook_4_2", flush=True)
            cities_list = []
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    PARAMS_SELECT_CITY = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    SQL_SELECT_CITY = """
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            KEN_CODE=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(CITY_CODE AS INTEGER)"""
                    cities_list.append(CITY.objects.raw(SQL_SELECT_CITY, PARAMS_SELECT_CITY))
    
            print("create_hojo_chosa_workbook_4_3", flush=True)
            if bool(cities_list) == True:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area
    
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            print("create_hojo_chosa_workbook_4_4", flush=True)
            if bool(kasen_setubi_list) == True:
                for i, kasen_setubi in enumerate(kasen_setubi_list):
                    ws_kasen_setubi.cell(row=i+1, column=1).value = kasen_setubi.kasen_setubi_code
                    ws_kasen_setubi.cell(row=i+1, column=2).value = str(kasen_setubi.kasen_setubi_name) + ":" + str(kasen_setubi.kasen_setubi_code)
    
            ### 1040: 水系（水系・沿岸）
            print("create_hojo_chosa_workbook_4_5", flush=True)
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code
    
            ### 1050: 水系種別（水系・沿岸種別）
            print("create_hojo_chosa_workbook_4_6", flush=True)
            if bool(suikei_type_list) == True:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)
    
            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("create_hojo_chosa_workbook_4_7", flush=True)
            kasens_list = []
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    PARAMS_SELECT_KASEN = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    SQL_SELECT_KASEN = """
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            SUIKEI_CODE=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(KASEN_CODE AS INTEGER)"""
                    kasens_list.append(KASEN.objects.raw(SQL_SELECT_KASEN, PARAMS_SELECT_KASEN))
    
            print("create_hojo_chosa_workbook_4_8", flush=True)
            if bool(kasens_list) == True:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code
    
            ### 1070: 河川種別（河川・海岸種別）
            print("create_hojo_chosa_workbook_4_9", flush=True)
            if bool(kasen_type_list) == True:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)
    
            ### 7010: 入力データ_異常気象
            print("create_hojo_chosa_workbook_4_10", flush=True)
            if bool(weather_list) == True:
                for i, weather in enumerate(weather_list):
                    ws_weather.cell(row=i+1, column=1).value = weather.weather_id
                    ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 5/10.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("create_hojo_chosa_workbook_5_1", flush=True)
            if bool(ken_list) == True and bool(cities_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("create_hojo_chosa_workbook_5_2", flush=True)
            if bool(suikei_list) == True and bool(kasens_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 6/10.', 'DEBUG')
            ### ws_hojo.cell(row=6, column=1).value = 'NO.'
            ### ws_hojo.cell(row=6, column=2).value = '水系・沿岸名[全角]'
            ### ws_hojo.cell(row=6, column=3).value = '水系種別[全角]'
            ### ws_hojo.cell(row=6, column=4).value = '河川・海岸名[全角]'
            ### ws_hojo.cell(row=6, column=5).value = '河川種別[全角]'
            ### ws_hojo.cell(row=6, column=6).value = '都道府県名[全角]'
            ### ws_hojo.cell(row=6, column=7).value = '工事番号'
            ### ws_hojo.cell(row=6, column=8).value = ''
            ### ws_hojo.cell(row=6, column=9).value = '工事区分'
            ### ws_hojo.cell(row=6, column=10).value = '市区町村コード'
            ### ws_hojo.cell(row=6, column=11).value = '工種区分'
            ### ws_hojo.cell(row=6, column=12).value = ''
            ### ws_hojo.cell(row=6, column=13).value = '異常気象コード'
            ### ws_hojo.cell(row=6, column=14).value = '水害発生'
            ### ws_hojo.cell(row=6, column=15).value = ''
            ### ws_hojo.cell(row=6, column=16).value = '決定額(千円)'
            ### ws_hojo.cell(row=6, column=17).value = '備考'
            ### ws_hojo.cell(row=7, column=1).value = ''
            ### ws_hojo.cell(row=7, column=2).value = ''
            ### ws_hojo.cell(row=7, column=3).value = ''
            ### ws_hojo.cell(row=7, column=4).value = ''
            ### ws_hojo.cell(row=7, column=5).value = ''
            ### ws_hojo.cell(row=7, column=6).value = ''
            ### ws_hojo.cell(row=7, column=7).value = '工事番号'
            ### ws_hojo.cell(row=7, column=8).value = '枝番'
            ### ws_hojo.cell(row=7, column=9).value = ''
            ### ws_hojo.cell(row=7, column=10).value = ''
            ### ws_hojo.cell(row=7, column=11).value = ''
            ### ws_hojo.cell(row=7, column=12).value = ''
            ### ws_hojo.cell(row=7, column=13).value = ''
            ### ws_hojo.cell(row=7, column=14).value = '月'
            ### ws_hojo.cell(row=7, column=15).value = '日'
            ### ws_hojo.cell(row=7, column=16).value = ''
            ### ws_hojo.cell(row=7, column=17).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ### 入力データ用のEXCELシートのプルダウンリストをセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7/10.', 'DEBUG')
            ### 1040: 水系（水系・沿岸）
            if len(suikei_list) > 0:
                dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
                dv_suikei.ranges = 'B8:B6007'
                ws_hojo.add_data_validation(dv_suikei)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_1/10.', 'DEBUG')
            ### 1050: 水系種別（水系・沿岸種別）
            if len(suikei_type_list) > 0:
                dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
                dv_suikei_type.ranges = 'C8:C6007'
                ws_hojo.add_data_validation(dv_suikei_type)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_2/10.', 'DEBUG')
            ### 1060: 河川（河川・海岸）
            ### dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA8)")
            ### dv_kasen.ranges = 'D8:D8'
            ### ws_hojo.add_data_validation(dv_kasen)
            ### ws_hojo.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_hojo.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA"+str(i)+")")
                dv_kasen.ranges = 'D'+str(i)+':D'+str(i)
                ws_hojo.add_data_validation(dv_kasen)
                ### ws_hojo.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_hojo.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_3/10.', 'DEBUG')
            ### 1070: 河川種別（河川・海岸種別）
            if len(kasen_type_list) > 0:
                dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
                dv_kasen_type.ranges = 'E8:E6007'
                ws_hojo.add_data_validation(dv_kasen_type)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_4/10.', 'DEBUG')
            ### 1010: 都道府県
            if len(ken_list) > 0:
                dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
                dv_ken.ranges = 'G8:G6007'
                ws_hojo.add_data_validation(dv_ken)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_5/10.', 'DEBUG')
            ### 1010: 都道府県コード
            for i in range(8, 6008):
                ws_hojo.cell(row=i, column=9).value = "=RIGHT(G"+str(i)+",2)"

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_6/10.', 'DEBUG')
            ### 1020: 市区町村
            ### dv_city = DataValidation(type="list", formula1="=INDIRECT(AB8)")
            ### dv_city.ranges = 'H8:H8'
            ### ws_hojo.add_data_validation(dv_city)
            ### ws_hojo.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_hojo.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_city = DataValidation(type="list", formula1="=INDIRECT(AB"+str(i)+")")
                dv_city.ranges = 'H'+str(i)+':H'+str(i)
                ws_hojo.add_data_validation(dv_city)
                ### ws_hojo.cell(row=i, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_hojo.cell(row=i, column=28).value = "=VLOOKUP(G"+str(i)+",CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_7/10.', 'DEBUG')
            ### 1020: 市区町村コード
            for i in range(8, 6008):
                ws_hojo.cell(row=i, column=18).value = "=RIGHT(H"+str(i)+",6)"

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_8/10.', 'DEBUG')
            ### 7010: 入力データ_異常気象
            if len(weather_list) > 0:
                dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
                dv_weather.ranges = 'K8:K6007'
                ws_hojo.add_data_validation(dv_weather)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_9/10.', 'DEBUG')
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            if len(kasen_setubi_list) > 0:
                dv_kasen_setubi = DataValidation(type="list", formula1="KASEN_SETUBI!$B$1:$B$%d" % len(kasen_setubi_list))
                dv_kasen_setubi.ranges = 'P8:P6007'
                ws_hojo.add_data_validation(dv_kasen_setubi)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0080)
            ### EXCELのセルに、値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 8/10.', 'DEBUG')
            SQL_SELECT_HOJO = """
                SELECT 
                    HOJ1.HOJO_ID, 
                    HOJ1.HOJO_NAME, 
                    HOJ1.HOJO_HEADER_ID, 
                    HOJ1.HOJO_HEADER_NAME, 
                    HOJ1.KEN_CODE, 
                    KEN1.KEN_NAME, 
                    HOJ1.CITY_CODE, 
                    CIT1.CITY_NAME, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.END_DATE::TIMESTAMPTZ), 'DD') AS END_DAY, 
                    HOJ1.SUIKEI_CODE, 
                    SUI1.SUIKEI_NAME, 
                    SUI1.SUIKEI_TYPE_CODE, 
                    SUT1.SUIKEI_TYPE_NAME, 
                    HOJ1.KASEN_CODE, 
                    KAS1.KASEN_NAME, 
                    KAS1.KASEN_TYPE_CODE, 
                    KAT1.KASEN_TYPE_NAME, 
                    HOJ1.WEATHER_ID, 
                    WEA1.WEATHER_NAME, 
                    HOJ1.KASEN_SETUBI_CODE, 
                    KAB1.KASEN_SETUBI_NAME, 
                    HOJ1.KOJI_CODE, 
                    HOJ1.BRANCH_CODE, 
                    HOJ1.KOJI_TYPE_CODE, 
                    HOJ1.KOSH_TYPE_CODE, 
                    CAST(HOJ1.DETERMINED_COST AS NUMERIC(20,10)) AS DETERMINED_COST, 
                    HOJ1.COMMENT AS COMMENT 
                FROM HOJO_VIEW HOJ1 
                LEFT JOIN KEN KEN1 ON HOJ1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON HOJ1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN SUIKEI SUI1 ON HOJ1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                LEFT JOIN SUIKEI_TYPE SUT1 ON SUI1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                LEFT JOIN KASEN KAS1 ON HOJ1.KASEN_CODE=KAS1.KASEN_CODE 
                LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                LEFT JOIN WEATHER WEA1 ON HOJ1.WEATHER_ID=WEA1.WEATHER_ID 
                LEFT JOIN KASEN_SETUBI KAB1 ON HOJ1.KASEN_SETUBI_CODE=KAB1.KASEN_SETUBI_CODE 
                WHERE 
                    HOJ1.HOJO_HEADER_ID=%(HOJO_HEADER_ID)s 
                ORDER BY 
                    CAST(HOJ1.HOJO_ID AS INTEGER)"""

            PARAMS_SELECT_HOJO = dict({
                'HOJO_HEADER_ID': hojo_header_list[0].hojo_header_id
            })
                    
            COLUMN = dict({
                'HOJO_ID': 1,
                'SUIKEI_CODE': 2,
                'SUIKEI_TYPE_CODE': 3,
                'KASEN_CODE': 4,
                'KASEN_TYPE_CODE': 5,
                'KEN_CODE': 6,
                'KOJI_CODE': 7,
                'BRANCH_CODE': 8,
                'KOJI_TYPE_CODE': 9,
                'CITY_CODE': 10,
                'KOSH_TYPE_CODE': 11,
                'WEATHER_ID': 13,
                'BEGIN_MONTH': 14,
                'BEGIN_DAY': 15,
                'DETERMINED_COST': 16,
                'COMMENT': 17,
            })

            detail_hojo_list = HOJO.objects.raw(SQL_SELECT_HOJO, PARAMS_SELECT_HOJO)
    
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0090)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9/10.', 'DEBUG')
            green_fill = PatternFill(fgColor='CCFFCC', patternType='solid')
            
            ### if bool(hojo_list) == True:                                              ### DELETE 2024/10/15
            ###     for row_num, hojo in enumerate(hojo_list, 8):                        ### DELETE 2024/10/15
            if bool(detail_hojo_list) == True:                                           ### ADD 2024/10/15
                for row_num, detail_hojo in enumerate(detail_hojo_list, 8):              ### ADD 2024/10/15 ### SECOND ARGUMENT MEANS STARTS AT 8
                    
                    if (bool(str(detail_hojo.hojo_id)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["HOJO_ID"]).value = (str(detail_hojo.hojo_id))
                        ws_hojo.cell(row=row_num, column=COLUMN["HOJO_ID"]).fill = green_fill
                    
                    if (bool(str(detail_hojo.suikei_name)) == True and bool(str(detail_hojo.suikei_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["SUIKEI_CODE"]).value = (str(detail_hojo.suikei_name) + ":" + str(detail_hojo.suikei_code))

                    if (bool(str(detail_hojo.suikei_type_name)) == True and bool(str(detail_hojo.suikei_type_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["SUIKEI_TYPE_CODE"]).value = (str(detail_hojo.suikei_type_name) + ":" + str(detail_hojo.suikei_type_code))
                    
                    if (bool(str(detail_hojo.kasen_name)) == True and bool(str(detail_hojo.kasen_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["KASEN_CODE"]).value = (str(detail_hojo.kasen_name) + ":" + str(detail_hojo.kasen_code))
                        
                    if (bool(str(detail_hojo.kasen_type_name)) == True and bool(str(detail_hojo.kasen_type_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["KASEN_TYPE_CODE"]).value = (str(detail_hojo.kasen_type_name) + ":" + str(detail_hojo.kasen_type_code))
                    
                    if (bool(str(detail_hojo.ken_name)) == True and bool(str(detail_hojo.ken_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["KEN_CODE"]).value = (str(detail_hojo.ken_name) + ":" + str(detail_hojo.ken_code))

                    if (bool(str(detail_hojo.koji_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["KOJI_CODE"]).value = (str(detail_hojo.koji_code))

                    if (bool(str(detail_hojo.branch_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["BRANCH_CODE"]).value = (str(detail_hojo.branch_code))

                    if (bool(str(detail_hojo.koji_type_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["KOJI_TYPE_CODE"]).value = (str(detail_hojo.koji_type_code))
                    
                    if (bool(str(detail_hojo.city_name)) == True and bool(str(detail_hojo.city_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["CITY_CODE"]).value = (str(detail_hojo.city_name) + ":" + str(detail_hojo.city_code))

                    if (bool(str(detail_hojo.kosh_type_code)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["KOSH_TYPE_CODE"]).value = (str(detail_hojo.kosh_type_code))
                    
                    if (bool(str(detail_hojo.weather_name)) == True and bool(str(detail_hojo.weather_id)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["WEATHER_ID"]).value = (str(detail_hojo.weather_name) + ":" + str(detail_hojo.weather_id))
                        
                    if (bool(str(detail_hojo.begin_month)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["BEGIN_MONTH"]).value = (str(detail_hojo.begin_month))

                    if (bool(str(detail_hojo.begin_day)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["BEGIN_DAY"]).value = (str(detail_hojo.begin_day))
                        
                    if (bool(str(detail_hojo.determined_cost)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["DETERMINED_COST"]).value = (str(detail_hojo.determined_cost))
                    
                    if (bool(str(detail_hojo.comment)) == True):
                        ws_hojo.cell(row=row_num, column=COLUMN["COMMENT"]).value = (str(detail_hojo.comment))

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0100)
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 10/10.', 'DEBUG')
            print_log('[INFO] P0000Common.create_hojo_chosa_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False

    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_hojo_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        ### ※単数EXCELファイル、単数EXCELシートのため、get_ippan_chosa_excelのような処理は不要である。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        PARAMS_SELECT_HOJO_HEADER = dict({
            'HOJO_HEADER_ID': arguments["HOJO_HEADER_ID"]
        })
        SQL_SELECT_HOJO_HEADER = """
            SELECT 
                * 
            FROM HOJO_HEADER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s LIMIT 1"""
                
        hojo_header_list = HOJO_HEADER.objects.raw(SQL_SELECT_HOJO_HEADER, PARAMS_SELECT_HOJO_HEADER)

        if bool(hojo_header_list) == False:
            print_log('[WARN] P0000Common.get_hojo_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_setubi_list = KASEN_SETUBI.objects.raw("""SELECT * FROM KASEN_SETUBI ORDER BY CAST(KASEN_SETUBI_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/hojo_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'hojo_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/hojo_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'hojo_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0060)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_hojo_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_hojo_chosa_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0080)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0090)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if arguments["FILE_TYPE"] == _HOJ_CHO_EXC:
            return True, excel_file_path
        elif arguments["FILE_TYPE"] == _HOJ_CHO_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_hojo_chosa_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_chosa_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公益事業調査票ファイル生成処理
### arguments["KOEKI_HEADER_ID"]
### arguments["FILE_TYPE"]
###############################################################################
def get_koeki_chosa_csv_excel(request, arguments):
    
    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、単数EXCELシート対応版
    ###########################################################################
    def create_koeki_chosa_workbook():
        try:
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_koeki_chosa_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 1/10.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 2/10.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            
            ### 公益事業調査票 ユーザ入力用シート ※１シート固定
            ws_koeki = workbook["KOEKI"]
            
            ### 公益事業調査票 プログラム制御用シート？？？
            ### ws_koeki_header = workbook["KOEKI_HEADER"]                     ### DELETE 2024/10/15
            ws_header = workbook["HEADER"]                                     ### ADD 2024/10/15
            
            ### 公益事業調査票 プルダウン用シート
            ws_ken = workbook["KEN"]
            ws_city = workbook["CITY"]
            ws_kasen_setubi = workbook["KASEN_SETUBI"]
            ws_suikei = workbook["SUIKEI"]
            ws_suikei_type = workbook["SUIKEI_TYPE"]
            ws_kasen = workbook["KASEN"]
            ws_kasen_type = workbook["KASEN_TYPE"]
            ws_weather = workbook["WEATHER"]
            ws_business = workbook["BUSINESS"]

            ### 公益事業調査票 プルダウン用シート
            ws_city_vlook = workbook["CITY_VLOOK"]
            ws_kasen_vlook = workbook["KASEN_VLOOK"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 3/10.', 'DEBUG')
            ### 公益事業調査票 ユーザ入力用シート ※１シート固定
            ws_koeki.sheet_view.showGridLines = False
            
            ### 公益事業調査票 プログラム制御用シート？？？
            ### ws_koeki_header.sheet_view.showGridLines = False               ### DELETE 2024/10/15
            ws_header.sheet_view.showGridLines = False                         ### ADD 2024/10/15
            
            ### 公益事業調査票 プルダウン用シート
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_setubi.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            ws_business.sheet_view.showGridLines = False
            
            ### 公益事業調査票 プルダウン用シート
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 4/10.', 'DEBUG')
            ### 1010: 都道府県シート
            print("create_koeki_chosa_workbook_4_1", flush=True)
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            ### 1020: 市区町村シート
            print("create_koeki_chosa_workbook_4_2", flush=True)
            cities_list = []
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    PARAMS_SELECT_CITY = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    SQL_SELECT_CITY = """
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            KEN_CODE=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(CITY_CODE AS INTEGER)"""
                    cities_list.append(CITY.objects.raw(SQL_SELECT_CITY, PARAMS_SELECT_CITY))
    
            print("create_koeki_chosa_workbook_4_3", flush=True)
            if bool(cities_list) == True:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area
    
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            print("create_koeki_chosa_workbook_4_4", flush=True)
            if bool(kasen_setubi_list) == True:
                for i, kasen_setubi in enumerate(kasen_setubi_list):
                    ws_kasen_setubi.cell(row=i+1, column=1).value = kasen_setubi.kasen_setubi_code
                    ws_kasen_setubi.cell(row=i+1, column=2).value = str(kasen_setubi.kasen_setubi_name) + ":" + str(kasen_setubi.kasen_setubi_code)
    
            ### 1040: 水系（水系・沿岸）
            print("create_koeki_chosa_workbook_4_5", flush=True)
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code
    
            ### 1050: 水系種別（水系・沿岸種別）
            print("create_koeki_chosa_workbook_4_6", flush=True)
            if bool(suikei_type_list) == True:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)
    
            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("create_koeki_chosa_workbook_4_7", flush=True)
            kasens_list = []
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    PARAMS_SELECT_KASEN = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    SQL_SELECT_KASEN = """
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            SUIKEI_CODE=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(KASEN_CODE AS INTEGER)"""
                    kasens_list.append(KASEN.objects.raw(SQL_SELECT_KASEN, PARAMS_SELECT_KASEN))
    
            print("create_koeki_chosa_workbook_4_8", flush=True)
            if bool(kasens_list) == True:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code
    
            ### 1070: 河川種別（河川・海岸種別）
            print("create_koeki_chosa_workbook_4_9", flush=True)
            if bool(kasen_type_list) == True:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)


            ### 1080: 水害原因
            print("create_koeki_chosa_workbook_4_10", flush=True)
            ### if bool(cause_list) == True:
            ###     for i, cause in enumerate(cause_list):
            ###         ws_cause.cell(row=i+1, column=1).value = cause.cause_code
            ###         ws_cause.cell(row=i+1, column=2).value = str(cause.cause_name) + ":" + str(cause.cause_code)
    
            ### 7010: 入力データ_異常気象
            print("create_koeki_chosa_workbook_4_11", flush=True)
            ### if bool(weather_list) == True:
            ###     for i, weather in enumerate(weather_list):
            ###         ws_weather.cell(row=i+1, column=1).value = weather.weather_id
            ###         ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

            ### 1140: 公益事業分類
            print("create_koeki_chosa_workbook_4_12", flush=True)
            ### if bool(business_list) == True:
            ###     for i, business in enumerate(business_list):
            ###         ws_business.cell(row=i+1, column=1).value = business.business_code
            ###         ws_business.cell(row=i+1, column=2).value = str(business.business_name) + ":" + str(business.business_code)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 5/10.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("create_koeki_chosa_workbook_5_1", flush=True)
            if bool(ken_list) == True and bool(cities_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("create_koeki_chosa_workbook_5_2", flush=True)
            if bool(suikei_list) == True and bool(kasens_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 6/10.', 'DEBUG')
            ### ws_koeki.cell(row=6, column=1).value = 'NO.'
            ### ws_koeki.cell(row=6, column=2).value = '水害発生年月日'
            ### ws_koeki.cell(row=6, column=3).value = ''
            ### ws_koeki.cell(row=6, column=4).value = ''
            ### ws_koeki.cell(row=6, column=5).value = ''
            ### ws_koeki.cell(row=6, column=6).value = '被害箇所'
            ### ws_koeki.cell(row=6, column=7).value = ''
            ### ws_koeki.cell(row=6, column=8).value = ''
            ### ws_koeki.cell(row=6, column=9).value = ''
            ### ws_koeki.cell(row=6, column=10).value = ''
            ### ws_koeki.cell(row=6, column=11).value = '河川・海岸名・地区名'
            ### ws_koeki.cell(row=6, column=12).value = ''
            ### ws_koeki.cell(row=6, column=13).value = ''
            ### ws_koeki.cell(row=6, column=14).value = ''
            ### ws_koeki.cell(row=6, column=15).value = '工種区分'
            ### ws_koeki.cell(row=6, column=16).value = '水害原因コード'
            ### ws_koeki.cell(row=6, column=17).value = ''
            ### ws_koeki.cell(row=6, column=18).value = ''
            ### ws_koeki.cell(row=6, column=19).value = '異常気象コード'
            ### ws_koeki.cell(row=6, column=20).value = '事業コード'
            ### ws_koeki.cell(row=6, column=21).value = '調査対象機関名称[全角]'
            ### ws_koeki.cell(row=6, column=22).value = '被害金額'
            ### ws_koeki.cell(row=6, column=23).value = ''
            ### ws_koeki.cell(row=6, column=24).value = ''
            ### ws_koeki.cell(row=6, column=25).value = ''
            ### ws_koeki.cell(row=6, column=26).value = ''
            ### ws_koeki.cell(row=6, column=27).value = '営業停止期間等'
            ### ws_koeki.cell(row=6, column=28).value = ''
            ### ws_koeki.cell(row=6, column=29).value = ''
            ### ws_koeki.cell(row=6, column=30).value = '照会先'
            ### ws_koeki.cell(row=6, column=31).value = ''
            ### ws_koeki.cell(row=6, column=32).value = ''
            ### ws_koeki.cell(row=6, column=33).value = '備考'
            ### ws_koeki.cell(row=7, column=1).value = ''
            ### ws_koeki.cell(row=7, column=2).value = ''
            ### ws_koeki.cell(row=7, column=3).value = ''
            ### ws_koeki.cell(row=7, column=4).value = ''
            ### ws_koeki.cell(row=7, column=5).value = ''
            ### ws_koeki.cell(row=7, column=6).value = '都道府県[全角]'
            ### ws_koeki.cell(row=7, column=7).value = '都道府県コード'
            ### ws_koeki.cell(row=7, column=8).value = '市区町村名[全角]'
            ### ws_koeki.cell(row=7, column=9).value = '市区町村コード'
            ### ws_koeki.cell(row=7, column=10).value = '町丁名・大字名[全角]'
            ### ws_koeki.cell(row=7, column=11).value = '水系・沿岸名[全角]'
            ### ws_koeki.cell(row=7, column=12).value = '水系種別[全角]'
            ### ws_koeki.cell(row=7, column=13).value = '河川・海岸名[全角]'
            ### ws_koeki.cell(row=7, column=14).value = '河川種別[全角]'
            ### ws_koeki.cell(row=7, column=15).value = ''
            ### ws_koeki.cell(row=7, column=16).value = ''
            ### ws_koeki.cell(row=7, column=17).value = ''
            ### ws_koekivv.cell(row=7, column=18).value = ''
            ### ws_koeki.cell(row=7, column=19).value = ''
            ### ws_koeki.cell(row=7, column=20).value = ''
            ### ws_koeki.cell(row=7, column=21).value = ''
            ### ws_koeki.cell(row=7, column=22).value = '物的被害額(千円)'
            ### ws_koeki.cell(row=7, column=23).value = '営業停止損失額(千円)'
            ### ws_koeki.cell(row=7, column=24).value = ''
            ### ws_koeki.cell(row=7, column=25).value = ''
            ### ws_koeki.cell(row=7, column=26).value = '営業停止損失額合計(千円)'
            ### ws_koeki.cell(row=7, column=27).value = '停止期間'
            ### ws_koeki.cell(row=7, column=28).value = ''
            ### ws_koeki.cell(row=7, column=29).value = '停止数量'
            ### ws_koeki.cell(row=7, column=30).value = '調査担当課名[全角]'
            ### ws_koeki.cell(row=7, column=31).value = '調査担当者名[全角]'
            ### ws_koeki.cell(row=7, column=32).value = '電話番号'
            ### ws_koeki.cell(row=7, column=33).value = '備考'
            ### ws_koeki.cell(row=8, column=1).value = ''
            ### ws_koeki.cell(row=8, column=2).value = '月'
            ### ws_koeki.cell(row=8, column=3).value = '日'
            ### ws_koeki.cell(row=8, column=4).value = '月'
            ### ws_koeki.cell(row=8, column=5).value = '日'
            ### ws_koeki.cell(row=8, column=6).value = ''
            ### ws_koeki.cell(row=8, column=7).value = ''
            ### ws_koeki.cell(row=8, column=8).value = ''
            ### ws_koeki.cell(row=8, column=9).value = ''
            ### ws_koeki.cell(row=8, column=10).value = ''
            ### ws_koeki.cell(row=8, column=11).value = ''
            ### ws_koeki.cell(row=8, column=12).value = ''
            ### ws_koeki.cell(row=8, column=13).value = ''
            ### ws_koeki.cell(row=8, column=14).value = ''
            ### ws_koeki.cell(row=8, column=15).value = ''
            ### ws_koeki.cell(row=8, column=16).value = '1'
            ### ws_koeki.cell(row=8, column=17).value = '2'
            ### ws_koeki.cell(row=8, column=18).value = '3'
            ### ws_koeki.cell(row=8, column=19).value = ''
            ### ws_koeki.cell(row=8, column=20).value = ''
            ### ws_koeki.cell(row=8, column=21).value = ''
            ### ws_koeki.cell(row=8, column=22).value = ''
            ### ws_koeki.cell(row=8, column=23).value = '営業停止に伴う売上減少額'
            ### ws_koeki.cell(row=8, column=24).value = '代替活動費（外注費）'
            ### ws_koeki.cell(row=8, column=25).value = 'その他'
            ### ws_koeki.cell(row=8, column=26).value = ''
            ### ws_koeki.cell(row=8, column=27).value = '日'
            ### ws_koeki.cell(row=8, column=28).value = '時間'
            ### ws_koeki.cell(row=8, column=29).value = ''
            ### ws_koeki.cell(row=8, column=30).value = ''
            ### ws_koeki.cell(row=8, column=31).value = ''
            ### ws_koeki.cell(row=8, column=32).value = ''
            ### ws_koeki.cell(row=8, column=33).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ### 入力データ用のEXCELシートのプルダウンリストをセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7/10.', 'DEBUG')
            ### 1040: 水系（水系・沿岸）
            ### if len(suikei_list) > 0:
            ###     dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
            ###     dv_suikei.ranges = 'B8:B6007'
            ###     ws_koeki.add_data_validation(dv_suikei)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_1/10.', 'DEBUG')
            ### 1050: 水系種別（水系・沿岸種別）
            ### if len(suikei_type_list) > 0:
            ###     dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
            ###     dv_suikei_type.ranges = 'C8:C6007'
            ###     ws_koeki.add_data_validation(dv_suikei_type)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_2/10.', 'DEBUG')
            ### 1060: 河川（河川・海岸）
            ### ### dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA8)")
            ### ### dv_kasen.ranges = 'D8:D8'
            ### ### ws_koeki.add_data_validation(dv_kasen)
            ### ### ws_koeki.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ### ws_koeki.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS
            ### for i in range(8, 6008):
            ###     dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA"+str(i)+")")
            ###     dv_kasen.ranges = 'D'+str(i)+':D'+str(i)
            ###     ws_koeki.add_data_validation(dv_kasen)
            ###     ### ws_koeki.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ###     ws_koeki.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_3/10.', 'DEBUG')
            ### 1070: 河川種別（河川・海岸種別）
            ### if len(kasen_type_list) > 0:
            ###     dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
            ###     dv_kasen_type.ranges = 'E8:E6007'
            ###     ws_koeki.add_data_validation(dv_kasen_type)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_4/10.', 'DEBUG')
            ### 1010: 都道府県
            ### if len(ken_list) > 0:
            ###     dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
            ###     dv_ken.ranges = 'G8:G6007'
            ###     ws_koeki.add_data_validation(dv_ken)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_5/10.', 'DEBUG')
            ### 1010: 都道府県コード
            ### for i in range(8, 6008):
            ###     ws_koeki.cell(row=i, column=9).value = "=RIGHT(G"+str(i)+",2)"

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_6/10.', 'DEBUG')
            ### 1020: 市区町村
            ### ### dv_city = DataValidation(type="list", formula1="=INDIRECT(AB8)")
            ### ### dv_city.ranges = 'H8:H8'
            ### ### ws_koeki.add_data_validation(dv_city)
            ### ### ws_koeki.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ### ws_koeki.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS
            ### for i in range(8, 6008):
            ###     dv_city = DataValidation(type="list", formula1="=INDIRECT(AB"+str(i)+")")
            ###     dv_city.ranges = 'H'+str(i)+':H'+str(i)
            ###     ws_koeki.add_data_validation(dv_city)
            ###     ### ws_koeki.cell(row=i, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ###     ws_koeki.cell(row=i, column=28).value = "=VLOOKUP(G"+str(i)+",CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_7/10.', 'DEBUG')
            ### 1020: 市区町村コード
            ### for i in range(8, 6008):
            ###     ws_koeki.cell(row=i, column=18).value = "=RIGHT(H"+str(i)+",6)"

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_8/10.', 'DEBUG')
            ### 7010: 入力データ_異常気象
            ### if len(weather_list) > 0:
            ###     dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
            ###     dv_weather.ranges = 'K8:K6007'
            ###     ws_koeki.add_data_validation(dv_weather)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_9/10.', 'DEBUG')
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            ### if len(kasen_setubi_list) > 0:
            ###     dv_kasen_setubi = DataValidation(type="list", formula1="KASEN_SETUBI!$B$1:$B$%d" % len(kasen_setubi_list))
            ###     dv_kasen_setubi.ranges = 'P8:P6007'
            ###     ws_koeki.add_data_validation(dv_kasen_setubi)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0080)
            ### EXCELのセルに、値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 8/10.', 'DEBUG')
            SQL_SELECT_KOEKI = """
                SELECT 
                    KOE1.KOEKI_ID,
                    KOE1.KOEKI_NAME,
                    KOE1.KOEKI_HEADER_ID, 
                    KOE1.KOEKI_HEADER_NAME, 
                    KOE1.KEN_CODE, 
                    KEN1.KEN_NAME, 
                    KOE1.CITY_CODE, 
                    CIT1.CITY_NAME, 
                    KOE1.SUIKEI_CODE, 
                    SUI1.SUIKEI_NAME, 
                    SUI1.SUIKEI_TYPE_CODE, 
                    SUT1.SUIKEI_TYPE_NAME, 
                    KOE1.KASEN_CODE, 
                    KAS1.KASEN_NAME, 
                    KAS1.KASEN_TYPE_CODE, 
                    KAT1.KASEN_TYPE_NAME, 
                    TO_CHAR(TIMEZONE('JST', KOE1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH, 
                    TO_CHAR(TIMEZONE('JST', KOE1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY, 
                    TO_CHAR(TIMEZONE('JST', KOE1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH, 
                    TO_CHAR(TIMEZONE('JST', KOE1.END_DATE::TIMESTAMPTZ), 'DD') AS END_DAY, 
                    KOE1.KASEN_SETUBI_CODE, 
                    KAB1.KASEN_SETUBI_NAME, 
                    KOE1.WEATHER_ID, 
                    WEA1.WEATHER_NAME, 
                    KOE1.CAUSE_1_CODE, 
                    CAU1.CAUSE_NAME AS CAUSE_1_NAME, 
                    KOE1.CAUSE_2_CODE, 
                    CAU2.CAUSE_NAME AS CAUSE_2_NAME, 
                    KOE1.CAUSE_3_CODE, 
                    CAU3.CAUSE_NAME AS CAUSE_3_NAME, 
                    KOE1.BUSINESS_CODE, 
                    BUS1.BUSINESS_NAME, 
                    KOE1.ORGANIZATION_NAME, 
                    CAST(KOE1.PHYSICAL_DAMAGE AS NUMERIC(20,10)) AS PHYSICAL_DAMAGE, 
                    CAST(KOE1.SALES_DAMAGE AS NUMERIC(20,10)) AS SALES_DAMAGE,
                    CAST(KOE1.ALT_DAMAGE AS NUMERIC(20,10)) AS ALT_DAMAGE, 
                    CAST(KOE1.OTHER_DAMAGE AS NUMERIC(20,10)) AS OTHER_DAMAGE, 
                    CAST(KOE1.SALES_ALT_OTHER_DAMAGE AS NUMERIC(20,10)) AS SALES_ALT_OTHER_DAMAGE, 
                    CAST(KOE1.SUSPENDED_DAYS AS NUMERIC(20,10)) AS SUSPENDED_DAYS, 
                    CAST(KOE1.SUSPENDED_HOURS AS NUMERIC(20,10)) AS SUSPENDED_HOURS, 
                    CAST(KOE1.SUSPENDED_AMOUNTS AS NUMERIC(20,10)) AS SUSPENDED_AMOUNTS, 
                    KOE1.DEPARTMENT_NAME, 
                    KOE1.EMPLOYEE_NAME, 
                    KOE1.TELEPHONE, 
                    KOE1.COMMENT 
                FROM KOEKI_VIEW KOE1 
                LEFT JOIN KEN KEN1 ON KOE1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON KOE1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN SUIKEI SUI1 ON KOE1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                LEFT JOIN KASEN KAS1 ON KOE1.KASEN_CODE=KAS1.KASEN_CODE 
                LEFT JOIN KASEN_SETUBI KAB1 ON KOE1.KASEN_SETUBI_CODE=KAB1.KASEN_SETUBI_CODE 
                LEFT JOIN WEATHER WEA1 ON KOE1.WEATHER_ID=WEA1.WEATHER_ID 
                LEFT JOIN CAUSE CAU1 ON KOE1.CAUSE_1_CODE=CAU1.CAUSE_CODE 
                LEFT JOIN CAUSE CAU2 ON KOE1.CAUSE_2_CODE=CAU2.CAUSE_CODE 
                LEFT JOIN CAUSE CAU3 ON KOE1.CAUSE_3_CODE=CAU3.CAUSE_CODE 
                LEFT JOIN SUIKEI_TYPE SUT1 ON SUT1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                LEFT JOIN BUSINESS BUS1 ON KOE1.BUSINESS_CODE=BUS1.BUSINESS_CODE 
                WHERE 
                    KOE1.KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s 
                ORDER BY 
                    CAST(KOE1.KOEKI_ID AS INTEGER)"""

            PARAMS_SELECT_KOEKI = dict({
                'KOEKI_HEADER_ID': koeki_header_list[0].koeki_header_id
            })
                    
            COLUMN = dict({
                'KOEKI_ID': 1,
                'BEGIN_MONTH': 2,
                'BEGIN_DAY': 3,
                'END_MONTH': 4,
                'END_DAY': 5,
                'KEN_CODE': 6,
                'KEN_CODE2': 7,
                'CITY_CODE': 8,
                'CITY_CODE2': 9,
                'KOEKI_NAME': 10,
                'SUIKEI_CODE': 11,
                'SUIKEI_TYPE_CODE': 12,
                'KASEN_CODE': 13,
                'KASEN_TYPE_CODE': 14,
                'KASEN_SETUBI_CODE': 15,
                'CAUSE_1_CODE': 16,
                'CAUSE_2_CODE': 17,
                'CAUSE_3_CODE': 18,
                'WEATHER_ID': 19,
                'BUSINESS_CODE': 20,
                'ORGANIZATION_NAME': 21,
                'PHYSICAL_DAMAGE': 22,
                'SALES_DAMAGE': 23,
                'ALT_DAMAGE': 24,
                'OTHER_DAMAGE': 25,
                'SALES_ALT_OTHER_DAMAGE': 26,
                'SUSPENDED_DAYS': 27,
                'SUSPENDED_HOURS': 28,
                'SUSPENDED_AMOUNTS': 29,
                'DEPARTMENT_NAME': 30,
                'EMPLOYEE_NAME': 31,
                'TELEPHONE': 32,
                'COMMENT': 33,
            })

            detail_koeki_list = KOEKI.objects.raw(SQL_SELECT_KOEKI, PARAMS_SELECT_KOEKI)
    
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0090)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9/10.', 'DEBUG')
            green_fill = PatternFill(fgColor='CCFFCC', patternType='solid')

            ### if bool(koeki_list) == True:                                             ### DELETE 2024/10/15
            ###     for row_num, koeki in enumerate(koeki_list, 9):                      ### DELETE 2024/10/15
            if bool(detail_koeki_list) == True:                                          ### ADD 2024/10/15
                for row_num, detail_koeki in enumerate(detail_koeki_list, 9):            ### ADD 2024/10/15 ### SECOND ARGUMENT MEANS STARTS AT 9
                    
                    if (bool(str(detail_koeki.koeki_id)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["KOEKI_ID"]).value = (str(detail_koeki.koeki_id))
                        ws_koeki.cell(row=row_num, column=COLUMN["KOEKI_ID"]).fill = green_fill

                    if (bool(str(detail_koeki.begin_month)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["BEGIN_MONTH"]).value = (str(detail_koeki.begin_month))

                    if (bool(str(detail_koeki.begin_day)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["BEGIN_DAY"]).value = (str(detail_koeki.begin_day))
                    
                    if (bool(str(detail_koeki.end_month)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["END_MONTH"]).value = (str(detail_koeki.end_month))
                        
                    if (bool(str(detail_koeki.end_day)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["END_DAY"]).value = (str(detail_koeki.end_day))

                    if (bool(str(detail_koeki.ken_name)) == True and bool(str(detail_koeki.ken_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["KEN_CODE"]).value = (str(detail_koeki.ken_name) + ":" + str(detail_koeki.ken_code))
                    
                    if (bool(str(detail_koeki.ken_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["KEN_CODE2"]).value = (str(detail_koeki.ken_code))

                    if (bool(str(detail_koeki.city_name)) == True and bool(str(detail_koeki.city_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["CITY_CODE"]).value = (str(detail_koeki.city_name) + ":" + str(detail_koeki.city_code))

                    if (bool(str(detail_koeki.city_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["CITY_CODE2"]).value = (str(detail_koeki.city_code))
                    
                    if (bool(str(detail_koeki.koeki_name)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["KOEKI_NAME"]).value = (str(detail_koeki.koeki_name))
                   
                    if (bool(str(detail_koeki.suikei_name)) == True and bool(str(detail_koeki.suikei_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["SUIKEI_CODE"]).value = (str(detail_koeki.suikei_name) + ":" + str(detail_koeki.suikei_code))

                    if (bool(str(detail_koeki.suikei_type_name)) == True and bool(str(detail_koeki.suikei_type_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["SUIKEI_TYPE_CODE"]).value = (str(detail_koeki.suikei_type_name) + ":" + str(detail_koeki.suikei_type_code))
                    
                    if (bool(str(detail_koeki.kasen_name)) == True and bool(str(detail_koeki.kasen_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["KASEN_CODE"]).value = (str(detail_koeki.kasen_name) + ":" + str(detail_koeki.kasen_code))
                        
                    if (bool(str(detail_koeki.kasen_type_name)) == True and bool(str(detail_koeki.kasen_type_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["KASEN_TYPE_CODE"]).value = (str(detail_koeki.kasen_type_name) + ":" + str(detail_koeki.kasen_type_code))
                    
                    if (bool(str(detail_koeki.kasen_setubi_name)) == True and bool(str(detail_koeki.kasen_setubi_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["KASEN_SETUBI_CODE"]).value = (str(detail_koeki.kasen_setubi_name) + ":" + str(detail_koeki.kasen_setubi_code))
                        
                    if (bool(str(detail_koeki.cause_1_name)) == True and bool(str(detail_koeki.cause_1_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["CAUSE_1_CODE"]).value = (str(detail_koeki.cause_1_name) + ":" + str(detail_koeki.cause_1_code))

                    if (bool(str(detail_koeki.cause_2_name)) == True and bool(str(detail_koeki.cause_2_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["CAUSE_2_CODE"]).value = (str(detail_koeki.cause_2_name) + ":" + str(detail_koeki.cause_2_code))

                    if (bool(str(detail_koeki.cause_3_name)) == True and bool(str(detail_koeki.cause_3_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["CAUSE_3_CODE"]).value = (str(detail_koeki.cause_3_name) + ":" + str(detail_koeki.cause_3_code))

                    if (bool(str(detail_koeki.weather_name)) == True and bool(str(detail_koeki.weather_id)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["WEATHER_ID"]).value = (str(detail_koeki.weather_name) + ":" + str(detail_koeki.weather_id))

                    if (bool(str(detail_koeki.business_name)) == True and bool(str(detail_koeki.business_code)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["BUSINESS_CODE"]).value = (str(detail_koeki.business_name) + ":" + str(detail_koeki.business_code))

                    if (bool(str(detail_koeki.organization_name)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["ORGANIZATION_NAME"]).value = (str(detail_koeki.organization_name))

                    if (bool(str(detail_koeki.physical_damage)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["PHYSICAL_DAMAGE"]).value = (str(detail_koeki.physical_damage))

                    if (bool(str(detail_koeki.sales_damage)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["SALES_DAMAGE"]).value = (str(detail_koeki.sales_damage))

                    if (bool(str(detail_koeki.alt_damage)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["ALT_DAMAGE"]).value = (str(detail_koeki.alt_damage))

                    if (bool(str(detail_koeki.other_damage)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["OTHER_DAMAGE"]).value = (str(detail_koeki.other_damage))

                    if (bool(str(detail_koeki.sales_alt_other_damage)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["SALES_ALT_OTHER_DAMAGE"]).value = (str(detail_koeki.sales_alt_other_damage))

                    if (bool(str(detail_koeki.suspended_days)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["SUSPENDED_DAYS"]).value = (str(detail_koeki.suspended_days))

                    if (bool(str(detail_koeki.suspended_hours)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["SUSPENDED_HOURS"]).value = (str(detail_koeki.suspended_hours))

                    if (bool(str(detail_koeki.suspended_amounts)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["SUSPENDED_AMOUNTS"]).value = (str(detail_koeki.suspended_amounts))

                    if (bool(str(detail_koeki.department_name)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["DEPARTMENT_NAME"]).value = (str(detail_koeki.department_name))

                    if (bool(str(detail_koeki.employee_name)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["EMPLOYEE_NAME"]).value = (str(detail_koeki.employee_name))

                    if (bool(str(detail_koeki.telephone)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["TELEPHONE"]).value = (str(detail_koeki.telephone))
                    
                    if (bool(str(detail_koeki.comment)) == True):
                        ws_koeki.cell(row=row_num, column=COLUMN["COMMENT"]).value = (str(detail_koeki.comment))

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0100)
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 10/10.', 'DEBUG')
            print_log('[INFO] P0000Common.create_koeki_chosa_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_koeki_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        ### ※単数EXCELファイル、単数EXCELシートのため、get_ippan_chosa_excelのような処理は不要である。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        PARAMS_SELECT_KOEKI_HEADER = dict({
            'KOEKI_HEADER_ID': func_params["KOEKI_HEADER_ID"]
        })
        SQL_SELECT_KOEKI_HEADER = """
            SELECT 
                * 
            FROM KOEKI_HEADER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s LIMIT 1"""
                
        koeki_header_list = KOEKI_HEADER.objects.raw(SQL_SELECT_KOEKI_HEADER, PARAMS_SELECT_KOEKI_HEADER)

        if bool(koeki_header_list) == False:
            print_log('[WARN] P0000Common.get_koeki_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_setubi_list = KASEN_SETUBI.objects.raw("""SELECT * FROM KASEN_SETUBI ORDER BY CAST(KASEN_SETUBI_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/koeki_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'koeki_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/koeki_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'koeki_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0060)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_koeki_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_koeki_chosa_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0080)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0090)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if arguments["FILE_TYPE"] == _KOE_CHO_EXC:
            return True, excel_file_path
        elif arguments["FILE_TYPE"] == _KOE_CHO_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_koeki_chosa_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_chosa_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 一般資産集計結果ファイル生成処理
### arguments["IPPAN_HEADER_ID"]
### arguments["FILE_TYPE"]
###############################################################################
def get_ippan_summary_csv_excel(request, arguments):
    
    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ###########################################################################
    def create_ippan_summary_workbook():
        try:
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_ippan_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 1/7.', 'DEBUG')
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 2/7.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_ippan_summary = workbook["IPPAN_SUMMARY"]
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 3/7.', 'DEBUG')
            ws_ippan_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### EXCELシートのキャプションに値をセットする。
            ### EXCELシートの出力用セルに空の値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 4/7.', 'DEBUG')
            ws_ippan_summary.cell(row=6, column=1).value = 'NO.'
            ws_ippan_summary.cell(row=6, column=2).value = 'ファイル名'
            ws_ippan_summary.cell(row=6, column=3).value = '都道府県\n[全角]'
            ### ws_ippan_summary.cell(row=6, column=4).value = ''
            ws_ippan_summary.cell(row=6, column=5).value = '市区町村名\n[全角]'
            ws_ippan_summary.cell(row=6, column=6).value = '水害発生月日'
            ### ws_ippan_summary.cell(row=6, column=7).value = ''
            ws_ippan_summary.cell(row=6, column=8).value = '水害終了月日'
            ws_ippan_summary.cell(row=6, column=10).value = '水害原因'
            ### ws_ippan_summary.cell(row=6, column=11).value = ''
            ### ws_ippan_summary.cell(row=6, column=12).value = ''
            ws_ippan_summary.cell(row=6, column=13).value = '水害区域番号'
            ws_ippan_summary.cell(row=6, column=14).value = '水系・沿岸名\n[全角]'
            ws_ippan_summary.cell(row=6, column=15).value = '水系種別\n[全角]'
            ws_ippan_summary.cell(row=6, column=16).value = '河川・海岸名\n[全角]'
            ws_ippan_summary.cell(row=6, column=17).value = '河川種別\n[全角]'
            ws_ippan_summary.cell(row=6, column=18).value = '地盤勾配区分'
            ws_ippan_summary.cell(row=6, column=19).value = '町丁名・大字名\n[全角]'
            ws_ippan_summary.cell(row=6, column=20).value = '名称\n[全角]'
            ws_ippan_summary.cell(row=6, column=21).value = '地上地下区分'
            ws_ippan_summary.cell(row=6, column=22).value = '浸水土砂区分'
            ws_ippan_summary.cell(row=6, column=23).value = '被害建物棟数'
            ### ws_ippan_summary.cell(row=6, column=24).value = ''
            ### ws_ippan_summary.cell(row=6, column=25).value = ''
            ### ws_ippan_summary.cell(row=6, column=26).value = ''
            ### ws_ippan_summary.cell(row=6, column=27).value = ''
            ### ws_ippan_summary.cell(row=6, column=28).value = ''
            ws_ippan_summary.cell(row=6, column=29).value = '被害建物の延床面積(m2)'
            ws_ippan_summary.cell(row=6, column=30).value = '被災世帯数'
            ws_ippan_summary.cell(row=6, column=31).value = '被災事業所数'
            ws_ippan_summary.cell(row=6, column=32).value = '農家・漁家戸数'
            ### ws_ippan_summary.cell(row=6, column=33).value = ''
            ### ws_ippan_summary.cell(row=6, column=34).value = ''
            ### ws_ippan_summary.cell(row=6, column=35).value = ''
            ### ws_ippan_summary.cell(row=6, column=36).value = ''
            ws_ippan_summary.cell(row=6, column=37).value = '事業所従業者数'
            ### ws_ippan_summary.cell(row=6, column=38).value = ''
            ### ws_ippan_summary.cell(row=6, column=39).value = ''
            ### ws_ippan_summary.cell(row=6, column=40).value = ''
            ### ws_ippan_summary.cell(row=6, column=41).value = ''
            ws_ippan_summary.cell(row=6, column=42).value = '事業所の産業分類'
            ws_ippan_summary.cell(row=6, column=43).value = '地下空間の利用形態'
            ws_ippan_summary.cell(row=6, column=44).value = '備考1'
            ws_ippan_summary.cell(row=6, column=45).value = '備考2'
            ws_ippan_summary.cell(row=6, column=46).value = '水害区域面積\n(宅地)(m2)'
            ws_ippan_summary.cell(row=6, column=47).value = '水害区域面積\n(農地)(m2)'
            ws_ippan_summary.cell(row=6, column=48).value = '水害区域面積\n(地下)(m2)'
            ws_ippan_summary.cell(row=6, column=49).value = '工種'
            ws_ippan_summary.cell(row=6, column=50).value = '農作物被害額(千円)'
            ws_ippan_summary.cell(row=6, column=51).value = '異常気象コード'
            ws_ippan_summary.cell(row=6, column=52).value = '調査票シート名'
            ### ws_ippan_summary.cell(row=6, column=53).value = ''
            ws_ippan_summary.cell(row=6, column=54).value = 'ファイル最終更新日時'
            ws_ippan_summary.cell(row=6, column=55).value = 'ファイルパス'
            ws_ippan_summary.cell(row=6, column=56).value = '家屋被害額_床下'
            ws_ippan_summary.cell(row=6, column=57).value = '家屋被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=58).value = '家屋被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=59).value = '家屋被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=60).value = '家屋被害額_半壊'
            ws_ippan_summary.cell(row=6, column=61).value = '家屋被害額_全壊'
            ws_ippan_summary.cell(row=6, column=62).value = '家庭用品自動車以外被害額_床下'
            ws_ippan_summary.cell(row=6, column=63).value = '家庭用品自動車以外被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=64).value = '家庭用品自動車以外被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=65).value = '家庭用品自動車以外被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=66).value = '家庭用品自動車以外被害額_半壊'
            ws_ippan_summary.cell(row=6, column=67).value = '家庭用品自動車以外被害額_全壊'
            ws_ippan_summary.cell(row=6, column=68).value = '家庭用品自動車被害額_床下'
            ws_ippan_summary.cell(row=6, column=69).value = '家庭用品自動車被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=70).value = '家庭用品自動車被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=71).value = '家庭用品自動車被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=72).value = '家庭用品自動車被害額_半壊'
            ws_ippan_summary.cell(row=6, column=73).value = '家庭用品自動車被害額_全壊'
            ws_ippan_summary.cell(row=6, column=74).value = '家庭応急対策費_代替活動費_床下'
            ws_ippan_summary.cell(row=6, column=75).value = '家庭応急対策費_代替活動費_01から49cm'
            ws_ippan_summary.cell(row=6, column=76).value = '家庭応急対策費_代替活動費_50から99cm'
            ws_ippan_summary.cell(row=6, column=77).value = '家庭応急対策費_代替活動費_100cm以上'
            ws_ippan_summary.cell(row=6, column=78).value = '家庭応急対策費_代替活動費_半壊'
            ws_ippan_summary.cell(row=6, column=79).value = '家庭応急対策費_代替活動費_全壊'
            ws_ippan_summary.cell(row=6, column=80).value = '家庭応急対策費_清掃費_床下'
            ws_ippan_summary.cell(row=6, column=81).value = '家庭応急対策費_清掃費_01から49cm'
            ws_ippan_summary.cell(row=6, column=82).value = '家庭応急対策費_清掃費_50から99cm'
            ws_ippan_summary.cell(row=6, column=83).value = '家庭応急対策費_清掃費_100cm以上'
            ws_ippan_summary.cell(row=6, column=84).value = '家庭応急対策費_清掃費_半壊'
            ws_ippan_summary.cell(row=6, column=85).value = '家庭応急対策費_清掃費_全壊'
            ws_ippan_summary.cell(row=6, column=86).value = '事業所被害額_償却資産被害額_床下'
            ws_ippan_summary.cell(row=6, column=87).value = '事業所被害額_償却資産被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=88).value = '事業所被害額_償却資産被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=89).value = '事業所被害額_償却資産被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=90).value = '事業所被害額_償却資産被害額_全壊'
            ws_ippan_summary.cell(row=6, column=91).value = '事業所被害額_在庫資産被害額_床下'
            ws_ippan_summary.cell(row=6, column=92).value = '事業所被害額_在庫資産被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=93).value = '事業所被害額_在庫資産被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=94).value = '事業所被害額_在庫資産被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=95).value = '事業所被害額_在庫資産被害額_全壊'
            ws_ippan_summary.cell(row=6, column=96).value = '事業所被害額_営業停止に伴う被害額_床下'
            ws_ippan_summary.cell(row=6, column=97).value = '事業所被害額_営業停止に伴う被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=98).value = '事業所被害額_営業停止に伴う被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=99).value = '事業所被害額_営業停止に伴う被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=100).value = '事業所被害額_営業停止に伴う被害額_全壊'
            ws_ippan_summary.cell(row=6, column=101).value = '事業所被害額_営業停滞に伴う被害額_床下'
            ws_ippan_summary.cell(row=6, column=102).value = '事業所被害額_営業停滞に伴う被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=103).value = '事業所被害額_営業停滞に伴う被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=104).value = '事業所被害額_営業停滞に伴う被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=105).value = '事業所被害額_営業停滞に伴う被害額_全壊'
            ws_ippan_summary.cell(row=6, column=106).value = '農漁家被害額_償却資産被害額_床下'
            ws_ippan_summary.cell(row=6, column=107).value = '農漁家被害額_償却資産被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=108).value = '農漁家被害額_償却資産被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=109).value = '農漁家被害額_償却資産被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=110).value = '農漁家被害額_償却資産被害額_全壊'
            ws_ippan_summary.cell(row=6, column=111).value = '農漁家被害額_在庫資産被害額_床下'
            ws_ippan_summary.cell(row=6, column=112).value = '農漁家被害額_在庫資産被害額_01から49cm'
            ws_ippan_summary.cell(row=6, column=113).value = '農漁家被害額_在庫資産被害額_50から99cm'
            ws_ippan_summary.cell(row=6, column=114).value = '農漁家被害額_在庫資産被害額_100cm以上'
            ws_ippan_summary.cell(row=6, column=115).value = '農漁家被害額_在庫資産被害額_全壊'
            ws_ippan_summary.cell(row=6, column=116).value = '事業所応急対策費_代替活動費_床下'
            ws_ippan_summary.cell(row=6, column=117).value = '事業所応急対策費_代替活動費_01から49cm'
            ws_ippan_summary.cell(row=6, column=118).value = '事業所応急対策費_代替活動費_50から99cm'
            ws_ippan_summary.cell(row=6, column=119).value = '事業所応急対策費_代替活動費_100cm以上'
            ws_ippan_summary.cell(row=6, column=120).value = '事業所応急対策費_代替活動費_半壊'
            ws_ippan_summary.cell(row=6, column=121).value = '事業所応急対策費_代替活動費_全壊'

            ws_ippan_summary.cell(row=7, column=6).value = '月'
            ws_ippan_summary.cell(row=7, column=7).value = '日'
            ws_ippan_summary.cell(row=7, column=8).value = '月'
            ws_ippan_summary.cell(row=7, column=9).value = '日'
            ws_ippan_summary.cell(row=7, column=10).value = '1'
            ws_ippan_summary.cell(row=7, column=11).value = '2'
            ws_ippan_summary.cell(row=7, column=12).value = '3'
            ws_ippan_summary.cell(row=7, column=23).value = '床下'
            ws_ippan_summary.cell(row=7, column=24).value = '1-49cm'
            ws_ippan_summary.cell(row=7, column=25).value = '50-99cm'
            ws_ippan_summary.cell(row=7, column=26).value = '1m以上'
            ws_ippan_summary.cell(row=7, column=27).value = '半壊'
            ws_ippan_summary.cell(row=7, column=28).value = '全壊'
            ws_ippan_summary.cell(row=7, column=32).value = '床下'
            ws_ippan_summary.cell(row=7, column=33).value = '1-49cm'
            ws_ippan_summary.cell(row=7, column=34).value = '50-99cm'
            ws_ippan_summary.cell(row=7, column=35).value = '1m以上'
            ws_ippan_summary.cell(row=7, column=36).value = '全壊'
            ws_ippan_summary.cell(row=7, column=37).value = '床下'
            ws_ippan_summary.cell(row=7, column=38).value = '1-49cm'
            ws_ippan_summary.cell(row=7, column=39).value = '50-99cm'
            ws_ippan_summary.cell(row=7, column=40).value = '1m以上'
            ws_ippan_summary.cell(row=7, column=41).value = '全壊'

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### EXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 5/7.', 'DEBUG')
            
            
            COLUMN = dict({
                'IPPAN_ID': 1,                                                 ### NO
                'UPLOAD_FILE_NAME': 2,                                         ### ファイル名
                
                'KEN_NAME': 4,                                                 ### 都道府県[全角]
                'CITY_NAME': 5,                                                ### 市区町村名[全角]
                'BEGIN_MONTH': 6,                                              ### 水害発生月日 月
                'BEGIN_DAY': 7,                                                ### 水害発生月日 日
                'END_MONTH': 8,                                                ### 水害終了月日 月
                'END_DAY': 9,                                                  ### 水害終了月日 日
                'CAUSE_1_CODE': 10,                                            ### 水害原因 1
                'CAUSE_2_CODE': 11,                                            ### 水害原因 2
                'CAUSE_3_CODE': 12,                                            ### 水害原因 3
                'KUIKI_ID': 13,                                                ### 水害区域番号
                'SUIKEI_NAME': 14,                                             ### 水系・沿岸名[全角]
                'SUIKEI_TYPE_NAME': 15,                                        ### 水系種別[全角]
                'KASEN_NAME': 16,                                              ### 河川・海岸名[全角]
                'KASEN_TYPE_NAME': 17,                                         ### 河川種別[全角]
                'GRADIENT_CODE': 18,                                           ### 地盤勾配区分
                'IPPAN_NAME': 19,                                              ### 町丁名・大字名[全角]
                'BUILDING_CODE': 20,                                           ### 名称[全角]
                'UNDERGROUND_CODE': 21,                                        ### 地上地下区分
                'FLOOD_SEDIMENT_CODE': 22,                                     ### 浸水土砂区分
                
                'BUILDING_LV00': 23,                                           ### 被害建物棟数 床下
                'BUILDING_LV01_49': 24,                                        ### 被害建物棟数 1-49cm
                'BUILDING_LV50_99': 25,                                        ### 被害建物棟数 50-99cm
                'BUILDING_LV100': 26,                                          ### 被害建物棟数 1m以上
                'BUILDING_HALF': 27,                                           ### 被害建物棟数 半壊
                'BUILDING_FULL': 28,                                           ### 被害建物棟数 全壊
                'FLOOR_AREA': 29,                                              ### 被害建物の延床面積(m2)
                'FAMILY': 30,                                                  ### 被災世帯数
                'OFFICE': 31,                                                  ### 被災事業所数
                'FARMER_FISHER_LV00': 32,                                      ### 農家・漁家戸数 床下
                'FARMER_FISHER_LV01_49': 33,                                   ### 農家・漁家戸数 1-49cm
                'FARMER_FISHER_LV50_99': 34,                                   ### 農家・漁家戸数 50-99cm
                'FARMER_FISHER_LV100': 35,                                     ### 農家・漁家戸数 1m以上
                'FARMER_FISHER_FULL': 36,                                      ### 農家・漁家戸数 全壊
                'EMPLOYEE_LV00': 37,                                           ### 事業所従業者数 床下
                'EMPLOYEE_LV01_49': 38,                                        ### 事業所従業者数 1-49cm
                'EMPLOYEE_LV50_99': 39,                                        ### 事業所従業者数 50-99cm
                'EMPLOYEE_LV100': 40,                                          ### 事業所従業者数 1m以上
                'EMPLOYEE_FULL': 41,                                           ### 事業所従業者数 全壊
               
                'INDUSTRY_CODE': 42,                                           ### 事業所の産業分類
                'USAGE_CODE': 43,                                              ### 地下空間の利用形態
                'COMMENT1': 44,                                                ### 備考1
                'COMMENT2': 45,                                                ### 備考2
                'RESIDENTIAL_AREA': 46,                                        ### 水害区域面積(宅地)(m2)
                'AGRICULTURAL_AREA': 47,                                       ### 水害区域面積(農地)(m2)
                'UNDERGROUND_AREA': 48,                                        ### 水害区域面積(地下)(m2)
                'KASEN_KAIGAN_CODE': 49,                                       ### 工種
                'CROP_DAMAGE': 50,                                             ### 農作物被害額(千円)
                'WEATHER_ID': 51,                                              ### 異常気象コード
                'IPPAN_HEADER_NAME': 52,                                       ### 調査票シート名
             
                'COMMITTED_AT': 54,                                            ### ファイル最終更新日時
                'UPLOAD_FILE_PATH': 55,                                        ### ファイルパス
               
                'HOUSE_SUMMARY_LV00': 56,                                      ### 家屋被害額_床下
                'HOUSE_SUMMARY_LV01_49': 57,                                   ### 家屋被害額_01から49cm
                'HOUSE_SUMMARY_LV50_99': 58,                                   ### 家屋被害額_50から99cm
                'HOUSE_SUMMARY_LV100': 59,                                     ### 家屋被害額_100cm以上
                'HOUSE_SUMMARY_HALF': 60,                                      ### 家屋被害額_半壊
                'HOUSE_SUMMARY_FULL': 61,                                      ### 家屋被害額_全壊
                
                'HOUSEHOLD_SUMMARY_LV00': 62,                                  ### 家庭用品自動車以外被害額_床下
                'HOUSEHOLD_SUMMARY_LV01_49': 63,                               ### 家庭用品自動車以外被害額_01から49cm
                'HOUSEHOLD_SUMMARY_LV50_99': 64,                               ### 家庭用品自動車以外被害額_50から99cm
                'HOUSEHOLD_SUMMARY_LV100': 65,                                 ### 家庭用品自動車以外被害額_100cm以上
                'HOUSEHOLD_SUMMARY_HALF': 66,                                  ### 家庭用品自動車以外被害額_半壊
                'HOUSEHOLD_SUMMARY_FULL': 67,                                  ### 家庭用品自動車以外被害額_全壊
                
                'CAR_SUMMARY_LV00': 68,                                        ### 家庭用品自動車被害額_床下
                'CAR_SUMMARY_LV01_49': 69,                                     ### 家庭用品自動車被害額_01から49cm
                'CAR_SUMMARY_LV50_99': 70,                                     ### 家庭用品自動車被害額_50から99cm
                'CAR_SUMMARY_LV100': 71,                                       ### 家庭用品自動車被害額_100cm以上
                'CAR_SUMMARY_HALF': 72,                                        ### 家庭用品自動車被害額_半壊
                'CAR_SUMMARY_FULL': 73,                                        ### 家庭用品自動車被害額_全壊
                
                'HOUSE_ALT_SUMMARY_LV00': 74,                                  ### 家庭応急対策費_代替活動費_床下
                'HOUSE_ALT_SUMMARY_LV01_49': 75,                               ### 家庭応急対策費_代替活動費_01から49cm
                'HOUSE_ALT_SUMMARY_LV50_99': 76,                               ### 家庭応急対策費_代替活動費_50から99cm
                'HOUSE_ALT_SUMMARY_LV100': 77,                                 ### 家庭応急対策費_代替活動費_100cm以上
                'HOUSE_ALT_SUMMARY_HALF': 78,                                  ### 家庭応急対策費_代替活動費_半壊
                'HOUSE_ALT_SUMMARY_FULL': 79,                                  ### 家庭応急対策費_代替活動費_全壊
                
                'HOUSE_CLEAN_SUMMARY_LV00': 80,                                ### 家庭応急対策費_清掃費_床下
                'HOUSE_CLEAN_SUMMARY_LV01_49': 81,                             ### 家庭応急対策費_清掃費_01から49cm
                'HOUSE_CLEAN_SUMMARY_LV50_99': 82,                             ### 家庭応急対策費_清掃費_50から99cm
                'HOUSE_CLEAN_SUMMARY_LV100': 83,                               ### 家庭応急対策費_清掃費_100cm以上
                'HOUSE_CLEAN_SUMMARY_HALF': 84,                                ### 家庭応急対策費_清掃費_半壊
                'HOUSE_CLEAN_SUMMARY_FULL': 85,                                ### 家庭応急対策費_清掃費_全壊
                
                'OFFICE_DEP_SUMMARY_LV00': 86,                                 ### 事業所被害額_償却資産被害額_床下
                'OFFICE_DEP_SUMMARY_LV01_49': 87,                              ### 事業所被害額_償却資産被害額_01から49cm
                'OFFICE_DEP_SUMMARY_LV50_99': 88,                              ### 事業所被害額_償却資産被害額_50から99cm
                'OFFICE_DEP_SUMMARY_LV100': 89,                                ### 事業所被害額_償却資産被害額_100cm以上
                'OFFICE_DEP_SUMMARY_FULL': 90,                                 ### 事業所被害額_償却資産被害額_全壊
                
                'OFFICE_INV_SUMMARY_LV00': 91,                                 ### 事業所被害額_在庫資産被害額_床下
                'OFFICE_INV_SUMMARY_LV01_49': 92,                              ### 事業所被害額_在庫資産被害額_01から49cm
                'OFFICE_INV_SUMMARY_LV50_99': 93,                              ### 事業所被害額_在庫資産被害額_50から99cm
                'OFFICE_INV_SUMMARY_LV100': 94,                                ### 事業所被害額_在庫資産被害額_100cm以上
                'OFFICE_INV_SUMMARY_FULL': 95,                                 ### 事業所被害額_在庫資産被害額_全壊
                
                'OFFICE_SUS_SUMMARY_LV00': 96,                                 ### 事業所被害額_営業停止に伴う被害額_床下
                'OFFICE_SUS_SUMMARY_LV01_49': 97,                              ### 事業所被害額_営業停止に伴う被害額_01から49cm
                'OFFICE_SUS_SUMMARY_LV50_99': 98,                              ### 事業所被害額_営業停止に伴う被害額_50から99cm
                'OFFICE_SUS_SUMMARY_LV100': 99,                                ### 事業所被害額_営業停止に伴う被害額_100cm以上
                'OFFICE_SUS_SUMMARY_FULL': 100,                                ### 事業所被害額_営業停止に伴う被害額_全壊
                
                'OFFICE_STG_SUMMARY_LV00': 101,                                ### 事業所被害額_営業停滞に伴う被害額_床下
                'OFFICE_STG_SUMMARY_LV01_49': 102,                             ### 事業所被害額_営業停滞に伴う被害額_01から49cm
                'OFFICE_STG_SUMMARY_LV50_99': 103,                             ### 事業所被害額_営業停滞に伴う被害額_50から99cm
                'OFFICE_STG_SUMMARY_LV100': 104,                               ### 事業所被害額_営業停滞に伴う被害額_100cm以上
                'OFFICE_STG_SUMMARY_FULL': 105,                                ### 事業所被害額_営業停滞に伴う被害額_全壊
                
                'FARMER_FISHER_DEP_SUMMARY_LV00': 106,                         ### 農漁家被害額_償却資産被害額_床下
                'FARMER_FISHER_DEP_SUMMARY_LV01_49': 107,                      ### 農漁家被害額_償却資産被害額_01から49cm
                'FARMER_FISHER_DEP_SUMMARY_LV50_99': 108,                      ### 農漁家被害額_償却資産被害額_50から99cm
                'FARMER_FISHER_DEP_SUMMARY_LV100': 109,                        ### 農漁家被害額_償却資産被害額_100cm以上
                'FARMER_FISHER_DEP_SUMMARY_FULL': 110,                         ### 農漁家被害額_償却資産被害額_全壊
                
                'FARMER_FISHER_INV_SUMMARY_LV00': 111,                         ### 農漁家被害額_在庫資産被害額_床下
                'FARMER_FISHER_INV_SUMMARY_LV01_49': 112,                      ### 農漁家被害額_在庫資産被害額_01から49cm
                'FARMER_FISHER_INV_SUMMARY_LV50_99': 113,                      ### 農漁家被害額_在庫資産被害額_50から99cm
                'FARMER_FISHER_INV_SUMMARY_LV100': 114,                        ### 農漁家被害額_在庫資産被害額_100cm以上
                'FARMER_FISHER_INV_SUMMARY_FULL': 115,                         ### 農漁家被害額_在庫資産被害額_全壊
                
                'OFFICE_ALT_SUMMARY_LV00': 116,                                ### 事業所応急対策費_代替活動費_床下
                'OFFICE_ALT_SUMMARY_LV01_49': 117,                             ### 事業所応急対策費_代替活動費_01から49cm
                'OFFICE_ALT_SUMMARY_LV50_99': 118,                             ### 事業所応急対策費_代替活動費_50から99cm
                'OFFICE_ALT_SUMMARY_LV100': 119,                               ### 事業所応急対策費_代替活動費_100cm以上
                'OFFICE_ALT_SUMMARY_HALF': 120,                                ### 事業所応急対策費_代替活動費_半壊
                'OFFICE_ALT_SUMMARY_FULL': 121,                                ### 事業所応急対策費_代替活動費_全壊
            })
            
            SQL_SELECT_IPPAN_SUMMARY = """
                SELECT 
                    IPS1.ID, 
                    IPS1.IPPAN_ID,                                             -- 1
                    IPH1.UPLOAD_FILE_NAME AS UPLOAD_FILE_NAME,                 -- 2

                    KEN1.KEN_NAME,                                             -- 4
                    CIT1.CITY_NAME,                                            -- 5
                    TO_CHAR(TIMEZONE('JST', IPH1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH, -- 6
                    TO_CHAR(TIMEZONE('JST', IPH1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY,   -- 7
                    TO_CHAR(TIMEZONE('JST', IPH1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH,     -- 8
                    TO_CHAR(TIMEZONE('JST', IPH1.END_DATE::TIMESTAMPTZ), 'MM') AS END_DAY,       -- 9
                    IPH1.CAUSE_1_CODE AS CAUSE_1_CODE,                         -- 10
                    IPH1.CAUSE_2_CODE AS CAUSE_2_CODE,                         -- 11
                    IPH1.CAUSE_3_CODE AS CAUSE_3_CODE,                         -- 12
                    IPH1.KUIKI_ID AS KUIKI_ID,                                 -- 13
                    SUI1.SUIKEI_NAME AS SUIKEI_NAME,                           -- 14
                    STP1.SUIKEI_TYPE_NAME AS SUIKEI_TYPE_NAME,                 -- 15
                    KAS1.KASEN_NAME AS KASEN_NAME,                             -- 16
                    KTP1.KASEN_TYPE_NAME AS KASEN_TYPE_NAME,                   -- 17
                    IPH1.GRADIENT_CODE AS GRADIENT_CODE,                       -- 18
                    IPP1.IPPAN_NAME,                                           -- 19 
                    -- IPS1.BUILDING_CODE AS BUILDING_CODE,                    -- 20 2024/11/18 COMMENT OUT
                    -- IPS1.UNDERGROUND_CODE AS UNDERGROUND_CODE,              -- 21 2024/11/18 COMMENT OUT
                    -- IPS1.FLOOD_SEDIMENT_CODE AS FLOOD_SEDIMENT_CODE,        -- 22 2024/11/18 COMMENT OUT
                    IPP1.BUILDING_CODE AS BUILDING_CODE,                       -- 20 2024/11/18 ADD
                    IPP1.UNDERGROUND_CODE AS UNDERGROUND_CODE,                 -- 21 2024/11/18 ADD
                    IPP1.FLOOD_SEDIMENT_CODE AS FLOOD_SEDIMENT_CODE,           -- 22 2024/11/18 ADD

                    IPP1.BUILDING_LV00 AS BUILDING_LV00,                       -- 23
                    IPP1.BUILDING_LV01_49 AS BUILDING_LV01_49,                 -- 24
                    IPP1.BUILDING_LV50_99 AS BUILDING_LV50_99,                 -- 25
                    IPP1.BUILDING_LV100 AS BUILDING_LV100,                     -- 26
                    IPP1.BUILDING_HALF AS BUILDING_HALF,                       -- 27
                    IPP1.BUILDING_FULL AS BUILDING_FULL,                       -- 28
                    IPP1.FLOOR_AREA AS FLOOR_AREA,                             -- 29
                    IPP1.FAMILY AS FAMILY,                                     -- 30
                    IPP1.OFFICE AS OFFICE,                                     -- 31
                    IPP1.FARMER_FISHER_LV00 AS FARMER_FISHER_LV00,             -- 32
                    IPP1.FARMER_FISHER_LV01_49 AS FARMER_FISHER_LV01_49,       -- 33
                    IPP1.FARMER_FISHER_LV50_99 AS FARMER_FISHER_LV50_99,       -- 34
                    IPP1.FARMER_FISHER_LV100 AS FARMER_FISHER_LV100,           -- 35
                    IPP1.FARMER_FISHER_FULL AS FARMER_FISHER_FULL,             -- 36
                    IPP1.EMPLOYEE_LV00 AS EMPLOYEE_LV00,                       -- 37
                    IPP1.EMPLOYEE_LV01_49 AS EMPLOYEE_LV01_49,                 -- 38
                    IPP1.EMPLOYEE_LV50_99 AS EMPLOYEE_LV50_99,                 -- 39
                    IPP1.EMPLOYEE_LV100 AS EMPLOYEE_LV100,                     -- 40
                    IPP1.EMPLOYEE_FULL AS EMPLOYEE_FULL,                       -- 41
                    
                    IPP1.INDUSTRY_CODE AS INDUSTRY_CODE,                       -- 42
                    IPP1.USAGE_CODE AS USAGE_CODE,                             -- 43
                    IPP1.COMMENT AS COMMENT1,                                  -- 44
                    IPH1.RESIDENTIAL_AREA AS RESIDENTIAL_AREA,                 -- 46
                    IPH1.AGRICULTURAL_AREA AS AGRICULTURAL_AREA,               -- 47
                    IPH1.UNDERGROUND_AREA AS UNDERGROUND_AREA,                 -- 48
                    IPH1.KASEN_KAIGAN_CODE AS KASEN_KAIGAN_CODE,               -- 49
                    IPH1.CROP_DAMAGE AS CROP_DAMAGE,                           -- 50
                    IPH1.WEATHER_ID AS WEATHER_ID,                             -- 51
                    IPH1.IPPAN_HEADER_NAME AS IPPAN_HEADER_NAME,               -- 52
                    
                    IPH1.COMMITTED_AT AS COMMITTED_AT,                         -- 54
                    IPH1.UPLOAD_FILE_PATH AS UPLOAD_FILE_PATH,                 -- 55
                    
                    CAST(IPS1.HOUSE_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV00,                                  -- 56
                    CAST(IPS1.HOUSE_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV01_49,                            -- 57
                    CAST(IPS1.HOUSE_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV50_99,                            -- 58
                    CAST(IPS1.HOUSE_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV100,                                -- 59
                    CAST(IPS1.HOUSE_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSE_SUMMARY_HALF,                                  -- 60
                    CAST(IPS1.HOUSE_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSE_SUMMARY_FULL,                                  -- 61
                    
                    CAST(IPS1.HOUSEHOLD_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV00,                          -- 62
                    CAST(IPS1.HOUSEHOLD_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV01_49,                    -- 63
                    CAST(IPS1.HOUSEHOLD_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV50_99,                    -- 64
                    CAST(IPS1.HOUSEHOLD_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV100,                        -- 65
                    CAST(IPS1.HOUSEHOLD_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_HALF,                          -- 66
                    CAST(IPS1.HOUSEHOLD_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_FULL,                          -- 67
                    
                    CAST(IPS1.CAR_SUMMARY_LV00 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV00,                                      -- 68
                    CAST(IPS1.CAR_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV01_49,                                -- 69
                    CAST(IPS1.CAR_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV50_99,                                -- 70
                    CAST(IPS1.CAR_SUMMARY_LV100 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV100,                                    -- 71
                    CAST(IPS1.CAR_SUMMARY_HALF AS NUMERIC(20,10)) AS CAR_SUMMARY_HALF,                                      -- 72
                    CAST(IPS1.CAR_SUMMARY_FULL AS NUMERIC(20,10)) AS CAR_SUMMARY_FULL,                                      -- 73
                    
                    CAST(IPS1.HOUSE_ALT_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV00,                          -- 74
                    CAST(IPS1.HOUSE_ALT_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV01_49,                    -- 75
                    CAST(IPS1.HOUSE_ALT_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV50_99,                    -- 76
                    CAST(IPS1.HOUSE_ALT_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV100,                        -- 77
                    CAST(IPS1.HOUSE_ALT_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_HALF,                          -- 78
                    CAST(IPS1.HOUSE_ALT_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_FULL,                          -- 79
                    
                    CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV00,                      -- 80
                    CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV01_49,                -- 81
                    CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV50_99,                -- 82
                    CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV100,                    -- 83
                    CAST(IPS1.HOUSE_CLEAN_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_HALF,                      -- 84
                    CAST(IPS1.HOUSE_CLEAN_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_FULL,                      -- 85
                    
                    CAST(IPS1.OFFICE_DEP_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV00,                        -- 86
                    CAST(IPS1.OFFICE_DEP_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV01_49,                  -- 87
                    CAST(IPS1.OFFICE_DEP_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV50_99,                  -- 88
                    CAST(IPS1.OFFICE_DEP_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV100,                      -- 89
                    CAST(IPS1.OFFICE_DEP_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_FULL,                        -- 90
                    
                    CAST(IPS1.OFFICE_INV_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV00,                        -- 91
                    CAST(IPS1.OFFICE_INV_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV01_49,                  -- 92
                    CAST(IPS1.OFFICE_INV_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV50_99,                  -- 93
                    CAST(IPS1.OFFICE_INV_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV100,                      -- 94
                    CAST(IPS1.OFFICE_INV_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_FULL,                        -- 95
                    
                    CAST(IPS1.OFFICE_SUS_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV00,                        -- 96
                    CAST(IPS1.OFFICE_SUS_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV01_49,                  -- 97
                    CAST(IPS1.OFFICE_SUS_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV50_99,                  -- 98
                    CAST(IPS1.OFFICE_SUS_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV100,                      -- 99
                    CAST(IPS1.OFFICE_SUS_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_FULL,                        -- 100
                    
                    CAST(IPS1.OFFICE_STG_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV00,                        -- 101
                    CAST(IPS1.OFFICE_STG_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV01_49,                  -- 102
                    CAST(IPS1.OFFICE_STG_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV50_99,                  -- 103
                    CAST(IPS1.OFFICE_STG_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV100,                      -- 104
                    CAST(IPS1.OFFICE_STG_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_FULL,                        -- 105
                    
                    CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV00 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV00,          -- 106
                    CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV01_49,    -- 107
                    CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV50_99,    -- 108
                    CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV100 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV100,        -- 109
                    CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_FULL AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_FULL,          -- 110
                    
                    CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV00 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV00,          -- 111
                    CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV01_49,    -- 112
                    CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV50_99,    -- 113
                    CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV100 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV100,        -- 114
                    CAST(IPS1.FARMER_FISHER_INV_SUMMARY_FULL AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_FULL,          -- 115
                    
                    CAST(IPS1.OFFICE_ALT_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV00,                        -- 116
                    CAST(IPS1.OFFICE_ALT_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV01_49,                  -- 117
                    CAST(IPS1.OFFICE_ALT_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV50_99,                  -- 118
                    CAST(IPS1.OFFICE_ALT_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV100,                      -- 119
                    CAST(IPS1.OFFICE_ALT_SUMMARY_HALF AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_HALF,                        -- 120
                    CAST(IPS1.OFFICE_ALT_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_FULL                         -- 121
                FROM IPPAN_SUMMARY IPS1 
                LEFT JOIN IPPAN_HEADER IPH1 ON IPS1.IPPAN_HEADER_ID=IPH1.IPPAN_HEADER_ID 
                LEFT JOIN IPPAN IPP1 ON IPS1.IPPAN_ID=IPP1.IPPAN_ID 
                LEFT JOIN KEN KEN1 ON IPH1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON IPH1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN SUIKEI SUI1 ON IPH1.SUIKEI_CODE=SUI1.SUIKEI_CODE
                LEFT JOIN SUIKEI_TYPE STP1 ON IPH1.SUIKEI_TYPE_CODE=STP1.SUIKEI_TYPE_CODE
                LEFT JOIN KASEN KAS1 ON IPH1.KASEN_CODE=KAS1.KASEN_CODE
                LEFT JOIN KASEN_TYPE KTP1 ON IPH1.KASEN_TYPE_CODE=KTP1.KASEN_TYPE_CODE                                      -- 2024/11/18 EDIT
                WHERE 
                    IPS1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                    IPS1.DELETED_AT IS NULL                                                                                 -- 2024/11/18 ADD
                ORDER BY 
                    CAST(IPS1.IPPAN_ID AS INTEGER)"""

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### EXCELシートに値をセットする。
            ### ※複数シートを１シートに出力するため、変数のROW_START_NUMを使用して、シート毎の出力先の最初の行番号を管理する。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 6/7.', 'DEBUG')
            row_start_num = 8
            for i, ippan_header in enumerate(ippan_header_list, 0):            ### STARTS AT 0
                
                print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 6_1/7.', 'DEBUG')
                PARAMS_SELECT_IPPAN_SUMMARY = dict({
                    'IPPAN_HEADER_ID': ippan_header.ippan_header_id
                })
                        
                detail_ippan_summary_list = IPPAN_SUMMARY.objects.raw(SQL_SELECT_IPPAN_SUMMARY, PARAMS_SELECT_IPPAN_SUMMARY)
                
                ###############################################################
                ### EXCELの一覧部のセルに、出力データ_一覧部分の値を埋め込む。
                ###############################################################
                print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 6_2/7.', 'DEBUG')
                if bool(detail_ippan_summary_list) == True:                                         ### ADD 2024/10/15
                    for j, detail_ippan_summary in enumerate(detail_ippan_summary_list, 0):         ### ADD 2024/10/15 ### SECOND ARGUMENT MEANS STARTS AT 20
                        row_num = row_start_num + j
                        
                        print(1)
                        if (bool(str(detail_ippan_summary.ippan_id)) == True and bool(detail_ippan_summary.ippan_id)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["IPPAN_ID"]).value = str(detail_ippan_summary.ippan_id)
                        
                        print(2)
                        if (bool(str(detail_ippan_summary.upload_file_name)) == True and bool(detail_ippan_summary.upload_file_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["UPLOAD_FILE_NAME"]).value = str(detail_ippan_summary.upload_file_name)
                        
                        print(3)
                        if (bool(str(detail_ippan_summary.ken_name)) == True and bool(detail_ippan_summary.ken_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["KEN_NAME"]).value = str(detail_ippan_summary.ken_name)
                        
                        print(4)
                        if (bool(str(detail_ippan_summary.city_name)) == True and bool(detail_ippan_summary.city_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CITY_NAME"]).value = str(detail_ippan_summary.city_name)
                        
                        print(5)
                        if (bool(str(detail_ippan_summary.begin_month)) == True and bool(detail_ippan_summary.begin_month)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BEGIN_MONTH"]).value = str(detail_ippan_summary.begin_month)
                        
                        print(6)
                        if (bool(str(detail_ippan_summary.begin_day)) == True and bool(detail_ippan_summary.begin_day)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BEGIN_DAY"]).value = str(detail_ippan_summary.begin_day)
                        
                        print(7)
                        if (bool(str(detail_ippan_summary.end_month)) == True and bool(detail_ippan_summary.end_month)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["END_MONTH"]).value = str(detail_ippan_summary.end_month)
                        
                        print(8)
                        if (bool(str(detail_ippan_summary.end_day)) == True and bool(detail_ippan_summary.end_day)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["END_DAY"]).value = str(detail_ippan_summary.end_day)
                        
                        print(9)
                        if (bool(str(detail_ippan_summary.cause_1_code)) == True and bool(detail_ippan_summary.cause_1_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAUSE_1_CODE"]).value = str(detail_ippan_summary.cause_1_code)
                        
                        print(10)
                        ### print_log('[DEBUG] detail_ippan_summary.cause_2_code={}'.format(detail_ippan_summary.cause_2_code), 'DEBUG')
                        ### print_log('[DEBUG] str(detail_ippan_summary.cause_2_code)={}'.format(str(detail_ippan_summary.cause_2_code)), 'DEBUG')
                        ### print_log('[DEBUG] bool(str(detail_ippan_summary.cause_2_code))={}'.format(bool(str(detail_ippan_summary.cause_2_code))), 'DEBUG')
                        ### print_log('[DEBUG] bool(detail_ippan_summary.cause_2_code)={}'.format(bool(detail_ippan_summary.cause_2_code)), 'DEBUG')
                        if (bool(str(detail_ippan_summary.cause_2_code)) == True and bool(detail_ippan_summary.cause_2_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAUSE_2_CODE"]).value = str(detail_ippan_summary.cause_2_code)

                        print(11)
                        if (bool(str(detail_ippan_summary.cause_3_code)) == True and bool(detail_ippan_summary.cause_3_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAUSE_3_CODE"]).value = str(detail_ippan_summary.cause_3_code)

                        print(12)
                        if (bool(str(detail_ippan_summary.kuiki_id)) == True and bool(detail_ippan_summary.kuiki_id)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["KUIKI_ID"]).value = str(detail_ippan_summary.kuiki_id)

                        print(13)
                        if (bool(str(detail_ippan_summary.suikei_name) and bool(detail_ippan_summary.suikei_name)) == True):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["SUIKEI_NAME"]).value = str(detail_ippan_summary.suikei_name)

                        print(14)
                        if (bool(str(detail_ippan_summary.suikei_type_name)) == True and bool(detail_ippan_summary.suikei_type_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["SUIKEI_TYPE_NAME"]).value = str(detail_ippan_summary.suikei_type_name)

                        print(15)
                        if (bool(str(detail_ippan_summary.kasen_name)) == True and bool(detail_ippan_summary.kasen_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["KASEN_NAME"]).value = str(detail_ippan_summary.kasen_name)

                        print(16)
                        if (bool(str(detail_ippan_summary.kasen_type_name)) == True and bool(detail_ippan_summary.kasen_type_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["KASEN_TYPE_NAME"]).value = str(detail_ippan_summary.kasen_type_name)

                        print(17)
                        if (bool(str(detail_ippan_summary.gradient_code)) == True and bool(detail_ippan_summary.gradient_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["GRADIENT_CODE"]).value = str(detail_ippan_summary.gradient_code)

                        print(18)
                        if (bool(str(detail_ippan_summary.ippan_name)) == True and bool(detail_ippan_summary.ippan_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["IPPAN_NAME"]).value = str(detail_ippan_summary.ippan_name)

                        print(19)
                        if (bool(str(detail_ippan_summary.building_code)) == True and bool(detail_ippan_summary.building_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BUILDING_CODE"]).value = str(detail_ippan_summary.building_code)

                        print(20)
                        if (bool(str(detail_ippan_summary.underground_code)) == True and bool(detail_ippan_summary.underground_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["UNDERGROUND_CODE"]).value = str(detail_ippan_summary.underground_code)

                        print(21)
                        if (bool(str(detail_ippan_summary.flood_sediment_code)) == True and bool(detail_ippan_summary.flood_sediment_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FLOOD_SEDIMENT_CODE"]).value = str(detail_ippan_summary.flood_sediment_code)

                        print(22)
                        if (bool(str(detail_ippan_summary.building_lv00)) == True and bool(detail_ippan_summary.building_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BUILDING_LV00"]).value = detail_ippan_summary.building_lv00

                        print(23)
                        if (bool(str(detail_ippan_summary.building_lv01_49)) == True and bool(detail_ippan_summary.building_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BUILDING_LV01_49"]).value = detail_ippan_summary.building_lv01_49

                        print(24)
                        if (bool(str(detail_ippan_summary.building_lv50_99)) == True and bool(detail_ippan_summary.building_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BUILDING_LV50_99"]).value = detail_ippan_summary.building_lv50_99

                        print(25)
                        if (bool(str(detail_ippan_summary.building_lv100)) == True and bool(detail_ippan_summary.building_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BUILDING_LV100"]).value = detail_ippan_summary.building_lv100
                        
                        print(26)
                        if (bool(str(detail_ippan_summary.building_half)) == True and bool(detail_ippan_summary.building_half)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BUILDING_HALF"]).value = detail_ippan_summary.building_half
                        
                        print(27)
                        if (bool(str(detail_ippan_summary.building_full)) == True and bool(detail_ippan_summary.building_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["BUILDING_FULL"]).value = detail_ippan_summary.building_full
                        
                        print(28)
                        if (bool(str(detail_ippan_summary.floor_area)) == True and bool(detail_ippan_summary.floor_area)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FLOOR_AREA"]).value = detail_ippan_summary.floor_area
                        
                        print(29)
                        if (bool(str(detail_ippan_summary.family)) == True and bool(detail_ippan_summary.family)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FAMILY"]).value = detail_ippan_summary.family
                        
                        print(30)
                        if (bool(str(detail_ippan_summary.office)) == True and bool(detail_ippan_summary.office)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE"]).value = detail_ippan_summary.office
                        
                        print(31)
                        if (bool(str(detail_ippan_summary.farmer_fisher_lv00)) == True and bool(detail_ippan_summary.farmer_fisher_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_LV00"]).value = detail_ippan_summary.farmer_fisher_lv00
                        
                        print(32)
                        if (bool(str(detail_ippan_summary.farmer_fisher_lv01_49)) == True and bool(detail_ippan_summary.farmer_fisher_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_LV01_49"]).value = detail_ippan_summary.farmer_fisher_lv01_49
                        
                        print(33)
                        if (bool(str(detail_ippan_summary.farmer_fisher_lv50_99)) == True and bool(detail_ippan_summary.farmer_fisher_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_LV50_99"]).value = detail_ippan_summary.farmer_fisher_lv50_99
                        
                        print(34)
                        if (bool(str(detail_ippan_summary.farmer_fisher_lv100)) == True and bool(detail_ippan_summary.farmer_fisher_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_LV100"]).value = detail_ippan_summary.farmer_fisher_lv100
                        
                        print(35)
                        if (bool(str(detail_ippan_summary.farmer_fisher_full)) == True and bool(detail_ippan_summary.farmer_fisher_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_FULL"]).value = detail_ippan_summary.farmer_fisher_full
                        
                        print(36)
                        if (bool(str(detail_ippan_summary.employee_lv00)) == True and bool(detail_ippan_summary.employee_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["EMPLOYEE_LV00"]).value = detail_ippan_summary.employee_lv00
                        
                        print(37)
                        if (bool(str(detail_ippan_summary.employee_lv01_49)) == True and bool(detail_ippan_summary.employee_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["EMPLOYEE_LV01_49"]).value = detail_ippan_summary.employee_lv01_49
                        
                        print(38)
                        if (bool(str(detail_ippan_summary.employee_lv50_99)) == True and bool(detail_ippan_summary.employee_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["EMPLOYEE_LV50_99"]).value = detail_ippan_summary.employee_lv50_99
                        
                        print(39)
                        if (bool(str(detail_ippan_summary.employee_lv100)) == True and bool(detail_ippan_summary.employee_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["EMPLOYEE_LV100"]).value = detail_ippan_summary.employee_lv100
                        
                        print(40)
                        if (bool(str(detail_ippan_summary.employee_full)) == True and bool(detail_ippan_summary.employee_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["EMPLOYEE_FULL"]).value = detail_ippan_summary.employee_full
                        
                        print(41)
                        if (bool(str(detail_ippan_summary.industry_code)) == True and bool(detail_ippan_summary.industry_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["INDUSTRY_CODE"]).value = str(detail_ippan_summary.industry_code)
                        
                        print(42)
                        if (bool(str(detail_ippan_summary.usage_code)) == True and bool(detail_ippan_summary.usage_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["USAGE_CODE"]).value = str(detail_ippan_summary.usage_code)
                        
                        print(43)
                        if (bool(str(detail_ippan_summary.comment)) == True and bool(detail_ippan_summary.comment)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["COMMENT1"]).value = str(detail_ippan_summary.comment)
                            
                        ### if (bool(str()) == True):
                        ###     ws_ippan_summary.cell(row=row_num, column=COLUMN["COMMENT2"]).value = ""
                        
                        print(44)
                        if (bool(str(detail_ippan_summary.residential_area)) == True and bool(detail_ippan_summary.residential_area)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["RESIDENTIAL_AREA"]).value = detail_ippan_summary.residential_area
                        
                        print(45)
                        if (bool(str(detail_ippan_summary.agricultural_area)) == True and bool(detail_ippan_summary.agricultural_area)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["AGRICULTURAL_AREA"]).value = detail_ippan_summary.agricultural_area
                        
                        print(46)
                        if (bool(str(detail_ippan_summary.underground_area)) == True and bool(detail_ippan_summary.underground_area)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["UNDERGROUND_AREA"]).value = detail_ippan_summary.underground_area
                        
                        print(47)
                        if (bool(str(detail_ippan_summary.kasen_kaigan_code)) == True and bool(detail_ippan_summary.kasen_kaigan_code)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["KASEN_KAIGAN_CODE"]).value = str(detail_ippan_summary.kasen_kaigan_code)
                        
                        print(48)
                        if (bool(str(detail_ippan_summary.crop_damage)) == True and bool(detail_ippan_summary.crop_damage)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CROP_DAMAGE"]).value = detail_ippan_summary.crop_damage
                        
                        print(49)
                        if (bool(str(detail_ippan_summary.weather_id)) == True and bool(detail_ippan_summary.weather_id)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["WEATHER_ID"]).value = str(detail_ippan_summary.weather_id)

                        print(50)
                        if (bool(str(detail_ippan_summary.ippan_header_name)) == True and bool(detail_ippan_summary.ippan_header_name)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["IPPAN_HEADER_NAME"]).value = str(detail_ippan_summary.ippan_header_name)

                        print(51)
                        if (bool(str(detail_ippan_summary.committed_at)) == True and bool(detail_ippan_summary.committed_at)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["COMMITTED_AT"]).value = str(detail_ippan_summary.committed_at)

                        print(52)
                        if (bool(str(detail_ippan_summary.upload_file_path)) == True and bool(detail_ippan_summary.upload_file_path)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["UPLOAD_FILE_PATH"]).value = str(detail_ippan_summary.upload_file_path)

                        print(53)
                        if (bool(str(detail_ippan_summary.house_summary_lv00)) == True and bool(detail_ippan_summary.house_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_SUMMARY_LV00"]).value = detail_ippan_summary.house_summary_lv00

                        print(54)
                        if (bool(str(detail_ippan_summary.house_summary_lv01_49)) == True and bool(detail_ippan_summary.house_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_SUMMARY_LV01_49"]).value = detail_ippan_summary.house_summary_lv01_49

                        print(55)
                        if (bool(str(detail_ippan_summary.house_summary_lv50_99)) == True and bool(detail_ippan_summary.house_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_SUMMARY_LV50_99"]).value = detail_ippan_summary.house_summary_lv50_99

                        print(56)
                        if (bool(str(detail_ippan_summary.house_summary_lv100)) == True and bool(detail_ippan_summary.house_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_SUMMARY_LV100"]).value = detail_ippan_summary.house_summary_lv100

                        print(57)
                        if (bool(str(detail_ippan_summary.house_summary_half)) == True and bool(detail_ippan_summary.house_summary_half)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_SUMMARY_HALF"]).value = detail_ippan_summary.house_summary_half

                        print(58)
                        if (bool(str(detail_ippan_summary.house_summary_full)) == True and bool(detail_ippan_summary.house_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_SUMMARY_FULL"]).value = detail_ippan_summary.house_summary_full

                        print(59)
                        if (bool(str(detail_ippan_summary.household_summary_lv00)) == True and bool(detail_ippan_summary.household_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSEHOLD_SUMMARY_LV00"]).value = detail_ippan_summary.household_summary_lv00

                        print(60)
                        if (bool(str(detail_ippan_summary.household_summary_lv01_49)) == True and bool(detail_ippan_summary.household_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSEHOLD_SUMMARY_LV01_49"]).value = detail_ippan_summary.household_summary_lv01_49

                        print(61)
                        if (bool(str(detail_ippan_summary.household_summary_lv50_99)) == True and bool(detail_ippan_summary.household_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSEHOLD_SUMMARY_LV50_99"]).value = detail_ippan_summary.household_summary_lv50_99

                        print(62)
                        if (bool(str(detail_ippan_summary.household_summary_lv100)) == True and bool(detail_ippan_summary.household_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSEHOLD_SUMMARY_LV100"]).value = detail_ippan_summary.household_summary_lv100

                        print(63)
                        if (bool(str(detail_ippan_summary.household_summary_half)) == True and bool(detail_ippan_summary.household_summary_half)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSEHOLD_SUMMARY_HALF"]).value = detail_ippan_summary.household_summary_half

                        print(64)
                        if (bool(str(detail_ippan_summary.household_summary_full)) == True and bool(detail_ippan_summary.household_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSEHOLD_SUMMARY_FULL"]).value = detail_ippan_summary.household_summary_full

                        print(65)
                        if (bool(str(detail_ippan_summary.car_summary_lv00)) == True and bool(detail_ippan_summary.car_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAR_SUMMARY_LV00"]).value = detail_ippan_summary.car_summary_lv00

                        print(66)
                        if (bool(str(detail_ippan_summary.car_summary_lv01_49)) == True and bool(detail_ippan_summary.car_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAR_SUMMARY_LV01_49"]).value = detail_ippan_summary.car_summary_lv01_49

                        print(67)
                        if (bool(str(detail_ippan_summary.car_summary_lv50_99)) == True and bool(detail_ippan_summary.car_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAR_SUMMARY_LV50_99"]).value = detail_ippan_summary.car_summary_lv50_99

                        print(68)
                        if (bool(str(detail_ippan_summary.car_summary_lv100)) == True and bool(detail_ippan_summary.car_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAR_SUMMARY_LV100"]).value = detail_ippan_summary.car_summary_lv100

                        print(69)
                        if (bool(str(detail_ippan_summary.car_summary_half)) == True and bool(detail_ippan_summary.car_summary_half)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAR_SUMMARY_HALF"]).value = detail_ippan_summary.car_summary_half

                        print(70)
                        if (bool(str(detail_ippan_summary.car_summary_full)) == True and bool(detail_ippan_summary.car_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["CAR_SUMMARY_FULL"]).value = detail_ippan_summary.car_summary_full

                        print(71)
                        if (bool(str(detail_ippan_summary.house_alt_summary_lv00)) == True and bool(detail_ippan_summary.house_alt_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_ALT_SUMMARY_LV00"]).value = detail_ippan_summary.house_alt_summary_lv00

                        print(72)
                        if (bool(str(detail_ippan_summary.house_alt_summary_lv01_49)) == True and bool(detail_ippan_summary.house_alt_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_ALT_SUMMARY_LV01_49"]).value = detail_ippan_summary.house_alt_summary_lv01_49

                        print(73)
                        if (bool(str(detail_ippan_summary.house_alt_summary_lv50_99)) == True and bool(detail_ippan_summary.house_alt_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_ALT_SUMMARY_LV50_99"]).value = detail_ippan_summary.house_alt_summary_lv50_99

                        print(74)
                        if (bool(str(detail_ippan_summary.house_alt_summary_lv100)) == True and bool(detail_ippan_summary.house_alt_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_ALT_SUMMARY_LV100"]).value = detail_ippan_summary.house_alt_summary_lv100

                        print(75)
                        if (bool(str(detail_ippan_summary.house_alt_summary_half)) == True and bool(detail_ippan_summary.house_alt_summary_half)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_ALT_SUMMARY_HALF"]).value = detail_ippan_summary.house_alt_summary_half

                        print(76)
                        if (bool(str(detail_ippan_summary.house_alt_summary_full)) == True and bool(detail_ippan_summary.house_alt_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_ALT_SUMMARY_FULL"]).value = detail_ippan_summary.house_alt_summary_full

                        print(77)
                        if (bool(str(detail_ippan_summary.house_clean_summary_lv00)) == True and bool(detail_ippan_summary.house_clean_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_CLEAN_SUMMARY_LV00"]).value = detail_ippan_summary.house_clean_summary_lv00

                        print(78)
                        if (bool(str(detail_ippan_summary.house_clean_summary_lv01_49)) == True and bool(detail_ippan_summary.house_clean_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_CLEAN_SUMMARY_LV01_49"]).value = detail_ippan_summary.house_clean_summary_lv01_49

                        print(79)
                        if (bool(str(detail_ippan_summary.house_clean_summary_lv50_99)) == True and bool(detail_ippan_summary.house_clean_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_CLEAN_SUMMARY_LV50_99"]).value = detail_ippan_summary.house_clean_summary_lv50_99

                        print(80)
                        if (bool(str(detail_ippan_summary.house_clean_summary_lv100)) == True and bool(detail_ippan_summary.house_clean_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_CLEAN_SUMMARY_LV100"]).value = detail_ippan_summary.house_clean_summary_lv100

                        print(81)
                        if (bool(str(detail_ippan_summary.house_clean_summary_half)) == True and bool(detail_ippan_summary.house_clean_summary_half)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_CLEAN_SUMMARY_HALF"]).value = detail_ippan_summary.house_clean_summary_half

                        print(82)
                        if (bool(str(detail_ippan_summary.house_clean_summary_full)) == True and bool(detail_ippan_summary.house_clean_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["HOUSE_CLEAN_SUMMARY_FULL"]).value = detail_ippan_summary.house_clean_summary_full

                        print(83)
                        if (bool(str(detail_ippan_summary.office_dep_summary_lv00)) == True and bool(detail_ippan_summary.office_dep_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_DEP_SUMMARY_LV00"]).value = detail_ippan_summary.office_dep_summary_lv00

                        print(84)
                        if (bool(str(detail_ippan_summary.office_dep_summary_lv01_49)) == True and bool(detail_ippan_summary.office_dep_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_DEP_SUMMARY_LV01_49"]).value = detail_ippan_summary.office_dep_summary_lv01_49

                        print(85)
                        if (bool(str(detail_ippan_summary.office_dep_summary_lv50_99)) == True and bool(detail_ippan_summary.office_dep_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_DEP_SUMMARY_LV50_99"]).value = detail_ippan_summary.office_dep_summary_lv50_99

                        print(86)
                        if (bool(str(detail_ippan_summary.office_dep_summary_lv100)) == True and bool(detail_ippan_summary.office_dep_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_DEP_SUMMARY_LV100"]).value = detail_ippan_summary.office_dep_summary_lv100

                        print(87)
                        if (bool(str(detail_ippan_summary.office_dep_summary_full)) == True and bool(detail_ippan_summary.office_dep_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_DEP_SUMMARY_FULL"]).value = detail_ippan_summary.office_dep_summary_full

                        print(88)
                        if (bool(str(detail_ippan_summary.office_inv_summary_lv00)) == True and bool(detail_ippan_summary.office_inv_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_INV_SUMMARY_LV00"]).value = detail_ippan_summary.office_inv_summary_lv00

                        print(89)
                        if (bool(str(detail_ippan_summary.office_inv_summary_lv01_49)) == True and bool(detail_ippan_summary.office_inv_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_INV_SUMMARY_LV01_49"]).value = detail_ippan_summary.office_inv_summary_lv01_49

                        print(90)
                        if (bool(str(detail_ippan_summary.office_inv_summary_lv50_99)) == True and bool(detail_ippan_summary.office_inv_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_INV_SUMMARY_LV50_99"]).value = detail_ippan_summary.office_inv_summary_lv50_99

                        print(91)
                        if (bool(str(detail_ippan_summary.office_inv_summary_lv100)) == True and bool(detail_ippan_summary.office_inv_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_INV_SUMMARY_LV100"]).value = detail_ippan_summary.office_inv_summary_lv100

                        print(92)
                        if (bool(str(detail_ippan_summary.office_inv_summary_full)) == True and bool(detail_ippan_summary.office_inv_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_INV_SUMMARY_FULL"]).value = detail_ippan_summary.office_inv_summary_full

                        print(93)
                        if (bool(str(detail_ippan_summary.office_sus_summary_lv00)) == True and bool(detail_ippan_summary.office_sus_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_SUS_SUMMARY_LV00"]).value = detail_ippan_summary.office_sus_summary_lv00

                        print(94)
                        if (bool(str(detail_ippan_summary.office_sus_summary_lv01_49)) == True and bool(detail_ippan_summary.office_sus_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_SUS_SUMMARY_LV01_49"]).value = detail_ippan_summary.office_sus_summary_lv01_49

                        print(95)
                        if (bool(str(detail_ippan_summary.office_sus_summary_lv50_99)) == True and bool(detail_ippan_summary.office_sus_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_SUS_SUMMARY_LV50_99"]).value = detail_ippan_summary.office_sus_summary_lv50_99

                        print(96)
                        if (bool(str(detail_ippan_summary.office_sus_summary_lv100)) == True and bool(detail_ippan_summary.office_sus_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_SUS_SUMMARY_LV100"]).value = detail_ippan_summary.office_sus_summary_lv100

                        print(97)
                        if (bool(str(detail_ippan_summary.office_sus_summary_full)) == True and bool(detail_ippan_summary.office_sus_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_SUS_SUMMARY_FULL"]).value = detail_ippan_summary.office_sus_summary_full

                        print(98)
                        if (bool(str(detail_ippan_summary.office_stg_summary_lv00)) == True and bool(detail_ippan_summary.office_stg_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_STG_SUMMARY_LV00"]).value = detail_ippan_summary.office_stg_summary_lv00

                        print(99)
                        if (bool(str(detail_ippan_summary.office_stg_summary_lv01_49)) == True and bool(detail_ippan_summary.office_stg_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_STG_SUMMARY_LV01_49"]).value = detail_ippan_summary.office_stg_summary_lv01_49

                        print(100)
                        if (bool(str(detail_ippan_summary.office_stg_summary_lv50_99)) == True and bool(detail_ippan_summary.office_stg_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_STG_SUMMARY_LV50_99"]).value = detail_ippan_summary.office_stg_summary_lv50_99

                        print(101)
                        if (bool(str(detail_ippan_summary.office_stg_summary_lv100)) == True and bool(detail_ippan_summary.office_stg_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_STG_SUMMARY_LV100"]).value = detail_ippan_summary.office_stg_summary_lv100

                        print(102)
                        if (bool(str(detail_ippan_summary.office_stg_summary_full)) == True and bool(detail_ippan_summary.office_stg_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_STG_SUMMARY_FULL"]).value = detail_ippan_summary.office_stg_summary_full

                        print(103)
                        if (bool(str(detail_ippan_summary.farmer_fisher_dep_summary_lv00)) == True and bool(detail_ippan_summary.farmer_fisher_dep_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_DEP_SUMMARY_LV00"]).value = detail_ippan_summary.farmer_fisher_dep_summary_lv00

                        print(104)
                        if (bool(str(detail_ippan_summary.farmer_fisher_dep_summary_lv01_49)) == True and bool(detail_ippan_summary.farmer_fisher_dep_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_DEP_SUMMARY_LV01_49"]).value = detail_ippan_summary.farmer_fisher_dep_summary_lv01_49

                        print(105)
                        if (bool(str(detail_ippan_summary.farmer_fisher_dep_summary_lv50_99)) == True and bool(detail_ippan_summary.farmer_fisher_dep_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_DEP_SUMMARY_LV50_99"]).value = detail_ippan_summary.farmer_fisher_dep_summary_lv50_99

                        print(106)
                        if (bool(str(detail_ippan_summary.farmer_fisher_dep_summary_lv100)) == True and bool(detail_ippan_summary.farmer_fisher_dep_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_DEP_SUMMARY_LV100"]).value = detail_ippan_summary.farmer_fisher_dep_summary_lv100

                        print(107)
                        if (bool(str(detail_ippan_summary.farmer_fisher_dep_summary_full)) == True and bool(detail_ippan_summary.farmer_fisher_dep_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_DEP_SUMMARY_FULL"]).value = detail_ippan_summary.farmer_fisher_dep_summary_full

                        print(108)
                        if (bool(str(detail_ippan_summary.farmer_fisher_inv_summary_lv00)) == True and bool(detail_ippan_summary.farmer_fisher_inv_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_INV_SUMMARY_LV00"]).value = detail_ippan_summary.farmer_fisher_inv_summary_lv00

                        print(109)
                        if (bool(str(detail_ippan_summary.farmer_fisher_inv_summary_lv01_49)) == True and bool(detail_ippan_summary.farmer_fisher_inv_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_INV_SUMMARY_LV01_49"]).value = detail_ippan_summary.farmer_fisher_inv_summary_lv01_49

                        print(110)
                        if (bool(str(detail_ippan_summary.farmer_fisher_inv_summary_lv50_99)) == True and bool(detail_ippan_summary.farmer_fisher_inv_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_INV_SUMMARY_LV50_99"]).value = detail_ippan_summary.farmer_fisher_inv_summary_lv50_99

                        print(111)
                        if (bool(str(detail_ippan_summary.farmer_fisher_inv_summary_lv100)) == True and bool(detail_ippan_summary.farmer_fisher_inv_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_INV_SUMMARY_LV100"]).value = detail_ippan_summary.farmer_fisher_inv_summary_lv100

                        print(112)
                        if (bool(str(detail_ippan_summary.farmer_fisher_inv_summary_full)) == True and bool(detail_ippan_summary.farmer_fisher_inv_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["FARMER_FISHER_INV_SUMMARY_FULL"]).value = detail_ippan_summary.farmer_fisher_inv_summary_full

                        print(113)
                        if (bool(str(detail_ippan_summary.office_alt_summary_lv00)) == True and bool(detail_ippan_summary.office_alt_summary_lv00)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_ALT_SUMMARY_LV00"]).value = detail_ippan_summary.office_alt_summary_lv00

                        print(114)
                        if (bool(str(detail_ippan_summary.office_alt_summary_lv01_49)) == True and bool(detail_ippan_summary.office_alt_summary_lv01_49)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_ALT_SUMMARY_LV01_49"]).value = detail_ippan_summary.office_alt_summary_lv01_49

                        print(115)
                        if (bool(str(detail_ippan_summary.office_alt_summary_lv50_99)) == True and bool(detail_ippan_summary.office_alt_summary_lv50_99)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_ALT_SUMMARY_LV50_99"]).value = detail_ippan_summary.office_alt_summary_lv50_99

                        print(116)
                        if (bool(str(detail_ippan_summary.office_alt_summary_lv100)) == True and bool(detail_ippan_summary.office_alt_summary_lv100)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_ALT_SUMMARY_LV100"]).value = detail_ippan_summary.office_alt_summary_lv100

                        print(117)
                        if (bool(str(detail_ippan_summary.office_alt_summary_half)) == True and bool(detail_ippan_summary.office_alt_summary_half)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_ALT_SUMMARY_HALF"]).value = detail_ippan_summary.office_alt_summary_half

                        print(118)
                        if (bool(str(detail_ippan_summary.office_alt_summary_full)) == True and bool(detail_ippan_summary.office_alt_summary_full)):
                            ws_ippan_summary.cell(row=row_num, column=COLUMN["OFFICE_ALT_SUMMARY_FULL"]).value = detail_ippan_summary.office_alt_summary_full
                        
                print(119)
                if bool(detail_ippan_summary_list) == True:                                         ### ADD 2024/10/15
                    row_start_num = row_start_num + len(detail_ippan_summary_list)
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 7/7.', 'DEBUG')
            print_log('[INFO] P0000Common.create_ippan_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
            
    try:
        #######################################################################
        ### 引数チェック処理(0010)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_ippan_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')
        ### SQL_SELECT_IPPAN_HEADER_01 = """
        ###     SELECT 
        ###         * 
        ###     FROM IPPAN_HEADER 
        ###     WHERE 
        ###         IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s LIMIT 1"""
        ### SQL_SELECT_IPPAN_HEADER_02 = """
        ###     SELECT 
        ###         * 
        ###     FROM IPPAN_HEADER 
        ###     WHERE 
        ###         UPLOAD_FILE_PATH=%(UPLOAD_FILE_PATH)s
        ###     ORDER BY CAST(IPPAN_HEADER_ID AS INTEGER)"""

        SQL_SELECT_IPPAN_HEADER_01 = """
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND
                DELETED_AT IS NULL LIMIT 1"""
        SQL_SELECT_IPPAN_HEADER_02 = """
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                UPLOAD_FILE_PATH=%(UPLOAD_FILE_PATH)s AND
                DELETED_AT IS NULL
            ORDER BY CAST(IPPAN_HEADER_ID AS INTEGER)"""

        PARAMS_SELECT_IPPAN_HEADER_01 = dict({
            'IPPAN_HEADER_ID': arguments["IPPAN_HEADER_ID"]
        })
    
        temporary_ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER_01, PARAMS_SELECT_IPPAN_HEADER_01)

        PARAMS_SELECT_IPPAN_HEADER_02 = dict({
            'UPLOAD_FILE_PATH': temporary_ippan_header_list[0].upload_file_path
        })

        ippan_header_list = IPPAN_HEADER.objects.raw(SQL_SELECT_IPPAN_HEADER_02, PARAMS_SELECT_IPPAN_HEADER_02)
        
        if (bool(temporary_ippan_header_list) == False) or (bool(ippan_header_list) == False):
            print_log('[WARN] P0000Common.get_ippan_summary_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        ### if bool(ippan_header_list) == True:                                ### 2024/11/14 COMMENT OUT
        ###     ippan_header_count = len(ippan_header_list)
        ### else:
        ###     ippan_header_count = 0

        #######################################################################
        ### DBアクセス処理(0030)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/ippan_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'ippan_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/ippan_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'ippan_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0060)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_ippan_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_ippan_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0080)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0090)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if arguments["FILE_TYPE"] == _IPP_SUM_EXC:
            return True, excel_file_path
        elif arguments["FILE_TYPE"] == _IPP_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_ippan_summary_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_summary_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設地方単独事業集計結果ファイル生成処理
### func_params["CHITAN_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_chitan_summary_csv_excel(request, func_params):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_chitan_summary_workbook():
        try:

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_chitan_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 1/6.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 2/6.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_chitan_summary = workbook["CHITAN_SUMMARY"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 3/6.', 'DEBUG')
            ws_chitan_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 4/6.', 'DEBUG')
            ws_chitan_summary.cell(row=6, column=1).value = ''
            ws_chitan_summary.cell(row=6, column=2).value = ''
            ws_chitan_summary.cell(row=6, column=3).value = ''
            ws_chitan_summary.cell(row=6, column=4).value = ''
            ws_chitan_summary.cell(row=6, column=5).value = ''
            ws_chitan_summary.cell(row=6, column=6).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 5/6.', 'DEBUG')
            for i, chitan_summary in enumerate(chitan_summary_list):
                ws_chitan_summary.cell(row=i+20, column=1).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=2).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=3).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=4).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=5).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=6).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=7).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=8).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=9).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=10).value = chitan_summary.ken_name

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 6/6.', 'DEBUG')
            print_log('[INFO] P0000Common.create_chitan_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
            
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_chitan_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/chitan_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'chitan_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/chitan_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'chitan_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_chitan_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_chitan_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _CHI_SUM_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _CHI_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_chitan_summary_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_summary_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設補助事業集計結果ファイル生成処理
### func_params["HOJO_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_hojo_summary_csv_excel(request, func_params):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_hojo_summary_workbook():
        try:

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_hojo_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 1/6.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 2/6.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_hojo_summary = workbook["HOJO_SUMMARY"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 3/6.', 'DEBUG')
            ws_hojo_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 4/6.', 'DEBUG')
            ws_hojo_summary.cell(row=6, column=1).value = ''
            ws_hojo_summary.cell(row=6, column=2).value = ''
            ws_hojo_summary.cell(row=6, column=3).value = ''
            ws_hojo_summary.cell(row=6, column=4).value = ''
            ws_hojo_summary.cell(row=6, column=5).value = ''
            ws_hojo_summary.cell(row=6, column=6).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 5/6.', 'DEBUG')
            for i, hojo_summary in enumerate(hojo_summary_list):
                ws_hojo_summary.cell(row=i+20, column=1).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=2).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=3).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=4).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=5).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=6).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=7).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=8).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=9).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=10).value = hojo_summary.ken_name

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 6/6.', 'DEBUG')
            print_log('[INFO] P0000Common.create_hojo_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
            
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_hojo_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 5/6.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/hojo_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'hojo_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/hojo_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'hojo_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_hojo_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_hojo_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _HOJ_SUM_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _HOJ_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_hojo_summary_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_summary_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公益事業集計結果ファイル生成処理
### func_params["KOEKI_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_koeki_summary_csv_excel(request, func_params):
    
    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_koeki_summary_workbook():
        try:

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_koeki_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 1/6.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 2/6.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_koeki_summary = workbook["KOEKI_SUMMARY"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 3/6.', 'DEBUG')
            ws_koeki_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 4/6.', 'DEBUG')
            ws_koeki_summary.cell(row=6, column=1).value = ''
            ws_koeki_summary.cell(row=6, column=2).value = ''
            ws_koeki_summary.cell(row=6, column=3).value = ''
            ws_koeki_summary.cell(row=6, column=4).value = ''
            ws_koeki_summary.cell(row=6, column=5).value = ''
            ws_koeki_summary.cell(row=6, column=6).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 5/6.', 'DEBUG')
            for i, koeki_summary in enumerate(koeki_summary_list):
                ws_koeki_summary.cell(row=i+20, column=1).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=2).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=3).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=4).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=5).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=6).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=7).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=8).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=9).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=10).value = koeki_summary.ken_name

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 6/6.', 'DEBUG')
            print_log('[INFO] P0000Common.create_koeki_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
            
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_koeki_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/koeki_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'koeki_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/koeki_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'koeki_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_koeki_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_koeki_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _KOE_SUM_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _KOE_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_koeki_summary_csv_excel()関数 sys.exc_info()[0]={}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_summary_csv_excel()関数 sys.exc_info()[1]={}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""
