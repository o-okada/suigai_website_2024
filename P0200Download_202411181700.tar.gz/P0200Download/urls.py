from django.urls import path
from . import views

app_name = 'P0200Download'
urlpatterns = [

    ### 初期選択無しのダウンロード画面を表示する。
    path('', views.index_view, name='index_view'), 

    ### 初期選択有りのダウンロード画面を表示する。
    ### 帳票形式のデータ
    path('ippan/chosa/', views.index_ippan_chosa_view, name='index_ippan_chosa_view'), 
    ###  path('area/', views.index_area_view, name='index_area_view'), 
    path('chitan/chosa/', views.index_chitan_chosa_view, name='index_chitan_chosa_view'), 
    path('hojo/chosa/', views.index_hojo_chosa_view, name='index_hojo_chosa_view'), 
    path('koeki/chosa/', views.index_koeki_chosa_view, name='index_koeki_chosa_view'), 

    ### 初期選択有りのダウンロード画面を表示する。
    ### 集計形式のデータ
    path('ippan/summary/', views.index_ippan_summary_view, name='index_ippan_summary_view'), 
    path('chitan/summary/', views.index_chitan_summary_view, name='index_chitan_summary_view'), 
    path('hojo/summary/', views.index_hojo_summary_view, name='index_hojo_summary_view'), 
    path('koeki/summary/', views.index_koeki_summary_view, name='index_koeki_summary_view'), 

    ### ダウンロード処理
    ### 帳票形式のデータ
    path('download/ippan/chosa/', views.download_ippan_chosa_view, name='download_ippan_chosa_view'), 
    ### ### ###  path('download/area/', views.download_area_view, name='download_area_view'), 
    path('download/chitan/chosa/', views.download_chitan_chosa_view, name='download_chitan_chosa_view'), 
    path('download/hojo/chosa/', views.download_hojo_chosa_view, name='download_hojo_chosa_view'), 
    path('download/koeki/chosa/', views.download_koeki_chosa_view, name='download_koeki_chosa_view'), 

    ### ダウンロード処理
    ### 集計形式のデータ
    path('download/ippan/summary/', views.download_ippan_summary_view, name='download_ippan_summary_view'), 
    path('download/chitan/summary/', views.download_chitan_summary_view, name='download_chitan_summary_view'), 
    path('download/hojo/summary/', views.download_hojo_summary_view, name='download_hojo_summary_view'), 
    path('download/koeki/summary/', views.download_koeki_summary_view, name='download_koeki_summary_view'), 

    ### 非同期ダウンロード状況画面を表示する。
    path('progress/<slug:hash_code>/<slug:count>/', views.progress_view, name='progress_view'), 
]
