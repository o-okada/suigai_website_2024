#!/bin/bash

echo "python3 manage.py bucket_KEN_ACT_01"
python3 manage.py bucket_KEN_ACT_01
echo "sleep 5s"
sleep 5s

