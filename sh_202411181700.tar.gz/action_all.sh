#!/bin/bash

### ./check_IPP_ACT_01.sh &
### sleep 5s

### ./summarize_IPP_ACT_02.sh &
### sleep 5s

### ./check_IPP_ACT_03.sh &
### sleep 5s

./download_IPP_ACT_90.sh &
sleep 5s
