#!/bin/bash

while true
do
    echo "python3 manage.py check_IPP_ACT_03"
    python3 manage.py check_IPP_ACT_03
    echo "sleep 5s"
    sleep 5s
done
