#!/bin/bash

while true
do
    echo "python3 manage.py check_IPP_ACT_01"
    python3 manage.py check_IPP_ACT_01
    echo "sleep 5s"
    sleep 5s
done
