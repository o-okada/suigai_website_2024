#!/bin/bash

while true
do
    echo "python3 manage.py download_KOE_ACT_90"
    python3 manage.py download_KOE_ACT_90
    echo "sleep 5s"
    sleep 5s
done
