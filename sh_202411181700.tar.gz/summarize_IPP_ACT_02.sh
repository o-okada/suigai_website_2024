#!/bin/bash

while true
do
    echo "python3 manage.py summarize_IPP_ACT_02"
    python3 manage.py summarize_IPP_ACT_02
    echo "sleep 5s"
    sleep 5s
done
