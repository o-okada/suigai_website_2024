#!/bin/bash

while true
do
    echo "python3 manage.py download_HOJ_ACT_90"
    python3 manage.py download_HOJ_ACT_90
    echo "sleep 5s"
    sleep 5s
done
